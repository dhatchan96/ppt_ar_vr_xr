"""
ThreatGuard Pro - Database Management
Simplified database operations for enhanced vulnerability management
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Simplified database manager for file-based storage"""
    
    def __init__(self):
        self.data_dir = Path("threatguard_data")
        self.data_dir.mkdir(exist_ok=True)
    
    def get_vulnerabilities(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get vulnerabilities with optional filtering"""
        try:
            vuln_file = self.data_dir / "threat_issues.json"
            if not vuln_file.exists():
                return []
            
            with open(vuln_file, 'r') as f:
                vulnerabilities = json.load(f)
            
            if filters:
                filtered_vulns = []
                for vuln in vulnerabilities:
                    match = True
                    for key, value in filters.items():
                        if vuln.get(key) != value:
                            match = False
                            break
                    if match:
                        filtered_vulns.append(vuln)
                return filtered_vulns
            
            return vulnerabilities
            
        except Exception as e:
            logger.error(f"Error getting vulnerabilities: {e}")
            return []
    
    def save_vulnerability(self, vulnerability: Dict[str, Any]) -> bool:
        """Save a vulnerability"""
        try:
            vuln_file = self.data_dir / "threat_issues.json"
            
            if vuln_file.exists():
                with open(vuln_file, 'r') as f:
                    vulnerabilities = json.load(f)
            else:
                vulnerabilities = []
            
            # Update existing or add new
            existing_idx = next((i for i, v in enumerate(vulnerabilities) if v.get('id') == vulnerability.get('id')), None)
            if existing_idx is not None:
                vulnerabilities[existing_idx] = vulnerability
            else:
                vulnerabilities.append(vulnerability)
            
            with open(vuln_file, 'w') as f:
                json.dump(vulnerabilities, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            logger.error(f"Error saving vulnerability: {e}")
            return False
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get database health status"""
        try:
            vuln_file = self.data_dir / "threat_issues.json"
            if vuln_file.exists():
                with open(vuln_file, 'r') as f:
                    vulnerabilities = json.load(f)
                return {
                    "status": "healthy",
                    "total_vulnerabilities": len(vulnerabilities),
                    "last_updated": datetime.now().isoformat()
                }
            else:
                return {
                    "status": "healthy",
                    "total_vulnerabilities": 0,
                    "last_updated": datetime.now().isoformat()
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }

# Global database manager instance
db_manager = DatabaseManager()

