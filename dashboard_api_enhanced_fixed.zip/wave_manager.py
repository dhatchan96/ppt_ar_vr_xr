"""
ThreatGuard Pro - Wave Management Module
Enhanced vulnerability remediation organization and prioritization
"""

import json
import uuid
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict

from config import settings
from database import db_manager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class WavePlan:
    """Wave plan for vulnerability remediation"""
    id: str
    name: str
    description: str
    target_start_date: str
    target_completion_date: str
    status: str  # PLANNING, IN_PROGRESS, COMPLETED, ON_HOLD
    priority: str  # CRITICAL, HIGH, MEDIUM, LOW
    business_impact: str  # CRITICAL, HIGH, MEDIUM, LOW
    team_owner: str
    budget_allocation: float
    fte_requirement: float
    created_at: str
    updated_at: str
    
    # Wave metadata
    wave_number: int
    total_vulnerabilities: int
    completed_vulnerabilities: int
    estimated_effort_hours: float
    actual_effort_hours: float

@dataclass
class WaveAssignment:
    """Vulnerability assignment to a wave"""
    id: str
    wave_id: str
    vulnerability_id: str
    assigned_date: str
    assigned_by: str
    estimated_effort_hours: float
    actual_effort_hours: float
    status: str  # ASSIGNED, IN_PROGRESS, COMPLETED, BLOCKED
    notes: str
    completion_date: str

class WaveManager:
    """Enhanced wave management for vulnerability remediation"""
    
    def __init__(self):
        self.waves_file = Path("threatguard_data/wave_plans.json")
        self.assignments_file = Path("threatguard_data/wave_assignments.json")
        self._ensure_files_exist()
        self._load_waves()
        self._load_assignments()
    
    def _ensure_files_exist(self):
        """Ensure wave management files exist"""
        if not self.waves_file.exists():
            self._create_default_waves()
        
        if not self.assignments_file.exists():
            self._create_default_assignments()
    
    def _create_default_waves(self):
        """Create default wave plans"""
        default_waves = [
            {
                "id": str(uuid.uuid4()),
                "name": "Wave 1 - Critical Security Issues",
                "description": "Address critical security vulnerabilities with immediate business impact",
                "target_start_date": (datetime.now() + timedelta(days=7)).isoformat(),
                "target_completion_date": (datetime.now() + timedelta(days=30)).isoformat(),
                "status": "PLANNING",
                "priority": "CRITICAL",
                "business_impact": "CRITICAL",
                "team_owner": "Security Team",
                "budget_allocation": 50000.0,
                "fte_requirement": 4.0,
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "wave_number": 1,
                "total_vulnerabilities": 0,
                "completed_vulnerabilities": 0,
                "estimated_effort_hours": 160.0,
                "actual_effort_hours": 0.0
            },
            {
                "id": str(uuid.uuid4()),
                "name": "Wave 2 - High Priority Infrastructure",
                "description": "Address high-priority infrastructure vulnerabilities",
                "target_start_date": (datetime.now() + timedelta(days=45)).isoformat(),
                "target_completion_date": (datetime.now() + timedelta(days=90)).isoformat(),
                "status": "PLANNING",
                "priority": "HIGH",
                "business_impact": "HIGH",
                "team_owner": "Infrastructure Team",
                "budget_allocation": 30000.0,
                "fte_requirement": 2.0,
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "wave_number": 2,
                "total_vulnerabilities": 0,
                "completed_vulnerabilities": 0,
                "estimated_effort_hours": 80.0,
                "actual_effort_hours": 0.0
            },
            {
                "id": str(uuid.uuid4()),
                "name": "Wave 3 - Technical Debt Reduction",
                "description": "Address technical debt and code quality issues",
                "target_start_date": (datetime.now() + timedelta(days=90)).isoformat(),
                "target_completion_date": (datetime.now() + timedelta(days=180)).isoformat(),
                "status": "PLANNING",
                "priority": "MEDIUM",
                "business_impact": "MEDIUM",
                "team_owner": "Development Team",
                "budget_allocation": 20000.0,
                "fte_requirement": 1.5,
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "wave_number": 3,
                "total_vulnerabilities": 0,
                "total_vulnerabilities": 0,
                "completed_vulnerabilities": 0,
                "estimated_effort_hours": 60.0,
                "actual_effort_hours": 0.0
            }
        ]
        
        with open(self.waves_file, 'w') as f:
            json.dump(default_waves, f, indent=2, default=str)
        
        logger.info("Created default wave plans")
    
    def _create_default_assignments(self):
        """Create default wave assignments"""
        default_assignments = []
        
        with open(self.assignments_file, 'w') as f:
            json.dump(default_assignments, f, indent=2, default=str)
        
        logger.info("Created default wave assignments")
    
    def _load_waves(self):
        """Load wave plans from file"""
        try:
            with open(self.waves_file, 'r') as f:
                waves_data = json.load(f)
                self.waves = [WavePlan(**wave) for wave in waves_data]
        except Exception as e:
            logger.error(f"Failed to load waves: {e}")
            self.waves = []
    
    def _load_assignments(self):
        """Load wave assignments from file"""
        try:
            with open(self.assignments_file, 'r') as f:
                assignments_data = json.load(f)
                self.assignments = [WaveAssignment(**assignment) for assignment in assignments_data]
        except Exception as e:
            logger.error(f"Failed to load assignments: {e}")
            self.assignments = []
    
    def _save_waves(self):
        """Save wave plans to file"""
        try:
            waves_data = [asdict(wave) for wave in self.waves]
            with open(self.waves_file, 'w') as f:
                json.dump(waves_data, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save waves: {e}")
    
    def _save_assignments(self):
        """Save wave assignments to file"""
        try:
            assignments_data = [asdict(assignment) for assignment in self.assignments]
            with open(self.assignments_file, 'w') as f:
                json.dump(assignments_data, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save assignments: {e}")
    
    def create_wave(self, wave_data: Dict[str, Any]) -> Optional[str]:
        """Create a new wave plan"""
        try:
            wave_id = str(uuid.uuid4())
            wave = WavePlan(
                id=wave_id,
                name=wave_data.get('name', ''),
                description=wave_data.get('description', ''),
                target_start_date=wave_data.get('target_start_date', ''),
                target_completion_date=wave_data.get('target_completion_date', ''),
                status=wave_data.get('status', 'PLANNING'),
                priority=wave_data.get('priority', 'MEDIUM'),
                business_impact=wave_data.get('business_impact', 'MEDIUM'),
                team_owner=wave_data.get('team_owner', ''),
                budget_allocation=wave_data.get('budget_allocation', 0.0),
                fte_requirement=wave_data.get('fte_requirement', 0.0),
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                wave_number=len(self.waves) + 1,
                total_vulnerabilities=0,
                completed_vulnerabilities=0,
                estimated_effort_hours=wave_data.get('estimated_effort_hours', 0.0),
                actual_effort_hours=0.0
            )
            
            self.waves.append(wave)
            self._save_waves()
            
            logger.info(f"Created wave: {wave.name}")
            return wave_id
            
        except Exception as e:
            logger.error(f"Failed to create wave: {e}")
            return None
    
    def update_wave(self, wave_id: str, updates: Dict[str, Any]) -> bool:
        """Update an existing wave plan"""
        try:
            wave = next((w for w in self.waves if w.id == wave_id), None)
            if not wave:
                logger.warning(f"Wave not found: {wave_id}")
                return False
            
            # Update fields
            for key, value in updates.items():
                if hasattr(wave, key):
                    setattr(wave, key, value)
            
            wave.updated_at = datetime.now().isoformat()
            self._save_waves()
            
            logger.info(f"Updated wave: {wave.name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update wave: {e}")
            return False
    
    def assign_vulnerability_to_wave(self, vulnerability_id: str, wave_id: str, 
                                   assigned_by: str, estimated_effort_hours: float = 0.0) -> bool:
        """Assign a vulnerability to a wave"""
        try:
            # Check if vulnerability is already assigned
            existing = next((a for a in self.assignments if a.vulnerability_id == vulnerability_id), None)
            if existing:
                logger.warning(f"Vulnerability {vulnerability_id} already assigned to wave {existing.wave_id}")
                return False
            
            # Create assignment
            assignment = WaveAssignment(
                id=str(uuid.uuid4()),
                wave_id=wave_id,
                vulnerability_id=vulnerability_id,
                assigned_date=datetime.now().isoformat(),
                assigned_by=assigned_by,
                estimated_effort_hours=estimated_effort_hours,
                actual_effort_hours=0.0,
                status='ASSIGNED',
                notes='',
                completion_date=''
            )
            
            self.assignments.append(assignment)
            self._save_assignments()
            
            # Update wave statistics
            self._update_wave_statistics(wave_id)
            
            logger.info(f"Assigned vulnerability {vulnerability_id} to wave {wave_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to assign vulnerability to wave: {e}")
            return False
    
    def _update_wave_statistics(self, wave_id: str):
        """Update wave statistics based on assignments"""
        try:
            wave = next((w for w in self.waves if w.id == wave_id), None)
            if not wave:
                return
            
            # Count assignments for this wave
            wave_assignments = [a for a in self.assignments if a.wave_id == wave_id]
            completed_assignments = [a for a in wave_assignments if a.status == 'COMPLETED']
            
            wave.total_vulnerabilities = len(wave_assignments)
            wave.completed_vulnerabilities = len(completed_assignments)
            wave.actual_effort_hours = sum(a.actual_effort_hours for a in completed_assignments)
            
            self._save_waves()
            
        except Exception as e:
            logger.error(f"Failed to update wave statistics: {e}")
    
    def get_wave_progress(self, wave_id: str) -> Dict[str, Any]:
        """Get progress information for a wave"""
        try:
            wave = next((w for w in self.waves if w.id == wave_id), None)
            if not wave:
                return {}
            
            wave_assignments = [a for a in self.assignments if a.wave_id == wave_id]
            
            progress = {
                'wave_id': wave_id,
                'wave_name': wave.name,
                'total_vulnerabilities': wave.total_vulnerabilities,
                'completed_vulnerabilities': wave.completed_vulnerabilities,
                'in_progress_vulnerabilities': len([a for a in wave_assignments if a.status == 'IN_PROGRESS']),
                'blocked_vulnerabilities': len([a for a in wave_assignments if a.status == 'BLOCKED']),
                'completion_percentage': (wave.completed_vulnerabilities / wave.total_vulnerabilities * 100) if wave.total_vulnerabilities > 0 else 0,
                'estimated_effort_hours': wave.estimated_effort_hours,
                'actual_effort_hours': wave.actual_effort_hours,
                'effort_completion_percentage': (wave.actual_effort_hours / wave.estimated_effort_hours * 100) if wave.estimated_effort_hours > 0 else 0,
                'status': wave.status,
                'target_completion_date': wave.target_completion_date,
                'days_remaining': self._calculate_days_remaining(wave.target_completion_date)
            }
            
            return progress
            
        except Exception as e:
            logger.error(f"Failed to get wave progress: {e}")
            return {}
    
    def _calculate_days_remaining(self, target_date: str) -> int:
        """Calculate days remaining until target completion date"""
        try:
            target = datetime.fromisoformat(target_date)
            remaining = target - datetime.now()
            return max(0, remaining.days)
        except Exception:
            return 0
    
    def get_all_waves_progress(self) -> List[Dict[str, Any]]:
        """Get progress for all waves"""
        return [self.get_wave_progress(wave.id) for wave in self.waves]
    
    def get_vulnerabilities_by_wave(self, wave_id: str) -> List[Dict[str, Any]]:
        """Get all vulnerabilities assigned to a specific wave"""
        try:
            wave_assignments = [a for a in self.assignments if a.wave_id == wave_id]
            
            # Get vulnerability details from database
            vulnerabilities = []
            for assignment in wave_assignments:
                vuln = db_manager.get_vulnerabilities({'id': assignment.vulnerability_id})
                if vuln:
                    vuln_data = vuln[0] if isinstance(vuln, list) else vuln
                    vuln_data['assignment_status'] = assignment.status
                    vuln_data['estimated_effort_hours'] = assignment.estimated_effort_hours
                    vuln_data['actual_effort_hours'] = assignment.actual_effort_hours
                    vuln_data['assigned_date'] = assignment.assigned_date
                    vuln_data['completion_date'] = assignment.completion_date
                    vuln_data['notes'] = assignment.notes
                    vulnerabilities.append(vuln_data)
            
            return vulnerabilities
            
        except Exception as e:
            logger.error(f"Failed to get vulnerabilities by wave: {e}")
            return []
    
    def update_assignment_status(self, assignment_id: str, status: str, 
                               actual_effort_hours: float = None, notes: str = None) -> bool:
        """Update the status of a wave assignment"""
        try:
            assignment = next((a for a in self.assignments if a.id == assignment_id), None)
            if not assignment:
                logger.warning(f"Assignment not found: {assignment_id}")
                return False
            
            assignment.status = status
            if actual_effort_hours is not None:
                assignment.actual_effort_hours = actual_effort_hours
            
            if notes is not None:
                assignment.notes = notes
            
            if status == 'COMPLETED':
                assignment.completion_date = datetime.now().isoformat()
            
            self._save_assignments()
            
            # Update wave statistics
            self._update_wave_statistics(assignment.wave_id)
            
            logger.info(f"Updated assignment {assignment_id} status to {status}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update assignment status: {e}")
            return False
    
    def get_wave_recommendations(self) -> Dict[str, Any]:
        """Get recommendations for wave planning based on vulnerability analysis"""
        try:
            # Get all vulnerabilities
            vulnerabilities = db_manager.get_vulnerabilities()
            
            # Analyze vulnerabilities for wave planning
            critical_vulns = [v for v in vulnerabilities if v.get('severity') == 'CRITICAL_BOMB']
            high_vulns = [v for v in vulnerabilities if v.get('severity') == 'HIGH_RISK']
            medium_vulns = [v for v in vulnerabilities if v.get('severity') == 'MEDIUM_RISK']
            
            # Calculate effort estimates
            total_effort = sum(v.get('effort', 0) for v in vulnerabilities) / 60  # Convert minutes to hours
            
            recommendations = {
                'wave_1_recommendations': {
                    'focus': 'Critical security vulnerabilities',
                    'estimated_effort': sum(v.get('effort', 0) for v in critical_vulns) / 60,
                    'vulnerability_count': len(critical_vulns),
                    'priority': 'Immediate',
                    'team_requirements': 'Security Team + Senior Developers'
                },
                'wave_2_recommendations': {
                    'focus': 'High-risk infrastructure issues',
                    'estimated_effort': sum(v.get('effort', 0) for v in high_vulns) / 60,
                    'vulnerability_count': len(high_vulns),
                    'priority': 'High',
                    'team_requirements': 'Infrastructure Team + DevOps'
                },
                'wave_3_recommendations': {
                    'focus': 'Technical debt and code quality',
                    'estimated_effort': sum(v.get('effort', 0) for v in medium_vulns) / 60,
                    'vulnerability_count': len(medium_vulns),
                    'priority': 'Medium',
                    'team_requirements': 'Development Team'
                },
                'overall_metrics': {
                    'total_vulnerabilities': len(vulnerabilities),
                    'total_estimated_effort_hours': total_effort,
                    'recommended_team_size': max(1, total_effort / 160),  # 160 hours per month per FTE
                    'estimated_completion_months': total_effort / 160
                }
            }
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Failed to get wave recommendations: {e}")
            return {}

# Global instance
wave_manager = WaveManager()
