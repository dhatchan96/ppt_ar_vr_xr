# Scan Performance Optimization & Stuck Scan Resolution

## Overview
This document outlines the improvements made to address stuck scans and performance issues in large repository scanning.

## Problem Analysis
Scans were getting stuck on long projects due to several factors:
- Insufficient timeouts for Git cloning and file analysis
- Low file processing limits (1000 files max)
- Small file size limits (1MB max)
- No performance monitoring or diagnostics
- Sequential processing bottlenecks

## Solutions Implemented

### 1. Enhanced Configuration (`config.py`)
**Increased limits and timeouts for large projects:**
```python
# Scan settings
MAX_SCAN_WORKERS = 4
SCAN_TIMEOUT_SECONDS = 600  # 10 minutes (increased from 300s)

# Performance settings for large projects
MAX_FILES_PER_SCAN = 5000  # Increased from 1000
MAX_FILE_SIZE_MB = 5  # Increased from 1MB
GIT_CLONE_TIMEOUT = 600  # 10 minutes (increased from 300s)
FILE_ANALYSIS_TIMEOUT = 600  # 10 minutes (increased from 300s)
PARALLEL_FILE_PROCESSING = True
MAX_WORKERS_FOR_PARALLEL = 8
```

### 2. Performance Monitoring (`performance_monitor.py`)
**Real-time system resource tracking:**
- CPU usage monitoring
- Memory usage tracking
- Disk I/O monitoring
- Scan phase timing
- File processing time tracking
- Performance recommendations

**Key Features:**
- Automatic resource sampling every 5 seconds
- Phase-based timing (startup, cloning, file processing, threat analysis)
- Performance bottleneck identification
- Automated recommendations based on metrics

### 3. Enhanced Async Scanner (`async_repo_scanner.py`)
**Integrated performance monitoring and improved timeouts:**
- Performance monitoring integration
- Configurable timeouts from settings
- Better error handling and cleanup
- Phase-based progress tracking

**Performance Tracking:**
```python
# Start monitoring at scan start
performance_monitor.start_monitoring(scan_id)
performance_monitor.record_phase("scan_startup")

# Track repository cloning
performance_monitor.record_phase("repository_cloning")
# ... clone repository ...
performance_monitor.end_phase("repository_cloning")

# Track file processing
performance_monitor.record_phase("file_processing")
# ... process files ...
performance_monitor.end_phase("file_processing")

# Track threat analysis
performance_monitor.record_phase("threat_analysis")
# ... analyze threats ...
performance_monitor.end_phase("threat_analysis")

# Generate performance report
performance_report = performance_monitor.get_performance_report()
```

### 4. Diagnostic Tool (`diagnose_stuck_scans.py`)
**Comprehensive scan diagnostics:**
- Active job monitoring
- System resource analysis
- Upload directory status
- Recent failure analysis
- Issue identification and recommendations

**Usage:**
```bash
python diagnose_stuck_scans.py
```

**API Endpoint:**
```
GET /api/diagnostic/scan-status
```

### 5. Enhanced API Integration (`dashboard_api_enhanced.py`)
**Updated to use new configurable settings:**
- Git clone timeout from settings
- File size limits from settings
- Performance monitoring integration

## Configuration Options

### Environment Variables
You can override default settings using environment variables:

```bash
# Timeouts
export SCAN_TIMEOUT_SECONDS=900  # 15 minutes
export GIT_CLONE_TIMEOUT=900     # 15 minutes
export FILE_ANALYSIS_TIMEOUT=900 # 15 minutes

# File limits
export MAX_FILES_PER_SCAN=10000  # 10,000 files
export MAX_FILE_SIZE_MB=10       # 10MB files

# Performance
export PARALLEL_FILE_PROCESSING=true
export MAX_WORKERS_FOR_PARALLEL=16
```

### Recommended Settings by Project Size

**Small Projects (< 1000 files):**
```python
MAX_FILES_PER_SCAN = 2000
MAX_FILE_SIZE_MB = 2
GIT_CLONE_TIMEOUT = 300
FILE_ANALYSIS_TIMEOUT = 300
MAX_WORKERS_FOR_PARALLEL = 4
```

**Medium Projects (1000-5000 files):**
```python
MAX_FILES_PER_SCAN = 8000
MAX_FILE_SIZE_MB = 5
GIT_CLONE_TIMEOUT = 600
FILE_ANALYSIS_TIMEOUT = 600
MAX_WORKERS_FOR_PARALLEL = 8
```

**Large Projects (> 5000 files):**
```python
MAX_FILES_PER_SCAN = 15000
MAX_FILE_SIZE_MB = 10
GIT_CLONE_TIMEOUT = 900
FILE_ANALYSIS_TIMEOUT = 900
MAX_WORKERS_FOR_PARALLEL = 12
```

## Monitoring and Diagnostics

### Performance Reports
Performance reports are automatically generated and logged for each scan:
- Total scan duration
- Average CPU and memory usage
- Peak resource usage
- Phase-by-phase timing
- File processing statistics
- Performance recommendations

### Diagnostic Reports
Run diagnostics to identify issues:
```bash
python diagnose_stuck_scans.py
```

**Report includes:**
- Active job status and duration
- System resource usage
- Upload directory analysis
- Recent failures
- Identified issues
- Recommendations

### API Diagnostics
Access diagnostics via API:
```bash
curl http://localhost:5000/api/diagnostic/scan-status
```

## Troubleshooting

### Common Issues and Solutions

**1. Scans timing out on large repositories:**
- Increase `GIT_CLONE_TIMEOUT` and `FILE_ANALYSIS_TIMEOUT`
- Check network connectivity and repository size
- Consider using shallow clones for very large repos

**2. High memory usage:**
- Reduce `MAX_WORKERS_FOR_PARALLEL`
- Decrease `MAX_FILES_PER_SCAN`
- Process files in smaller batches

**3. High CPU usage:**
- Reduce `MAX_WORKERS_FOR_PARALLEL`
- Optimize regex patterns in threat detection
- Run scans during off-peak hours

**4. Low disk space:**
- Clean up `uploaded_projects` directory
- Increase disk space
- Reduce `MAX_FILE_SIZE_MB`

### Performance Optimization Tips

1. **Monitor performance reports** to identify bottlenecks
2. **Adjust settings** based on project size and system resources
3. **Use diagnostic tools** to identify issues before they become problems
4. **Clean up regularly** to prevent disk space issues
5. **Consider parallel processing** for large projects with sufficient resources

## Future Improvements

### Planned Enhancements
1. **Incremental scanning** - Only scan changed files
2. **Shallow cloning** - Clone only recent history for large repos
3. **Distributed scanning** - Spread load across multiple workers
4. **Caching** - Cache scan results for unchanged files
5. **Adaptive timeouts** - Adjust timeouts based on repository size

### Performance Metrics
Track these metrics to optimize performance:
- Average scan duration by repository size
- Resource usage patterns
- Failure rates and causes
- File processing efficiency
- Threat detection accuracy

## Conclusion

These improvements significantly enhance the system's ability to handle large projects without getting stuck. The combination of increased timeouts, better resource management, performance monitoring, and diagnostic tools provides a robust solution for scanning repositories of any size.

For ongoing optimization, regularly review performance reports and adjust settings based on your specific use cases and system resources.


