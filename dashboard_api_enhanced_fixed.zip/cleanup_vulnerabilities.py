#!/usr/bin/env python3
"""
Vulnerability Records Cleanup Script
Cleans up vulnerability records in the vulnerability management system
"""

import json
import os
import shutil
from pathlib import Path
from datetime import datetime
import sqlite3

class VulnerabilityCleanup:
    def __init__(self):
        self.data_dir = Path("threatguard_data")
        self.backup_dir = Path("threatguard_data/backups")
        
    def create_backup(self, file_path: Path, backup_name: str = None):
        """Create a backup of a file before modification"""
        if not self.backup_dir.exists():
            self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        if backup_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{file_path.stem}.backup_{timestamp}{file_path.suffix}"
        
        backup_path = self.backup_dir / backup_name
        shutil.copy2(file_path, backup_path)
        print(f"✅ Created backup: {backup_path}")
        return backup_path
    
    def cleanup_threat_issues(self, keep_recent_days: int = 30):
        """Clean up threat_issues.json file"""
        file_path = self.data_dir / "threat_issues.json"
        
        if not file_path.exists():
            print("⚠️ threat_issues.json not found")
            return {"cleaned": 0, "backup_created": False}
        
        # Create backup
        backup_path = self.create_backup(file_path)
        
        try:
            # Load current data
            with open(file_path, 'r', encoding='utf-8') as f:
                issues_data = json.load(f)
            
            # Handle both array and object formats
            if isinstance(issues_data, dict):
                issues_list = issues_data.get('issues', [])
                original_count = len(issues_list)
            else:
                issues_list = issues_data
                original_count = len(issues_list)
            
            if keep_recent_days == 0:
                # Clear all data
                cleaned_issues = []
                print(f"🗑️ Clearing all {original_count} threat issues")
            else:
                # Filter by date
                cutoff_date = datetime.now().timestamp() - (keep_recent_days * 24 * 60 * 60)
                cleaned_issues = [
                    issue for issue in issues_list
                    if isinstance(issue, dict) and 
                    issue.get('creation_date', 0) > cutoff_date
                ]
                print(f"🗑️ Removed {original_count - len(cleaned_issues)} old threat issues (kept {len(cleaned_issues)} from last {keep_recent_days} days)")
            
            # Save cleaned data
            if isinstance(issues_data, dict):
                issues_data['issues'] = cleaned_issues
            else:
                issues_data = cleaned_issues
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(issues_data, f, indent=2, ensure_ascii=False)
            
            return {
                "cleaned": original_count - len(cleaned_issues),
                "remaining": len(cleaned_issues),
                "backup_created": True,
                "backup_path": str(backup_path)
            }
            
        except Exception as e:
            print(f"❌ Error cleaning threat_issues.json: {e}")
            return {"error": str(e)}
    
    def cleanup_scan_history(self, keep_recent_days: int = 30):
        """Clean up scan_history.json file"""
        file_path = self.data_dir / "scan_history.json"
        
        if not file_path.exists():
            print("⚠️ scan_history.json not found")
            return {"cleaned": 0, "backup_created": False}
        
        # Create backup
        backup_path = self.create_backup(file_path)
        
        try:
            # Load current data
            with open(file_path, 'r', encoding='utf-8') as f:
                scans_data = json.load(f)
            
            # Handle both array and object formats
            if isinstance(scans_data, dict):
                scans_list = scans_data.get('scans', [])
                original_count = len(scans_list)
            else:
                scans_list = scans_data
                original_count = len(scans_list)
            
            if keep_recent_days == 0:
                # Clear all data
                cleaned_scans = []
                print(f"🗑️ Clearing all {original_count} scan history records")
            else:
                # Filter by date
                cutoff_date = datetime.now().timestamp() - (keep_recent_days * 24 * 60 * 60)
                cleaned_scans = [
                    scan for scan in scans_list
                    if isinstance(scan, dict) and 
                    scan.get('timestamp', 0) > cutoff_date
                ]
                print(f"🗑️ Removed {original_count - len(cleaned_scans)} old scan history records (kept {len(cleaned_scans)} from last {keep_recent_days} days)")
            
            # Save cleaned data
            if isinstance(scans_data, dict):
                scans_data['scans'] = cleaned_scans
            else:
                scans_data = cleaned_scans
            
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(scans_data, f, indent=2, ensure_ascii=False)
            
            return {
                "cleaned": original_count - len(cleaned_scans),
                "remaining": len(cleaned_scans),
                "backup_created": True,
                "backup_path": str(backup_path)
            }
            
        except Exception as e:
            print(f"❌ Error cleaning scan_history.json: {e}")
            return {"error": str(e)}
    
    def cleanup_jobs_database(self, keep_recent_days: int = 30):
        """Clean up jobs.db database"""
        db_path = self.data_dir / "jobs.db"
        
        if not db_path.exists():
            print("⚠️ jobs.db not found")
            return {"cleaned": 0, "backup_created": False}
        
        # Create backup
        backup_path = self.create_backup(db_path)
        
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Get total count
            cursor.execute("SELECT COUNT(*) FROM jobs")
            original_count = cursor.fetchone()[0]
            
            if keep_recent_days == 0:
                # Clear all jobs
                cursor.execute("DELETE FROM jobs")
                print(f"🗑️ Clearing all {original_count} jobs")
            else:
                # Delete old jobs
                cutoff_timestamp = datetime.now().timestamp() - (keep_recent_days * 24 * 60 * 60)
                cursor.execute("DELETE FROM jobs WHERE created_at < ?", (cutoff_timestamp,))
                deleted_count = cursor.rowcount
                print(f"🗑️ Removed {deleted_count} old jobs (kept jobs from last {keep_recent_days} days)")
            
            conn.commit()
            conn.close()
            
            return {
                "cleaned": original_count - (original_count - cursor.rowcount if keep_recent_days == 0 else cursor.rowcount),
                "backup_created": True,
                "backup_path": str(backup_path)
            }
            
        except Exception as e:
            print(f"❌ Error cleaning jobs.db: {e}")
            return {"error": str(e)}
    
    def cleanup_uploaded_projects(self, keep_recent_days: int = 30):
        """Clean up uploaded_projects directory"""
        uploaded_dir = Path("uploaded_projects")
        
        if not uploaded_dir.exists():
            print("⚠️ uploaded_projects directory not found")
            return {"cleaned": 0, "backup_created": False}
        
        try:
            # Count total projects
            project_dirs = [d for d in uploaded_dir.iterdir() if d.is_dir()]
            original_count = len(project_dirs)
            
            if keep_recent_days == 0:
                # Clear all projects
                for project_dir in project_dirs:
                    shutil.rmtree(project_dir)
                print(f"🗑️ Cleared all {original_count} uploaded projects")
                cleaned_count = original_count
            else:
                # Remove old projects
                cutoff_time = datetime.now().timestamp() - (keep_recent_days * 24 * 60 * 60)
                cleaned_count = 0
                
                for project_dir in project_dirs:
                    # Check if directory is old enough to be removed
                    # Use directory creation time as fallback
                    try:
                        dir_time = project_dir.stat().st_ctime
                        if dir_time < cutoff_time:
                            shutil.rmtree(project_dir)
                            cleaned_count += 1
                    except Exception as e:
                        print(f"⚠️ Could not process {project_dir.name}: {e}")
                
                print(f"🗑️ Removed {cleaned_count} old uploaded projects (kept projects from last {keep_recent_days} days)")
            
            return {
                "cleaned": cleaned_count,
                "remaining": original_count - cleaned_count
            }
            
        except Exception as e:
            print(f"❌ Error cleaning uploaded_projects: {e}")
            return {"error": str(e)}
    
    def clear_in_memory_data(self):
        """Clear in-memory detector data by calling API endpoints"""
        try:
            import requests
            
            # Clear threats
            response = requests.delete('http://localhost:5000/api/threats')
            if response.status_code == 200:
                print("✅ Cleared in-memory threat data")
            else:
                print(f"⚠️ Failed to clear threats: {response.status_code}")
            
            # Clear scan history
            response = requests.delete('http://localhost:5000/api/scan-history')
            if response.status_code == 200:
                print("✅ Cleared in-memory scan history data")
            else:
                print(f"⚠️ Failed to clear scan history: {response.status_code}")
            
            return {"success": True}
            
        except Exception as e:
            print(f"❌ Error clearing in-memory data: {e}")
            return {"error": str(e)}
    
    def cleanup_old_backups(self, keep_backup_days: int = 7):
        """Clean up old backup files"""
        if not self.backup_dir.exists():
            print("⚠️ No backup directory found")
            return {"cleaned": 0}
        
        try:
            cutoff_time = datetime.now().timestamp() - (keep_backup_days * 24 * 60 * 60)
            cleaned_count = 0
            
            for backup_file in self.backup_dir.iterdir():
                if backup_file.is_file() and backup_file.stat().st_ctime < cutoff_time:
                    backup_file.unlink()
                    cleaned_count += 1
            
            print(f"🗑️ Removed {cleaned_count} old backup files")
            return {"cleaned": cleaned_count}
            
        except Exception as e:
            print(f"❌ Error cleaning old backups: {e}")
            return {"error": str(e)}
    
    def cleanup_all_vulnerability_data(self, keep_recent_days: int = 30):
        """Clean up all vulnerability-related data"""
        print("🧹 Starting comprehensive vulnerability cleanup...")
        
        results = {}
        
        # Clean up JSON files
        results['threat_issues'] = self.cleanup_threat_issues(keep_recent_days)
        results['scan_history'] = self.cleanup_scan_history(keep_recent_days)
        
        # Clean up database
        results['jobs'] = self.cleanup_jobs_database(keep_recent_days)
        
        # Clean up uploaded projects
        results['uploaded_projects'] = self.cleanup_uploaded_projects(keep_recent_days)
        
        # Clear in-memory data
        results['in_memory'] = self.clear_in_memory_data()
        
        # Clean up old backups
        results['old_backups'] = self.cleanup_old_backups()
        
        print("✅ Comprehensive vulnerability cleanup completed!")
        return results

def main():
    """Command-line interface for vulnerability cleanup"""
    cleanup = VulnerabilityCleanup()
    
    print("🧹 ThreatGuard Pro Vulnerability Cleanup Tool")
    print("=" * 50)
    
    while True:
        print("\nOptions:")
        print("1. Clean all vulnerability data (keep last 30 days)")
        print("2. Clean all vulnerability data (keep last 7 days)")
        print("3. Clear ALL vulnerability data (keep nothing)")
        print("4. Clean specific data type")
        print("5. Clean old backups only")
        print("6. Exit")
        
        choice = input("\nEnter your choice (1-6): ").strip()
        
        if choice == "1":
            results = cleanup.cleanup_all_vulnerability_data(30)
            print("\nResults:", results)
            
        elif choice == "2":
            results = cleanup.cleanup_all_vulnerability_data(7)
            print("\nResults:", results)
            
        elif choice == "3":
            confirm = input("⚠️ This will delete ALL vulnerability data. Are you sure? (yes/no): ")
            if confirm.lower() == "yes":
                results = cleanup.cleanup_all_vulnerability_data(0)
                print("\nResults:", results)
            else:
                print("Operation cancelled.")
                
        elif choice == "4":
            print("\nSpecific cleanup options:")
            print("1. Threat issues only")
            print("2. Scan history only")
            print("3. Jobs database only")
            print("4. Uploaded projects only")
            print("5. In-memory data only")
            
            sub_choice = input("Enter choice (1-5): ").strip()
            days = int(input("Keep data from last N days (0 = clear all): "))
            
            if sub_choice == "1":
                results = cleanup.cleanup_threat_issues(days)
            elif sub_choice == "2":
                results = cleanup.cleanup_scan_history(days)
            elif sub_choice == "3":
                results = cleanup.cleanup_jobs_database(days)
            elif sub_choice == "4":
                results = cleanup.cleanup_uploaded_projects(days)
            elif sub_choice == "5":
                results = cleanup.clear_in_memory_data()
            else:
                print("Invalid choice.")
                continue
                
            print("\nResults:", results)
            
        elif choice == "5":
            results = cleanup.cleanup_old_backups()
            print("\nResults:", results)
            
        elif choice == "6":
            print("Goodbye!")
            break
            
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
