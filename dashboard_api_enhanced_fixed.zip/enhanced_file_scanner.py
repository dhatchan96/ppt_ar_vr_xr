#!/usr/bin/env python3
"""
Enhanced File Scanner with Parallel Processing
Optimized for handling large projects without getting stuck
"""

import os
import time
import concurrent.futures
from pathlib import Path
from typing import List, Dict, Any
import logging
from config import settings

logger = logging.getLogger(__name__)

class EnhancedFileScanner:
    """Enhanced file scanner with parallel processing and better performance"""
    
    def __init__(self):
        self.processed_files = 0
        self.skipped_files = 0
        self.total_files = 0
        self.start_time = None
        
    def scan_files_parallel(self, file_paths: List[Dict], scan_config: Dict) -> Dict[str, Any]:
        """Scan files in parallel for better performance on large projects"""
        self.start_time = time.time()
        self.total_files = len(file_paths)
        
        logger.info(f"Starting parallel scan of {self.total_files} files")
        
        if not settings.PARALLEL_FILE_PROCESSING or self.total_files < 10:
            # Use sequential processing for small projects
            return self._scan_files_sequential(file_paths, scan_config)
        
        # Use parallel processing for large projects
        max_workers = min(settings.MAX_WORKERS_FOR_PARALLEL, self.total_files)
        logger.info(f"Using {max_workers} workers for parallel processing")
        
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all file scanning tasks
            future_to_file = {
                executor.submit(self._scan_single_file, file_info, scan_config): file_info 
                for file_info in file_paths
            }
            
            # Process completed tasks with timeout
            for future in concurrent.futures.as_completed(future_to_file, timeout=settings.FILE_ANALYSIS_TIMEOUT):
                try:
                    result = future.result(timeout=60)  # 1 minute per file timeout
                    if result:
                        results.append(result)
                        self.processed_files += 1
                    else:
                        self.skipped_files += 1
                        
                    # Log progress every 100 files
                    if self.processed_files % 100 == 0:
                        self._log_progress()
                        
                except concurrent.futures.TimeoutError:
                    file_info = future_to_file[future]
                    logger.warning(f"File scan timeout for {file_info.get('name', 'unknown')}")
                    self.skipped_files += 1
                except Exception as e:
                    file_info = future_to_file[future]
                    logger.error(f"Error scanning file {file_info.get('name', 'unknown')}: {e}")
                    self.skipped_files += 1
        
        return self._compile_results(results, scan_config)
    
    def _scan_files_sequential(self, file_paths: List[Dict], scan_config: Dict) -> Dict[str, Any]:
        """Scan files sequentially (fallback for small projects)"""
        logger.info("Using sequential file processing")
        results = []
        
        for file_info in file_paths:
            try:
                result = self._scan_single_file(file_info, scan_config)
                if result:
                    results.append(result)
                    self.processed_files += 1
                else:
                    self.skipped_files += 1
                    
                # Log progress every 50 files
                if self.processed_files % 50 == 0:
                    self._log_progress()
                    
            except Exception as e:
                logger.error(f"Error scanning file {file_info.get('name', 'unknown')}: {e}")
                self.skipped_files += 1
        
        return self._compile_results(results, scan_config)
    
    def _scan_single_file(self, file_info: Dict, scan_config: Dict) -> Dict[str, Any]:
        """Scan a single file with timeout protection"""
        try:
            file_path = file_info['path']
            file_name = file_info['name']
            file_type = file_info['type']
            file_id = file_info['id']
            
            # Check file size before processing
            file_size = os.path.getsize(file_path)
            if file_size > settings.MAX_FILE_SIZE_MB * 1024 * 1024:
                logger.debug(f"Skipping large file: {file_name} ({file_size / (1024*1024):.1f}MB)")
                return None
            
            # Read file content with timeout
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Skip files that are mostly binary
            if len(content) > 0:
                binary_ratio = sum(1 for c in content if ord(c) < 32 and c not in '\n\r\t') / len(content)
                if binary_ratio > 0.1:
                    return None
            
            lines = content.splitlines()
            file_lines = len(lines)
            
            # Perform security analysis (import here to avoid circular imports)
            from dashboard_api_enhanced import detector, advanced_detector, scan_file_content
            
            # Enhanced standard security rules scan
            applicable_rules = detector.rules_engine.get_enabled_rules(file_type)
            file_issues = scan_file_content(file_name, content, applicable_rules, file_id, 
                                          scan_config.get('scan_id'), scan_config.get('ait_tag'), 
                                          scan_config.get('spk_tag'), scan_config.get('repo_name'))
            
            # Advanced threat pattern detection with timeout
            threat_matches = []
            try:
                threat_matches = advanced_detector.analyze_file(file_path)
            except Exception as e:
                logger.warning(f"Advanced detection failed for {file_name}: {e}")
            
            # Create threat issues from matches
            threat_issues = []
            for pattern in threat_matches:
                try:
                    threat_issue = detector.issue_manager.create_issue(
                        rule_id=f"MALWARE_{pattern.pattern_type}",
                        file_path=file_name,
                        line_number=pattern.line_number,
                        column=1,
                        message=f"{pattern.description} - {pattern.trigger_analysis}",
                        severity=pattern.severity,
                        issue_type=pattern.pattern_type,
                        code_snippet=pattern.code_snippet,
                        suggested_fix=f"Remove {pattern.pattern_type.lower()} behavior - {pattern.payload_analysis}",
                        ait_tag=scan_config.get('ait_tag'),
                        spk_tag=scan_config.get('spk_tag'),
                        repo_name=scan_config.get('repo_name'),
                        scan_id=scan_config.get('scan_id')
                    )
                    threat_issues.append(threat_issue)
                except Exception as e:
                    logger.warning(f"Failed to create threat issue for {file_name}: {e}")
            
            all_issues = file_issues + threat_issues
            
            # Calculate metrics
            logic_bomb_count = len([p for p in threat_matches if 'BOMB' in p.pattern_type or 'TRIGGER' in p.pattern_type])
            critical_threats = len([i for i in all_issues if i.severity in ['BLOCKER', 'CRITICAL', 'CRITICAL_BOMB']])
            
            return {
                'file_id': file_id,
                'file_name': file_name,
                'file_path': file_name,
                'file_type': file_type,
                'lines_scanned': file_lines,
                'issues': [self._format_issue(issue) for issue in all_issues],
                'issues_count': len(all_issues),
                'logic_bomb_count': logic_bomb_count,
                'threat_pattern_count': len(threat_matches),
                'critical_threats': critical_threats,
                'scan_status': 'completed',
                'threat_level': self._determine_threat_level(all_issues, threat_matches)
            }
            
        except Exception as e:
            logger.error(f"Error in _scan_single_file for {file_info.get('name', 'unknown')}: {e}")
            return None
    
    def _format_issue(self, issue) -> Dict[str, Any]:
        """Format issue for response"""
        return {
            'id': getattr(issue, 'id', ''),
            'rule_id': getattr(issue, 'rule_id', ''),
            'file_path': getattr(issue, 'file_path', ''),
            'line_number': getattr(issue, 'line_number', 0),
            'column': getattr(issue, 'column', 0),
            'message': getattr(issue, 'message', ''),
            'severity': getattr(issue, 'severity', ''),
            'type': getattr(issue, 'type', ''),
            'status': getattr(issue, 'status', ''),
            'code_snippet': getattr(issue, 'code_snippet', ''),
            'suggested_fix': getattr(issue, 'suggested_fix', '')
        }
    
    def _determine_threat_level(self, issues: List, threat_matches: List) -> str:
        """Determine threat level based on issues and matches"""
        if any(issue.severity in ['BLOCKER', 'CRITICAL', 'CRITICAL_BOMB'] for issue in issues):
            return 'CRITICAL'
        elif any(issue.severity in ['MAJOR', 'HIGH_RISK'] for issue in issues):
            return 'HIGH'
        elif any(issue.severity in ['MINOR', 'MEDIUM_RISK'] for issue in issues):
            return 'MEDIUM'
        elif issues or threat_matches:
            return 'LOW'
        return 'NONE'
    
    def _compile_results(self, results: List[Dict], scan_config: Dict) -> Dict[str, Any]:
        """Compile final scan results"""
        end_time = time.time()
        duration = end_time - self.start_time
        
        total_issues = sum(r.get('issues_count', 0) for r in results)
        total_lines = sum(r.get('lines_scanned', 0) for r in results)
        total_logic_bombs = sum(r.get('logic_bomb_count', 0) for r in results)
        total_threat_patterns = sum(r.get('threat_pattern_count', 0) for r in results)
        
        logger.info(f"Scan completed: {self.processed_files} files processed, {self.skipped_files} skipped in {duration:.2f}s")
        
        return {
            'scan_id': scan_config.get('scan_id'),
            'project_id': scan_config.get('project_id'),
            'project_name': scan_config.get('project_name'),
            'scan_type': scan_config.get('scan_type', 'enhanced'),
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'duration_ms': int(duration * 1000),
            'files_scanned': self.processed_files,
            'files_skipped': self.skipped_files,
            'total_files': self.total_files,
            'lines_of_code': total_lines,
            'issues': [issue for r in results for issue in r.get('issues', [])],
            'total_issues': total_issues,
            'logic_bomb_count': total_logic_bombs,
            'threat_pattern_count': total_threat_patterns,
            'file_results': results,
            'coverage': (self.processed_files / self.total_files * 100) if self.total_files > 0 else 0,
            'duplications': 0.0,  # Would need additional analysis
            'maintainability_rating': 'A',  # Would need additional analysis
            'reliability_rating': 'A',  # Would need additional analysis
            'security_rating': self._calculate_security_rating(total_issues, total_logic_bombs),
            'threat_shield_status': 'ACTIVE',
            'logic_bomb_risk_score': self._calculate_risk_score(total_logic_bombs, total_issues),
            'performance_metrics': {
                'parallel_processing_used': settings.PARALLEL_FILE_PROCESSING and self.total_files >= 10,
                'workers_used': min(settings.MAX_WORKERS_FOR_PARALLEL, self.total_files) if settings.PARALLEL_FILE_PROCESSING else 1,
                'files_per_second': self.processed_files / duration if duration > 0 else 0,
                'average_time_per_file': duration / self.processed_files if self.processed_files > 0 else 0
            }
        }
    
    def _calculate_security_rating(self, total_issues: int, logic_bombs: int) -> str:
        """Calculate security rating based on issues found"""
        if logic_bombs > 0:
            return 'F'
        elif total_issues > 50:
            return 'D'
        elif total_issues > 20:
            return 'C'
        elif total_issues > 5:
            return 'B'
        return 'A'
    
    def _calculate_risk_score(self, logic_bombs: int, total_issues: int) -> float:
        """Calculate risk score (0.0 to 1.0)"""
        if logic_bombs > 0:
            return 1.0
        elif total_issues > 0:
            return min(0.9, total_issues / 100.0)
        return 0.0
    
    def _log_progress(self):
        """Log scan progress"""
        elapsed = time.time() - self.start_time
        progress = (self.processed_files / self.total_files * 100) if self.total_files > 0 else 0
        logger.info(f"Progress: {progress:.1f}% ({self.processed_files}/{self.total_files} files) in {elapsed:.1f}s")


