#!/usr/bin/env python3
"""
Check specific job status
"""

import requests
import json

def check_specific_job(job_id):
    try:
        response = requests.get(f"http://localhost:5000/api/jobs/{job_id}/status", timeout=10)
        if response.status_code == 200:
            job = response.json()
            print(f"Job {job_id}:")
            print(f"  Status: {job['status']}")
            print(f"  Progress: {job.get('progress', '')}")
            print(f"  Created: {job.get('created_at', '')}")
            print(f"  Started: {job.get('started_at', '')}")
            print(f"  Completed: {job.get('completed_at', '')}")
            if job.get('error_message'):
                print(f"  Error: {job['error_message']}")
        else:
            print(f"Failed to get job status: {response.status_code}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_specific_job("d63005c7-7484-4963-ac0a-3e9b4e77ef05")
