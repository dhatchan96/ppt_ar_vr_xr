#!/usr/bin/env python3
"""
Performance Monitor for Large Project Scans
Helps identify bottlenecks and optimize scan performance
"""

import time
import psutil
import threading
from typing import Dict, List, Any
import logging

logger = logging.getLogger(__name__)

class PerformanceMonitor:
    """Monitor performance during large project scans"""
    
    def __init__(self):
        self.start_time = None
        self.metrics = {
            'cpu_usage': [],
            'memory_usage': [],
            'disk_io': [],
            'file_processing_times': [],
            'scan_phases': {}
        }
        self.monitoring = False
        self.monitor_thread = None
        
    def start_monitoring(self, scan_id: str):
        """Start performance monitoring"""
        self.start_time = time.time()
        self.metrics = {
            'scan_id': scan_id,
            'cpu_usage': [],
            'memory_usage': [],
            'disk_io': [],
            'file_processing_times': [],
            'scan_phases': {},
            'start_time': self.start_time
        }
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_system, daemon=True)
        self.monitor_thread.start()
        logger.info(f"Performance monitoring started for scan {scan_id}")
        
    def stop_monitoring(self):
        """Stop performance monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        logger.info("Performance monitoring stopped")
        
    def _monitor_system(self):
        """Monitor system resources"""
        while self.monitoring:
            try:
                # CPU usage
                cpu_percent = psutil.cpu_percent(interval=1)
                self.metrics['cpu_usage'].append({
                    'timestamp': time.time(),
                    'usage': cpu_percent
                })
                
                # Memory usage
                memory = psutil.virtual_memory()
                self.metrics['memory_usage'].append({
                    'timestamp': time.time(),
                    'total': memory.total,
                    'available': memory.available,
                    'percent': memory.percent
                })
                
                # Disk I/O
                disk_io = psutil.disk_io_counters()
                if disk_io:
                    self.metrics['disk_io'].append({
                        'timestamp': time.time(),
                        'read_bytes': disk_io.read_bytes,
                        'write_bytes': disk_io.write_bytes,
                        'read_count': disk_io.read_count,
                        'write_count': disk_io.write_count
                    })
                    
            except Exception as e:
                logger.error(f"Error in performance monitoring: {e}")
                
            time.sleep(5)  # Sample every 5 seconds
            
    def record_phase(self, phase_name: str, start_time: float = None):
        """Record the start of a scan phase"""
        if start_time is None:
            start_time = time.time()
        self.metrics['scan_phases'][phase_name] = {
            'start_time': start_time,
            'end_time': None
        }
        
    def end_phase(self, phase_name: str, end_time: float = None):
        """Record the end of a scan phase"""
        if end_time is None:
            end_time = time.time()
        if phase_name in self.metrics['scan_phases']:
            self.metrics['scan_phases'][phase_name]['end_time'] = end_time
            duration = end_time - self.metrics['scan_phases'][phase_name]['start_time']
            logger.info(f"Phase '{phase_name}' completed in {duration:.2f} seconds")
            
    def record_file_processing(self, file_name: str, processing_time: float):
        """Record file processing time"""
        self.metrics['file_processing_times'].append({
            'file_name': file_name,
            'processing_time': processing_time,
            'timestamp': time.time()
        })
        
    def get_performance_report(self) -> Dict[str, Any]:
        """Generate performance report"""
        if not self.start_time:
            return {}
            
        end_time = time.time()
        total_duration = end_time - self.start_time
        
        # Calculate averages
        avg_cpu = sum(m['usage'] for m in self.metrics['cpu_usage']) / len(self.metrics['cpu_usage']) if self.metrics['cpu_usage'] else 0
        avg_memory = sum(m['percent'] for m in self.metrics['memory_usage']) / len(self.metrics['memory_usage']) if self.metrics['memory_usage'] else 0
        
        # Calculate phase durations
        phase_durations = {}
        for phase_name, phase_data in self.metrics['scan_phases'].items():
            if phase_data['end_time']:
                phase_durations[phase_name] = phase_data['end_time'] - phase_data['start_time']
                
        # File processing statistics
        file_times = [f['processing_time'] for f in self.metrics['file_processing_times']]
        avg_file_time = sum(file_times) / len(file_times) if file_times else 0
        max_file_time = max(file_times) if file_times else 0
        min_file_time = min(file_times) if file_times else 0
        
        return {
            'scan_id': self.metrics.get('scan_id'),
            'total_duration': total_duration,
            'average_cpu_usage': avg_cpu,
            'average_memory_usage': avg_memory,
            'peak_cpu_usage': max(m['usage'] for m in self.metrics['cpu_usage']) if self.metrics['cpu_usage'] else 0,
            'peak_memory_usage': max(m['percent'] for m in self.metrics['memory_usage']) if self.metrics['memory_usage'] else 0,
            'phase_durations': phase_durations,
            'files_processed': len(self.metrics['file_processing_times']),
            'average_file_processing_time': avg_file_time,
            'max_file_processing_time': max_file_time,
            'min_file_processing_time': min_file_time,
            'performance_recommendations': self._generate_recommendations(avg_cpu, avg_memory, avg_file_time, total_duration)
        }
        
    def _generate_recommendations(self, avg_cpu: float, avg_memory: float, avg_file_time: float, total_duration: float) -> List[str]:
        """Generate performance recommendations"""
        recommendations = []
        
        if avg_cpu > 80:
            recommendations.append("High CPU usage detected. Consider reducing parallel workers or optimizing pattern matching.")
            
        if avg_memory > 80:
            recommendations.append("High memory usage detected. Consider processing files in smaller batches.")
            
        if avg_file_time > 5:
            recommendations.append("Slow file processing detected. Consider optimizing regex patterns or reducing file size limits.")
            
        if total_duration > 600:  # 10 minutes
            recommendations.append("Long scan duration detected. Consider increasing file limits or using parallel processing.")
            
        if not recommendations:
            recommendations.append("Performance appears optimal. No immediate optimizations needed.")
            
        return recommendations

# Global performance monitor instance
performance_monitor = PerformanceMonitor()
