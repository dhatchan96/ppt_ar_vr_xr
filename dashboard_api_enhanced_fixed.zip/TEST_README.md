# Repository Scanning Test Scripts

This directory contains test scripts to validate repository scanning functionality, especially for large repositories (200MB+).

## 📋 Prerequisites

1. **Backend API Running**: Make sure the backend API is running on `http://localhost:5000`
2. **Python Dependencies**: Install required packages:
   ```bash
   pip install -r test_requirements.txt
   ```

## 🧪 Available Test Scripts

### 1. Quick Medium Repository Test (`test_medium_repo_scan.py`)

**Purpose**: Quick validation of scanning functionality with a ~150MB repository

**Usage**:
```bash
python test_medium_repo_scan.py
```

**What it tests**:
- Job creation and monitoring
- Progress tracking
- Result retrieval and validation
- Performance metrics
- Data completeness

**Expected Duration**: 10-30 minutes

### 2. Comprehensive Large Repository Test (`test_large_repo_scan.py`)

**Purpose**: Comprehensive testing of large repository scanning (200MB+) with detailed analysis

**Usage**:
```bash
python test_large_repo_scan.py
```

**What it tests**:
- Multiple large repositories
- Memory usage monitoring
- Performance analysis
- Result accuracy validation
- Comprehensive reporting

**Expected Duration**: 1-3 hours (depending on repository size)

## 📊 Test Repositories

### Medium Test (React.js)
- **URL**: `https://github.com/facebook/react`
- **Size**: ~150MB
- **Files**: Thousands of files
- **Purpose**: Validate scanning performance and accuracy

### Large Tests (VS Code + React)
- **VS Code**: `https://github.com/microsoft/vscode` (~200MB)
- **React**: `https://github.com/facebook/react` (~150MB)
- **Purpose**: Stress test scanning system

## 🔍 What the Tests Validate

### 1. **Job Management**
- ✅ Job creation via API
- ✅ Progress monitoring
- ✅ Status updates
- ✅ Result retrieval

### 2. **Scan Results**
- ✅ Files scanned count
- ✅ Lines of code analysis
- ✅ Threat detection
- ✅ Logic bomb metrics
- ✅ File-level results

### 3. **Performance**
- ✅ Scan duration
- ✅ Memory usage
- ✅ Files per second processing
- ✅ Resource utilization

### 4. **Data Quality**
- ✅ Result completeness
- ✅ Data structure validation
- ✅ Issue classification
- ✅ Metrics accuracy

## 📈 Expected Results

### Success Criteria
- **Files Scanned**: > 0
- **Scan Duration**: < 30 minutes (medium), < 2 hours (large)
- **Memory Usage**: < 2GB peak
- **Data Completeness**: All required fields present
- **Issue Detection**: Accurate threat classification

### Performance Benchmarks
- **Medium Repo**: 5-15 minutes
- **Large Repo**: 15-60 minutes
- **Memory Peak**: < 1.5GB
- **Files/Second**: > 10

## 📄 Test Reports

The comprehensive test generates detailed reports:

### Report Location
- **Filename**: `large_repo_scan_test_report_YYYYMMDD_HHMMSS.json`
- **Format**: JSON with detailed analysis

### Report Contents
- Test summary and success rate
- Performance metrics
- Memory usage analysis
- Result validation
- Recommendations for optimization

## 🚨 Troubleshooting

### Common Issues

1. **API Connection Failed**
   ```
   ❌ Failed to create job: Connection refused
   ```
   **Solution**: Ensure backend API is running on port 5000

2. **Job Timeout**
   ```
   ❌ Job timed out after 30 minutes
   ```
   **Solution**: Check system resources and repository size

3. **Memory Issues**
   ```
   ❌ Memory usage too high
   ```
   **Solution**: Close other applications, increase system memory

4. **No Results Data**
   ```
   ❌ No result data found
   ```
   **Solution**: Check job status, ensure scan completed successfully

### Debug Mode

Enable detailed logging by modifying the scripts:
```python
# Add to test scripts for more verbose output
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 🔧 Customization

### Adding New Test Repositories

Edit the test scripts to add your own repositories:

```python
test_repos = [
    {
        "url": "https://github.com/your-repo/your-project",
        "expected_size_mb": 100,
        "description": "Your custom repository"
    }
]
```

### Modifying Test Parameters

Adjust timeouts and thresholds:
```python
max_wait_time = 3600  # 1 hour timeout
check_interval = 10   # Check every 10 seconds
```

## 📞 Support

If tests fail or you need assistance:
1. Check the console output for error messages
2. Verify backend API is running correctly
3. Ensure sufficient system resources
4. Review the generated test reports

## 🎯 Best Practices

1. **Run tests during low system load**
2. **Monitor system resources during testing**
3. **Keep test reports for comparison**
4. **Run tests regularly to catch regressions**
5. **Use different repository sizes for comprehensive testing**
