#!/usr/bin/env python3
"""
Simple script to check job status
"""

import requests
import json

def check_jobs():
    try:
        response = requests.get("http://localhost:5000/api/jobs", timeout=5)
        if response.status_code == 200:
            jobs = response.json()
            print("Current jobs:")
            for job in jobs.get('jobs', []):
                print(f"  - {job['job_id']}: {job['status']} - {job.get('progress', '')}")
        else:
            print(f"Failed to get jobs: {response.status_code}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_jobs()
