#!/usr/bin/env python3
import sqlite3
from datetime import datetime, timedelta

def check_cancelled_jobs():
    try:
        conn = sqlite3.connect('threatguard_data/jobs.db')
        cursor = conn.cursor()
        
        # Check for cancelled jobs
        cursor.execute('SELECT job_id, status, created_at FROM scan_jobs WHERE status = "cancelled"')
        cancelled_jobs = cursor.fetchall()
        
        print(f"Found {len(cancelled_jobs)} cancelled jobs:")
        for job_id, status, created_at in cancelled_jobs:
            print(f"  {job_id}: {status} (created: {created_at})")
        
        # Check for jobs older than 3 days
        cutoff_date = datetime.now() - timedelta(days=3)
        cutoff_date_str = cutoff_date.isoformat()
        
        cursor.execute('''
            SELECT job_id, status, created_at FROM scan_jobs 
            WHERE status IN ("completed", "failed", "cancelled") 
            AND created_at < ?
        ''', (cutoff_date_str,))
        
        old_jobs = cursor.fetchall()
        print(f"\nFound {len(old_jobs)} jobs older than 3 days that should be cleaned up:")
        for job_id, status, created_at in old_jobs:
            print(f"  {job_id}: {status} (created: {created_at})")
        
        # Check all statuses
        cursor.execute('SELECT status, COUNT(*) FROM scan_jobs GROUP BY status')
        status_counts = cursor.fetchall()
        
        print(f"\nAll job statuses and counts:")
        for status, count in status_counts:
            print(f"  {status}: {count}")
        
        conn.close()
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_cancelled_jobs()
