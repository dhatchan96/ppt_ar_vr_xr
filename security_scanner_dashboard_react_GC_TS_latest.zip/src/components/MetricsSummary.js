import React, { useEffect, useState } from "react";
import API from "../api";
import { Line, Doughnut, Bar, Radar, PolarArea } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  RadialLinearScale,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import "../style.css";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  RadialLinearScale,
  ArcElement,
  Tooltip,
  Legend
);

const MetricsSummary = () => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      setLoading(true);
      const res = await API.get("/api/command-center/metrics");
      setMetrics(res.data);
      setError(null);
    } catch (err) {
      console.error("Failed to load metrics", err);
      setError("Failed to load metrics. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <div className="container-fluid mt-4 px-5 mb-5">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-3">Loading security metrics...</p>
        </div>
      </div>
    );

  if (error)
    return (
      <div className="container-fluid mt-4 px-5 mb-5">
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      </div>
    );

  if (!metrics)
    return (
      <div className="container-fluid mt-4 px-5 mb-5">
        <div className="alert alert-warning" role="alert">
          No metrics available. Please upload a scan file to see analytics.
        </div>
      </div>
    );

  // Extract data from metrics
  const {
    threats,
    logic_bomb_metrics,
    threat_intelligence,
    scan_info,
    threat_shield,
  } = metrics;

  // Threat Distribution by Type
  const threatTypeData = {
    labels: Object.keys(threats?.by_type || {}),
    datasets: [
      {
        data: Object.values(threats?.by_type || {}),
        backgroundColor: [
          "#dc3545",
          "#fd7e14",
          "#ffc107",
          "#198754",
          "#0dcaf0",
          "#6f42c1",
          "#e83e8c",
        ],
        borderWidth: 2,
        borderColor: "#fff",
      },
    ],
  };

  // Threat Distribution by Severity
  const threatSeverityData = {
    labels: Object.keys(threats?.by_severity || {}),
    datasets: [
      {
        data: Object.values(threats?.by_severity || {}),
        backgroundColor: [
          "#dc3545",
          "#fd7e14",
          "#ffc107",
          "#198754",
          "#6c757d",
        ],
        borderWidth: 2,
        borderColor: "#fff",
      },
    ],
  };

  // Logic Bomb Metrics Trend
  const logicBombTrendData = {
    labels: [
      "Threat Density",
      "Detection Confidence",
      "Trigger Complexity",
      "Payload Severity",
    ],
    datasets: [
      {
        label: "Current Values",
        data: [
          (metrics.logic_bomb_metrics?.threat_density || 0) / 100 || 0,
          logic_bomb_metrics?.detection_confidence_avg || 0,
          logic_bomb_metrics?.trigger_complexity_score || 0,
          logic_bomb_metrics?.payload_severity_score || 0,
        ],
        backgroundColor: "rgba(13, 110, 253, 0.2)",
        borderColor: "#0d6efd",
        borderWidth: 2,
        pointBackgroundColor: "#0d6efd",
        pointBorderColor: "#fff",
        pointRadius: 6,
      },
    ],
  };

  // Shield Effectiveness Over Time (simulated data)
  const shieldEffectivenessData = {
    labels: ["Week 1", "Week 2", "Week 3", "Week 4", "Current"],
    datasets: [
      {
        label: "Shield Effectiveness (%)",
        data: [85, 78, 92, 88, threat_shield?.protection_effectiveness || 85],
        fill: true,
        backgroundColor: "rgba(25, 135, 84, 0.1)",
        borderColor: "#198754",
        tension: 0.4,
      },
    ],
  };

  // Threat Intelligence Radar - Enhanced with better metrics and scaling
  const threatIntelligenceData = {
    labels: [
      "Threat Level",
      "Detection Confidence",
      "Shield Effectiveness",
      "Risk Score",
      "Response Time",
      "Coverage",
    ],
    datasets: [
      {
        label: "Current Assessment",
        data: [
          getThreatLevelScore(threat_intelligence?.threat_level),
          logic_bomb_metrics?.detection_confidence_avg || 85,
          threat_shield?.protection_effectiveness || 95,
          Math.min(metrics?.threat_ratings?.logic_bomb_risk_score || 0, 100), // Cap at 100
          getResponseTimeScore(
            logic_bomb_metrics?.neutralization_urgency_hours || 24
          ),
          getCoverageScore(
            scan_info?.files_scanned || 0,
            scan_info?.lines_of_code || 1000
          ),
        ],
        backgroundColor: "rgba(220, 53, 69, 0.2)",
        borderColor: "#dc3545",
        borderWidth: 2,
        pointBackgroundColor: "#dc3545",
        pointRadius: 4,
      },
    ],
  };

  // Neutralization Urgency Timeline
  const urgencyData = {
    labels: [
      "Critical (2h)",
      "High (6h)",
      "Medium (12h)",
      "Low (24h)",
      "Current",
    ],
    datasets: [
      {
        label: "Neutralization Urgency (hours)",
        data: [
          2,
          6,
          12,
          24,
          logic_bomb_metrics?.neutralization_urgency_hours || 24,
        ],
        backgroundColor: [
          "#dc3545",
          "#fd7e14",
          "#ffc107",
          "#198754",
          "#0dcaf0",
        ],
        borderWidth: 1,
        borderColor: "#fff",
      },
    ],
  };

  // Security Ratings Distribution
  const securityRatingsData = {
    labels: [
      "A (Excellent)",
      "B (Good)",
      "C (Fair)",
      "D (Poor)",
      "E (Critical)",
    ],
    datasets: [
      {
        label: "Security Rating",
        data: [1, 0, 0, 0, 0], // Placeholder - would need historical data
        backgroundColor: [
          "#198754",
          "#198754",
          "#ffc107",
          "#fd7e14",
          "#dc3545",
        ],
        borderWidth: 1,
        borderColor: "#fff",
      },
    ],
  };

  // Helper function to convert threat level to numeric score
  function getThreatLevelScore(level) {
    const levels = {
      MINIMAL: 20,
      LOW: 40,
      MODERATE: 60,
      HIGH: 80,
      CRITICAL: 100,
    };
    return levels[level] || 50;
  }

  // Helper function to convert response time to score (lower hours = higher score)
  function getResponseTimeScore(hours) {
    if (hours <= 2) return 100; // Critical - immediate response
    if (hours <= 6) return 80; // High - quick response
    if (hours <= 12) return 60; // Medium - moderate response
    if (hours <= 24) return 40; // Low - slow response
    return 20; // Very slow response
  }

  // Helper function to calculate coverage score based on files and lines scanned
  function getCoverageScore(filesScanned, linesOfCode) {
    if (filesScanned === 0) return 0;

    // Calculate coverage based on files and lines
    const fileScore = Math.min(filesScanned * 5, 50); // Max 50 points for files
    const lineScore = Math.min(linesOfCode / 100, 50); // Max 50 points for lines

    return Math.min(fileScore + lineScore, 100);
  }

  return (
    <div className="">
      <div className="row mb-4">
        <div className="col-12">
          <h2 className="mb-3">🛡️ Security Analytics & Threat Intelligence</h2>
          <p className="text-muted">
            Comprehensive analysis of security threats, detection metrics, and
            protection effectiveness
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="row g-3 mb-5">
        <div className="col-md-3">
          <div className="card text-center h-100 shadow">
            <div className="card-body">
              <h5 className="card-title fs-2">{threats?.total || 0}</h5>
              <p className="card-text">Total Threats</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center h-100 shadow">
            <div className="card-body">
              <h5 className="card-title fs-2">
                {threats?.critical_bombs || 0}
              </h5>
              <p className="card-text">Critical Bombs</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center h-100 shadow">
            <div className="card-body">
              <h5 className="card-title fs-2">
                {threat_shield?.protection_effectiveness || 0}%
              </h5>
              <p className="card-text">Shield Effectiveness</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center h-100 shadow">
            <div className="card-body">
              <h5 className="card-title fs-2">
                {Math.round(
                  (metrics.logic_bomb_metrics?.threat_density || 0) / 100
                ) || 0}%
              </h5>
              <p className="card-text">Threat Density</p>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-4">
        {/* Threat Distribution by Type */}
        <div className="col-md-6 col-lg-4">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">🎯 Threat Distribution by Type</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Doughnut
                  data={threatTypeData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: "bottom",
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Threat Distribution by Severity */}
        <div className="col-md-6 col-lg-4">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">⚠️ Threat Distribution by Severity</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Doughnut
                  data={threatSeverityData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: "bottom",
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Logic Bomb Metrics Radar */}
        <div className="col-md-6 col-lg-4">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">📊 Logic Bomb Metrics Overview</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Radar
                  data={logicBombTrendData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      r: {
                        beginAtZero: true,
                        max: 100,
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Shield Effectiveness Trend */}
        <div className="col-md-6 col-lg-6">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">🛡️ Shield Effectiveness Trend</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Line
                  data={shieldEffectivenessData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true,
                        max: 100,
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Threat Intelligence Radar */}
        <div className="col-md-6 col-lg-6">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">🧠 Threat Intelligence Assessment</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Radar
                  data={threatIntelligenceData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                          stepSize: 20,
                          color: "#666",
                          font: {
                            size: 10,
                          },
                        },
                        grid: {
                          color: "rgba(0,0,0,0.1)",
                        },
                        pointLabels: {
                          color: "#333",
                          font: {
                            size: 11,
                            weight: "bold",
                          },
                        },
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                      tooltip: {
                        callbacks: {
                          label: function (context) {
                            const labels = [
                              "Threat Level",
                              "Detection Confidence",
                              "Shield Effectiveness",
                              "Risk Score",
                              "Response Time",
                              "Coverage",
                            ];
                            return `${labels[context.dataIndex]}: ${
                              context.parsed.r
                            }%`;
                          },
                        },
                      },
                    },
                    elements: {
                      point: {
                        radius: 4,
                        hoverRadius: 6,
                      },
                    },
                  }}
                />
              </div>
              <div className="mt-3">
                <small className="text-muted">
                  <strong>Metrics Explained:</strong>
                  <br />• <strong>Threat Level:</strong> Overall threat
                  assessment (0-100%)
                  <br />• <strong>Detection Confidence:</strong> Accuracy of
                  threat detection
                  <br />• <strong>Shield Effectiveness:</strong> Protection
                  system performance
                  <br />• <strong>Risk Score:</strong> Calculated security risk
                  level
                  <br />• <strong>Response Time:</strong> Speed of threat
                  neutralization (higher = faster)
                  <br />• <strong>Coverage:</strong> Code coverage and scan
                  completeness
                </small>
              </div>
            </div>
          </div>
        </div>

        {/* Neutralization Urgency */}
        <div className="col-md-6 col-lg-6">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">⏰ Neutralization Urgency Timeline</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Bar
                  data={urgencyData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true,
                        title: {
                          display: true,
                          text: "Hours",
                        },
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Security Ratings Distribution */}
        <div className="col-md-6 col-lg-6">
          <div className="card h-100 shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">📈 Security Ratings Distribution</h6>
            </div>
            <div className="card-body">
              <div style={{ height: "300px" }}>
                <Bar
                  data={securityRatingsData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true,
                      },
                    },
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Metrics Table */}
      <div className="row mt-4">
        <div className="col-12">
          <div className="card shadow">
            <div className="card-header py-3">
              <h6 className="mb-0">📋 Detailed Metrics Summary</h6>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <h6>Detection Metrics</h6>
                  <ul className="list-unstyled">
                    <li>
                      <strong>Detection Confidence:</strong>{" "}
                      {logic_bomb_metrics?.detection_confidence_avg || 0}%
                    </li>
                    <li>
                      <strong>Trigger Complexity:</strong>{" "}
                      {logic_bomb_metrics?.trigger_complexity_score || 0}%
                    </li>
                    <li>
                      <strong>Payload Severity:</strong>{" "}
                      {logic_bomb_metrics?.payload_severity_score || 0}%
                    </li>
                    <li>
                      <strong>Threat Density:</strong>{" "}
                      {logic_bomb_metrics?.threat_density || 0}/1K
                    </li>
                  </ul>
                </div>
                <div className="col-md-6">
                  <h6>Protection Metrics</h6>
                  <ul className="list-unstyled">
                    <li>
                      <strong>Shield Status:</strong>{" "}
                      <span
                        className={`badge bg-${
                          threat_shield?.status === "PROTECTED"
                            ? "success"
                            : threat_shield?.status === "BLOCKED"
                            ? "danger"
                            : "warning"
                        }`}
                      >
                        {threat_shield?.status || "UNKNOWN"}
                      </span>
                    </li>
                    <li>
                      <strong>Protection Effectiveness:</strong>{" "}
                      {threat_shield?.protection_effectiveness || 0}%
                    </li>
                    <li>
                      <strong>Neutralization Urgency:</strong>{" "}
                      {logic_bomb_metrics?.neutralization_urgency_hours || 0}{" "}
                      hours
                    </li>
                    <li>
                      <strong>Risk Score:</strong>{" "}
                      {metrics?.threat_ratings?.logic_bomb_risk_score || 0}/100
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetricsSummary;
