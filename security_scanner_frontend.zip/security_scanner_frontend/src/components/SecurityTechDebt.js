import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';

const SecurityTechDebt = () => {
  const [techDebtData, setTechDebtData] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('business_impact');
  const [showResolved, setShowResolved] = useState(true);

  useEffect(() => {
    fetchTechDebtData();
  }, []);

  const fetchTechDebtData = async () => {
    try {
      const res = await API.get('/api/security-tech-debt');
      setTechDebtData(res.data);
    } catch (error) {
      console.error('Error fetching security tech debt:', error);
    }
  };

  const [selectedIssue, setSelectedIssue] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const handleFixIssue = async (issueId) => {
    try {
      // Find the current issue to determine its status
      const currentIssue = sortedIssues.find(issue => issue.id === issueId);
      const newStatus = currentIssue?.status === 'RESOLVED' ? 'PENDING' : 'RESOLVED';
      
      await API.put(`/api/issues/${issueId}/status`, { status: newStatus });
      fetchTechDebtData();
      
      // Show success message
      const message = newStatus === 'RESOLVED' 
        ? 'Issue marked as resolved successfully!' 
        : 'Issue marked as pending successfully!';
      alert(message);
    } catch (error) {
      console.error('Failed to update issue status:', error);
      alert('Failed to update issue status. Please try again.');
    }
  };

  const handleViewDetails = (issue) => {
    setSelectedIssue(issue);
    setShowDetailsModal(true);
  };

  const handleCloseDetails = () => {
    setShowDetailsModal(false);
    setSelectedIssue(null);
  };

  if (!techDebtData) {
    return <p className="text-center mt-5">Loading security tech debt analysis...</p>;
  }

  const { summary, by_category } = techDebtData;
  
  // Get all issues for filtering and sorting
  const allIssues = Object.values(by_category).flat();
  let filteredIssues = selectedCategory === 'all' 
    ? allIssues 
    : by_category[selectedCategory] || [];
    
  // Filter by resolved status
  if (!showResolved) {
    filteredIssues = filteredIssues.filter(issue => issue.status !== 'RESOLVED');
  }

  // Sort issues
  const sortedIssues = [...filteredIssues].sort((a, b) => {
    if (sortBy === 'business_impact') {
      const impactOrder = { 'Critical': 3, 'High': 2, 'Medium': 1, 'Low': 0 };
      return impactOrder[b.business_impact] - impactOrder[a.business_impact];
    }
    if (sortBy === 'remediation_effort') {
      return b.remediation_effort - a.remediation_effort;
    }
    if (sortBy === 'severity') {
      const severityOrder = { 'CRITICAL': 4, 'MAJOR': 3, 'MINOR': 2, 'INFO': 1 };
      return severityOrder[b.severity] - severityOrder[a.severity];
    }
    return 0;
  });

  const categoryMapping = {
    'HARDCODED_CREDENTIALS': { name: 'Hardcoded Credentials', icon: '🔑', color: '#dc3545' },
    'HARDCODED_URLS': { name: 'Hardcoded URLs', icon: '🌐', color: '#fd7e14' },
    'INPUT_VALIDATION': { name: 'Input Validation', icon: '🛡️', color: '#ffc107' },
    'VULNERABLE_LIBRARIES': { name: 'Vulnerable Libraries', icon: '📚', color: '#6f42c1' },
    'PLAIN_TEXT_STORAGE': { name: 'Plain Text Storage', icon: '💾', color: '#dc3545' },
    'CORS_POLICY': { name: 'CORS Policy', icon: '🌍', color: '#20c997' },
    'RATE_LIMITING': { name: 'Rate Limiting', icon: '⏱️', color: '#0dcaf0' },
    'SECURE_COOKIES': { name: 'Secure Cookies', icon: '🍪', color: '#fd7e14' },
    'SSL_TLS': { name: 'SSL/TLS', icon: '🔒', color: '#dc3545' },
    'SECRETS_MANAGEMENT': { name: 'Secrets Management', icon: '🗝️', color: '#6f42c1' },
    'GENERAL_SECURITY_DEBT': { name: 'General Security Debt', icon: '⚠️', color: '#6c757d' },
    'MALICIOUS_CODE': { name: 'Malicious Code', icon: '🦠', color: '#dc3545' },
    'TIME_BASED_THREAT': { name: 'Time-Based Threat', icon: '⏰', color: '#fd7e14' },
    'USER_TARGETED_THREAT': { name: 'User-Targeted Threat', icon: '👤', color: '#dc3545' },
    'DESTRUCTIVE_ACTION': { name: 'Destructive Action', icon: '💥', color: '#dc3545' },
    'FINANCIAL_SECURITY': { name: 'Financial Security', icon: '💰', color: '#dc3545' },
    'SECURITY_ISSUE': { name: 'Security Issue', icon: '🛡️', color: '#6c757d' },
    'UNKNOWN': { name: 'Security Vulnerability', icon: '⚠️', color: '#6c757d' },
    'ACCESS_CONTROL': { name: 'Access Control', icon: '👤', color: '#198754' }
  };

  return (
    <div className="container-fluid mt-4 px-5" style={{ background: '#fff', color: '#222', minHeight: '100vh' }}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: '#0d6efd' }}>
          🔧 Security Technical Debt Dashboard
        </h2>
        <div className="d-flex gap-3">
          <select 
            className="form-select" 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)}
            style={{ width: '200px' }}
          >
            <option value="all">All Categories</option>
            {Object.keys(by_category).map(cat => (
              <option key={cat} value={cat}>
                {categoryMapping[cat]?.name || cat}
              </option>
            ))}
          </select>
          <select 
            className="form-select" 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            style={{ width: '180px' }}
          >
            <option value="business_impact">Business Impact</option>
            <option value="remediation_effort">Effort Required</option>
            <option value="severity">Severity</option>
          </select>
          <div className="form-check">
            <input 
              className="form-check-input" 
              type="checkbox" 
              id="showResolved"
              checked={showResolved}
              onChange={(e) => setShowResolved(e.target.checked)}
            />
            <label className="form-check-label" htmlFor="showResolved">
              Show Resolved
            </label>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="row g-4 mb-5">
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #dc3545' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#dc3545' }}>{summary.hardcoded_credentials}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Hardcoded Credentials</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #fd7e14' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#fd7e14' }}>{summary.hardcoded_urls}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Hardcoded URLs</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #ffc107' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#ffc107' }}>{summary.input_validation}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Input Validation</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #6f42c1' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#6f42c1' }}>{summary.vulnerable_libraries}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Vulnerable Libraries</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #198754' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#198754' }}>{summary.access_control}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Access Control</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #0d6efd' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#0d6efd' }}>{Math.round(summary.total_effort_hours)}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Total Hours</div>
            </div>
          </div>
        </div>
      </div>

      {/* Category Overview */}
      <div className="row g-3 mb-5">
        {Object.entries(by_category).map(([category, issues]) => {
          const categoryInfo = categoryMapping[category] || { name: category, icon: '⚠️', color: '#6c757d' };
          return (
            <div key={category} className="col-md-4">
              <div 
                className="card h-100" 
                style={{ 
                  background: '#f8f9fa', 
                  border: `2px solid ${categoryInfo.color}`,
                  cursor: 'pointer'
                }}
                onClick={() => setSelectedCategory(category)}
              >
                <div className="card-body text-center">
                  <div style={{ fontSize: '2rem' }}>{categoryInfo.icon}</div>
                  <h6 style={{ color: categoryInfo.color, marginTop: '0.5rem' }}>
                    {categoryInfo.name}
                  </h6>
                  <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: categoryInfo.color }}>
                    {issues.length}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#888' }}>
                    {Math.round(issues.reduce((sum, issue) => sum + issue.remediation_effort, 0) / 60)}h effort
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Issues Table */}
      <div className="section" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb' }}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h3 style={{ color: '#0d6efd' }}>
            {selectedCategory === 'all' ? 'All Security Tech Debt Issues' : `${categoryMapping[selectedCategory]?.name || selectedCategory} Issues`}
          </h3>
          <span className="badge bg-primary">{sortedIssues.length} issues</span>
        </div>

        <div className="table-responsive">
          <table className="table table-bordered table-hover align-middle" style={{ background: '#fff' }}>
            <thead className="table-light">
              <tr>
                <th style={{ color: '#0d6efd' }}>Status</th>
                <th style={{ color: '#0d6efd' }}>Priority</th>
                <th style={{ color: '#0d6efd' }}>Category</th>
                <th style={{ color: '#0d6efd' }}>AIT → SPK → Repo</th>
                <th style={{ color: '#0d6efd' }}>File</th>
                <th style={{ color: '#0d6efd' }}>Line</th>
                <th style={{ color: '#0d6efd' }}>Issue</th>
                <th style={{ color: '#0d6efd' }}>Business Impact</th>
                <th style={{ color: '#0d6efd' }}>Effort</th>
                <th style={{ color: '#0d6efd' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedIssues.length > 0 ? (
                sortedIssues.map((issue) => {
                  const categoryInfo = categoryMapping[issue.debt_category] || { 
          name: issue.debt_category_display || 'Security Vulnerability', 
          icon: '⚠️', 
          color: '#6c757d' 
        };
                  const isResolved = issue.status === 'RESOLVED';
                  return (
                    <tr key={issue.id} style={{
                      opacity: isResolved ? 0.6 : 1,
                      background: isResolved ? '#f8f9fa' : '#fff',
                      textDecoration: isResolved ? 'line-through' : 'none'
                    }}>
                      <td>
                        <span className={`badge ${
                          isResolved ? 'bg-success' : 'bg-warning'
                        }`}>
                          {isResolved ? '✅ Resolved' : '⏳ Pending'}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${
                          issue.business_impact === 'Critical' ? 'bg-danger' :
                          issue.business_impact === 'High' ? 'bg-warning' :
                          issue.business_impact === 'Medium' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {issue.business_impact}
                        </span>
                      </td>
                                          <td>
                      <span style={{ color: categoryInfo.color }}>
                        {categoryInfo.icon} {categoryInfo.name}
                      </span>
                    </td>
                      <td style={{ fontSize: '0.85rem' }}>
                        <div style={{ color: '#0d6efd', fontWeight: 'bold' }}>{issue.ait_tag}</div>
                        <div style={{ color: '#6f42c1' }}>→ {issue.spk_tag}</div>
                        <div style={{ color: '#198754' }}>→ {issue.repo_name}</div>
                        <div style={{ color: '#888', fontSize: '0.75rem' }}>Scan: {issue.scan_id.substring(0, 8)}...</div>
                      </td>
                      <td style={{ 
                        wordBreak: 'break-all', 
                        maxWidth: '200px',
                        fontSize: '0.85rem',
                        color: '#222'
                      }}>
                        {issue.file_name && issue.file_name !== "unknown_file" ? 
                         (issue.file_name.includes("/") ? issue.file_name.split("/").pop() : 
                          issue.file_name.includes("\\") ? issue.file_name.split("\\").pop() : 
                          issue.file_name) :
                         issue.file_path && issue.file_path !== "unknown_file" ? 
                         (issue.file_path.includes("/") ? issue.file_path.split("/").pop() : 
                          issue.file_path.includes("\\") ? issue.file_path.split("\\").pop() : 
                          issue.file_path) :
                         "Unknown File"}
                      </td>
                      <td className="text-center" style={{ color: '#0d6efd' }}>
                        {issue.line_number}
                      </td>
                      <td style={{ maxWidth: '300px' }}>
                        <div style={{ fontWeight: 'bold', color: '#222', fontSize: '0.9rem' }}>
                          {issue.message}
                        </div>
                        <div style={{ 
                          fontFamily: 'monospace', 
                          fontSize: '0.75rem', 
                          color: '#666',
                          background: '#f8f9fa',
                          padding: '0.25rem',
                          borderRadius: '3px',
                          marginTop: '0.25rem'
                        }}>
                          {issue.code_snippet.substring(0, 80)}...
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${
                          issue.business_impact === 'Critical' ? 'bg-danger' :
                          issue.business_impact === 'High' ? 'bg-warning text-dark' :
                          issue.business_impact === 'Medium' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {issue.business_impact}
                        </span>
                      </td>
                      <td className="text-center">
                        <span style={{ fontWeight: 'bold', color: '#fd7e14' }}>
                          {issue.remediation_effort}m
                        </span>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          {!isResolved ? (
                            <>
                              <button 
                                className="btn btn-sm btn-success"
                                onClick={() => handleFixIssue(issue.id)}
                                title="Mark as Fixed"
                              >
                                ✅
                              </button>
                              <button 
                                className="btn btn-sm btn-warning"
                                onClick={() => alert('Assign functionality coming soon!')}
                                title="Assign"
                              >
                                👤
                              </button>
                            </>
                          ) : (
                            <button 
                              className="btn btn-sm btn-secondary"
                              onClick={() => handleFixIssue(issue.id)}
                              title="Mark as Pending"
                            >
                              🔄
                            </button>
                          )}
                          <button 
                            className="btn btn-sm btn-info"
                            onClick={() => handleViewDetails(issue)}
                            title="View Details"
                          >
                            👁️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="10" className="text-center" style={{ color: '#888', padding: '2rem' }}>
                    {!showResolved && allIssues.some(issue => issue.status === 'RESOLVED') 
                      ? '🎉 All issues in this category are resolved! Uncheck "Show Resolved" to see pending issues.'
                      : '🎉 No security tech debt issues found in this category!'
                    }
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Remediation Recommendations */}
      {sortedIssues.length > 0 && (
        <div className="mt-5">
          <div className="card" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb' }}>
            <div className="card-header" style={{ background: '#e9f3ff' }}>
              <h5 style={{ color: '#0d6efd' }}>🛠️ Remediation Recommendations</h5>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <h6 style={{ color: '#dc3545' }}>High Priority (Complete First)</h6>
                  <ul>
                    {sortedIssues
                      .filter(issue => issue.business_impact === 'Critical' || issue.business_impact === 'High')
                      .slice(0, 5)
                      .map(issue => (
                        <li key={issue.id} style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
                          <strong>{categoryMapping[issue.debt_category]?.name || issue.debt_category_display || 'Security Vulnerability'}:</strong> {issue.suggested_fix}
                        </li>
                      ))
                    }
                  </ul>
                </div>
                <div className="col-md-6">
                  <h6 style={{ color: '#0d6efd' }}>Implementation Timeline</h6>
                  <div style={{ fontSize: '0.9rem' }}>
                    <div className="mb-2">
                      <strong>Sprint 1 (Critical):</strong> {Math.round(
                        sortedIssues
                          .filter(i => i.business_impact === 'Critical')
                          .reduce((sum, i) => sum + i.remediation_effort, 0) / 60
                      )} hours
                    </div>
                    <div className="mb-2">
                      <strong>Sprint 2-3 (High):</strong> {Math.round(
                        sortedIssues
                          .filter(i => i.business_impact === 'High')
                          .reduce((sum, i) => sum + i.remediation_effort, 0) / 60
                      )} hours
                    </div>
                    <div className="mb-2">
                      <strong>Future Sprints (Medium/Low):</strong> {Math.round(
                        sortedIssues
                          .filter(i => ['Medium', 'Low'].includes(i.business_impact))
                          .reduce((sum, i) => sum + i.remediation_effort, 0) / 60
                      )} hours
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Issue Details Modal */}
      {showDetailsModal && selectedIssue && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header" style={{ background: '#e9f3ff' }}>
                <h5 className="modal-title" style={{ color: '#0d6efd' }}>
                  🔍 Security Tech Debt Details
                </h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={handleCloseDetails}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6 style={{ color: '#0d6efd' }}>Issue Information</h6>
                    <table className="table table-sm">
                      <tbody>
                        <tr>
                          <td><strong>Category:</strong></td>
                          <td>{categoryMapping[selectedIssue.debt_category]?.name || selectedIssue.debt_category_display || 'Security Vulnerability'}</td>
                        </tr>
                        <tr>
                          <td><strong>File:</strong></td>
                          <td>{selectedIssue.file_name && selectedIssue.file_name !== "unknown_file" ? 
                               (selectedIssue.file_name.includes("/") ? selectedIssue.file_name.split("/").pop() : 
                                selectedIssue.file_name.includes("\\") ? selectedIssue.file_name.split("\\").pop() : 
                                selectedIssue.file_name) :
                               selectedIssue.file_path && selectedIssue.file_path !== "unknown_file" ? 
                               (selectedIssue.file_path.includes("/") ? selectedIssue.file_path.split("/").pop() : 
                                selectedIssue.file_path.includes("\\") ? selectedIssue.file_path.split("\\").pop() : 
                                selectedIssue.file_path) :
                               "Unknown File"}</td>
                        </tr>
                        <tr>
                          <td><strong>Line:</strong></td>
                          <td>{selectedIssue.line_number}</td>
                        </tr>
                        <tr>
                          <td><strong>Status:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.status === 'RESOLVED' ? 'bg-success' : 'bg-warning'
                            }`}>
                              {selectedIssue.status === 'RESOLVED' ? '✅ Resolved' : '⏳ Pending'}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Severity:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.severity === 'CRITICAL' ? 'bg-danger' :
                              selectedIssue.severity === 'MAJOR' ? 'bg-warning text-dark' :
                              selectedIssue.severity === 'MINOR' ? 'bg-info' : 'bg-secondary'
                            }`}>
                              {selectedIssue.severity}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Business Impact:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.business_impact === 'Critical' ? 'bg-danger' :
                              selectedIssue.business_impact === 'High' ? 'bg-warning text-dark' :
                              selectedIssue.business_impact === 'Medium' ? 'bg-info' : 'bg-secondary'
                            }`}>
                              {selectedIssue.business_impact}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Remediation Effort:</strong></td>
                          <td>{selectedIssue.remediation_effort} minutes</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="col-md-6">
                    <h6 style={{ color: '#0d6efd' }}>Hierarchical Tags</h6>
                    <div style={{ background: '#f8f9fa', padding: '1rem', borderRadius: '5px' }}>
                      <div><strong>AIT:</strong> {selectedIssue.ait_tag}</div>
                      <div><strong>SPK:</strong> {selectedIssue.spk_tag}</div>
                      <div><strong>Repo:</strong> {selectedIssue.repo_name}</div>
                      <div><strong>Scan ID:</strong> {selectedIssue.scan_id}</div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Issue Description</h6>
                  <p style={{ background: '#f8f9fa', padding: '1rem', borderRadius: '5px' }}>
                    {selectedIssue.message}
                  </p>
                </div>

                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Code Snippet</h6>
                  <pre style={{ 
                    background: '#f8f9fa', 
                    padding: '1rem', 
                    borderRadius: '5px',
                    fontSize: '0.85rem',
                    border: '1px solid #e5e7eb'
                  }}>
                    {selectedIssue.code_snippet}
                  </pre>
                </div>

                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Suggested Fix</h6>
                  <p style={{ 
                    background: '#e8f5e8', 
                    padding: '1rem', 
                    borderRadius: '5px',
                    border: '1px solid #198754'
                  }}>
                    {selectedIssue.suggested_fix}
                  </p>
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className={`btn ${selectedIssue.status === 'RESOLVED' ? 'btn-warning' : 'btn-success'}`}
                  onClick={() => {
                    handleFixIssue(selectedIssue.id);
                    handleCloseDetails();
                  }}
                >
                  {selectedIssue.status === 'RESOLVED' ? '🔄 Mark as Pending' : '✅ Mark as Resolved'}
                </button>
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={handleCloseDetails}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecurityTechDebt;