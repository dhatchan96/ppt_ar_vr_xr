import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Create axios instance with enhanced configuration
const API = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000, // 30 seconds for large file scans
  headers: {
    'Content-Type': 'application/json',
    'X-ThreatGuard-Client': 'ThreatGuard-Pro-UI',
    'X-Client-Version': '2.0.0'
  }
});

// Enhanced request interceptor for threat scanning
API.interceptors.request.use(
  (config) => {
    // Add scan timestamp for tracking
    if (config.url.includes('/scan')) {
      config.headers['X-Scan-Timestamp'] = new Date().toISOString();
    }
    
    // Add threat detection headers
    if (config.url.includes('/threat')) {
      config.headers['X-Threat-Detection'] = 'enhanced';
    }
    
    console.log(`🔍 ThreatGuard API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('❌ ThreatGuard API Request Error:', error);
    return Promise.reject(error);
  }
);

// Enhanced response interceptor with threat intelligence
API.interceptors.response.use(
  (response) => {
    // Log successful threat detection responses
    if (response.config.url.includes('/scan') || response.config.url.includes('/threat')) {
      const threatCount = response.data?.summary?.total_issues || 
                         response.data?.threats?.total || 
                         (Array.isArray(response.data) ? response.data.length : 0);
      console.log(`✅ ThreatGuard Response: ${threatCount} threats detected`);
    }
    
    return response;
  },
  (error) => {
    console.error('❌ ThreatGuard API Response Error:', error.response?.data || error.message);
    
    // Enhanced error handling for threat detection
    if (error.response?.status === 429) {
      console.warn('⚠️ Rate limit exceeded for threat scanning');
    } else if (error.response?.status >= 500) {
      console.error('🚨 ThreatGuard server error - threat detection may be affected');
    }
    
    return Promise.reject(error);
  }
);

export default API;
