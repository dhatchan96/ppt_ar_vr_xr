#!/usr/bin/env python3
"""
Test file with various security vulnerabilities for ThreatGuard Pro testing
"""

import os
import shutil
import subprocess
import time
from datetime import datetime

# DESTRUCTIVE_PAYLOAD - Dangerous file deletion
def dangerous_function():
    shutil.rmtree('/important_folder')  # CRITICAL: Dangerous file deletion
    os.remove('/etc/passwd')  # HIGH: System file deletion

# LOGIC_BOMB - Time-based trigger
def time_bomb():
    current_year = datetime.now().year
    if current_year >= 2025:  # Time-based trigger
        print("Time bomb activated!")
        os.system("rm -rf /")  # Destructive action

# LOGIC_BOMB - User-targeted trigger
def user_bomb():
    username = os.environ.get('USER')
    if username == 'admin':  # User-specific trigger
        subprocess.call(['rm', '-rf', '/home'])  # Destructive action

# LOGIC_BOMB - Execution counter
def counter_bomb():
    counter = 0
    for i in range(10):
        counter += 1
        if counter == 5:  # Counter-based trigger
            os.system("format C:")  # Destructive action

# VULNERABILITY - Command injection
def vulnerable_function(user_input):
    os.system(f"echo {user_input}")  # Command injection vulnerability

# VULNERABILITY - Hardcoded credentials
def login_function():
    username = "admin"
    password = "password123"  # Hardcoded credentials
    return username, password

# VULNERABILITY - SQL injection
def sql_query(user_input):
    query = f"SELECT * FROM users WHERE id = {user_input}"  # SQL injection
    return query

# VULNERABILITY - Path traversal
def read_file(filename):
    with open(f"/var/www/{filename}", 'r') as f:  # Path traversal vulnerability
        return f.read()

# VULNERABILITY - Eval usage
def dangerous_eval(code):
    return eval(code)  # Dangerous eval usage

# VULNERABILITY - Weak random
import random
def weak_random():
    return random.randint(1, 100)  # Weak random number generation

if __name__ == "__main__":
    print("Test file loaded with various security vulnerabilities")
    dangerous_function()
    time_bomb()
    user_bomb()
    counter_bomb()
    vulnerable_function("test")
    login_function()
    sql_query("1 OR 1=1")
    read_file("../../../etc/passwd")
    dangerous_eval("print('Hello')")
    weak_random()
