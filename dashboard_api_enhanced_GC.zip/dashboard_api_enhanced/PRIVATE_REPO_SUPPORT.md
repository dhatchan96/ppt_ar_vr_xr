# Private GitHub Repository Support

## Overview

ThreatGuard Pro now supports scanning private GitHub repositories in addition to public ones. This feature allows security professionals to analyze private codebases for logic bombs and security threats while maintaining proper authentication and security.

## Features Added

### 1. GitHub Token Authentication
- **Backend Support**: Updated API endpoint to accept GitHub Personal Access Tokens
- **Frontend Integration**: Added secure token input with password masking
- **Error Handling**: Comprehensive error handling for authentication failures
- **Security**: Tokens are not stored and are cleared after each scan

### 2. Enhanced User Experience
- **Smart Detection**: Automatically detects when a private repository requires authentication
- **Progressive Disclosure**: Token input only appears when needed (401 errors)
- **Clear Guidance**: Provides links to GitHub token creation page
- **Visual Feedback**: Different UI states for public vs private repositories

## How It Works

### 1. Public Repository Flow
1. User enters GitHub URL
2. System attempts to clone without authentication
3. If successful, proceeds with scan
4. Results displayed normally

### 2. Private Repository Flow
1. User enters GitHub URL
2. System attempts to clone without authentication
3. If 401 error received, shows token input UI
4. User enters GitHub Personal Access Token
5. System retries with authentication
6. Results displayed with "(Private Repo)" indicator

## Technical Implementation

### Backend Changes

#### Enhanced API Endpoint
```python
@app.route('/api/scan/github', methods=['POST'])
def scan_github_repository():
    github_url = data.get('github_url')
    github_token = data.get('github_token')  # New parameter
    
    # Clone with authentication if token provided
    if github_token:
        clone_url = f"https://{github_token}@github.com/{owner}/{repo}.git"
    else:
        clone_url = github_url
```

#### Error Handling
- **401 Errors**: Authentication failed - prompts for token
- **404 Errors**: Repository not found or access denied
- **Network Errors**: Clear error messages with suggestions

### Frontend Changes

#### State Management
```javascript
const [githubToken, setGithubToken] = useState('');
const [showTokenInput, setShowTokenInput] = useState(false);
```

#### Conditional UI
- Token input only appears when 401 error is received
- Secure password field for token input
- Clear visual indicators for private repositories

## Security Considerations

### Token Handling
- **No Storage**: Tokens are never stored on the server
- **Memory Only**: Tokens exist only in memory during scan
- **Automatic Cleanup**: Tokens are cleared after each scan
- **Secure Transmission**: Tokens sent over HTTPS only

### Repository Access
- **Minimal Scope**: Only requires 'repo' scope for repository access
- **Temporary Access**: Access only during scan duration
- **No Persistence**: No long-term access to repositories

### Error Security
- **No Token Exposure**: Error messages never expose token content
- **Generic Messages**: Authentication errors are generic to prevent information leakage

## User Guide

### Creating a GitHub Token

1. **Navigate to GitHub Settings**
   - Go to https://github.com/settings/tokens
   - Click "Generate new token (classic)"

2. **Configure Token**
   - **Note**: "ThreatGuard Pro Security Scan"
   - **Expiration**: Choose appropriate expiration (recommend 30 days)
   - **Scopes**: Select "repo" for full repository access

3. **Copy Token**
   - Copy the generated token immediately
   - Store securely (you won't see it again)

### Using Private Repository Scan

1. **Enter Repository URL**
   - Use format: `https://github.com/owner/repository`
   - Works for both public and private repositories

2. **Handle Authentication**
   - For public repos: Scan proceeds automatically
   - For private repos: Enter your GitHub token when prompted

3. **Review Results**
   - Results show "(Private Repo)" indicator for private repositories
   - Same comprehensive threat analysis as public repositories

## Error Handling

### Common Scenarios

#### Authentication Failed (401)
- **Cause**: Invalid or expired token
- **Solution**: Generate new token with correct permissions
- **UI**: Shows token input with error message

#### Repository Not Found (404)
- **Cause**: Repository doesn't exist or no access
- **Solution**: Check repository URL and permissions
- **UI**: Shows clear error message

#### Network Issues
- **Cause**: Internet connectivity or GitHub API issues
- **Solution**: Check network connection and try again
- **UI**: Shows generic network error message

### Error Messages

| Error Type | Message | Action Required |
|------------|---------|-----------------|
| 401 | Authentication failed. Please check your GitHub token. | Enter valid token |
| 404 | Repository not found or access denied. | Check URL and permissions |
| Network | Failed to connect to GitHub. | Check internet connection |
| Timeout | Repository too large or slow connection. | Try smaller repository |

## Best Practices

### Token Management
- **Use Short Expiration**: Set tokens to expire in 30 days or less
- **Minimal Scope**: Only grant 'repo' access, not full account access
- **Regular Rotation**: Generate new tokens periodically
- **Secure Storage**: Store tokens securely, not in plain text files

### Repository Access
- **Verify Permissions**: Ensure token has access to target repository
- **Test with Public First**: Test the feature with public repositories
- **Monitor Usage**: Check GitHub token usage in account settings

### Security Scanning
- **Scan Regularly**: Schedule regular scans for critical repositories
- **Review Results**: Carefully review all detected threats
- **Follow Up**: Address high-priority threats immediately

## Troubleshooting

### Token Issues
1. **Token Not Working**
   - Verify token has 'repo' scope
   - Check token expiration date
   - Ensure token has access to target repository

2. **Authentication Errors**
   - Generate new token with correct permissions
   - Verify repository URL is correct
   - Check if repository is accessible with token

### Repository Issues
1. **Private Repository Not Found**
   - Verify repository exists and is accessible
   - Check token has correct permissions
   - Ensure repository is not archived or deleted

2. **Large Repository Timeout**
   - Try scanning specific branches or directories
   - Check network connection speed
   - Consider scanning smaller repositories first

## API Reference

### Request Format
```json
{
  "scan_id": "github_scan_123",
  "scan_type": "github",
  "project_id": "github-scan-1234567890",
  "project_name": "GitHub Repository Scan",
  "timestamp": "2025-01-30T10:00:00Z",
  "github_url": "https://github.com/owner/repository",
  "github_token": "ghp_xxxxxxxxxxxxxxxxxxxx",  // Optional
  "ait_tag": "AIT",
  "spk_tag": "SPK-SECURITY",
  "repo_name": "github-repo"
}
```

### Response Format
```json
{
  "scan_id": "github_scan_123",
  "project_id": "github-scan-1234567890",
  "summary": {
    "total_issues": 5,
    "logic_bomb_risk_score": 75
  },
  "github_info": {
    "owner": "owner",
    "repo": "repository",
    "url": "https://github.com/owner/repository",
    "files_count": 150,
    "is_private": true,
    "auth_used": true
  }
}
```

## Future Enhancements

### Planned Features
1. **Token Management**: Secure token storage and management
2. **Branch Selection**: Scan specific branches or commits
3. **Incremental Scans**: Only scan changed files
4. **Webhook Integration**: Automatic scanning on repository updates
5. **Organization Support**: Scan repositories across organizations

### Security Improvements
1. **Token Encryption**: Encrypt tokens in transit and storage
2. **Audit Logging**: Log all repository access attempts
3. **Rate Limiting**: Implement GitHub API rate limiting
4. **Access Control**: Role-based access to private repositories

## Conclusion

Private repository support significantly enhances ThreatGuard Pro's capabilities by allowing security professionals to scan their private codebases for logic bombs and security threats. The implementation maintains high security standards while providing a seamless user experience.

The feature supports:
- ✅ Public GitHub repositories
- ✅ Private GitHub repositories with authentication
- ✅ Secure token handling
- ✅ Comprehensive error handling
- ✅ Clear user guidance
- ✅ Integration with existing threat detection

This enhancement makes ThreatGuard Pro a complete solution for both public and private repository security scanning. 