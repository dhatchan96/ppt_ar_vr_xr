#!/usr/bin/env python3
"""
Test script for private GitHub repository scan functionality
"""

import requests
import json
import time
import os

def test_private_repo_scan(github_url, github_token=None):
    """Test private GitHub repository scanning"""
    
    # Test data
    test_payload = {
        "scan_id": "test_private_scan_001",
        "scan_type": "github",
        "project_id": "test-private-github-scan",
        "project_name": "Test Private GitHub Repository Scan",
        "timestamp": "2025-01-30T10:00:00Z",
        "github_url": github_url,
        "ait_tag": "AIT",
        "spk_tag": "SPK-SECURITY",
        "repo_name": "private-github-repo"
    }
    
    # Add token if provided
    if github_token:
        test_payload["github_token"] = github_token
        print(f"🔐 Testing with authentication token")
    else:
        print(f"🌐 Testing without authentication token")
    
    try:
        print("🧪 Testing private GitHub repository scan functionality...")
        print(f"📦 Target repository: {github_url}")
        
        # Make the API call
        response = requests.post(
            "http://localhost:5000/api/scan/github",
            json=test_payload,
            timeout=60  # 60 seconds timeout for GitHub clone
        )
        
        print(f"📊 Response status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Private repository scan completed successfully!")
            print(f"📁 Files scanned: {result.get('files_scanned', 0)}")
            print(f"🚨 Threats found: {result.get('summary', {}).get('total_issues', 0)}")
            print(f"🎯 Risk score: {result.get('summary', {}).get('logic_bomb_risk_score', 0)}/100")
            
            if 'github_info' in result:
                github_info = result['github_info']
                print(f"🔗 Repository: {github_info.get('owner', 'unknown')}/{github_info.get('repo', 'unknown')}")
                print(f"📊 Files count: {github_info.get('files_count', 0)}")
                print(f"🔒 Private repo: {github_info.get('is_private', False)}")
                print(f"🔐 Auth used: {github_info.get('auth_used', False)}")
            
            return True
        elif response.status_code == 401:
            print("❌ Authentication failed - token required or invalid")
            print("💡 This is expected for private repositories without valid token")
            return False
        elif response.status_code == 404:
            print("❌ Repository not found or access denied")
            return False
        else:
            print(f"❌ Scan failed with status {response.status_code}")
            print(f"Error: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure the server is running on http://localhost:5000")
        return False
    except requests.exceptions.Timeout:
        print("❌ Request timed out. The repository might be too large or the server is slow.")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return False

def test_public_repo_scan():
    """Test public repository scanning (should work without token)"""
    return test_private_repo_scan("https://github.com/octocat/Hello-World")

def test_private_repo_without_token():
    """Test private repository without token (should fail with 401)"""
    # Use a known private repository URL (replace with actual private repo)
    private_repo_url = "https://github.com/username/private-repo"  # Replace with actual private repo
    return test_private_repo_scan(private_repo_url)

def test_private_repo_with_token():
    """Test private repository with token (requires valid token)"""
    # Get token from environment variable for security
    github_token = os.getenv('GITHUB_TOKEN')
    if not github_token:
        print("⚠️  GITHUB_TOKEN environment variable not set")
        print("💡 Set it with: export GITHUB_TOKEN='your_token_here'")
        return False
    
    # Use a known private repository URL (replace with actual private repo)
    private_repo_url = "https://github.com/username/private-repo"  # Replace with actual private repo
    return test_private_repo_scan(private_repo_url, github_token)

def test_server_health():
    """Test if the server is running"""
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code == 200:
            print("✅ Server is running and healthy")
            return True
        else:
            print(f"❌ Server responded with status {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Server is not running on http://localhost:5000")
        return False
    except Exception as e:
        print(f"❌ Error checking server health: {str(e)}")
        return False

def main():
    print("🚀 ThreatGuard Pro - Private Repository Scan Test")
    print("=" * 60)
    
    # First check if server is running
    if not test_server_health():
        print("\n❌ Cannot proceed without a running server.")
        print("Please start the server with: python dashboard_api_enhanced.py")
        return
    
    print("\n" + "=" * 60)
    print("🧪 Testing Public Repository (should work without token)")
    test_public_repo_scan()
    
    print("\n" + "=" * 60)
    print("🧪 Testing Private Repository without Token (should fail with 401)")
    test_private_repo_without_token()
    
    print("\n" + "=" * 60)
    print("🧪 Testing Private Repository with Token")
    test_private_repo_with_token()
    
    print("\n" + "=" * 60)
    print("📋 Test Summary")
    print("✅ Public repository scanning")
    print("✅ Private repository authentication handling")
    print("✅ Error handling for unauthorized access")
    print("✅ Token-based authentication")
    print("\n🏁 All tests completed")

if __name__ == "__main__":
    main() 