// Shared in-memory arrays for rooms and bookings
let rooms = [];
let bookings = [];

module.exports = { rooms, bookings };
