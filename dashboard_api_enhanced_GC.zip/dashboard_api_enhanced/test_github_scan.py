#!/usr/bin/env python3
"""
Test script for GitHub repository scan functionality
"""

import requests
import json
import time

def test_github_scan():
    """Test the GitHub repository scan endpoint"""
    
    # Test data
    test_payload = {
        "scan_id": "test_github_scan_001",
        "scan_type": "github",
        "project_id": "test-github-scan",
        "project_name": "Test GitHub Repository Scan",
        "timestamp": "2025-01-30T10:00:00Z",
        "github_url": "https://github.com/octocat/Hello-World",
        "ait_tag": "AIT",
        "spk_tag": "SPK-SECURITY",
        "repo_name": "github-repo"
    }
    
    try:
        print("🧪 Testing GitHub repository scan functionality...")
        print(f"📦 Target repository: {test_payload['github_url']}")
        
        # Make the API call
        response = requests.post(
            "http://localhost:5000/api/scan/github",
            json=test_payload,
            timeout=60  # 60 seconds timeout for GitHub clone
        )
        
        print(f"📊 Response status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print("✅ GitHub scan completed successfully!")
            print(f"📁 Files scanned: {result.get('files_scanned', 0)}")
            print(f"🚨 Threats found: {result.get('summary', {}).get('total_issues', 0)}")
            print(f"🎯 Risk score: {result.get('summary', {}).get('logic_bomb_risk_score', 0)}/100")
            
            if 'github_info' in result:
                github_info = result['github_info']
                print(f"🔗 Repository: {github_info.get('owner', 'unknown')}/{github_info.get('repo', 'unknown')}")
                print(f"📊 Files count: {github_info.get('files_count', 0)}")
            
            return True
        else:
            print(f"❌ GitHub scan failed with status {response.status_code}")
            print(f"Error: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to server. Make sure the server is running on http://localhost:5000")
        return False
    except requests.exceptions.Timeout:
        print("❌ Request timed out. The repository might be too large or the server is slow.")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        return False

def test_server_health():
    """Test if the server is running"""
    try:
        response = requests.get("http://localhost:5000/api/health", timeout=5)
        if response.status_code == 200:
            print("✅ Server is running and healthy")
            return True
        else:
            print(f"❌ Server responded with status {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Server is not running on http://localhost:5000")
        return False
    except Exception as e:
        print(f"❌ Error checking server health: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 ThreatGuard Pro - GitHub Scan Test")
    print("=" * 50)
    
    # First check if server is running
    if test_server_health():
        print("\n" + "=" * 50)
        # Test GitHub scan functionality
        test_github_scan()
    else:
        print("\n❌ Cannot proceed without a running server.")
        print("Please start the server with: python dashboard_api_enhanced.py")
    
    print("\n" + "=" * 50)
    print("�� Test completed") 