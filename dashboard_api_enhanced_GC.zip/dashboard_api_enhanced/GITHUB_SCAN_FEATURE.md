# GitHub Repository Scan Feature

## Overview

The ThreatGuard Pro dashboard now includes a new GitHub repository upload functionality that allows users to scan GitHub repositories for logic bombs and security threats directly from the command center page.

## Features Added

### 1. Backend API Endpoint
- **Endpoint**: `POST /api/scan/github`
- **Location**: `dashboard_api_enhanced.py`
- **Functionality**: 
  - Clones GitHub repositories automatically
  - Scans all files for logic bombs and security threats
  - Supports public repositories
  - Handles large repositories with file size limits
  - Generates comprehensive threat reports

### 2. Frontend Integration

#### JavaScript Version (`enhanced_threatguard_dashboard (1).js`)
- Added GitHub URL input field
- Added "Scan GitHub Repo" button
- Integrated with existing scan workflow
- Real-time status updates during scanning

#### React Version (`ThreatGuardDashboard.js`)
- Added GitHub repository upload section
- Separate UI component for GitHub scanning
- Enhanced with hierarchical tagging (AIT → SPK → REPO)
- Improved user experience with loading states

### 3. API Client Updates
- **File**: `api_js_enhanced.js` and `security_scanner_dashboard_react/src/api.js`
- Added `scanGithubRepository()` method
- Enhanced error handling for GitHub-specific issues
- Proper timeout handling for large repositories

## How It Works

### 1. User Interface
1. User enters a GitHub repository URL in the format: `https://github.com/owner/repository`
2. Clicks the "📦 Scan GitHub Repo" button
3. System validates the URL format
4. Shows loading state during scan

### 2. Backend Processing
1. **URL Validation**: Validates GitHub URL format using regex
2. **Repository Cloning**: Uses `git clone` to download the repository
3. **File Processing**: 
   - Walks through all files in the repository
   - Skips binary files and files larger than 1MB
   - Extracts text content for analysis
4. **Threat Detection**: 
   - Applies existing logic bomb detection rules
   - Performs comprehensive security analysis
   - Generates threat intelligence reports
5. **Cleanup**: Removes temporary cloned repository

### 3. Results Display
- Shows number of files scanned
- Displays threat count and risk score
- Provides detailed threat breakdown
- Integrates with existing dashboard metrics

## Technical Implementation

### Backend Changes

#### New API Endpoint
```python
@app.route('/api/scan/github', methods=['POST'])
def scan_github_repository():
    """Scan GitHub repository for logic bombs and security threats"""
```

#### Key Features
- **Git Integration**: Uses `subprocess.run()` to clone repositories
- **File Type Detection**: Automatically detects file languages based on extensions
- **Error Handling**: Comprehensive error handling for network issues, invalid URLs, etc.
- **Resource Management**: Proper cleanup of temporary files

### Frontend Changes

#### State Management
```javascript
const [githubUrl, setGithubUrl] = useState('');
const [scanningGithub, setScanningGithub] = useState(false);
```

#### UI Components
- GitHub URL input field with validation
- Scan button with loading states
- Error handling and user feedback
- Integration with existing toast notifications

## Usage Examples

### Basic Usage
1. Navigate to the ThreatGuard Pro dashboard
2. Find the "GitHub Repository Scanner" section
3. Enter a GitHub URL: `https://github.com/username/repository`
4. Click "📦 Scan GitHub Repo"
5. Wait for the scan to complete
6. Review the results in the dashboard

### Supported URL Formats
- `https://github.com/owner/repository`
- `https://github.com/owner/repository.git`
- `https://github.com/owner/repository/`

## Error Handling

### Common Issues
1. **Invalid URL Format**: Shows error message with correct format
2. **Repository Not Found**: Handles 404 errors gracefully
3. **Large Repositories**: Implements timeout and file size limits
4. **Network Issues**: Provides clear error messages
5. **Permission Issues**: Handles private repository access errors

### User Feedback
- Loading states during scan
- Progress indicators for large repositories
- Clear error messages with suggestions
- Success notifications with scan summary

## Security Considerations

### Repository Access
- Only supports public repositories
- No authentication required for basic functionality
- Secure handling of temporary files

### File Processing
- Skips binary files to prevent issues
- Limits file size to 1MB per file
- Handles encoding issues gracefully
- Sanitizes file paths for security

### Data Handling
- Temporary files are cleaned up after scan
- No persistent storage of repository content
- Secure error handling without exposing sensitive information

## Performance Optimizations

### Repository Size Handling
- File size limits (1MB per file)
- Timeout handling for large repositories
- Progress indicators for user feedback

### Memory Management
- Streams file content instead of loading all at once
- Cleans up temporary directories
- Efficient file type detection

## Integration with Existing Features

### Dashboard Metrics
- Integrates with existing threat metrics
- Updates logic bomb risk scores
- Maintains hierarchical tagging (AIT → SPK → REPO)

### Threat Intelligence
- Uses existing threat detection rules
- Generates comprehensive threat reports
- Integrates with VS Code Copilot functionality

### File Management
- Saves scanned files to `uploaded_projects/` structure
- Maintains compatibility with existing file scan features
- Supports VS Code remediation workflows

## Testing

### Test Script
A test script is provided (`test_github_scan.py`) to verify functionality:
```bash
python test_github_scan.py
```

### Test Cases
- Valid GitHub URL scanning
- Invalid URL handling
- Large repository timeout
- Network error handling
- File processing edge cases

## Future Enhancements

### Planned Features
1. **Private Repository Support**: Add authentication for private repos
2. **Branch Selection**: Allow scanning specific branches
3. **Incremental Scans**: Only scan changed files
4. **Webhook Integration**: Automatic scanning on repository updates
5. **Advanced Filtering**: Filter by file types, directories, etc.

### Performance Improvements
1. **Parallel Processing**: Scan multiple files simultaneously
2. **Caching**: Cache repository metadata
3. **Streaming**: Stream large files instead of loading entirely
4. **Background Jobs**: Move scanning to background processes

## Troubleshooting

### Common Issues
1. **Server Not Running**: Ensure `python dashboard_api_enhanced.py` is running
2. **Git Not Installed**: Install Git on the server
3. **Network Issues**: Check internet connectivity
4. **Permission Errors**: Ensure write permissions for temporary directories

### Debug Information
- Check server logs for detailed error messages
- Use the test script to verify functionality
- Monitor network requests in browser developer tools

## Conclusion

The GitHub repository scan feature provides a powerful new capability for ThreatGuard Pro users to easily scan GitHub repositories for security threats. The implementation is robust, user-friendly, and integrates seamlessly with existing dashboard functionality.

The feature supports:
- ✅ Public GitHub repositories
- ✅ Comprehensive threat detection
- ✅ Real-time user feedback
- ✅ Integration with existing workflows
- ✅ Proper error handling and cleanup
- ✅ Performance optimizations for large repositories

This enhancement significantly improves the usability of ThreatGuard Pro for security professionals who need to quickly assess the security posture of GitHub repositories. 