"""
File Comparison Database Manager
Stores file comparison results for Python migration analysis
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class FileComparisonDB:
    """SQLite database manager for file comparison records"""
    
    def __init__(self, data_dir: str = "threatguard_data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "file_comparison.db"
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database for file comparisons"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create file_comparisons table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS file_comparisons (
                        id TEXT PRIMARY KEY,
                        comparison_name TEXT NOT NULL,
                        ait_tag TEXT,
                        spk_tag TEXT,
                        repo_name TEXT,
                        original_zip_path TEXT,
                        modified_zip_path TEXT,
                        comparison_result TEXT,  -- JSON string with diff results
                        total_files_compared INTEGER DEFAULT 0,
                        total_files_changed INTEGER DEFAULT 0,
                        total_lines_added INTEGER DEFAULT 0,
                        total_lines_removed INTEGER DEFAULT 0,
                        created_at TEXT,
                        updated_at TEXT,
                        created_by TEXT,
                        metadata TEXT  -- JSON object as string
                    )
                ''')
                
                # Create indexes for better performance
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_file_comparisons_created_at 
                    ON file_comparisons(created_at DESC)
                ''')
                
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_file_comparisons_ait_spk_repo 
                    ON file_comparisons(ait_tag, spk_tag, repo_name)
                ''')
                
                conn.commit()
                logger.info("File Comparison SQLite database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize File Comparison SQLite database: {e}")
    
    def save_comparison(self, comparison_data: Dict[str, Any]) -> bool:
        """Save a file comparison record to SQLite"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                metadata_json = json.dumps(comparison_data.get('metadata', {}))
                comparison_result_json = json.dumps(comparison_data.get('comparison_result', {}))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO file_comparisons 
                    (id, comparison_name, ait_tag, spk_tag, repo_name, original_zip_path, 
                     modified_zip_path, comparison_result, total_files_compared, total_files_changed,
                     total_lines_added, total_lines_removed, created_at, updated_at, created_by, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    comparison_data.get('id'),
                    comparison_data.get('comparison_name'),
                    comparison_data.get('ait_tag'),
                    comparison_data.get('spk_tag'),
                    comparison_data.get('repo_name'),
                    comparison_data.get('original_zip_path'),
                    comparison_data.get('modified_zip_path'),
                    comparison_result_json,
                    comparison_data.get('total_files_compared', 0),
                    comparison_data.get('total_files_changed', 0),
                    comparison_data.get('total_lines_added', 0),
                    comparison_data.get('total_lines_removed', 0),
                    comparison_data.get('created_at'),
                    comparison_data.get('updated_at'),
                    comparison_data.get('created_by'),
                    metadata_json
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving file comparison to SQLite: {e}")
            return False
    
    def get_comparison(self, comparison_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific file comparison by ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM file_comparisons 
                    WHERE id = ?
                ''', (comparison_id,))
                
                row = cursor.fetchone()
                if row:
                    comparison = dict(row)
                    # Convert JSON strings back to objects
                    comparison['comparison_result'] = json.loads(comparison['comparison_result'] or '{}')
                    comparison['metadata'] = json.loads(comparison['metadata'] or '{}')
                    return comparison
                return None
        except Exception as e:
            logger.error(f"Error getting file comparison from SQLite: {e}")
            return None
    
    def get_all_comparisons(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get all file comparisons with optional filtering"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                query = "SELECT * FROM file_comparisons WHERE 1=1"
                params = []
                
                if filters:
                    if 'ait_tag' in filters and filters['ait_tag']:
                        query += " AND ait_tag = ?"
                        params.append(filters['ait_tag'])
                    
                    if 'spk_tag' in filters and filters['spk_tag']:
                        query += " AND spk_tag = ?"
                        params.append(filters['spk_tag'])
                    
                    if 'repo_name' in filters and filters['repo_name']:
                        query += " AND repo_name = ?"
                        params.append(filters['repo_name'])
                    
                    if 'created_by' in filters and filters['created_by']:
                        query += " AND created_by = ?"
                        params.append(filters['created_by'])
                
                query += " ORDER BY created_at DESC"
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                comparisons = []
                for row in rows:
                    comparison = dict(row)
                    # Convert JSON strings back to objects
                    comparison['comparison_result'] = json.loads(comparison['comparison_result'] or '{}')
                    comparison['metadata'] = json.loads(comparison['metadata'] or '{}')
                    comparisons.append(comparison)
                
                return comparisons
        except Exception as e:
            logger.error(f"Error getting file comparisons from SQLite: {e}")
            return []
    
    def delete_comparison(self, comparison_id: str) -> bool:
        """Delete a file comparison record"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM file_comparisons WHERE id = ?', (comparison_id,))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error deleting file comparison from SQLite: {e}")
            return False

# Global file comparison database instance
file_comparison_db = FileComparisonDB()

