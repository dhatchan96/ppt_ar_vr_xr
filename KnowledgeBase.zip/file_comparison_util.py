#!/usr/bin/env python3
"""
File Comparison Utility
Compares two project ZIP files and generates diff results
"""

import zipfile
import tempfile
import os
import difflib
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

class FileComparisonUtil:
    """Utility for comparing two ZIP files and generating diffs"""
    
    def __init__(self):
        pass
    
    def extract_zip(self, zip_path: str, extract_to: Path) -> Dict[str, str]:
        """Extract ZIP file and return mapping of relative paths to file contents"""
        file_contents = {}
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Get list of file names
                file_list = zip_ref.namelist()
                
                # Extract all files
                zip_ref.extractall(extract_to)
                
                # Read file contents
                for file_path in file_list:
                    # Skip directories
                    if file_path.endswith('/'):
                        continue
                    
                    full_path = extract_to / file_path
                    if full_path.exists() and full_path.is_file():
                        try:
                            # Try to read as text
                            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                                file_contents[file_path] = content
                        except Exception as e:
                            logger.warning(f"Could not read file {file_path} as text: {e}")
                            # Store as binary indicator
                            file_contents[file_path] = None
        
        except Exception as e:
            logger.error(f"Error extracting ZIP file {zip_path}: {e}")
            raise
        
        return file_contents
    
    def compare_files(self, original_contents: Dict[str, str], modified_contents: Dict[str, str]) -> Dict[str, Any]:
        """Compare two file content dictionaries and generate diff results"""
        results = {
            'files_compared': 0,
            'files_changed': [],
            'files_added': [],
            'files_removed': [],
            'total_lines_added': 0,
            'total_lines_removed': 0,
            'file_diffs': {}
        }
        
        # Get all unique file paths
        all_files = set(original_contents.keys()) | set(modified_contents.keys())
        
        for file_path in all_files:
            original_content = original_contents.get(file_path)
            modified_content = modified_contents.get(file_path)
            
            # Skip binary files
            if original_content is None or modified_content is None:
                continue
            
            results['files_compared'] += 1
            
            # File was added
            if original_content is None and modified_content is not None:
                results['files_added'].append(file_path)
                modified_lines = modified_content.splitlines()
                results['total_lines_added'] += len(modified_lines)
                results['file_diffs'][file_path] = {
                    'status': 'added',
                    'added_lines': len(modified_lines),
                    'removed_lines': 0,
                    'diff': self._generate_unified_diff(None, modified_content)
                }
            
            # File was removed
            elif original_content is not None and modified_content is None:
                results['files_removed'].append(file_path)
                original_lines = original_content.splitlines()
                results['total_lines_removed'] += len(original_lines)
                results['file_diffs'][file_path] = {
                    'status': 'removed',
                    'added_lines': 0,
                    'removed_lines': len(original_lines),
                    'diff': self._generate_unified_diff(original_content, None)
                }
            
            # File exists in both - compare content
            elif original_content != modified_content:
                results['files_changed'].append(file_path)
                
                # Generate diff
                diff_result = self._generate_unified_diff(original_content, modified_content)
                
                # Count lines
                original_lines = original_content.splitlines()
                modified_lines = modified_content.splitlines()
                
                added = sum(1 for line in diff_result['lines'] if line['type'] == 'added')
                removed = sum(1 for line in diff_result['lines'] if line['type'] == 'removed')
                
                results['total_lines_added'] += added
                results['total_lines_removed'] += removed
                
                results['file_diffs'][file_path] = {
                    'status': 'modified',
                    'added_lines': added,
                    'removed_lines': removed,
                    'diff': diff_result
                }
        
        return results
    
    def _generate_unified_diff(self, original_content: Optional[str], modified_content: Optional[str]) -> Dict[str, Any]:
        """Generate unified diff between two file contents"""
        if original_content is None:
            # File was added
            lines = modified_content.splitlines(keepends=True)
            diff_lines = []
            for i, line in enumerate(lines, 1):
                diff_lines.append({
                    'line_number': i,
                    'type': 'added',
                    'content': line.rstrip('\n\r')
                })
            return {
                'lines': diff_lines,
                'format': 'unified'
            }
        
        if modified_content is None:
            # File was removed
            lines = original_content.splitlines(keepends=True)
            diff_lines = []
            for i, line in enumerate(lines, 1):
                diff_lines.append({
                    'line_number': i,
                    'type': 'removed',
                    'content': line.rstrip('\n\r')
                })
            return {
                'lines': diff_lines,
                'format': 'unified'
            }
        
        # Both exist - generate diff using SequenceMatcher
        original_lines = original_content.splitlines(keepends=False)  # Don't keep line endings
        modified_lines = modified_content.splitlines(keepends=False)
        
        # Use SequenceMatcher to get opcodes
        matcher = difflib.SequenceMatcher(None, original_lines, modified_lines)
        diff_lines = []
        mod_line_num = 0
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                # Unchanged lines - show as context
                for line_num in range(i1, i2):
                    mod_line_num += 1
                    diff_lines.append({
                        'line_number': mod_line_num,
                        'type': 'context',
                        'content': original_lines[line_num]
                    })
            elif tag == 'delete':
                # Lines only in original (removed)
                for line_num in range(i1, i2):
                    diff_lines.append({
                        'line_number': mod_line_num + 1,
                        'type': 'removed',
                        'content': original_lines[line_num]
                    })
            elif tag == 'insert':
                # Lines only in modified (added)
                for line_num in range(j1, j2):
                    mod_line_num += 1
                    diff_lines.append({
                        'line_number': mod_line_num,
                        'type': 'added',
                        'content': modified_lines[line_num]
                    })
            elif tag == 'replace':
                # Lines changed
                # First show removed lines
                for line_num in range(i1, i2):
                    diff_lines.append({
                        'line_number': mod_line_num + 1,
                        'type': 'removed',
                        'content': original_lines[line_num]
                    })
                # Then show added lines
                for line_num in range(j1, j2):
                    mod_line_num += 1
                    diff_lines.append({
                        'line_number': mod_line_num,
                        'type': 'added',
                        'content': modified_lines[line_num]
                    })
        
        return {
            'lines': diff_lines,
            'format': 'unified'
        }
    
    def compare_zip_files(self, original_zip_path: str, modified_zip_path: str) -> Dict[str, Any]:
        """Compare two ZIP files and return detailed diff results"""
        original_dir = None
        modified_dir = None
        
        try:
            # Create temporary directories for extraction
            original_dir = tempfile.mkdtemp(prefix='file_compare_original_')
            modified_dir = tempfile.mkdtemp(prefix='file_compare_modified_')
            
            # Extract ZIP files
            logger.info(f"Extracting original ZIP: {original_zip_path}")
            original_contents = self.extract_zip(original_zip_path, Path(original_dir))
            
            logger.info(f"Extracting modified ZIP: {modified_zip_path}")
            modified_contents = self.extract_zip(modified_zip_path, Path(modified_dir))
            
            # Compare files
            logger.info("Comparing files...")
            comparison_result = self.compare_files(original_contents, modified_contents)
            
            return comparison_result
        
        finally:
            # Cleanup temporary directories
            import shutil
            if original_dir and os.path.exists(original_dir):
                try:
                    shutil.rmtree(original_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up original temp dir: {e}")
            
            if modified_dir and os.path.exists(modified_dir):
                try:
                    shutil.rmtree(modified_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up modified temp dir: {e}")

# Global file comparison utility instance
file_comparison_util = FileComparisonUtil()

