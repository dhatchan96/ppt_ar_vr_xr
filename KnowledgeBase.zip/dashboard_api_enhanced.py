#!/usr/bin/env python3

"""

ThreatGuard Pro - Enhanced Command Center Dashboard API

Advanced Threat Pattern Detection & Threat Intelligence Dashboard

Copyright 2025 - Enhanced with comprehensive security features

"""



from flask import Flask, request, jsonify, send_file

from flask_cors import CORS

import json

import os

import re

from datetime import datetime, timedelta

from typing import Dict, List, Any, Optional

import uuid

import tempfile

from pathlib import Path

import io

import zipfile

from dataclasses import dataclass

from urllib.parse import unquote

import logging

import time

import functools

import sqlite3

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



# Import our enhanced main threat detector components

from threatguard_main_enhanced import (

    LogicBombDetector, SecurityRule, ThreatShield, SecurityIssue,

    ThreatMetricsCalculator, ScanResult

)



# Import automated Copilot agent

from copilot_agent import start_copilot_agent, stop_copilot_agent, get_agent_status



# Enhanced vulnerability and wave management imports

from enhanced_vulnerability_api import vulnerability_api

from wave_manager import WaveManager

from health_monitoring import HealthMonitor



# Import admin data manager

from admin_data_manager import admin_data_manager

from job_manager import job_manager, JobStatus

from async_repo_scanner import async_repo_scanner

from config import settings

from diagnose_stuck_scans import ScanDiagnostic

from knowledge_base_manager import knowledge_base_manager



app = Flask(__name__)

CORS(app, origins=["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:3001", "http://127.0.0.1:3001"], supports_credentials=True)



# Initialize enhanced threat pattern detector

detector = LogicBombDetector()
# Reload detector data on startup to ensure we have the latest data
try:
    detector.issue_manager.load_issues()
    detector.load_scan_history()
    print("🔄 Startup reload: {} issues, {} scans loaded".format(
        len(detector.issue_manager.issues), 
        len(detector.scan_history)
    ))
except Exception as e:
    print("❌ Error during startup reload: {}".format(str(e)))





# Initialize new management systems

wave_manager = WaveManager()

health_monitor = HealthMonitor()



# Register new API blueprints

app.register_blueprint(vulnerability_api)



@dataclass

class ThreatPattern:

    """Advanced threat pattern for multi-language detection."""

    pattern_type: str

    description: str

    severity: str

    line_number: int

    code_snippet: str

    confidence: float

    language: str

    trigger_analysis: str = ""

    payload_analysis: str = ""



class AdvancedThreatPatternDetector:

    def __init__(self):

        self.threat_patterns = []

        self.supported_languages = {

            '.py': 'python', '.java': 'java', '.js': 'javascript', '.ts': 'typescript',

            '.cs': 'csharp', '.vb': 'vbnet', '.jsx': 'react', '.tsx': 'react_typescript',

            '.json': 'config', '.html': 'html', '.php': 'php', '.rb': 'ruby',

            '.go': 'golang', '.cpp': 'cpp', '.c': 'c', '.rs': 'rust'

        }

        self.init_threat_pattern_signatures()



    def init_threat_pattern_signatures(self):

        """Initialize comprehensive threat pattern signatures"""

        # Scheduled Threat (Time Bombs)

        self.scheduled_threat_patterns = [

            (r'if.*current_date\.year.*>=.*\d{4}', "Year-based trigger"),

            (r'if.*(?:date|datetime|time).*[><=].*\d{4}', "Date-based trigger"),

            (r'(?:datetime\.now|time\.time|Date\.now)\(\).*[><=].*\d+', "Time comparison trigger"),

            (r'if.*(?:month|day|year).*==.*\d+', "Calendar-based trigger"),

            (r'if.*current_time.*>.*\d+', "Timestamp-based trigger")

        ]

        

        # Targeted Attack (User Bombs)  

        self.targeted_attack_patterns = [

            (r'if.*(?:getuser|username|user|USER).*==.*["\'][^"\']+["\'].*:.*(?:delete|corrupt|destroy)', "User-specific trigger"),

            (r'if.*os\.environ\[["\'](?:USER|USERNAME)["\'].*==.*:.*(?:subprocess|system|exec)', "Environment user check"),

            (r'if.*whoami.*==.*["\'][^"\']+["\'].*:.*(?:rm|del|kill)', "Identity-based trigger")

        ]

        

        # Execution Trigger (Counter Bombs)

        self.execution_trigger_patterns = [

            (r'if.*counter.*==.*\d+', "Counter-based trigger"),

            (r'if.*(?:count|counter|iteration|exec_count)\s*[><=]\s*\d+', "Execution counter"),

            (r'if.*(?:attempts|tries|loops).*==.*\d+', "Attempt-based trigger"),

            (r'for.*range\(\d+\).*:.*(?:break|exit)', "Loop-based trigger"),

            (r'if.*attempts.*==.*\d+', "Attempt-based trigger")

        ]

        

        # System-Specific Threat (Environment Bombs)

        self.system_specific_threat_patterns = [

            (r'if.*(?:hostname|platform|gethostname).*==.*["\'][^"\']*["\'].*:.*(?:sys\.|os\.|subprocess)', "System-specific trigger"),

            (r'if.*(?:env|environment).*!=.*["\'][^"\']*["\'].*:.*(?:destroy|corrupt)', "Environment mismatch trigger"),

            (r'if.*socket\.gethostname.*==.*["\'][^"\']*["\'].*:.*(?:system|exec)', "Network hostname trigger")

        ]

        

        # Destructive payload detection (standalone destructive actions)

        self.payload_patterns = [

            (r'^[^#]*shutil\.rmtree\([^)]+\)', "Directory removal"),

            (r'^[^#]*os\.remove\([^)]+\)', "File removal"),

            (r'^[^#]*os\.system\([^)]*rm[^)]*\)', "System removal command"),

            (r'^[^#]*(?:subprocess\.call.*rm|system.*(?:del|rm)|rmdir.*\/s)', "File destruction"),

            (r'^[^#]*(?:format.*c:|mkfs|fdisk|dd.*if=)', "Disk formatting/destruction"),

            (r'^[^#]*(?:kill.*-9|taskkill.*\/f|killall|pkill)', "Process termination"),

            (r'^[^#]*(?:DROP\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM.*WHERE.*1=1)', "Database destruction")

        ]

        

        # Financial Fraud patterns

        self.financial_fraud_patterns = [

            (r'bitcoin.*address.*[13][a-km-zA-HJ-NP-Z1-9]{25,34}', "Bitcoin address detected"),

            (r'paypal\.me/[a-zA-Z0-9]+', "PayPal redirection"),

            (r'crypto.*wallet.*0x[a-fA-F0-9]{40}', "Crypto wallet address"),

            (r'transfer.*money.*(?:personal|admin|dev)', "Unauthorized money transfer"),

            (r'redirect.*payment', "Financial redirection detected")

        ]

        

        # Connection-Based Threat (Network Bombs)

        self.connection_based_threat_patterns = [

            (r'if.*(?:ping|connect|socket|urllib).*(?:fail|error|timeout).*:.*(?:delete|remove|destroy)', "Network failure trigger"),

            (r'if.*(?:requests\.get|urllib\.request).*(?:status_code|response).*!=.*200.*:.*(?:corrupt|delete)', "HTTP status trigger"),

            (r'if.*(?:socket\.connect|telnet|ssh).*(?:refused|timeout).*:.*(?:system|exec)', "Connection failure trigger")

        ]

        

        # Security Tech Debt patterns

        self.security_tech_debt_patterns = [

            (r'f["\'](?:SELECT|INSERT|UPDATE|DELETE).*\{[^}]*\}["\']', "SQL injection vulnerability"),

            (r'eval\s*\([^)]*\)', "Dangerous eval usage"),

            (r'(?:password|secret|api_key|access_token|private_key|auth_token)\s*=\s*["\'][^"\']+["\']', "Hardcoded secrets")

        ]



    def detect_language(self, filepath: str, content: str) -> str:

        _, ext = os.path.splitext(filepath.lower())

        return self.supported_languages.get(ext, 'unknown')



    def analyze_file(self, filepath: str) -> list:

        try:
            # Skip files likely to have false positives (same as LogicBombDetector)
            from pathlib import Path
            file_path_obj = Path(filepath)
            skip_extensions = ['.json', '.yaml', '.yml', '.xml', '.csv', '.txt', '.md', '.lock', '.sql', '.html', '.htm', '.log', '.css', '.js']
            
            # Check file extension and skip if in the list
            if file_path_obj.suffix.lower() in skip_extensions:
                print(f"⚠️ AdvancedDetector: Skipping {filepath} - file type likely to have false positives")
                return []
            
            # Skip library files and third-party dependencies
            library_patterns = [
                'jquery', 'bootstrap', 'angular', 'react', 'vue', 'lodash', 'underscore', 'moment',
                'axios', 'd3', 'chart', 'leaflet', 'openlayers', 'cesium', 'three', 'babylon',
                'socket.io', 'express', 'mongoose', 'sequelize', 'passport', 'bcrypt', 'jsonwebtoken',
                'multer', 'cors', 'helmet', 'compression', 'morgan', 'winston', 'nodemailer',
                'redis', 'elasticsearch', 'knex', 'bookshelf', 'waterline', 'sails', 'hapi',
                'koa', 'fastify', 'restify', 'loopback', 'feathers', 'adonis', 'nestjs',
                'webpack', 'babel', 'gulp', 'grunt', 'rollup', 'parcel', 'vite', 'esbuild',
                'typescript', 'flow', 'eslint', 'prettier', 'jest', 'mocha', 'chai', 'sinon',
                'cypress', 'puppeteer', 'playwright', 'selenium', 'karma', 'jasmine',
                'protractor', 'nightwatch', 'webdriver', 'testcafe', 'detox',
                'antd', 'material-ui', 'semantic-ui', 'bulma', 'tailwind', 'foundation',
                'pure', 'skeleton', 'milligram', 'spectre', 'tachyons', 'basscss',
                'normalize', 'reset', 'sanitize', 'modernizr', 'polyfill', 'shim',
                'min', 'minified', 'compressed', 'packed', 'bundle', 'vendor', 'lib',
                'node_modules', 'bower_components', 'vendor', 'third-party', 'external',
                'cdn', 'cdnjs', 'unpkg', 'jsdelivr', 'googleapis', 'cloudflare',
                'fontawesome', 'font-awesome', 'ionicons', 'material-icons', 'feather',
                'heroicons', 'lucide', 'phosphor', 'tabler', 'remix', 'eva',
                'prism', 'highlight', 'syntax', 'code', 'monaco', 'ace', 'codemirror',
                'tinymce', 'ckeditor', 'quill', 'froala', 'summernote', 'trumbowyg',
                'datatables', 'ag-grid', 'handsontable', 'tabulator', 'gridjs',
                'chart.js', 'd3', 'plotly', 'echarts', 'highcharts', 'amcharts',
                'leaflet', 'openlayers', 'mapbox', 'google-maps', 'here-maps',
                'socket.io', 'ws', 'sockjs', 'engine.io', 'primus', 'faye',
                'moment', 'dayjs', 'date-fns', 'luxon', 'chrono', 'timeago',
                'validator', 'joi', 'yup', 'ajv', 'zod', 'superstruct', 'io-ts',
                'ramda', 'lodash', 'underscore', 'immutable', 'mobx', 'rxjs',
                'redux', 'vuex', 'ngrx', 'zustand', 'jotai', 'recoil', 'valtio',
                'axios', 'fetch', 'request', 'got', 'node-fetch', 'ky', 'umi-request',
                'express', 'koa', 'fastify', 'hapi', 'restify', 'loopback', 'sails',
                'mongoose', 'sequelize', 'typeorm', 'prisma', 'waterline', 'bookshelf',
                'passport', 'jwt', 'oauth', 'auth0', 'firebase-auth', 'aws-cognito',
                'bcrypt', 'argon2', 'scrypt', 'pbkdf2', 'crypto', 'hash', 'encrypt',
                'multer', 'formidable', 'busboy', 'multiparty', 'connect-multiparty',
                'cors', 'helmet', 'compression', 'morgan', 'winston', 'pino', 'bunyan',
                'nodemailer', 'sendgrid', 'mailgun', 'ses', 'postmark', 'mandrill',
                'redis', 'memcached', 'ioredis', 'node-redis', 'redis-cluster',
                'elasticsearch', 'solr', 'lucene', 'algolia', 'swiftype', 'typesense',
                'webpack', 'rollup', 'parcel', 'vite', 'esbuild', 'swc', 'babel',
                'gulp', 'grunt', 'broccoli', 'brunch', 'fuse-box', 'systemjs',
                'typescript', 'flow', 'coffeescript', 'dart', 'clojurescript',
                'eslint', 'prettier', 'standard', 'xo', 'jshint', 'jslint', 'tslint',
                'jest', 'mocha', 'chai', 'sinon', 'ava', 'tape', 'tap', 'vitest',
                'cypress', 'puppeteer', 'playwright', 'selenium', 'webdriverio',
                'karma', 'jasmine', 'protractor', 'nightwatch', 'testcafe', 'detox'
            ]
            
            file_name_lower = file_path_obj.name.lower()
            if any(pattern in file_name_lower for pattern in library_patterns):
                print(f"⚠️ AdvancedDetector: Skipping {filepath} - appears to be a library/third-party file")
                return []

            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:

                content = f.read()

            language = self.detect_language(filepath, content)

            self.threat_patterns = []

            self._check_all_patterns(content, language, filepath)

            return self.threat_patterns

        except Exception:

            return []



    def _check_all_patterns(self, content: str, language: str, filepath: str):

        lines = content.split('\n')

        

        # Track which lines have been matched by specific threat types

        matched_lines = set()

        

        pattern_groups = [

            (self.scheduled_threat_patterns, "SCHEDULED_THREAT"),

            (self.targeted_attack_patterns, "TARGETED_ATTACK"), 

            (self.execution_trigger_patterns, "EXECUTION_TRIGGER"),

            (self.system_specific_threat_patterns, "SYSTEM_SPECIFIC_THREAT"),

            (self.financial_fraud_patterns, "FINANCIAL_FRAUD"),

            (self.connection_based_threat_patterns, "CONNECTION_BASED_THREAT"),

            (self.security_tech_debt_patterns, "SECURITY_TECH_DEBT"),

            (self.payload_patterns, "DESTRUCTIVE_PAYLOAD")  # Move destructive payload to end

        ]

        

        for pattern_list, threat_type in pattern_groups:

            for pattern, desc in pattern_list:

                for i, line in enumerate(lines, 1):

                    # Skip if line already matched by a more specific threat type

                    if i in matched_lines and threat_type == "DESTRUCTIVE_PAYLOAD":

                        continue

                    
                    
                    # ENHANCED FILTERING: Comprehensive false positive detection
                    stripped_line = line.strip()
                    line_lower = line.lower()
                    
                    # Skip lines that are clearly comments or documentation
                    if stripped_line.startswith(('#', '//', '/*', '*', '<!--')):
                        continue
                    
                    # Skip lines with docstrings
                    if '"""' in line or "'''" in line:
                        continue
                    
                    # Skip lines that are clearly function definitions
                    if stripped_line.startswith(('def ', 'import ', 'from ', 'class ', 'if __name__')):
                        continue
                    
                    # Skip lines that are clearly variable assignments or imports
                    if stripped_line.startswith(('import ', 'from ', 'import ', 'imports')):
                        continue
                    
                    # Enhanced print statement filtering - exclude ALL print statements for financial fraud
                    if stripped_line.startswith(('print(', 'logger.', 'log.', 'console.', 'print ')):
                        # For financial fraud rules, exclude print statements entirely
                        if threat_type == "FINANCIAL_FRAUD":
                            continue
                        # For other rules, only exclude if no dangerous keywords
                        if not any(keyword in line_lower for keyword in ['redirect', 'payment', 'wallet', 'fraud', 'money', 'transfer', 'bitcoin', 'crypto']):
                            continue
                    
                    # Enhanced comment filtering - exclude ALL comments for financial fraud
                    if threat_type == "FINANCIAL_FRAUD":
                        # For financial fraud, exclude any line that starts with # or contains only comments
                        if stripped_line.startswith('#'):
                            continue
                        # Also exclude lines that are mostly comments (after removing leading whitespace)
                        if line.strip().startswith('#'):
                            continue
                    
                    # Skip lines that are clearly error handling
                    if any(keyword in line_lower for keyword in ['except', 'finally', 'try:', 'catch']):
                        continue
                    
                    # Skip lines that are clearly configuration or constants
                    if any(keyword in line_lower for keyword in ['config', 'constant', 'setting', 'option']):
                        continue
                    
                    # Skip lines that are clearly test assertions
                    if any(keyword in line_lower for keyword in ['assert', 'expect', 'should', 'must']):
                        continue
                    
                    # Skip lines that are clearly documentation
                    if any(keyword in line_lower for keyword in ['note:', 'todo:', 'fixme:', 'hack:', 'warning:']):
                        continue
                    
                    # Skip lines with legitimate context keywords
                    legitimate_keywords = [
                        'test', 'mock', 'example', 'demo', 'config', 'setting', 'default', 
                        'cleanup', 'temp', 'cache', 'log', 'backup', 'placeholder', 'sample',
                        'debug', 'development', 'dev', 'staging', 'local', 'sandbox'
                    ]
                    if any(keyword in line_lower for keyword in legitimate_keywords):
                        continue
                    
                    # Skip lines that are just variable assignments without execution (but not for financial fraud)
                    if threat_type != "FINANCIAL_FRAUD":
                        if re.match(r'^\s*\w+\s*=\s*["\'][^"\']*["\']\s*$', line):
                            continue
                    
                    # Skip lines that are just string literals or comments in disguise
                    if re.match(r'^\s*["\'][^"\']*["\']\s*$', line):
                        continue
                    
                    # Skip HTML attributes and URLs (they're not code execution)
                    if any(attr in line_lower for attr in ['href=', 'src=', 'alt=', 'title=', 'content=', 'value=', 'placeholder=', 'data-']):
                        continue
                    
                    # Skip UI component keys and React/JSX attributes (not credentials)
                    if any(attr in line_lower for attr in ['key=', 'id=', 'class=', 'className=', 'style=', 'onclick=', 'onchange=']):
                        continue
                    
                    # Skip React/JSX component props and attributes
                    if re.search(r'<(?:Grid|div|span|button|input|form|table|tr|td|th|ul|li|ol|p|h[1-6]|img|a|link|script|style)', line_lower):
                        continue
                    
                    # Skip lines that are primarily URLs
                    if re.search(r'https?://[^\s]+', line) and not re.search(r'(?:exec|eval|system|subprocess)\s*\(', line):
                        continue
                    
                    # Destructive payload rules - allow legitimate cleanup
                    if threat_type == "DESTRUCTIVE_PAYLOAD":
                        if any(keyword in line_lower for keyword in ['cleanup', 'temp', 'cache', 'log', 'backup']):
                            continue
                        if any(keyword in line_lower for keyword in ['test', 'mock', 'example']):
                            continue
                    
                    # Financial fraud rules - allow legitimate payment processing
                    if threat_type == "FINANCIAL_FRAUD":
                        if any(keyword in line_lower for keyword in ['payment', 'transaction', 'api', 'service']):
                            continue
                    
                    # Security tech debt rules - allow configuration and examples
                    if threat_type == "SECURITY_TECH_DEBT":
                        if any(keyword in line_lower for keyword in ['config', 'setting', 'default', 'example', 'placeholder', 'test', 'mock']):
                            continue
                    

                    if re.search(pattern, line, re.IGNORECASE):

                        # Enhanced analysis

                        trigger_analysis = self._analyze_trigger_condition(line, threat_type)

                        payload_analysis = self._analyze_payload_potential(line, threat_type)

                        

                        # Determine severity based on threat type and payload

                        severity = self._determine_severity(threat_type, line)

                        confidence = self._calculate_confidence(line, threat_type, pattern)

                        

                        self.threat_patterns.append(

                            ThreatPattern(

                                threat_type, desc, severity, i, line.strip(), 

                                confidence, language, trigger_analysis, payload_analysis

                            )

                        )

                        

                        # Mark this line as matched by a specific threat type

                        if threat_type != "DESTRUCTIVE_PAYLOAD":

                            matched_lines.add(i)



    def _analyze_trigger_condition(self, line: str, threat_type: str) -> str:

        """Enhanced trigger analysis"""

        if threat_type == "SCHEDULED_THREAT":

            if re.search(r'\d{4}', line):

                return f"Triggered on specific year: {re.search(r'\d{4}', line).group()}"

            elif "datetime" in line or "time" in line:

                return "Triggered by time-based condition"

        elif threat_type == "TARGETED_ATTACK":

            user_match = re.search(r'["\']([^"\']+)["\']', line)

            if user_match:

                return f"Triggered for user: {user_match.group(1)}"

        elif threat_type == "EXECUTION_TRIGGER":

            count_match = re.search(r'\d+', line)

            if count_match:

                return f"Triggered after {count_match.group()} executions"

        elif threat_type == "SYSTEM_SPECIFIC_THREAT":

            env_match = re.search(r'["\']([^"\']+)["\']', line)

            if env_match:

                return f"Triggered on system: {env_match.group(1)}"

        elif threat_type == "FINANCIAL_FRAUD":

            return "Financial redirection detected - money theft risk"

        return f"Conditional trigger detected for {threat_type}"



    def _analyze_payload_potential(self, line: str, threat_type: str) -> str:

        """Enhanced payload analysis"""

        destructive_keywords = {

            "delete": "File deletion - Data loss",

            "remove": "Data removal - Information loss", 

            "destroy": "Data destruction - Complete loss",

            "format": "System formatting - Total destruction",

            "kill": "Process termination - Service disruption",

            "corrupt": "Data corruption - Integrity loss",

            "truncate": "Database truncation - Data wipe",

            "drop": "Database destruction - Schema loss",

            "bitcoin": "Cryptocurrency theft - Financial loss",

            "transfer": "Unauthorized transfer - Money theft"

        }

        

        for keyword, description in destructive_keywords.items():

            if keyword in line.lower():

                return description

        

        return f"Potential {threat_type} payload detected"



    def _determine_severity(self, threat_type: str, line: str) -> str:

        """Enhanced severity determination"""

        if threat_type == "DESTRUCTIVE_PAYLOAD":

            return "CRITICAL_BOMB"

        elif threat_type == "FINANCIAL_FRAUD":

            return "CRITICAL_BOMB"

        elif "format" in line.lower() or "destroy" in line.lower():

            return "CRITICAL_BOMB"

        elif threat_type in ["SCHEDULED_THREAT", "TARGETED_ATTACK"]:

            return "HIGH_RISK"

        elif threat_type == "EXECUTION_TRIGGER":

            return "MEDIUM_RISK"

        elif threat_type == "SECURITY_TECH_DEBT":

            return "CRITICAL"

        else:

            return "LOW_RISK"



    def _calculate_confidence(self, line: str, threat_type: str, pattern: str) -> float:

        """Enhanced confidence calculation"""

        base_confidence = 0.7

        

        # Increase confidence for specific indicators

        if threat_type == "DESTRUCTIVE_PAYLOAD":

            base_confidence += 0.2

        if threat_type == "FINANCIAL_FRAUD":

            base_confidence += 0.15

        if re.search(r'if.*:.*(?:delete|remove|destroy)', line):

            base_confidence += 0.1

        if len(re.findall(r'(?:delete|remove|destroy|corrupt|kill)', line, re.IGNORECASE)) > 1:

            base_confidence += 0.1

            

        return min(1.0, base_confidence)



# Global advanced threat pattern detector instance

advanced_detector = AdvancedThreatPatternDetector()



@app.route('/api/test-cors', methods=['GET'])

def test_cors():

    """Test endpoint to verify CORS is working."""

    return jsonify({

        'message': 'CORS test successful',

        'timestamp': datetime.now().isoformat(),

        'status': 'ok'

    })



@app.route('/api/command-center/metrics')

def get_command_center_metrics():

    """Get enhanced command center metrics"""

    try:

        print("DEBUG: Command center metrics endpoint called")

        # Get project_id from query parameters if provided
        project_id = request.args.get('project_id')
        
        metrics = detector.get_command_center_metrics(project_id)

        print(f"DEBUG: Command center metrics returned: {metrics}")

        return jsonify(metrics)

    except Exception as e:

        print(f"DEBUG: Command center metrics error: {e}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/logic-bomb-scan', methods=['POST'])

def start_logic_bomb_scan():

    """Start a new logic bomb detection scan"""

    try:

        data = request.get_json()

        project_path = data.get('project_path')

        project_id = data.get('project_id')

        

        if not project_path or not project_id:

            return jsonify({'error': 'Missing project_path or project_id'}), 400

        

        if not os.path.exists(project_path):

            return jsonify({'error': 'Project path does not exist'}), 400

        

        # Start enhanced logic bomb scan

        result = detector.scan_project(project_path, project_id)

        # Reload detector data to ensure API has latest threats and scans
        try:
            detector.issue_manager.load_issues()
            detector.load_scan_history()
            print("🔄 Auto-reloaded detector data: {} issues, {} scans".format(len(detector.issue_manager.issues), len(detector.scan_history)))
        except Exception as e:
            print(f"❌ Error auto-reloading detector data: {e}")

        return jsonify({

            'scan_id': result.scan_id,

            'project_id': result.project_id,

            'timestamp': result.timestamp,

            'files_scanned': result.files_scanned,

            'logic_bombs_detected': len(result.issues),

            'duration_ms': result.duration_ms,

            'threat_shield_status': result.threat_shield_status,

            'logic_bomb_risk_score': result.logic_bomb_risk_score,

            'threat_level': result.threat_intelligence.get('threat_level', 'UNKNOWN')

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



# Enhanced API endpoints for UI compatibility

@app.route('/api/scan', methods=['POST'])

def start_scan():

    """Enhanced scan endpoint for backward compatibility"""

    try:

        data = request.get_json()

        project_path = data.get('project_path')

        project_id = data.get('project_id')

        

        if not project_path or not project_id:

            return jsonify({'error': 'Missing project_path or project_id'}), 400

        

        if not os.path.exists(project_path):

            return jsonify({'error': 'Project path does not exist'}), 400

        

        # Start enhanced scan

        result = detector.scan_project(project_path, project_id)

        

        # Format issues for response

        formatted_issues = []

        for issue in result.issues:

            file_name = os.path.basename(issue.file_path) if issue.file_path else 'unknown'

            formatted_issues.append({

                'id': issue.id,

                'rule_id': issue.rule_id,

                'file_path': issue.file_path,

                'file_name': file_name,

                'line_number': issue.line_number,

                'column': issue.column,

                'message': issue.message,

                'severity': issue.severity,

                'type': issue.type,

                'status': issue.status,

                'assignee': issue.assignee,

                'creation_date': issue.creation_date,

                'update_date': issue.update_date,

                'effort': issue.effort,

                'code_snippet': issue.code_snippet,

                'suggested_fix': issue.suggested_fix,

                'threat_level': issue.threat_level,

                'trigger_analysis': issue.trigger_analysis,

                'payload_analysis': issue.payload_analysis,

                'ait_tag': getattr(issue, 'ait_tag', 'AIT'),

                'spk_tag': getattr(issue, 'spk_tag', 'SPK'),

                'repo_name': getattr(issue, 'repo_name', 'Repo'),

                'debt_category': getattr(issue, 'debt_category', 'UNKNOWN'),

                'business_impact': getattr(issue, 'business_impact', 'Medium'),

                'compliance_impact': getattr(issue, 'compliance_impact', 'None'),

                'security_domain': getattr(issue, 'security_domain', 'APPLICATION'),

                'component_name': getattr(issue, 'component_name', ''),

                'team_owner': getattr(issue, 'team_owner', ''),

                'priority_score': getattr(issue, 'priority_score', 0),

                'last_modified': getattr(issue, 'last_modified', ''),

                'exploitability': getattr(issue, 'exploitability', 'UNKNOWN'),

                'attack_vector': getattr(issue, 'attack_vector', 'UNKNOWN'),

                'data_classification': getattr(issue, 'data_classification', 'UNKNOWN'),

                'scan_id': result.scan_id

            })

        

        return jsonify({

            'scan_id': result.scan_id,

            'project_id': result.project_id,

            'timestamp': result.timestamp,

            'files_scanned': result.files_scanned,

            'issues_found': len(result.issues),

            'duration_ms': result.duration_ms,

            'quality_gate_status': result.threat_shield_status,

            'lines_of_code': getattr(result, 'lines_of_code', 0),

            'coverage': getattr(result, 'coverage', '100%'),

            'issues': formatted_issues  # Include the actual threats

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/threats')

def get_threats():

    """Get all threat issues"""

    try:

        # Get scan_id filter from query parameters

        scan_id_filter = request.args.get('scan_id')

        

        threats = []
        container_updates_needed = False

        for issue in detector.issue_manager.issues.values():

            # Extract filename from file_path

            file_name = os.path.basename(issue.file_path) if issue.file_path else 'unknown'

            

            # Filter by scan_id if provided

            issue_scan_id = getattr(issue, 'scan_id', 'unknown-scan')

            if scan_id_filter and issue_scan_id != scan_id_filter:

                continue

            

            docker_classification, detectable_by_tools, containerization_solution, changed = _enrich_container_metadata(issue)
            if changed:
                container_updates_needed = True

            threats.append({

                'id': issue.id,

                'rule_id': issue.rule_id,

                'file_path': issue.file_path,

                'file_name': file_name,  # Add file_name field

                'line_number': issue.line_number,

                'column': issue.column,

                'message': issue.message,

                'severity': issue.severity,

                'type': issue.type,

                'status': issue.status,

                'assignee': issue.assignee,

                'creation_date': issue.creation_date,

                'update_date': issue.update_date,

                'effort': issue.effort,

                'code_snippet': issue.code_snippet,

                'suggested_fix': issue.suggested_fix,

                'threat_level': issue.threat_level,

                'trigger_analysis': issue.trigger_analysis,

                'payload_analysis': issue.payload_analysis,

                'ait_tag': getattr(issue, 'ait_tag', 'AIT'),

                'spk_tag': getattr(issue, 'spk_tag', 'SPK'),

                'repo_name': getattr(issue, 'repo_name', 'Repo'),

                # Add additional fields that the VSCode extension expects

                'debt_category': getattr(issue, 'debt_category', 'UNKNOWN'),

                'business_impact': getattr(issue, 'business_impact', 'Medium'),

                'compliance_impact': getattr(issue, 'compliance_impact', 'None'),

                'security_domain': getattr(issue, 'security_domain', 'APPLICATION'),

                'component_name': getattr(issue, 'component_name', ''),

                'team_owner': getattr(issue, 'team_owner', ''),

                'priority_score': getattr(issue, 'priority_score', 0),

                'last_modified': getattr(issue, 'last_modified', ''),

                'exploitability': getattr(issue, 'exploitability', 'UNKNOWN'),

                'attack_vector': getattr(issue, 'attack_vector', 'UNKNOWN'),

                'data_classification': getattr(issue, 'data_classification', 'UNKNOWN'),

                'scan_id': issue_scan_id,
                
                # Containerization & Tool Detection fields
                'docker_classification': docker_classification,
                'detectable_by_tools': detectable_by_tools,
                'containerization_solution': containerization_solution

            })

        

        if container_updates_needed:
            try:
                detector.issue_manager.save_issues()
            except Exception as save_error:
                logger.error(f"Failed to persist container metadata updates: {save_error}")
        

        if scan_id_filter:

            print(f"Filtered threats by scan_id '{scan_id_filter}': {len(threats)} threats found")

        else:

            print(f"Returning all threats: {len(threats)} threats found")

        

        return jsonify(threats)

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/metrics/summary')

def get_metrics_summary():

    """Get summary metrics across all scans"""

    try:

        if not detector.scan_history:

            return jsonify({'error': 'No scan data available'})

        

        latest_scan = max(detector.scan_history, key=lambda x: x.timestamp)

        all_issues = []

        for scan in detector.scan_history[-10:]:  # Last 10 scans

            all_issues.extend(scan.issues)

        

        # Calculate trend data

        trends = {

            'security_rating_trend': [],

            'issues_trend': [],

            'coverage_trend': []

        }

        

        for scan in detector.scan_history[-10:]:

            trends['security_rating_trend'].append({

                'date': scan.timestamp,

                'value': ord(scan.security_rating) - ord('A') + 1

            })

            trends['issues_trend'].append({

                'date': scan.timestamp,

                'value': len(scan.issues)

            })

            trends['coverage_trend'].append({

                'date': scan.timestamp,

                'value': scan.coverage

            })

        

        summary = {

            'total_scans': len(detector.scan_history),

            'total_projects': len(set(scan.project_id for scan in detector.scan_history)),

            'total_issues': len(all_issues),

            'open_issues': len([i for i in all_issues if i.status == 'OPEN']),

            'resolved_issues': len([i for i in all_issues if i.status == 'RESOLVED']),

            'average_scan_duration': sum(scan.duration_ms for scan in detector.scan_history) / len(detector.scan_history),

            'latest_scan': {

                'project_id': latest_scan.project_id,

                'timestamp': latest_scan.timestamp,

                'security_rating': latest_scan.security_rating,

                'quality_gate_status': latest_scan.quality_gate_status

            },

            'trends': trends,

            'top_rules_violated': _get_top_rules_violated(all_issues),

            'issues_by_severity': _get_issues_by_severity(all_issues),

            'issues_by_type': _get_issues_by_type(all_issues)

        }

        

        return jsonify(summary)

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500

    

def _get_top_rules_violated(issues):

    """Get top rules violated"""

    rule_counts = {}

    for issue in issues:

        rule_counts[issue.rule_id] = rule_counts.get(issue.rule_id, 0) + 1



    # Sort by count and return top 10

    sorted_rules = sorted(rule_counts.items(), key=lambda x: x[1], reverse=True)

    return [{'rule_id': rule, 'count': count} for rule, count in sorted_rules[:10]]



def _get_issues_by_severity(issues):

    """Get issues grouped by severity"""

    severity_counts = {}

    for issue in issues:

        severity_counts[issue.severity] = severity_counts.get(issue.severity, 0) + 1

    return severity_counts



def _get_issues_by_type(issues):

    """Get issues grouped by type"""

    type_counts = {}

    for issue in issues:

        type_counts[issue.type] = type_counts.get(issue.type, 0) + 1

    return type_counts





@app.route('/api/issues')

def get_issues():

    """Backward compatibility endpoint for issues"""

    return get_threats()



@app.route('/api/threats/<threat_id>/status', methods=['PUT'])

def update_threat_status(threat_id):

    """Update threat status"""

    try:

        data = request.get_json()

        status = data.get('status')

        assignee = data.get('assignee')

        

        if not status:

            return jsonify({'error': 'Missing status'}), 400

        

        detector.issue_manager.update_issue_status(threat_id, status, assignee)

        return jsonify({'success': True})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/issues/<issue_id>/status', methods=['PUT'])

def update_issue_status(issue_id):

    """Backward compatibility endpoint for issue status"""

    return update_threat_status(issue_id)



@app.route('/api/threats/<threat_id>/neutralize', methods=['POST'])

def neutralize_threat(threat_id):

    """Neutralize a specific threat"""

    try:

        detector.issue_manager.update_issue_status(threat_id, "NEUTRALIZED")

        return jsonify({'success': True, 'message': 'Threat neutralized'})

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/threat-shields')

def get_threat_shields():

    """Get all threat shields"""

    try:

        shields = {}

        for shield_id, shield in detector.threat_shields.shields.items():

            shields[shield_id] = {

                'id': shield.id,

                'name': shield.name,

                'protection_rules': shield.protection_rules,

                'is_default': shield.is_default,

                'threat_categories': shield.threat_categories,

                'risk_threshold': shield.risk_threshold

            }

        

        return jsonify(shields)

    except Exception as e:

        return jsonify({'error': str(e)}), 500



# Backward compatibility - map to threat shields

@app.route('/api/quality-gates')

def get_quality_gates():

    """Backward compatibility endpoint for quality gates"""

    return get_threat_shields()



@app.route('/api/threat-shields', methods=['POST'])

def create_threat_shield():

    """Create a new threat shield"""

    try:

        data = request.get_json()

        

        shield_id = str(uuid.uuid4())

        shield = ThreatShield(

            id=shield_id,

            name=data['name'],

            protection_rules=data.get('protection_rules', []),

            is_default=data.get('is_default', False),

            threat_categories=data.get('threat_categories', []),

            risk_threshold=data.get('risk_threshold', 'MEDIUM_RISK')

        )

        

        detector.threat_shields.shields[shield_id] = shield

        detector.threat_shields.save_shields()

        

        return jsonify({'success': True, 'shield_id': shield_id})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/threat-shields/<shield_id>', methods=['PUT'])

def update_threat_shield(shield_id):

    """Update an existing threat shield"""

    try:

        data = request.get_json()

        

        if shield_id not in detector.threat_shields.shields:

            return jsonify({'error': 'Threat shield not found'}), 404

        

        shield = detector.threat_shields.shields[shield_id]

        

        # Update shield properties

        shield.name = data.get('name', shield.name)

        shield.protection_rules = data.get('protection_rules', shield.protection_rules)

        shield.threat_categories = data.get('threat_categories', shield.threat_categories)

        shield.risk_threshold = data.get('risk_threshold', shield.risk_threshold)

        shield.is_default = data.get('is_default', shield.is_default)

        

        detector.threat_shields.save_shields()

        

        return jsonify({'success': True, 'message': 'Threat shield updated successfully'})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/threat-shields/<shield_id>', methods=['DELETE'])

def delete_threat_shield(shield_id):

    """Delete a threat shield"""

    try:

        if shield_id not in detector.threat_shields.shields:

            return jsonify({'error': 'Threat shield not found'}), 404

        

        shield = detector.threat_shields.shields[shield_id]

        

        # Prevent deletion of default shield

        if shield.is_default:

            return jsonify({'error': 'Cannot delete default threat shield'}), 400

        

        del detector.threat_shields.shields[shield_id]

        detector.threat_shields.save_shields()

        

        return jsonify({'success': True, 'message': 'Threat shield deleted successfully'})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/threat-intelligence')

def get_threat_intelligence():

    """Get threat intelligence data"""

    try:

        # Debug: Check scan history

        print(f"Scan history length: {len(detector.scan_history)}")

        if detector.scan_history:

            print(f"Sample scan AIT tags: {[getattr(scan, 'ait_tag', 'N/A') for scan in detector.scan_history[:3]]}")

        

        history = []

        print(f"Processing {len(detector.scan_history)} scans")

        for scan in detector.scan_history:

            # Count vulnerabilities using the same logic as Active Threats Management tech debt tab

            scan_vulnerabilities = 0

            if hasattr(scan, 'issues') and scan.issues:

                for issue in scan.issues:

                    # Check if this issue is a vulnerability-related threat (same logic as tech debt tab)

                    threat_type = getattr(issue, 'type', '').lower()

                    threat_rule_id = getattr(issue, 'rule_id', '').lower()

                    threat_message = getattr(issue, 'message', '').lower()

                    

                    is_vulnerability = (

                        'vulnerability' in threat_type or

                        'security debt' in threat_type or

                        'security tech debt' in threat_type or

                        'security_tech_debt' in threat_type or

                        'vulnerability' in threat_rule_id or

                        'security_debt' in threat_rule_id or

                        'security_tech_debt' in threat_rule_id or

                        'vulnerability' in threat_message or

                        'security debt' in threat_message or

                        'security tech debt' in threat_message

                    )

                    

                    if is_vulnerability:

                        scan_vulnerabilities += 1

                

                # Debug: Print scan info

                print(f"Scan {scan.scan_id}: AIT={scan.ait_tag}, SPK={scan.spk_tag}, Repo={scan.repo_name}, Vulnerabilities={scan_vulnerabilities}")

            

            history.append({

                'scan_id': scan.scan_id,

                'project_id': scan.project_id,

                'ait_tag': getattr(scan, 'ait_tag', 'AIT'),

                'spk_tag': getattr(scan, 'spk_tag', 'SPK-DEFAULT'),

                'repo_name': getattr(scan, 'repo_name', 'unknown-repo'),

                'timestamp': scan.timestamp,

                'duration_ms': scan.duration_ms,

                'files_scanned': scan.files_scanned,

                'logic_bombs': len(scan.issues),

                'vulnerabilities': scan_vulnerabilities,

                'logic_bomb_risk_score': scan.logic_bomb_risk_score,

                'threat_shield_status': scan.threat_shield_status,

                'threat_level': scan.threat_intelligence.get('threat_level', 'UNKNOWN') if scan.threat_intelligence else 'UNKNOWN'

            })

        

        # Sort by timestamp, newest first

        history.sort(key=lambda x: x['timestamp'], reverse=True)

        

        # If no scan history, create sample data for testing

        if not history:

            print("No scan history found, creating sample data for testing")

            # Create sample scans with vulnerability counts

            sample_scans = [

                {

                    'scan_id': 'sample_scan_1',

                    'project_id': 'project_AIT001',

                    'ait_tag': 'AIT001',

                    'spk_tag': 'SPK001',

                    'repo_name': 'REPO001',

                    'timestamp': datetime.now().isoformat(),

                    'duration_ms': 5000,

                    'files_scanned': 100,

                    'logic_bombs': 3,

                    'vulnerabilities': 2,  # Sample vulnerability count

                    'logic_bomb_risk_score': 75,

                    'threat_shield_status': 'PROTECTED',

                    'threat_level': 'HIGH'

                },

                {

                    'scan_id': 'sample_scan_2',

                    'project_id': 'project_AIT002',

                    'ait_tag': 'AIT002',

                    'spk_tag': 'SPK002',

                    'repo_name': 'REPO002',

                    'timestamp': datetime.now().isoformat(),

                    'duration_ms': 3000,

                    'files_scanned': 50,

                    'logic_bombs': 1,

                    'vulnerabilities': 1,  # Sample vulnerability count

                    'logic_bomb_risk_score': 45,

                    'threat_shield_status': 'BLOCKED',

                    'threat_level': 'MEDIUM'

                }

            ]

            history.extend(sample_scans)

            print(f"Created {len(sample_scans)} sample scans with vulnerability data")

        

        # Calculate intelligence stats

        total_scans = len(history)

        threats_neutralized = len([i for i in detector.issue_manager.issues.values() if i.status == "NEUTRALIZED"])

        avg_risk_score = sum(h.get('logic_bomb_risk_score', 0) for h in history) / max(1, total_scans)

        shield_effectiveness = len([h for h in history if h['threat_shield_status'] == 'PROTECTED']) / max(1, total_scans) * 100

        

        return jsonify({

            'scan_history': history,

            'total_scans': total_scans,

            'threats_neutralized': threats_neutralized,

            'avg_risk_score': round(avg_risk_score, 1),

            'shield_effectiveness': round(shield_effectiveness, 1)

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/rules')

def get_rules():

    """Get all security rules"""

    try:

        rules = {}

        for rule_id, rule in detector.rules_engine.rules.items():

            rules[rule_id] = {

                'id': rule.id,

                'name': rule.name,

                'description': rule.description,

                'severity': rule.severity,

                'type': rule.type,

                'language': rule.language,

                'pattern': rule.pattern,

                'remediation_effort': rule.remediation_effort,

                'tags': rule.tags,

                'enabled': rule.enabled,

                'custom': rule.custom,

                'threat_category': rule.threat_category

            }

        

        return jsonify(rules)

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/rules', methods=['POST'])

def create_rule():

    """Create a new security rule"""

    try:

        data = request.get_json()

        

        # Validate required fields

        required_fields = ['id', 'name', 'description', 'severity', 'type', 'language', 'pattern']

        for field in required_fields:

            if field not in data:

                return jsonify({'error': f'Missing required field: {field}'}), 400

        

        # Check if rule ID already exists

        if data['id'] in detector.rules_engine.rules:

            return jsonify({'error': 'Rule ID already exists'}), 400

        

        # Create new rule

        rule = SecurityRule(

            id=data['id'],

            name=data['name'],

            description=data['description'],

            severity=data['severity'],

            type=data['type'],

            language=data['language'],

            pattern=data['pattern'],

            remediation_effort=data.get('remediation_effort', 30),

            tags=data.get('tags', []),

            enabled=data.get('enabled', True),

            custom=data.get('custom', True),

            threat_category=data.get('threat_category', 'UNKNOWN')

        )

        

        detector.rules_engine.add_rule(rule)

        return jsonify({'success': True, 'rule_id': rule.id})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/rules/<rule_id>', methods=['PUT'])

def update_rule(rule_id):

    """Update a security rule"""

    try:

        data = request.get_json()

        

        if rule_id not in detector.rules_engine.rules:

            return jsonify({'error': 'Rule not found'}), 404

        

        detector.rules_engine.update_rule(rule_id, data)

        return jsonify({'success': True})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/rules/<rule_id>', methods=['DELETE'])

def delete_rule(rule_id):

    """Delete a security rule"""

    try:

        if rule_id not in detector.rules_engine.rules:

            return jsonify({'error': 'Rule not found'}), 404

        

        detector.rules_engine.delete_rule(rule_id)

        return jsonify({'success': True})

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/scan/files', methods=['POST'])

def scan_uploaded_files():

    """Enhanced file scanning with advanced threat detection"""

    try:

        data = request.get_json()

        scan_id = data.get('scan_id', str(uuid.uuid4()))

        scan_type = data.get('scan_type', 'quick')

        file_contents = data.get('file_contents', [])

        project_id = data.get('project_id', f'upload-scan-{int(datetime.now().timestamp())}')

        project_name = data.get('project_name', 'File Upload Scan')

        source = data.get('source', 'unknown')  # Add source field

        ait_tag = data.get('ait_tag', 'AIT')

        spk_tag = data.get('spk_tag', 'SPK')

        repo_name = data.get('repo_name', 'Repo')



        if not file_contents:

            return jsonify({'error': 'No files provided'}), 400



        # Save uploaded files to uploaded_projects/{scan_id}/original/

        base_upload_dir = Path('uploaded_projects') / scan_id / 'original'

        base_upload_dir.mkdir(parents=True, exist_ok=True)

        

        file_paths = []

        uploaded_files_for_prompts = []

        

        for file_data in file_contents:

            file_path = base_upload_dir / file_data['name']

            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'w', encoding='utf-8') as f:

                f.write(file_data['content'])

            

            file_paths.append({

                'id': file_data['id'],

                'name': file_data['name'],

                'path': str(file_path),

                'type': file_data['type']

            })

            

            # Prepare data for prompt generation

            uploaded_files_for_prompts.append({

                'file_path': str(file_path),

                'content': file_data['content'],

                'file_name': file_data['name']

            })

        

        # Enhanced file scan with comprehensive threat analysis

        scan_result = perform_enhanced_file_scan(

            scan_id=scan_id,

            project_id=project_id,

            project_name=project_name,

            file_paths=file_paths,

            scan_type=scan_type,

            source=source,  # Pass source field

            ait_tag=ait_tag,

            spk_tag=spk_tag,

            repo_name=repo_name

        )

        

        # Generate VS Code Copilot prompts automatically

        try:

            prompts_data = generate_vscode_copilot_prompts(scan_id, uploaded_files_for_prompts)

            scan_result['prompts_generated'] = True

            scan_result['prompts_data'] = prompts_data

        except Exception as e:

            logging.error(f"Error generating prompts: {e}")

            scan_result['prompts_generated'] = False

            scan_result['prompts_error'] = str(e)

        

        return jsonify(scan_result)



    except Exception as e:

        return jsonify({'error': str(e)}), 500



def perform_enhanced_file_scan(scan_id: str, project_id: str, project_name: str, 

                              file_paths: list, scan_type: str = 'quick', source: str = 'unknown',

                              ait_tag: str = 'AIT', spk_tag: str = 'SPK', repo_name: str = 'Repo') -> dict:

    """Enhanced file scan with comprehensive threat detection"""

    start_time = datetime.now()

    total_issues = []

    total_threat_patterns = []

    file_results = []

    total_lines = 0



    for file_info in file_paths:

        try:

            file_path = file_info['path']

            file_name = file_info['name']

            file_type = file_info['type']

            file_id = file_info['id']

            # Skip files with extensions that typically don't contain executable code
            skip_extensions = ['.json', '.sql', '.md', '.txt', '.csv', '.xml', '.yaml', '.yml', '.log', '.lock', '.html', '.htm', '.css', '.js']
            file_extension = os.path.splitext(file_name)[1].lower()
            
            if file_extension in skip_extensions:
                print(f"DEBUG: Skipping {file_name} - file type {file_extension} typically doesn't contain executable code")
                continue
            
            # Skip library files and third-party dependencies
            library_patterns = [
                'jquery', 'bootstrap', 'angular', 'react', 'vue', 'lodash', 'underscore', 'moment',
                'axios', 'd3', 'chart', 'leaflet', 'openlayers', 'cesium', 'three', 'babylon',
                'socket.io', 'express', 'mongoose', 'sequelize', 'passport', 'bcrypt', 'jsonwebtoken',
                'multer', 'cors', 'helmet', 'compression', 'morgan', 'winston', 'nodemailer',
                'redis', 'elasticsearch', 'knex', 'bookshelf', 'waterline', 'sails', 'hapi',
                'koa', 'fastify', 'restify', 'loopback', 'feathers', 'adonis', 'nestjs',
                'webpack', 'babel', 'gulp', 'grunt', 'rollup', 'parcel', 'vite', 'esbuild',
                'typescript', 'flow', 'eslint', 'prettier', 'jest', 'mocha', 'chai', 'sinon',
                'cypress', 'puppeteer', 'playwright', 'selenium', 'karma', 'jasmine',
                'protractor', 'nightwatch', 'webdriver', 'testcafe', 'detox',
                'antd', 'material-ui', 'semantic-ui', 'bulma', 'tailwind', 'foundation',
                'pure', 'skeleton', 'milligram', 'spectre', 'tachyons', 'basscss',
                'normalize', 'reset', 'sanitize', 'modernizr', 'polyfill', 'shim',
                'min', 'minified', 'compressed', 'packed', 'bundle', 'vendor', 'lib',
                'node_modules', 'bower_components', 'vendor', 'third-party', 'external',
                'cdn', 'cdnjs', 'unpkg', 'jsdelivr', 'googleapis', 'cloudflare',
                'fontawesome', 'font-awesome', 'ionicons', 'material-icons', 'feather',
                'heroicons', 'lucide', 'phosphor', 'tabler', 'remix', 'eva',
                'prism', 'highlight', 'syntax', 'code', 'monaco', 'ace', 'codemirror',
                'tinymce', 'ckeditor', 'quill', 'froala', 'summernote', 'trumbowyg',
                'datatables', 'ag-grid', 'handsontable', 'tabulator', 'gridjs',
                'chart.js', 'd3', 'plotly', 'echarts', 'highcharts', 'amcharts',
                'leaflet', 'openlayers', 'mapbox', 'google-maps', 'here-maps',
                'socket.io', 'ws', 'sockjs', 'engine.io', 'primus', 'faye',
                'moment', 'dayjs', 'date-fns', 'luxon', 'chrono', 'timeago',
                'validator', 'joi', 'yup', 'ajv', 'zod', 'superstruct', 'io-ts',
                'ramda', 'lodash', 'underscore', 'immutable', 'mobx', 'rxjs',
                'redux', 'vuex', 'ngrx', 'zustand', 'jotai', 'recoil', 'valtio',
                'axios', 'fetch', 'request', 'got', 'node-fetch', 'ky', 'umi-request',
                'express', 'koa', 'fastify', 'hapi', 'restify', 'loopback', 'sails',
                'mongoose', 'sequelize', 'typeorm', 'prisma', 'waterline', 'bookshelf',
                'passport', 'jwt', 'oauth', 'auth0', 'firebase-auth', 'aws-cognito',
                'bcrypt', 'argon2', 'scrypt', 'pbkdf2', 'crypto', 'hash', 'encrypt',
                'multer', 'formidable', 'busboy', 'multiparty', 'connect-multiparty',
                'cors', 'helmet', 'compression', 'morgan', 'winston', 'pino', 'bunyan',
                'nodemailer', 'sendgrid', 'mailgun', 'ses', 'postmark', 'mandrill',
                'redis', 'memcached', 'ioredis', 'node-redis', 'redis-cluster',
                'elasticsearch', 'solr', 'lucene', 'algolia', 'swiftype', 'typesense',
                'webpack', 'rollup', 'parcel', 'vite', 'esbuild', 'swc', 'babel',
                'gulp', 'grunt', 'broccoli', 'brunch', 'fuse-box', 'systemjs',
                'typescript', 'flow', 'coffeescript', 'dart', 'clojurescript',
                'eslint', 'prettier', 'standard', 'xo', 'jshint', 'jslint', 'tslint',
                'jest', 'mocha', 'chai', 'sinon', 'ava', 'tape', 'tap', 'vitest',
                'cypress', 'puppeteer', 'playwright', 'selenium', 'webdriverio',
                'karma', 'jasmine', 'protractor', 'nightwatch', 'testcafe', 'detox'
            ]
            
            file_name_lower = file_name.lower()
            if any(pattern in file_name_lower for pattern in library_patterns):
                print(f"DEBUG: Skipping {file_name} - appears to be a library/third-party file")
                continue

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:

                content = f.read()



            lines = content.splitlines()

            file_lines = len(lines)

            total_lines += file_lines



            # Enhanced standard security rules scan

            applicable_rules = detector.rules_engine.get_enabled_rules(file_type)

            file_issues = scan_file_content(file_name, content, applicable_rules, file_id, scan_id, ait_tag, spk_tag, repo_name)



            # Advanced threat pattern detection

            threat_matches = advanced_detector.analyze_file(file_path)

            

            # DEBUG: Print what patterns were detected

            print(f"DEBUG: File {file_name} - Threat patterns detected: {len(threat_matches)}")

            for pattern in threat_matches:

                print(f"DEBUG: Pattern: {pattern.pattern_type} - {pattern.description}")

            

            threat_issues = [

                detector.issue_manager.create_issue(

                    rule_id=f"MALWARE_{pattern.pattern_type}",

                    file_path=file_name,

                    line_number=pattern.line_number,

                    column=1,

                    message=f"{pattern.description} - {pattern.trigger_analysis}",

                    severity=pattern.severity,

                    issue_type=pattern.pattern_type,

                    code_snippet=pattern.code_snippet,

                    suggested_fix=f"Remove {pattern.pattern_type.lower()} behavior - {pattern.payload_analysis}",

                    ait_tag=ait_tag,

                    spk_tag=spk_tag,

                    repo_name=repo_name,

                    scan_id=scan_id

                )

                for pattern in threat_matches

            ]

            

            # DEBUG: Print what issues were created

            print(f"DEBUG: File {file_name} - Issues created: {len(threat_issues)}")

            for issue in threat_issues:

                print(f"DEBUG: Created issue: type='{getattr(issue, 'type', 'UNKNOWN')}', rule_id='{getattr(issue, 'rule_id', 'UNKNOWN')}'")



            # Combine and deduplicate issues
            all_issues = file_issues + threat_issues
            
            # Enhanced deduplication logic to handle same line with different threat types
            seen_issues = set()
            deduplicated_issues = []
            
            for issue in all_issues:
                # Create multiple keys for different deduplication strategies
                file_path = issue.file_path
                line_number = issue.line_number
                rule_id = issue.rule_id
                threat_type = getattr(issue, 'type', 'UNKNOWN')
                
                # Key 1: Exact match (file, line, rule_id)
                exact_key = (file_path, line_number, rule_id)
                
                # Key 2: Same line, same threat type (different rules detecting same threat)
                threat_key = (file_path, line_number, threat_type)
                
                # Key 3: Same line, similar threat patterns (for hardcoded secrets, etc.)
                code_snippet = getattr(issue, 'code_snippet', '').strip()
                if code_snippet:
                    # Normalize code snippet for comparison (remove extra spaces, case insensitive)
                    normalized_snippet = ' '.join(code_snippet.lower().split())
                    snippet_key = (file_path, line_number, normalized_snippet)
                else:
                    snippet_key = None
                
                # Check if this is a duplicate
                is_duplicate = False
                duplicate_reason = ""
                
                if exact_key in seen_issues:
                    is_duplicate = True
                    duplicate_reason = "exact match"
                elif threat_key in seen_issues:
                    is_duplicate = True
                    duplicate_reason = "same threat type"
                elif snippet_key and snippet_key in seen_issues:
                    is_duplicate = True
                    duplicate_reason = "same code snippet"
                
                if not is_duplicate:
                    # Add all keys to prevent future duplicates
                    seen_issues.add(exact_key)
                    seen_issues.add(threat_key)
                    if snippet_key:
                        seen_issues.add(snippet_key)
                    deduplicated_issues.append(issue)
                else:
                    print(f"DEBUG: Duplicate issue removed ({duplicate_reason}): {file_path}:{line_number} - {rule_id} ({threat_type})")
            
            all_issues = deduplicated_issues



            # Inject hierarchical tags and scan_id into every issue

            for issue in all_issues:

                issue.ait_tag = ait_tag

                issue.spk_tag = spk_tag

                issue.repo_name = repo_name

                issue.scan_id = scan_id



            # Enhanced threat metrics per file

            logic_bomb_count = len([p for p in threat_matches if 'BOMB' in p.pattern_type or 'TRIGGER' in p.pattern_type])

            critical_threats = len([i for i in all_issues if i.severity in ['BLOCKER', 'CRITICAL', 'CRITICAL_BOMB']])

            

            file_result = {

                'file_id': file_id,

                'file_name': file_name,

                'file_path': file_name,  # Use file_name as the relative path for Copilot tasks

                'file_type': file_type,

                'lines_scanned': file_lines,

                'issues': [format_issue_for_response(issue) for issue in all_issues],

                'issues_count': len(all_issues),

                'logic_bomb_count': logic_bomb_count,

                'threat_pattern_count': len(threat_matches),

                'critical_threats': critical_threats,

                'scan_status': 'completed',

                'threat_level': determine_file_threat_level(all_issues, threat_matches)

            }



            file_results.append(file_result)

            total_issues.extend(all_issues)

            total_threat_patterns.extend(threat_matches)



        except Exception as e:

            file_results.append({

                'file_id': file_info['id'],

                'file_name': file_info['name'],

                'file_path': file_info['name'],  # Use file_name as the relative path

                'file_type': file_info['type'],

                'scan_status': 'error',

                'error_message': str(e)

            })



    # Enhanced metrics calculation

    logic_bomb_risk_score = ThreatMetricsCalculator.calculate_logic_bomb_risk_score(total_issues)

    threat_intelligence = ThreatMetricsCalculator.calculate_threat_intelligence(total_issues)

    

    # Calculate threat-specific metrics

    threat_metrics = {

        "SCHEDULED_THREAT": len([p for p in total_threat_patterns if p.pattern_type == "SCHEDULED_THREAT"]),

        "TARGETED_ATTACK": len([p for p in total_threat_patterns if p.pattern_type == "TARGETED_ATTACK"]),

        "EXECUTION_TRIGGER": len([p for p in total_threat_patterns if p.pattern_type == "EXECUTION_TRIGGER"]),

        "DESTRUCTIVE_PAYLOAD": len([p for p in total_threat_patterns if p.pattern_type == "DESTRUCTIVE_PAYLOAD"]),

        "FINANCIAL_FRAUD": len([p for p in total_threat_patterns if p.pattern_type == "FINANCIAL_FRAUD"]),

        "SYSTEM_SPECIFIC_THREAT": len([p for p in total_threat_patterns if p.pattern_type == "SYSTEM_SPECIFIC_THREAT"]),

        "CONNECTION_BASED_THREAT": len([p for p in total_threat_patterns if p.pattern_type == "CONNECTION_BASED_THREAT"]),

        "threat_density": ThreatMetricsCalculator.calculate_threat_density(total_issues, total_lines)

    }



    # Evaluate threat shield

    default_shield = next((s for s in detector.threat_shields.shields.values() if s.is_default), None)

    shield_result = detector.threat_shields.evaluate_shield(default_shield.id, threat_metrics) if default_shield else {}

    shield_status = shield_result.get("status", "PROTECTED")



    duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)

    timestamp = start_time.isoformat()



    # Global deduplication before storing in database
    print(f"DEBUG: Before deduplication: {len(total_issues)} issues")
    
    # Create a set to track unique issues based on content, not just ID
    seen_issues = set()
    deduplicated_issues = []
    
    for issue in total_issues:
        # Create a content-based key for deduplication
        file_path = issue.file_path
        line_number = issue.line_number
        code_snippet = getattr(issue, 'code_snippet', '').strip()
        threat_type = getattr(issue, 'type', 'UNKNOWN')
        
        # Normalize code snippet for comparison
        if code_snippet:
            normalized_snippet = ' '.join(code_snippet.lower().split())
        else:
            normalized_snippet = ''
        
        # Create multiple keys for different deduplication strategies
        content_key = (file_path, line_number, normalized_snippet, threat_type)
        line_key = (file_path, line_number, threat_type)
        
        # Check if this is a duplicate
        is_duplicate = False
        duplicate_reason = ""
        
        if content_key in seen_issues:
            is_duplicate = True
            duplicate_reason = "same content and threat type"
        elif line_key in seen_issues:
            is_duplicate = True
            duplicate_reason = "same line and threat type"
        
        if not is_duplicate:
            # Add keys to prevent future duplicates
            seen_issues.add(content_key)
            seen_issues.add(line_key)
            deduplicated_issues.append(issue)
        else:
            print(f"DEBUG: Global duplicate removed ({duplicate_reason}): {file_path}:{line_number} - {threat_type}")
    
    print(f"DEBUG: After deduplication: {len(deduplicated_issues)} issues")

    # Create enhanced scan result object

    scan_result_obj = ScanResult(

        project_id=project_id,

        scan_id=scan_id,

        timestamp=timestamp,

        duration_ms=duration_ms,

        files_scanned=len(file_paths),

        lines_of_code=total_lines,

        issues=deduplicated_issues,

        coverage=85.0,

        duplications=2.0,

        maintainability_rating="B",

        reliability_rating="A",

        security_rating=calculate_security_rating_from_issues(total_issues),

        threat_shield_status=shield_status,

        logic_bomb_risk_score=logic_bomb_risk_score,

        threat_intelligence=threat_intelligence,

        ait_tag=ait_tag,

        spk_tag=spk_tag,

        repo_name=repo_name

    )



    # Save to detector (history + issues)

    detector.scan_history.append(scan_result_obj)

    detector.save_scan_history()



    # Store only deduplicated issues
    for issue in deduplicated_issues:
        detector.issue_manager.issues[issue.id] = issue

    detector.issue_manager.save_issues()



    # Generate Copilot task for automated remediation

    generate_copilot_task(scan_id, project_id, project_name, total_issues, file_results, threat_intelligence, source)



    return {

        'scan_id': scan_id,

        'project_id': project_id,

        'project_name': project_name,

        'scan_type': scan_type,

        'timestamp': timestamp,

        'duration_ms': duration_ms,

        'files_scanned': len(file_paths),

        'lines_of_code': total_lines,

        'file_results': file_results,

        'summary': {

            'total_issues': len(deduplicated_issues),

            'logic_bomb_patterns_found': len(total_threat_patterns),

            'critical_threats': len([i for i in deduplicated_issues if i.severity in ['BLOCKER', 'CRITICAL', 'CRITICAL_BOMB']]),

            'security_rating': calculate_security_rating_from_issues(deduplicated_issues),

            'logic_bomb_risk_score': logic_bomb_risk_score,

            'threat_level': threat_intelligence.get('threat_level', 'MINIMAL'),

            'quality_gate_passed': shield_status == "PROTECTED",

            'technical_debt_hours': sum(getattr(i, 'effort', 0) for i in total_issues) // 60

        },

        'logic_bomb_metrics': threat_metrics,

        'metrics': {

            'coverage': 85.0,

            'duplications': 2.0,

            'lines_of_code': total_lines,

            'maintainability_rating': "B",

            'reliability_rating': "A",

            'security_rating': calculate_security_rating_from_issues(total_issues),

            'technical_debt_hours': sum(getattr(i, 'effort', 0) for i in total_issues) // 60

        },

        'threat_shield': {

            'status': shield_status,

            'message': 'Threat Shield Active' if shield_status == 'PROTECTED' else 'Threats Detected'

        },

        'threat_intelligence': threat_intelligence,

        'issue_breakdown': {

            'by_file': {f['file_name']: f['issues_count'] for f in file_results},

            'by_severity': {

                severity: len([i for i in total_issues if i.severity == severity])

                for severity in ['CRITICAL_BOMB', 'HIGH_RISK', 'MEDIUM_RISK', 'LOW_RISK', 'CRITICAL', 'MAJOR', 'MINOR']

            },

            'by_type': {

                threat_type: count for threat_type, count in threat_metrics.items()

            }

        }

    }



def determine_file_threat_level(issues: list, patterns: list) -> str:

    """Determine threat level for a specific file"""

    critical_count = len([i for i in issues if i.severity in ['CRITICAL_BOMB', 'CRITICAL']])

    high_count = len([i for i in issues if i.severity in ['HIGH_RISK', 'MAJOR']])

    pattern_count = len(patterns)

    

    if critical_count > 0 or pattern_count > 2:

        return "CRITICAL"

    elif high_count > 1 or pattern_count > 0:

        return "HIGH"

    elif high_count > 0:

        return "MEDIUM"

    else:

        return "LOW"



def calculate_security_rating_from_issues(issues: list) -> str:

    """Calculate security rating based on issues detected"""

    critical_bombs = len([i for i in issues if i.severity == "CRITICAL_BOMB"])

    critical_issues = len([i for i in issues if i.severity == "CRITICAL"])

    high_risks = len([i for i in issues if i.severity == "HIGH_RISK"])

    

    if critical_bombs > 0:

        return "F"

    elif critical_issues > 0:

        return "E"

    elif high_risks > 2:

        return "D"

    elif high_risks > 0:

        return "C"

    elif len(issues) > 5:

        return "B"

    else:

        return "A"



def _enrich_container_metadata(issue):
    """Ensure containerization metadata is populated from rule definitions."""
    docker_classification = getattr(issue, 'docker_classification', 'NONE') or 'NONE'
    detectable_by_tools = getattr(issue, 'detectable_by_tools', None) or []
    containerization_solution = getattr(issue, 'containerization_solution', '') or ''
    changed = False

    if getattr(issue, 'type', '') == 'CONTAINERIZATION_BLOCKER':
        rule = detector.rules_engine.rules.get(getattr(issue, 'rule_id', ''), None)
        if rule:
            rule_docker = getattr(rule, 'docker_classification', 'NONE') or 'NONE'
            rule_tools = getattr(rule, 'detectable_by_tools', None) or []
            rule_solution = getattr(rule, 'containerization_solution', '') or ''

            if docker_classification in ('', 'NONE') and rule_docker not in ('', 'NONE'):
                docker_classification = rule_docker
            if not detectable_by_tools and rule_tools:
                detectable_by_tools = rule_tools
            if not containerization_solution and rule_solution:
                containerization_solution = rule_solution

    # Normalize tool precedence: prefer named tools over RMENGINE_ONLY
    if detectable_by_tools:
        normalized_tools = []
        seen = set()
        for tool in detectable_by_tools:
            if tool and tool not in seen:
                normalized_tools.append(tool)
                seen.add(tool)
        has_named_tools = any(tool in ('SONARQUBE', 'CHECKMARX') for tool in normalized_tools)
        if has_named_tools:
            normalized_tools = [tool for tool in normalized_tools if tool != 'RMENGINE_ONLY']
        detectable_by_tools = normalized_tools
    if not detectable_by_tools:
        detectable_by_tools = ['RMENGINE_ONLY']

    if getattr(issue, 'docker_classification', 'NONE') != docker_classification:
        issue.docker_classification = docker_classification
        changed = True
    if (getattr(issue, 'detectable_by_tools', None) or []) != detectable_by_tools:
        issue.detectable_by_tools = detectable_by_tools
        changed = True
    if getattr(issue, 'containerization_solution', '') != containerization_solution:
        issue.containerization_solution = containerization_solution
        changed = True

    return docker_classification, detectable_by_tools, containerization_solution, changed


def format_issue_for_response(issue) -> dict:

    """Format issue for JSON response"""

    docker_classification, detectable_by_tools, containerization_solution, _ = _enrich_container_metadata(issue)

    return {

        'id': issue.id,

        'rule_id': issue.rule_id,

        'file_path': getattr(issue, 'file_path', ''),

        'file_name': getattr(issue, 'file_name', ''),

        'line_number': issue.line_number,

        'column': issue.column,

        'message': issue.message,

        'severity': issue.severity,

        'type': issue.type,

        'status': issue.status,

        'code_snippet': issue.code_snippet,

        'suggested_fix': issue.suggested_fix,

        'threat_level': getattr(issue, 'threat_level', 'UNKNOWN'),

        'trigger_analysis': getattr(issue, 'trigger_analysis', ''),

        'payload_analysis': getattr(issue, 'payload_analysis', ''),

        'effort_minutes': getattr(issue, 'effort', 0),

        'ait_tag': getattr(issue, 'ait_tag', 'AIT'),

        'spk_tag': getattr(issue, 'spk_tag', 'SPK'),

        'repo_name': getattr(issue, 'repo_name', 'Repo'),

        # Containerization metadata
        'docker_classification': docker_classification,
        'detectable_by_tools': detectable_by_tools,
        'containerization_solution': containerization_solution

    }



def scan_file_content(file_name: str, content: str, rules: list, file_id: str, 

                     scan_id: str = "unknown-scan", ait_tag: str = "AIT", 

                     spk_tag: str = "SPK-DEFAULT", repo_name: str = "unknown-repo") -> list:

    """Scan file content with security rules and proper hierarchical tagging"""

    import re

    issues = []

    lines = content.splitlines()



    for rule in rules:

        try:

            pattern = re.compile(rule.pattern, re.IGNORECASE | re.MULTILINE)



            for line_num, line in enumerate(lines, 1):

                # ENHANCED FILTERING: Comprehensive false positive detection
                stripped_line = line.strip()
                line_lower = line.lower()
                
                # Skip lines that are clearly comments or documentation
                if stripped_line.startswith(('#', '//', '/*', '*', '<!--')):
                    continue
                
                # Skip lines with docstrings
                if '"""' in line or "'''" in line:
                    continue
                
                # Skip lines that are clearly function definitions
                if stripped_line.startswith(('def ', 'import ', 'from ', 'class ', 'if __name__')):
                    continue
                
                # Skip lines that are clearly variable assignments or imports
                if stripped_line.startswith(('import ', 'from ', 'import ', 'imports')):
                    continue
                
                # Enhanced print statement filtering - exclude ALL print statements for financial fraud
                if stripped_line.startswith(('print(', 'logger.', 'log.', 'console.', 'print ')):
                    # For financial fraud rules, exclude print statements entirely
                    if rule.type == "FINANCIAL_FRAUD":
                        continue
                    # For other rules, only exclude if no dangerous keywords
                    if not any(keyword in line_lower for keyword in ['redirect', 'payment', 'wallet', 'fraud', 'money', 'transfer', 'bitcoin', 'crypto']):
                        continue
                
                # Enhanced comment filtering - exclude ALL comments for financial fraud
                if rule.type == "FINANCIAL_FRAUD":
                    # For financial fraud, exclude any line that starts with # or contains only comments
                    if stripped_line.startswith('#'):
                        continue
                    # Also exclude lines that are mostly comments (after removing leading whitespace)
                    if line.strip().startswith('#'):
                        continue
                
                # Skip lines that are clearly error handling
                if any(keyword in line_lower for keyword in ['except', 'finally', 'try:', 'catch']):
                    continue
                
                # Skip lines that are clearly configuration or constants
                if any(keyword in line_lower for keyword in ['config', 'constant', 'setting', 'option']):
                    continue
                
                # Skip lines that are clearly test assertions
                if any(keyword in line_lower for keyword in ['assert', 'expect', 'should', 'must']):
                    continue
                
                # Skip lines that are clearly documentation
                if any(keyword in line_lower for keyword in ['note:', 'todo:', 'fixme:', 'hack:', 'warning:']):
                    continue
                
                # Skip lines with legitimate context keywords
                legitimate_keywords = [
                    'test', 'mock', 'example', 'demo', 'config', 'setting', 'default', 
                    'cleanup', 'temp', 'cache', 'log', 'backup', 'placeholder', 'sample',
                    'debug', 'development', 'dev', 'staging', 'local', 'sandbox'
                ]
                if any(keyword in line_lower for keyword in legitimate_keywords):
                    continue
                
                # Skip lines that are just variable assignments without execution (but not for financial fraud)
                if rule.type != "FINANCIAL_FRAUD":
                    import re
                    if re.match(r'^\s*\w+\s*=\s*["\'][^"\']*["\']\s*$', line):
                        continue
                
                # Skip lines that are just string literals or comments in disguise
                if re.match(r'^\s*["\'][^"\']*["\']\s*$', line):
                    continue
                
                # Skip HTML attributes and URLs (they're not code execution)
                if any(attr in line_lower for attr in ['href=', 'src=', 'alt=', 'title=', 'content=', 'value=', 'placeholder=', 'data-']):
                    continue
                
                # Skip UI component keys and React/JSX attributes (not credentials)
                if any(attr in line_lower for attr in ['key=', 'id=', 'class=', 'className=', 'style=', 'onclick=', 'onchange=']):
                    continue
                
                # Skip React/JSX component props and attributes
                if re.search(r'<(?:Grid|div|span|button|input|form|table|tr|td|th|ul|li|ol|p|h[1-6]|img|a|link|script|style)', line_lower):
                    continue
                
                # Skip lines that are primarily URLs
                if re.search(r'https?://[^\s]+', line) and not re.search(r'(?:exec|eval|system|subprocess)\s*\(', line):
                    continue
                
                # Destructive payload rules - allow legitimate cleanup
                if 'destructive' in rule.id.lower():
                    if any(keyword in line_lower for keyword in ['cleanup', 'temp', 'cache', 'log', 'backup']):
                        continue
                    if any(keyword in line_lower for keyword in ['test', 'mock', 'example']):
                        continue
                
                # Hardcoded secrets rules - allow configuration
                if 'secret' in rule.id.lower() or 'credential' in rule.id.lower():
                    if any(keyword in line_lower for keyword in ['config', 'setting', 'default', 'example', 'placeholder']):
                        continue
                
                # Financial fraud rules - allow legitimate payment processing
                if rule.type == "FINANCIAL_FRAUD":
                    if any(keyword in line_lower for keyword in ['payment', 'transaction', 'api', 'service']):
                        continue
                
                # Security tech debt rules - allow configuration and examples
                if rule.type == "SECURITY_TECH_DEBT":
                    if any(keyword in line_lower for keyword in ['config', 'setting', 'default', 'example', 'placeholder', 'test', 'mock']):
                        continue

                matches = pattern.finditer(line)

                for match in matches:

                    issue = detector.issue_manager.create_issue(

                        rule_id=rule.id,

                        file_path=file_name,

                        line_number=line_num,

                        column=match.start() + 1,

                        message=rule.description,

                        severity=rule.severity,

                        issue_type=rule.type,

                        code_snippet=line.strip(),

                        suggested_fix=generate_fix_suggestion(rule, line.strip()),

                        ait_tag=ait_tag,

                        spk_tag=spk_tag,

                        repo_name=repo_name,

                        scan_id=scan_id

                    )

                    issue.effort = rule.remediation_effort

                    issues.append(issue)



        except re.error as e:

            print(f"⚠️ Invalid regex in rule {rule.id}: {e}")



    return issues



def generate_fix_suggestion(rule, code_snippet: str) -> str:

    """Generate specific fix suggestions based on rule and code"""

    suggestions = {

        'logic-bomb-time-trigger': f"Remove time-based conditions: {code_snippet[:50]}... Use proper scheduling systems instead.",

        'logic-bomb-user-targeted': f"Remove user-specific targeting: {code_snippet[:50]}... Implement proper authentication.",

        'logic-bomb-execution-counter': f"Remove execution counters: {code_snippet[:50]}... Use proper iteration controls.",

        'destructive-payload-detector': f"CRITICAL: Remove destructive operations: {code_snippet[:50]}... Implement proper data management.",

        'financial-fraud-detector': f"URGENT: Remove financial redirections: {code_snippet[:50]}... Use legitimate payment systems.",

        'hardcoded-secrets-detector': f"Move secrets to environment variables: os.getenv('SECRET_KEY')",

        'sql-injection-detector': "Use parameterized queries: cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",

        'eval-usage-detector': "Replace eval() with JSON.parse() for data or safer alternatives"

    }

    

    base_suggestion = suggestions.get(rule.id, "Review and fix according to security best practices")

    

    # Add context-specific suggestions

    if 'password' in code_snippet.lower():

        return f"{base_suggestion}. Consider using secure password hashing with bcrypt or argon2."

    elif 'key' in code_snippet.lower():

        return f"{base_suggestion}. Use a secure key management service."

    elif 'token' in code_snippet.lower():

        return f"{base_suggestion}. Generate tokens securely and store them encrypted."

    

    return base_suggestion



@app.route('/api/export')

def export_data():

    """Export all scanner data"""

    try:

        export_data = {

            'export_timestamp': datetime.now().isoformat(),

            'export_type': 'threatguard_pro_data',

            'rules': [

                {

                    'id': rule.id,

                    'name': rule.name,

                    'description': rule.description,

                    'severity': rule.severity,

                    'type': rule.type,

                    'language': rule.language,

                    'pattern': rule.pattern,

                    'remediation_effort': rule.remediation_effort,

                    'tags': rule.tags,

                    'enabled': rule.enabled,

                    'custom': rule.custom,

                    'threat_category': rule.threat_category

                }

                for rule in detector.rules_engine.rules.values()

            ],

            'threat_shields': [

                {

                    'id': shield.id,

                    'name': shield.name,

                    'protection_rules': shield.protection_rules,

                    'is_default': shield.is_default,

                    'threat_categories': shield.threat_categories,

                    'risk_threshold': shield.risk_threshold

                }

                for shield in detector.threat_shields.shields.values()

            ],

            'threats': [

                {

                    'id': issue.id,

                    'rule_id': issue.rule_id,

                    'file_path': issue.file_path,

                    'line_number': issue.line_number,

                    'column': issue.column,

                    'message': issue.message,

                    'severity': issue.severity,

                    'type': issue.type,

                    'status': issue.status,

                    'assignee': issue.assignee,

                    'creation_date': issue.creation_date,

                    'update_date': issue.update_date,

                    'effort': issue.effort,

                    'code_snippet': issue.code_snippet,

                    'suggested_fix': issue.suggested_fix,

                    'threat_level': issue.threat_level,

                    'trigger_analysis': issue.trigger_analysis,

                    'payload_analysis': issue.payload_analysis

                }

                for issue in detector.issue_manager.issues.values()

            ],

            'scan_history': [

                {

                    'scan_id': scan.scan_id,

                    'project_id': scan.project_id,

                    'timestamp': scan.timestamp,

                    'duration_ms': scan.duration_ms,

                    'files_scanned': scan.files_scanned,

                    'lines_of_code': scan.lines_of_code,

                    'coverage': scan.coverage,

                    'duplications': scan.duplications,

                    'maintainability_rating': scan.maintainability_rating,

                    'reliability_rating': scan.reliability_rating,

                    'security_rating': scan.security_rating,

                    'threat_shield_status': scan.threat_shield_status,

                    'logic_bomb_risk_score': scan.logic_bomb_risk_score,

                    'threats_count': len(scan.issues)

                }

                for scan in detector.scan_history

            ]

        }

        

        response = app.response_class(

            response=json.dumps(export_data, indent=2),

            status=200,

            mimetype='application/json'

        )

        response.headers['Content-Disposition'] = 'attachment; filename=threatguard_pro_export.json'

        

        return response

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/health', methods=['GET'])

def health_check():

    """Enhanced system health check for ThreatGuard Pro"""

    return jsonify({

        'status': 'healthy',

        'timestamp': datetime.now().isoformat(),

        'version': '2.0.0',

        'scanner_status': 'operational',

        'malware_detection': 'enabled',

        'threat_detection': 'enhanced',

        'supported_languages': list(advanced_detector.supported_languages.values()),

        'data_directory': str(detector.data_dir),

        'rules_count': len(detector.rules_engine.rules),

        'quality_gates_count': len(detector.threat_shields.shields),

        'total_issues': len(detector.issue_manager.issues),

        'scan_history_count': len(detector.scan_history),

        'active_threats': len(detector.issue_manager.get_active_threats()),

        'critical_bombs': len(detector.issue_manager.get_critical_bombs()),

        'system_features': {

            'logic_bomb_detection': 'enabled',

            'advanced_pattern_matching': 'enabled',

            'threat_intelligence': 'enabled',

            'real_time_analysis': 'enabled',

            'auto_neutralization': 'available'

        }

    })



# Additional endpoints for UI compatibility

@app.route('/api/dashboard/metrics')

def get_dashboard_metrics():

    """Backward compatibility endpoint for dashboard metrics"""

    return get_command_center_metrics()



@app.route('/api/scan-history')

def get_scan_history():

    """Get scan history including VSCode scans with optional filtering"""

    try:

        # Get query parameters for filtering

        ait_filter = request.args.get('ait_tag', '')

        spk_filter = request.args.get('spk_tag', '')

        repo_filter = request.args.get('repo_name', '')

        source_filter = request.args.get('source', '')

        

        # Get main scan history

        main_history = []

        for scan in detector.scan_history:

            # Apply filters

            if ait_filter and getattr(scan, 'ait_tag', 'AIT') != ait_filter:

                continue

            if spk_filter and getattr(scan, 'spk_tag', 'SPK-DEFAULT') != spk_filter:

                continue

            if repo_filter and getattr(scan, 'repo_name', 'unknown-repo') != repo_filter:

                continue

            if source_filter and 'main_scan' != source_filter:

                continue

                

            main_history.append({

                'scan_id': scan.scan_id,

                'project_id': scan.project_id,

                'ait_tag': getattr(scan, 'ait_tag', 'AIT'),

                'spk_tag': getattr(scan, 'spk_tag', 'SPK-DEFAULT'),

                'repo_name': getattr(scan, 'repo_name', 'unknown-repo'),

                'timestamp': scan.timestamp,

                'duration_ms': scan.duration_ms,

                'files_scanned': scan.files_scanned,

                'logic_bombs': len(scan.issues),

                'logic_bomb_risk_score': scan.logic_bomb_risk_score,

                'threat_shield_status': scan.threat_shield_status,

                'threat_level': scan.threat_intelligence.get('threat_level', 'UNKNOWN') if scan.threat_intelligence else 'UNKNOWN',

                'source': 'main_scan'

            })

        

        # Get VSCode scan history from uploaded_projects directory

        vscode_history = []

        uploaded_projects_dir = Path('uploaded_projects')

        if uploaded_projects_dir.exists():

            for scan_dir in uploaded_projects_dir.iterdir():

                if scan_dir.is_dir():

                    scan_data_file = scan_dir / 'scan_data' / 'scan_data.json'

                    if scan_data_file.exists():

                        try:

                            with open(scan_data_file, 'r', encoding='utf-8') as f:

                                scan_data = json.load(f)

                            

                            # Only include VSCode scans

                            if scan_data.get('source') == 'vscode_extension':

                                # Apply filters for VSCode scans

                                if source_filter and 'vscode_extension' != source_filter:

                                    continue

                                

                                scan_metrics = scan_data.get('scan_metrics', {})

                                threats = scan_data.get('threats', [])

                                

                                # Get AIT/SPK/Repo info from scan data

                                scan_ait = scan_data.get('ait_tag', 'AIT')

                                scan_spk = scan_data.get('spk_tag', 'SPK-DEFAULT')

                                scan_repo = scan_data.get('repo_name', 'unknown-repo')

                                

                                # Apply additional filters

                                if ait_filter and scan_ait != ait_filter:

                                    continue

                                if spk_filter and scan_spk != spk_filter:

                                    continue

                                if repo_filter and scan_repo != repo_filter:

                                    continue

                                

                                vscode_history.append({

                                    'scan_id': scan_data.get('scan_id', ''),

                                    'project_id': scan_data.get('file_path', '').split('/')[-1] if scan_data.get('file_path') else 'vscode-workspace',

                                    'file_name': scan_data.get('file_name', ''),

                                    'file_path': scan_data.get('file_path', ''),

                                    'timestamp': scan_data.get('timestamp', ''),

                                    'duration_ms': scan_metrics.get('duration_ms', 0),

                                    'files_scanned': scan_metrics.get('files_scanned', 1),

                                    'lines_of_code': scan_metrics.get('lines_of_code', 0),

                                    'coverage': scan_metrics.get('coverage', 'N/A'),

                                    'issues': threats,

                                    'issues_found': len(threats),

                                    'quality_gate_status': scan_metrics.get('quality_gate_status', 'UNKNOWN'),

                                    'threat_shield_status': scan_metrics.get('threat_shield_status', 'UNKNOWN'),

                                    'source': 'vscode_extension',

                                    'total_threats': len(threats),

                                    'ait_tag': scan_ait,

                                    'spk_tag': scan_spk,

                                    'repo_name': scan_repo

                                })

                        except Exception as e:

                            print(f"Error reading VSCode scan data from {scan_data_file}: {e}")

                            continue

        

        # Combine and sort all history

        all_history = main_history + vscode_history

        all_history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

        

        # Calculate intelligence stats

        total_scans = len(all_history)

        threats_neutralized = len([i for i in detector.issue_manager.issues.values() if i.status == "NEUTRALIZED"])

        avg_risk_score = sum(h.get('logic_bomb_risk_score', 0) for h in all_history) / max(1, total_scans)

        shield_effectiveness = len([h for h in all_history if h.get('threat_shield_status') == 'PROTECTED']) / max(1, total_scans) * 100

        

        return jsonify({

            'scan_history': all_history,

            'total_scans': total_scans,

            'threats_neutralized': threats_neutralized,

            'avg_risk_score': round(avg_risk_score, 1),

            'shield_effectiveness': round(shield_effectiveness, 1)

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



# Delete endpoints for admin panel

@app.route('/api/threats', methods=['DELETE'])

def delete_all_threats():

    """Delete all threats"""

    try:

        detector.issue_manager.issues.clear()

        detector.issue_manager.save_issues()

        return jsonify({'success': True, 'message': 'All threats deleted'})

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/issues', methods=['DELETE'])

def delete_all_issues():

    """Backward compatibility endpoint for deleting all issues"""

    return delete_all_threats()



@app.route('/api/scan-history', methods=['DELETE'])

def delete_scan_history():

    """Delete scan history"""

    try:

        detector.scan_history.clear()

        detector.save_scan_history()

        return jsonify({'success': True, 'message': 'Scan history cleared'})

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/security-tech-debt')

def get_security_tech_debt():

    """Get security technical debt data"""

    try:

        issues = list(detector.issue_manager.issues.values())

        tech_debt_data = []

        

        for issue in issues:

            if hasattr(issue, 'effort') and issue.effort > 0:

                # Determine business impact based on severity

                business_impact = 'Medium'

                if issue.severity == 'CRITICAL':

                    business_impact = 'Critical'

                elif issue.severity == 'MAJOR':

                    business_impact = 'High'

                elif issue.severity == 'MINOR':

                    business_impact = 'Medium'

                else:

                    business_impact = 'Low'

                

                # Determine debt category based on rule_id

                debt_category = 'GENERAL_SECURITY_DEBT'

                if 'hardcoded-credentials' in issue.rule_id:

                    debt_category = 'HARDCODED_CREDENTIALS'

                elif 'hardcoded-urls' in issue.rule_id:

                    debt_category = 'HARDCODED_URLS'

                elif 'input-validation' in issue.rule_id:

                    debt_category = 'INPUT_VALIDATION'

                elif 'vulnerable-libraries' in issue.rule_id:

                    debt_category = 'VULNERABLE_LIBRARIES'

                elif 'access-control' in issue.rule_id:

                    debt_category = 'ACCESS_CONTROL'

                

                tech_debt_data.append({

                    'id': issue.id,

                    'rule_id': issue.rule_id,

                    'file_path': issue.file_path,

                    'file_name': issue.file_path,

                    'line_number': issue.line_number,

                    'message': issue.message,

                    'severity': issue.severity,

                    'business_impact': business_impact,

                    'remediation_effort': issue.effort,

                    'debt_category': debt_category,

                    'debt_category_display': debt_category.replace('_', ' ').title(),

                    'code_snippet': getattr(issue, 'code_snippet', ''),

                    'suggested_fix': getattr(issue, 'suggested_fix', ''),

                    'type': issue.type,

                    'status': issue.status,

                    'ait_tag': getattr(issue, 'ait_tag', 'AIT'),

                    'spk_tag': getattr(issue, 'spk_tag', 'SPK-DEFAULT'),

                    'repo_name': getattr(issue, 'repo_name', 'unknown-repo'),

                    'scan_id': getattr(issue, 'scan_id', 'unknown-scan')

                })

        

        # Group issues by category

        by_category = {}

        summary = {

            'hardcoded_credentials': 0,

            'hardcoded_urls': 0,

            'input_validation': 0,

            'vulnerable_libraries': 0,

            'access_control': 0,

            'total_effort_hours': 0

        }

        

        for issue in tech_debt_data:

            # Use the debt_category from the issue

            category = issue.get('debt_category', 'GENERAL_SECURITY_DEBT').lower()

            

            # Map to summary categories

            if 'hardcoded_credentials' in category:

                summary['hardcoded_credentials'] += 1

            elif 'hardcoded_urls' in category:

                summary['hardcoded_urls'] += 1

            elif 'input_validation' in category:

                summary['input_validation'] += 1

            elif 'vulnerable_libraries' in category:

                summary['vulnerable_libraries'] += 1

            elif 'access_control' in category:

                summary['access_control'] += 1

            

            # Add to category

            if category not in by_category:

                by_category[category] = []

            by_category[category].append(issue)

            

            # Add to total effort

            summary['total_effort_hours'] += issue.get('remediation_effort', 0) // 60

        

        return jsonify({

            'summary': summary,

            'by_category': by_category

        })

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/projects', methods=['GET'])

def list_copilot_projects():

    """List all uploaded projects available for Copilot remediation."""

    try:

        print(f"[DEBUG] Starting list_copilot_projects")

        projects_dir = Path('uploaded_projects')

        print(f"[DEBUG] Projects directory: {projects_dir}")

        print(f"[DEBUG] Projects directory exists: {projects_dir.exists()}")

        

        if not projects_dir.exists():

            print(f"[DEBUG] Projects directory does not exist, returning empty list")

            return jsonify({'projects': []})

        

        projects = []

        scan_dirs = list(projects_dir.iterdir())

        print(f"[DEBUG] Found {len(scan_dirs)} scan directories")

        

        for scan_dir in scan_dirs:

            if scan_dir.is_dir():

                scan_id = scan_dir.name

                print(f"[DEBUG] Processing scan directory: {scan_id}")

                

                # Check if copilot task exists

                task_file = scan_dir / 'copilot_tasks' / 'copilot_task.json'

                vscode_prompts_file = scan_dir / 'vscode_prompts' / 'prompts_metadata.json'

                

                print(f"[DEBUG] Task file exists: {task_file.exists()}")

                print(f"[DEBUG] VS Code prompts file exists: {vscode_prompts_file.exists()}")

                

                task_data = None

                vscode_data = None

                

                if task_file.exists():

                    try:

                        with open(task_file, 'r', encoding='utf-8') as f:

                            task_data = json.load(f)

                        print(f"[DEBUG] Loaded task data for {scan_id}")

                    except (json.JSONDecodeError, Exception) as e:

                        print(f"[DEBUG] Error loading task data for {scan_id}: {e}")

                        task_data = None

                

                if vscode_prompts_file.exists():

                    try:

                        with open(vscode_prompts_file, 'r', encoding='utf-8') as f:

                            vscode_data = json.load(f)

                        print(f"[DEBUG] Loaded VS Code data for {scan_id}")

                    except (json.JSONDecodeError, Exception) as e:

                        print(f"[DEBUG] Error loading VS Code data for {scan_id}: {e}")

                        vscode_data = None

                

                # Count files

                original_dir = scan_dir / 'original'

                remediated_dir = scan_dir / 'remediated'

                vscode_remediated_dir = scan_dir / 'remediated_files'

                

                original_files = list(original_dir.glob('*')) if original_dir.exists() else []

                remediated_files = list(remediated_dir.glob('*')) if remediated_dir.exists() else []

                vscode_remediated_files = list(vscode_remediated_dir.glob('*')) if vscode_remediated_dir.exists() else []

                

                print(f"[DEBUG] {scan_id} - Original files: {len(original_files)}, Remediated: {len(remediated_files)}, VS Code: {len(vscode_remediated_files)}")

                

                # Determine project name and status

                project_name = "File Upload Scan"

                if task_data and isinstance(task_data, dict) and task_data.get('project_name'):

                    project_name = task_data.get('project_name')

                elif vscode_data and isinstance(vscode_data, dict) and vscode_data.get('scan_id'):

                    project_name = f"VS Code Scan {scan_id}"

                

                print(f"[DEBUG] Determined project name: {project_name}")

                print(f"[DEBUG] Task data project_name: {task_data.get('project_name') if task_data and isinstance(task_data, dict) else 'None'}")

                

                # Skip VS Code extension scans - only show React UI scans in copilot remediation

                project_id = task_data.get('project_id', f'upload-scan-{scan_id}') if task_data and isinstance(task_data, dict) else f'upload-scan-{scan_id}'

                

                # Check for VS Code extension scans by project name, project_id pattern, or source field

                source = task_data.get('source', '') if task_data and isinstance(task_data, dict) else ''

                print(f"[DEBUG] Scan {scan_id} - Project: {project_name}, ID: {project_id}, Source: {source}")

                

                # Check if this is a VS Code extension scan

                is_vscode_scan = (project_name.startswith("VS Code") or 

                                project_name == "VS Code File Scan" or 

                                project_id.startswith("vscode-scan-") or 

                                project_id.startswith("vscode-workspace-") or

                                source == "vscode-extension")

                

                # Check if this is a React UI scan

                is_react_ui_scan = (source == "react-ui" or 

                                  project_name == "Quick Security Scan" or

                                  project_id.startswith("react-ui-scan-"))

                

                # Check for AIT-SPK-REPO pattern in project_id (React UI scans)

                if "-" in project_id and any(part.startswith(("AIT", "SPK", "REPO")) for part in project_id.split("-")):

                    is_react_ui_scan = True

                    print(f"[DEBUG] Detected React UI scan by AIT-SPK-REPO pattern: {project_id}")

                

                # Check for AIT-SPK-REPO pattern in project_name (React UI scans)

                if project_name and "-" in project_name and any(part.startswith(("AIT", "SPK", "REPO")) for part in project_name.split("-")):

                    is_react_ui_scan = True

                    print(f"[DEBUG] Detected React UI scan by AIT-SPK-REPO pattern in project_name: {project_name}")

                

                # Check if scan has AIT-SPK-REPO tags in issues (from scan history)

                has_ait_spk_repo_tags = False

                try:

                    scan_history_file = Path('threatguard_data') / 'scan_history.json'

                    if scan_history_file.exists():

                        with open(scan_history_file, 'r', encoding='utf-8') as f:

                            scan_history = json.load(f)

                        

                        for scan in scan_history:

                            if scan.get('scan_id') == scan_id and 'issues' in scan and scan['issues']:

                                for issue in scan['issues']:

                                    if (issue.get('ait_tag') and issue.get('spk_tag') and issue.get('repo_name')):

                                        has_ait_spk_repo_tags = True

                                        print(f"[DEBUG] Found AIT-SPK-REPO tags in scan {scan_id}: AIT={issue.get('ait_tag')}, SPK={issue.get('spk_tag')}, REPO={issue.get('repo_name')}")

                                        break

                                if has_ait_spk_repo_tags:

                                    break

                except Exception as e:

                    print(f"[DEBUG] Error checking scan history for AIT-SPK-REPO tags: {e}")

                

                if has_ait_spk_repo_tags:

                    is_react_ui_scan = True

                    print(f"[DEBUG] Detected React UI scan by AIT-SPK-REPO tags in issues: {scan_id}")

                

                # Only include upload-scan-* if it has the AIT-SPK-REPO pattern

                if project_id.startswith("upload-scan-"):

                    if "-" in project_id and any(part.startswith(("AIT", "SPK", "REPO")) for part in project_id.split("-")):

                        is_react_ui_scan = True

                        print(f"[DEBUG] Detected React UI scan by upload-scan pattern with AIT-SPK-REPO: {project_id}")

                    else:

                        print(f"[DEBUG] Filtering out upload-scan without AIT-SPK-REPO pattern: {project_id}")

                        continue

                

                # For existing scans without source field, check project_id pattern

                if not source and not is_vscode_scan and not is_react_ui_scan:

                    # Check if project_id contains AIT-SPK-REPO pattern (React UI scans)

                    if "-" in project_id and any(part.startswith(("AIT", "SPK", "REPO")) for part in project_id.split("-")):

                        is_react_ui_scan = True

                        print(f"[DEBUG] Detected React UI scan by project_id pattern: {project_id}")

                

                # Also check if project_name is None but project_id has AIT-SPK-REPO pattern

                if project_name is None and not is_vscode_scan and not is_react_ui_scan:

                    if "-" in project_id and any(part.startswith(("AIT", "SPK", "REPO")) for part in project_id.split("-")):

                        is_react_ui_scan = True

                        print(f"[DEBUG] Detected React UI scan by project_id pattern (project_name is None): {project_id}")

                

                # Include any scan that has AIT-SPK-REPO tags in its issues (React UI scans)

                if has_ait_spk_repo_tags and not is_vscode_scan:

                    is_react_ui_scan = True

                    print(f"[DEBUG] Including scan with AIT-SPK-REPO tags: {scan_id} - {project_name} (ID: {project_id}, Source: {source})")

                

                if is_vscode_scan:

                    print(f"[DEBUG] Skipping VS Code extension scan: {scan_id} - {project_name} (ID: {project_id}, Source: {source})")

                    continue

                elif is_react_ui_scan:

                    print(f"[DEBUG] Including React UI scan: {scan_id} - {project_name} (ID: {project_id}, Source: {source})")

                else:

                    # Filter out unknown scans - only include explicitly identified React UI scans

                    print(f"[DEBUG] Unknown scan type, filtering out: {scan_id} - {project_name} (ID: {project_id}, Source: {source})")

                    continue

                

                # Determine status

                status = 'pending'

                if vscode_data and isinstance(vscode_data, dict) and vscode_data.get('prompts'):

                    # Check if any prompts are completed

                    prompts = vscode_data.get('prompts', [])

                    if isinstance(prompts, list):

                        completed_prompts = [p for p in prompts if isinstance(p, dict) and p.get('status') == 'completed']

                        if completed_prompts:

                            status = 'completed'

                        elif prompts:

                            status = 'processing'

                

                # Count total files

                total_files = len(original_files)

                

                # Count security issues

                total_issues = 0

                critical_issues = 0

                if vscode_data and isinstance(vscode_data, dict) and vscode_data.get('prompts'):

                    prompts = vscode_data.get('prompts', [])

                    if isinstance(prompts, list):

                        for prompt in prompts:

                            if isinstance(prompt, dict):

                                security_issues = prompt.get('security_issues', [])

                                if isinstance(security_issues, list):

                                    total_issues += len(security_issues)

                                    critical_issues += len([i for i in security_issues if isinstance(i, dict) and i.get('severity') == 'HIGH'])

                

                project_data = {

                    'scan_id': scan_id,

                    'project_name': project_name,

                    'project_id': project_id,

                    'timestamp': vscode_data.get('timestamp', task_data.get('timestamp', 'unknown') if task_data and isinstance(task_data, dict) else 'unknown') if vscode_data and isinstance(vscode_data, dict) else 'unknown',

                    'status': status,

                    'file_count': total_files,

                    'original_files_count': len(original_files),

                    'remediated_files_count': len(remediated_files) + len(vscode_remediated_files),

                    'total_issues': total_issues,

                    'critical_issues': critical_issues,

                    'has_vscode_prompts': vscode_data is not None,

                    'has_copilot_task': task_data is not None

                }

                

                print(f"[DEBUG] Adding project: {project_data}")

                projects.append(project_data)

        

        print(f"[DEBUG] Total projects found: {len(projects)}")

        

        # Sort by timestamp (newest first)

        projects.sort(key=lambda x: x['timestamp'], reverse=True)

        

        response_data = {'projects': projects}

        print(f"[DEBUG] Returning response: {response_data}")

        return jsonify(response_data)

        

    except Exception as e:

        print(f"[DEBUG] Error in list_copilot_projects: {e}")

        import traceback

        traceback.print_exc()

        return jsonify({'error': str(e), 'projects': []}), 500



@app.route('/api/copilot/process/<scan_id>', methods=['POST'])

def process_copilot_task_endpoint(scan_id):

    """Process Copilot task for a specific scan."""

    try:

        result = process_copilot_task(scan_id)

        return jsonify(result)

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/files/<scan_id>', methods=['GET', 'OPTIONS'])

def get_copilot_available_files(scan_id):

    """Get list of available files for a specific scan."""

    if request.method == 'OPTIONS':

        # Handle preflight request

        return jsonify({'status': 'ok'})

    

    try:

        print(f"[DEBUG] Getting available files for scan_id: {scan_id}")

        task_file = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

        print(f"[DEBUG] Task file path: {task_file}")

        print(f"[DEBUG] Task file exists: {task_file.exists()}")

        

        if not task_file.exists():

            print(f"[DEBUG] Task file not found for scan_id: {scan_id}")

            return jsonify({'error': 'Task not found'}), 404

        

        with open(task_file, 'r', encoding='utf-8') as f:

            task_data = json.load(f)

        

        # Get files from suggested_remediations

        available_files = list(task_data.get('suggested_remediations', {}).keys())

        print(f"[DEBUG] Available files: {available_files}")

        print(f"[DEBUG] Total files: {len(available_files)}")

        

        response_data = {

            'scan_id': scan_id,

            'available_files': available_files,

            'total_files': len(available_files)

        }

        print(f"[DEBUG] Response data: {response_data}")

        

        return jsonify(response_data)

        

    except Exception as e:

        print(f"[DEBUG] Error in get_copilot_available_files: {str(e)}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/files/<scan_id>/<path:file_name>', methods=['GET', 'OPTIONS'])

def get_copilot_file_contents(scan_id, file_name):

    """Get original and remediated file contents for comparison."""

    if request.method == 'OPTIONS':

        # Handle preflight request

        return jsonify({'status': 'ok'})

    

    try:

        print(f"[DEBUG] Getting file contents for scan_id: {scan_id}, file_name: {file_name}")

        # Decode the file name to handle special characters

        decoded_file_name = unquote(file_name)

        print(f"[DEBUG] Decoded file name: {decoded_file_name}")

        

        # Handle file paths with subdirectories properly

        original_file = Path('uploaded_projects') / scan_id / 'original' / decoded_file_name

        

        # Look for remediated file with the new naming convention

        file_name_without_ext = Path(decoded_file_name).stem

        file_ext = Path(decoded_file_name).suffix

        remediated_file_name = f"{file_name_without_ext}_original_remediated{file_ext}"

        remediated_file = Path('uploaded_projects') / scan_id / 'remediated_files' / remediated_file_name

        

        # Also try to get the remediated file path from copilot task JSON

        task_file = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

        if task_file.exists():

            try:

                with open(task_file, 'r', encoding='utf-8') as f:

                    task_data = json.load(f)

                

                # Find the file in file_paths

                for file_path, file_info in task_data.get("file_paths", {}).items():

                    if file_info.get("file_name") == decoded_file_name:

                        remediated_file_path = file_info.get("remediated_file_path")

                        if remediated_file_path:

                            remediated_file = Path(remediated_file_path)

                            print(f"[DEBUG] Found remediated file path in task: {remediated_file}")

                            break

            except Exception as e:

                print(f"[DEBUG] Error reading task file: {e}")

                # Continue with default path

        

        print(f"[DEBUG] Original file path: {original_file}")

        print(f"[DEBUG] Original file exists: {original_file.exists()}")

        print(f"[DEBUG] Original file absolute path: {original_file.absolute()}")

        print(f"[DEBUG] Remediated file path: {remediated_file}")

        print(f"[DEBUG] Remediated file exists: {remediated_file.exists()}")

        print(f"[DEBUG] Remediated file absolute path: {remediated_file.absolute()}")

        

        # Check if parent directories exist

        print(f"[DEBUG] Original parent exists: {original_file.parent.exists()}")

        print(f"[DEBUG] Remediated parent exists: {remediated_file.parent.exists()}")

        

        original_content = ""

        remediated_content = ""

        

        if original_file.exists():

            with open(original_file, 'r', encoding='utf-8') as f:

                original_content = f.read()

            print(f"[DEBUG] Original content length: {len(original_content)}")

        else:

            print(f"[DEBUG] Original file does not exist!")

        

        if remediated_file.exists():

            with open(remediated_file, 'r', encoding='utf-8') as f:

                remediated_content = f.read()

            print(f"[DEBUG] Remediated content length: {len(remediated_content)}")

        else:

            print(f"[DEBUG] Remediated file does not exist!")

        

        response_data = {

            'scan_id': scan_id,

            'file_name': decoded_file_name,

            'original_content': original_content,

            'remediated_content': remediated_content,

            'has_original': original_file.exists(),

            'has_remediated': remediated_file.exists()

        }

        print(f"[DEBUG] Response data keys: {list(response_data.keys())}")

        

        return jsonify(response_data)

        

    except Exception as e:

        print(f"[DEBUG] Error in get_copilot_file_contents: {str(e)}")

        import traceback

        print(f"[DEBUG] Full traceback: {traceback.format_exc()}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/task/<scan_id>', methods=['GET'])

def get_copilot_task(scan_id):

    """Get Copilot task details for a specific scan."""

    try:

        task_file = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

        if not task_file.exists():

            return jsonify({'error': 'Task not found'}), 404

        

        with open(task_file, 'r', encoding='utf-8') as f:

            task_data = json.load(f)

        

        return jsonify(task_data)

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/agent/start', methods=['POST'])

def start_automated_copilot_agent():

    """Start the automated Copilot agent."""

    try:

        success = start_copilot_agent()

        if success:

            return jsonify({

                'status': 'success',

                'message': 'Automated Copilot agent started successfully',

                'agent_status': get_agent_status()

            })

        else:

            return jsonify({

                'status': 'warning',

                'message': 'Copilot agent is already running',

                'agent_status': get_agent_status()

            })

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/agent/stop', methods=['POST'])

def stop_automated_copilot_agent():

    """Stop the automated Copilot agent."""

    try:

        success = stop_copilot_agent()

        if success:

            return jsonify({

                'status': 'success',

                'message': 'Automated Copilot agent stopped successfully',

                'agent_status': get_agent_status()

            })

        else:

            return jsonify({

                'status': 'warning',

                'message': 'Copilot agent is not running',

                'agent_status': get_agent_status()

            })

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/agent/status', methods=['GET'])

def get_automated_copilot_agent_status():

    """Get the status of the automated Copilot agent."""

    try:

        status = get_agent_status()

        return jsonify(status)

    except Exception as e:

        return jsonify({'error': str(e)}), 500



def generate_copilot_task(scan_id: str, project_id: str, project_name: str, issues: list, file_results: list, threat_intelligence: dict, source: str = 'unknown') -> None:

    """Generates a Copilot task file for automated remediation."""

    try:

        task_data = {

            "scan_id": scan_id,

            "project_id": project_id,

            "project_name": project_name,  # Add project name for filtering

            "source": source,  # Add source field for filtering

            "timestamp": datetime.now().isoformat(),

            "status": "pending",  # Add status field

            "threat_intelligence": threat_intelligence,

            "issues_summary": {

                "total_issues": len(issues),

                "critical_bombs": len([i for i in issues if i.severity == "CRITICAL_BOMB"]),

                "high_risks": len([i for i in issues if i.severity == "HIGH_RISK"]),

                "medium_risks": len([i for i in issues if i.severity == "MEDIUM_RISK"]),

                "low_risks": len([i for i in issues if i.severity == "LOW_RISK"]),

                "critical_issues": len([i for i in issues if i.severity == "CRITICAL"]),

                "major_issues": len([i for i in issues if i.severity == "MAJOR"]),

                "minor_issues": len([i for i in issues if i.severity == "MINOR"]),

                "info_issues": len([i for i in issues if i.severity == "INFO"]),

                "unknown_issues": len([i for i in issues if i.severity == "UNKNOWN"])

            },

            "file_results": file_results,

            "suggested_remediations": {},

            "file_paths": {}  # Add file paths mapping

        }



        # Group issues by file for easier remediation

        for file_result in file_results:

            file_name = file_result['file_name']

            # Use the full file path to handle subdirectories

            file_path = file_result.get('file_path', file_name)

            

            # Store the source file path for remediation

            original_dir = Path('uploaded_projects') / scan_id / 'original'

            source_file_path = original_dir / file_path

            task_data["file_paths"][file_path] = {

                "source_file_path": str(source_file_path),

                "file_name": file_name,

                "file_path": file_path,

                "remediated_file_path": str(Path('uploaded_projects') / scan_id / 'remediated_files' / f"{Path(file_name).stem}_original_remediated{Path(file_path).suffix}")

            }

            

            task_data["suggested_remediations"][file_path] = []

            for issue in file_result['issues']:

                # Only include issues that are not already neutralized

                if issue['status'] != 'NEUTRALIZED':

                    task_data["suggested_remediations"][file_path].append({

                        "issue_id": issue['id'],

                        "rule_id": issue['rule_id'],

                        "message": issue['message'],

                        "severity": issue['severity'],

                        "type": issue['type'],

                        "code_snippet": issue['code_snippet'],

                        "suggested_fix": issue['suggested_fix'],

                        "threat_level": issue['threat_level'],

                        "trigger_analysis": issue['trigger_analysis'],

                        "payload_analysis": issue['payload_analysis'],

                        "effort_minutes": issue['effort_minutes']

                    })



        # Ensure the directory exists

        task_dir = Path('uploaded_projects') / scan_id / 'copilot_tasks'

        task_dir.mkdir(parents=True, exist_ok=True)



        # Save the task file

        task_file_path = task_dir / 'copilot_task.json'

        with open(task_file_path, 'w', encoding='utf-8') as f:

            json.dump(task_data, f, indent=4)

        print(f"Copilot task generated at: {task_file_path}")



    except Exception as e:

        print(f"Error generating Copilot task: {e}")



def process_copilot_task(scan_id: str) -> dict:

    """Process Copilot task and generate remediated files."""

    try:

        task_file_path = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

        if not task_file_path.exists():

            return {"error": "Copilot task not found"}

        

        with open(task_file_path, 'r', encoding='utf-8') as f:

            task_data = json.load(f)

        

        # Create remediated files directory

        remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

        remediated_dir.mkdir(parents=True, exist_ok=True)

        

        remediated_files = []

        

        # Process each file that has issues

        for file_path, remediations in task_data.get("suggested_remediations", {}).items():

            if remediations:  # Only process files with issues

                # Get source file path from the file_paths mapping

                file_info = task_data.get("file_paths", {}).get(file_path, {})

                source_file_path = file_info.get("source_file_path")

                

                if not source_file_path:

                    print(f"Warning: No source file path found for {file_path}")

                    continue

                

                original_file_path = Path(source_file_path)

                if original_file_path.exists():

                    with open(original_file_path, 'r', encoding='utf-8') as f:

                        original_content = f.read()

                    

                    # Apply remediations (stub - in real implementation, this would use Copilot API)

                    remediated_content = apply_copilot_remediations(original_content, remediations)

                    

                    # Save remediated file with proper naming for diff comparison

                    file_name = file_info.get("file_name", Path(file_path).name)

                    remediated_file_path = Path(file_info.get("remediated_file_path", str(remediated_dir / f"{file_name}_original_remediated{Path(file_path).suffix}")))

                    

                    # Ensure the remediated directory exists

                    remediated_file_path.parent.mkdir(parents=True, exist_ok=True)

                    

                    with open(remediated_file_path, 'w', encoding='utf-8') as f:

                        f.write(remediated_content)

                    

                    remediated_files.append({

                        "file_name": file_name,

                        "file_path": file_path,

                        "original_path": str(original_file_path),

                        "remediated_path": str(remediated_file_path),

                        "remediations_applied": len(remediations)

                    })

        

        # Update task status

        task_data["status"] = "completed"

        task_data["remediated_files"] = remediated_files

        task_data["completion_timestamp"] = datetime.now().isoformat()

        

        with open(task_file_path, 'w', encoding='utf-8') as f:

            json.dump(task_data, f, indent=4)

        

        return {

            "status": "completed",

            "scan_id": scan_id,

            "remediated_files": remediated_files,

            "total_files_processed": len(remediated_files)

        }

        

    except Exception as e:

        return {"error": f"Error processing Copilot task: {e}"}



def apply_copilot_remediations(original_content: str, remediations: list) -> str:

    """Apply Copilot remediations to file content (stub implementation)."""

    # This is a stub - in real implementation, this would:

    # 1. Parse the original content

    # 2. Use Copilot API to generate fixes

    # 3. Apply the fixes to the content

    # 4. Return the remediated content

    

    remediated_content = original_content

    

    for remediation in remediations:

        # Add comments indicating what was fixed

        fix_comment = f"\n// FIXED: {remediation['message']} - {remediation['suggested_fix']}\n"

        remediated_content += fix_comment

    

    return remediated_content



@app.route('/api/copilot/vscode/instructions/<scan_id>', methods=['GET'])

def get_vscode_instructions(scan_id):

    """Get VS Code Copilot instructions for a scan."""

    try:

        instructions_dir = Path('uploaded_projects') / scan_id / 'vscode_instructions'

        if not instructions_dir.exists():

            return jsonify({'error': 'Instructions not found'}), 404

        

        instructions = []

        for file_path in instructions_dir.glob('*_instructions.md'):

            with open(file_path, 'r', encoding='utf-8') as f:

                content = f.read()

            

            instructions.append({

                'file': file_path.stem.replace('_instructions', ''),

                'content': content,

                'type': 'instructions'

            })

        

        return jsonify({

            'scan_id': scan_id,

            'instructions': instructions,

            'total_files': len(instructions)

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/vscode/prompts/<scan_id>', methods=['GET'])

def get_vscode_prompts(scan_id):

    """Get VS Code Copilot prompts for a scan."""

    try:

        instructions_dir = Path('uploaded_projects') / scan_id / 'vscode_instructions'

        if not instructions_dir.exists():

            return jsonify({'error': 'Prompts not found'}), 404

        

        prompts = []

        for file_path in instructions_dir.glob('*_copilot_prompt.txt'):

            with open(file_path, 'r', encoding='utf-8') as f:

                content = f.read()

            

            prompts.append({

                'file': file_path.stem.replace('_copilot_prompt', ''),

                'content': content,

                'type': 'prompt'

            })

        

        return jsonify({

            'scan_id': scan_id,

            'prompts': prompts,

            'total_files': len(prompts)

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/vscode/workspace/<scan_id>', methods=['GET'])

def get_vscode_workspace(scan_id):

    """Get VS Code workspace file for a scan."""

    try:

        workspace_file = Path('vscode_remediation_workspaces') / scan_id / f'{scan_id}.code-workspace'

        if not workspace_file.exists():

            return jsonify({'error': 'Workspace not found'}), 404

        

        with open(workspace_file, 'r', encoding='utf-8') as f:

            workspace_content = f.read()

        

        return jsonify({

            'scan_id': scan_id,

            'workspace_file': str(workspace_file),

            'workspace_content': workspace_content

        })

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/copilot/vscode/download/<scan_id>', methods=['GET'])

def download_vscode_files(scan_id):

    """Download all VS Code files for a scan as a ZIP."""

    try:

        import zipfile

        import io

        

        # Create ZIP file in memory

        zip_buffer = io.BytesIO()

        

        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:

            # Add instructions

            instructions_dir = Path('uploaded_projects') / scan_id / 'vscode_instructions'

            if instructions_dir.exists():

                for file_path in instructions_dir.rglob('*'):

                    if file_path.is_file():

                        arc_name = f'vscode_instructions/{file_path.name}'

                        zip_file.write(file_path, arc_name)

            

            # Add workspace

            workspace_file = Path('vscode_remediation_workspaces') / scan_id / f'{scan_id}.code-workspace'

            if workspace_file.exists():

                zip_file.write(workspace_file, f'workspace/{scan_id}.code-workspace')

            

            # Add original files

            original_dir = Path('uploaded_projects') / scan_id / 'original'

            if original_dir.exists():

                for file_path in original_dir.rglob('*'):

                    if file_path.is_file():

                        arc_name = f'original_files/{file_path.relative_to(original_dir)}'

                        zip_file.write(file_path, arc_name)

        

        zip_buffer.seek(0)

        

        return send_file(

            zip_buffer,

            mimetype='application/zip',

            as_attachment=True,

            download_name=f'vscode_copilot_remediation_{scan_id}.zip'

        )

        

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/remediate', methods=['POST'])

def vscode_remediate():

    """Handle VS Code agent remediation requests"""

    try:

        data = request.get_json()

        

        if not data:

            return jsonify({'error': 'No data provided'}), 400

            

        file_path = data.get('file_path')

        content = data.get('content')

        params = data.get('params', {})

        

        if not file_path or not content:

            return jsonify({'error': 'Missing file_path or content'}), 400

            

        # Generate remediation prompt

        language = detect_language_from_path(file_path)

        prompt = generate_vscode_remediation_prompt(file_path, content, params, language)

        

        # Execute remediation

        remediated_content = execute_vscode_remediation(prompt, file_path, language, content)

        

        # Save remediated file

        scan_id = params.get('scan_id', f"vscode_{int(time.time())}")

        saved_path = save_vscode_remediated_file(file_path, remediated_content, scan_id, params)

        

        return jsonify({

            'success': True,

            'scan_id': scan_id,

            'remediated_file': saved_path,

            'original_file': file_path,

            'timestamp': datetime.now().isoformat()

        })

        

    except Exception as e:

        logging.error(f"Error in VS Code remediation: {e}")

        return jsonify({'error': str(e)}), 500



def detect_language_from_path(file_path: str) -> str:

    """Detect language from file path"""

    ext = Path(file_path).suffix.lower()

    language_map = {

        '.py': 'python',

        '.js': 'javascript',

        '.ts': 'typescript',

        '.java': 'java',

        '.cs': 'csharp',

        '.php': 'php',

        '.rb': 'ruby',

        '.go': 'go',

        '.rs': 'rust',

        '.cpp': 'cpp',

        '.c': 'c',

        '.html': 'html',

        '.css': 'css',

        '.json': 'json'

    }

    return language_map.get(ext, 'text')



def generate_vscode_remediation_prompt(file_path: str, content: str, params: dict, language: str) -> str:

    """Generate remediation prompt for VS Code agent"""

    return f"""# SECURITY VULNERABILITY FIX REQUEST

# File: {Path(file_path).name}

# Language: {language}

# Scan ID: {params.get('scan_id', 'unknown')}

# Severity: {params.get('severity', 'MEDIUM')}

# Type: {params.get('type', 'GENERAL')}



# TASK FOR GITHUB COPILOT:

Please provide a secure, fixed version of this code that addresses potential security vulnerabilities.



# REQUIREMENTS:

1. Remove dangerous operations (subprocess calls, system commands, etc.)

2. Add proper input validation and sanitization

3. Use secure alternatives and best practices

4. Add comprehensive error handling

5. Include logging for security events

6. Follow OWASP security guidelines

7. Maintain the same functionality where possible

8. Add comments explaining security improvements



# SECURITY FOCUS AREAS:

- Replace destructive operations with safe alternatives

- Remove hardcoded credentials and secrets

- Add input validation and sanitization

- Implement proper error handling

- Use secure file operations

- Add logging and monitoring

- Follow principle of least privilege



# ORIGINAL CODE:

```{language}

{content}

```



# EXPECTED OUTPUT:

Please provide the complete fixed code with security improvements:



```{language}

"""



def execute_vscode_remediation(prompt: str, file_path: str, language: str, original_content: str = None) -> str:

    """Execute VS Code remediation by applying fixes to original content"""

    try:

        # If no original content provided, try to read it

        if original_content is None:

            original_file = Path(file_path)

            if original_file.exists():

                with open(original_file, 'r', encoding='utf-8') as f:

                    original_content = f.read()

            else:

                # Fallback to template if original file not found

                return f"""# SECURITY FIX: Generated by ThreatGuard VS Code Agent

# Original file: {Path(file_path).name}

# Remediation timestamp: {datetime.now().isoformat()}

# Note: Original file not found, using template



import logging

from pathlib import Path

import os



# Configure logging

logging.basicConfig(level=logging.INFO)

logger = logging.getLogger(__name__)



def secure_operation():

    \"\"\"

    Secure version of the original operation

    \"\"\"

    try:

        # Add your secure implementation here

        logger.info("Secure operation executed successfully")

        return True

    except Exception as e:

        logger.error("Secure operation failed: " + str(e))

        return False






if __name__ == "__main__":

    secure_operation()

"""

        

        # Start with the original content

        remediated_content = original_content

        

        # Add security header

        security_header = f"""# SECURITY FIX: Generated by ThreatGuard VS Code Agent

# Original file: {Path(file_path).name}

# Remediation timestamp: {datetime.now().isoformat()}

# Security improvements applied below:



"""

        

        # Apply security fixes based on language

        if language == 'python':

            # Apply Python-specific security fixes

            remediated_content = apply_python_security_fixes(remediated_content)

        elif language == 'javascript':

            # Apply JavaScript-specific security fixes

            remediated_content = apply_javascript_security_fixes(remediated_content)

        else:

            # Apply general security fixes

            remediated_content = apply_general_security_fixes(remediated_content)

        

        # Combine header with remediated content

        return security_header + remediated_content

            

    except Exception as e:

        logging.error(f"Error executing VS Code remediation: {e}")

        # Return original content with error comment if remediation fails

        return f"""# SECURITY FIX: Error in remediation

# Original file: {Path(file_path).name}

# Generated: {datetime.now().isoformat()}

# Error: {str(e)}



# Original content preserved below:

{original_content if original_content else "# No original content available"}



# TODO: Review and apply security improvements manually

"""



def apply_python_security_fixes(content: str) -> str:

    """Apply comprehensive Python security fixes with alternative solutions"""

    fixed_content = content

    

    # Replace dangerous subprocess calls with secure alternatives

    fixed_content = re.sub(

        r'subprocess\.call\(([^)]+)\)',

        r'subprocess.run(\1, shell=False, check=True, capture_output=True)',

        fixed_content

    )

    

    # Replace os.system with secure subprocess

    fixed_content = re.sub(

        r'os\.system\(([^)]+)\)',

        r'subprocess.run(\1, shell=False, check=True, capture_output=True)',

        fixed_content

    )

    

    # Replace eval with ast.literal_eval or custom parsing

    fixed_content = re.sub(

        r'eval\(([^)]+)\)',

        r'ast.literal_eval(\1) if ast.literal_eval.__doc__ else custom_safe_eval(\1)',

        fixed_content

    )

    

    # Replace exec with function-based execution

    fixed_content = re.sub(

        r'exec\(([^)]+)\)',

        r'execute_safely(\1)',

        fixed_content

    )

    

    # Replace hardcoded passwords with environment variables

    fixed_content = re.sub(

        r'password\s*=\s*["\'][^"\']*["\']',

        r'password = os.getenv("PASSWORD", "default_secure_password")',

        fixed_content

    )

    

    # Add input validation

    if 'def ' in fixed_content and 'input(' in fixed_content:

        fixed_content = fixed_content.replace(

            'input(',

            'validate_input(input('

        )

    

    # Add proper error handling

    if 'try:' not in fixed_content and 'except:' not in fixed_content:

        fixed_content = f"""import logging

import os

import ast

import subprocess

from typing import Any, Optional



def validate_input(user_input: str) -> str:

    \"\"\"Validate and sanitize user input\"\"\"

    if not user_input or not isinstance(user_input, str):

        raise ValueError("Invalid input provided")

    return user_input.strip()



def execute_safely(code: str) -> Any:

    \"\"\"Execute code safely with sandboxing\"\"\"

    # Implement safe execution logic

    logging.warning(f"Attempted to execute: {{code}}")

    return None



def custom_safe_eval(expression: str) -> Any:

    \"\"\"Custom safe evaluation function\"\"\"

    try:

        return ast.literal_eval(expression)

    except (ValueError, SyntaxError):

        logging.error(f"Unsafe evaluation attempted: {{expression}}")

        return None



# Configure logging

logging.basicConfig(level=logging.INFO)



{fixed_content}"""

    

    return fixed_content



def apply_javascript_security_fixes(content: str) -> str:

    """Apply comprehensive JavaScript security fixes with alternative solutions"""

    fixed_content = content

    

    # Replace eval with safer alternatives

    fixed_content = re.sub(

        r'eval\(([^)]+)\)',

        r'JSON.parse(\1) || safeEval(\1)',

        fixed_content

    )

    

    # Replace innerHTML with textContent or safe alternatives

    fixed_content = re.sub(

        r'\.innerHTML\s*=\s*([^;]+)',

        r'.textContent = sanitizeHTML(\1)',

        fixed_content

    )

    

    # Replace document.write with safer alternatives

    fixed_content = re.sub(

        r'document\.write\(([^)]+)\)',

        r'document.body.appendChild(document.createTextNode(\1))',

        fixed_content

    )

    

    # Replace hardcoded credentials with environment variables

    fixed_content = re.sub(

        r'password\s*:\s*["\'][^"\']*["\']',

        r'password: process.env.PASSWORD || "default_secure_password"',

        fixed_content

    )

    

    # Add input validation

    if 'function' in fixed_content and 'prompt(' in fixed_content:

        fixed_content = fixed_content.replace(

            'prompt(',

            'validateInput(prompt('

        )

    

    # Add security utilities

    if 'function' not in fixed_content or 'validateInput' not in fixed_content:

        fixed_content = f"""// Security utilities

function validateInput(input) {{

    if (!input || typeof input !== 'string') {{

        throw new Error('Invalid input provided');

    }}

    return input.trim();

}}



function sanitizeHTML(html) {{

    const div = document.createElement('div');

    div.textContent = html;

    return div.innerHTML;

}}



function safeEval(code) {{

    console.warn('Attempted to evaluate:', code);

    return null;

}}



// Input validation for all user inputs

function validateUserInput(input, type = 'string') {{

    switch(type) {{

        case 'email':

            return /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(input) ? input : null;

        case 'number':

            return !isNaN(input) ? Number(input) : null;

        case 'string':

        default:

            return validateInput(input);

    }}

}}



{fixed_content}"""

    

    return fixed_content



def apply_general_security_fixes(content: str) -> str:

    """Apply general security fixes with alternative solutions"""

    fixed_content = content

    

    # Add security headers

    if 'http' in fixed_content.lower() or 'https' in fixed_content.lower():

        fixed_content = f"""// Security headers configuration

const securityHeaders = {{

    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';",

    'X-Content-Type-Options': 'nosniff',

    'X-Frame-Options': 'DENY',

    'X-XSS-Protection': '1; mode=block',

    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',

    'Referrer-Policy': 'strict-origin-when-cross-origin'

}};



// Rate limiting configuration

const rateLimitConfig = {{

    windowMs: 15 * 60 * 1000, // 15 minutes

    max: 100, // limit each IP to 100 requests per windowMs

    message: 'Too many requests from this IP'

}};



// CORS configuration

const corsConfig = {{

    origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],

    credentials: true,

    methods: ['GET', 'POST', 'PUT', 'DELETE'],

    allowedHeaders: ['Content-Type', 'Authorization']

}};



{fixed_content}"""

    

    # Add input sanitization

    if 'input' in fixed_content.lower() or 'user' in fixed_content.lower():

        fixed_content = f"""// Input sanitization utilities

function sanitizeInput(input) {{

    if (typeof input !== 'string') return '';

    return input.replace(/[<>\"'&]/g, function(match) {{

        const escape = {{

            '<': '&lt;',

            '>': '&gt;',

            '"': '&quot;',

            "'": '&#x27;',

            '&': '&amp;'

        }};

        return escape[match];

    }});

}}



function validateAndSanitizeInput(input, type = 'string') {{

    const sanitized = sanitizeInput(input);

    if (!sanitized) throw new Error('Invalid input provided');

    return sanitized;

}}



{fixed_content}"""

    

    return fixed_content



def save_vscode_remediated_file(original_file_path: str, remediated_content: str, scan_id: str, params: dict) -> str:

    """Save VS Code remediated file"""

    try:

        # Create remediation directory structure - use the correct path

        remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

        remediated_dir.mkdir(parents=True, exist_ok=True)

        

        # Save remediated file with correct naming convention

        original_file = Path(original_file_path)

        remediated_file = remediated_dir / f"{original_file.stem}_original_original_remediated{original_file.suffix}"

        

        with open(remediated_file, 'w', encoding='utf-8') as f:

            f.write(remediated_content)

            

        # Create metadata file

        metadata = {

            'original_file': original_file_path,

            'remediated_file': str(remediated_file),

            'scan_id': scan_id,

            'timestamp': datetime.now().isoformat(),

            'params': params,

            'status': 'completed'

        }

        

        # Save metadata in the same directory as remediated files

        metadata_file = remediated_dir / 'vscode_metadata.json'

        with open(metadata_file, 'w', encoding='utf-8') as f:

            json.dump(metadata, f, indent=2)

            

        logging.info(f"VS Code remediated file saved: {remediated_file}")

        return str(remediated_file)

        

    except Exception as e:

        logging.error(f"Error saving VS Code remediated file: {e}")

        raise e



@app.route('/api/vscode-agent/status', methods=['GET'])

def vscode_agent_status():

    """Get VS Code agent status"""

    try:

        return jsonify({

            'status': 'running',

            'timestamp': datetime.now().isoformat(),

            'endpoints': {

                'remediate': '/api/vscode-agent/remediate',

                'status': '/api/vscode-agent/status'

            }

        })

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/remediate-content', methods=['GET'])

def get_remediated_content():

    """Get remediated content for VS Code extension"""

    try:

        remediated_file = request.args.get('remediated_file')

        if not remediated_file:

            return jsonify({'error': 'remediated_file parameter is required'}), 400

        

        # Construct the full path to the remediated file

        remediated_path = os.path.join('uploaded_projects', remediated_file)

        

        if not os.path.exists(remediated_path):

            return jsonify({'error': 'Remediated file not found'}), 404

        

        # Read the remediated content

        with open(remediated_path, 'r', encoding='utf-8') as f:

            content = f.read()

        

        return jsonify({

            'content': content,

            'file_path': remediated_path,

            'timestamp': datetime.now().isoformat()

        })

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/save-scan-data', methods=['POST'])

def save_vscode_scan_data():

    """Save scan data from VS Code extension to JSON for React UI"""

    try:

        data = request.get_json()

        if not data:

            return jsonify({'error': 'No data provided'}), 400

        

        # Extract scan data

        scan_id = data.get('scan_id', f'vscode-scan-{int(time.time())}')

        file_path = data.get('file_path', '')

        file_name = data.get('file_name', '')

        content = data.get('content', '')

        threats = data.get('threats', [])

        scan_metrics = data.get('scan_metrics', {})

        timestamp = data.get('timestamp', datetime.now().isoformat())

        

        # Create scan directory structure

        scan_dir = Path('uploaded_projects') / scan_id

        original_dir = scan_dir / 'original'

        scan_data_dir = scan_dir / 'scan_data'

        

        # Create directories

        original_dir.mkdir(parents=True, exist_ok=True)

        scan_data_dir.mkdir(parents=True, exist_ok=True)

        

        # Save original file

        if content and file_name:

            original_file_path = original_dir / file_name

            with open(original_file_path, 'w', encoding='utf-8') as f:

                f.write(content)

        

        # Create scan data JSON

        scan_data = {

            'scan_id': scan_id,

            'file_path': file_path,

            'file_name': file_name,

            'timestamp': timestamp,

            'threats': threats,

            'scan_metrics': scan_metrics,

            'source': 'vscode_extension',

            'total_threats': len(threats),

            'severity_breakdown': {

                'CRITICAL': len([t for t in threats if t.get('severity') == 'CRITICAL']),

                'HIGH': len([t for t in threats if t.get('severity') == 'HIGH']),

                'MEDIUM': len([t for t in threats if t.get('severity') == 'MEDIUM']),

                'LOW': len([t for t in threats if t.get('severity') == 'LOW'])

            },

            'threat_types': {

                'LOGIC_BOMB': len([t for t in threats if t.get('type') == 'LOGIC_BOMB']),

                'DESTRUCTIVE_PAYLOAD': len([t for t in threats if t.get('type') == 'DESTRUCTIVE_PAYLOAD']),

                'VULNERABILITY': len([t for t in threats if t.get('type') == 'VULNERABILITY']),

                'SECURITY_ISSUE': len([t for t in threats if t.get('type') == 'SECURITY_ISSUE'])

            }

        }

        

        # Save scan data JSON

        scan_data_file = scan_data_dir / 'scan_data.json'

        with open(scan_data_file, 'w', encoding='utf-8') as f:

            json.dump(scan_data, f, indent=2, default=str)

        

        # Save threats separately for easy access

        threats_file = scan_data_dir / 'threats.json'

        with open(threats_file, 'w', encoding='utf-8') as f:

            json.dump(threats, f, indent=2, default=str)

        

        # Save scan metrics

        metrics_file = scan_data_dir / 'metrics.json'

        with open(metrics_file, 'w', encoding='utf-8') as f:

            json.dump(scan_metrics, f, indent=2, default=str)

        

        return jsonify({

            'success': True,

            'scan_id': scan_id,

            'message': f'Scan data saved successfully. {len(threats)} threats detected.',

            'scan_data_path': str(scan_data_file),

            'threats_path': str(threats_file),

            'metrics_path': str(metrics_file)

        })

        

    except Exception as e:

        return jsonify({'error': f'Failed to save scan data: {str(e)}'}), 500



def generate_vscode_copilot_prompts(scan_id: str, uploaded_files: List[Dict]) -> Dict[str, Any]:

    """Generate VS Code Copilot prompts for uploaded files"""

    try:

        prompts_dir = Path('uploaded_projects') / scan_id / 'vscode_prompts'

        prompts_dir.mkdir(parents=True, exist_ok=True)

        

        prompts_data = {

            'scan_id': scan_id,

            'timestamp': datetime.now().isoformat(),

            'total_files': len(uploaded_files),

            'prompts': []

        }

        

        # Create .github/prompts directory

        github_prompts_dir = Path('.github') / 'prompts'

        github_prompts_dir.mkdir(parents=True, exist_ok=True)

        

        # Generate markdown prompt file content

        markdown_content = generate_markdown_prompt_content(scan_id, uploaded_files)

        

        # Save markdown file in .github/prompts folder

        markdown_file = github_prompts_dir / f"{scan_id}.prompt.md"

        with open(markdown_file, 'w', encoding='utf-8') as f:

            f.write(markdown_content)

        

        print(f"[DEBUG] Created markdown prompt file: {markdown_file}")

        

        for file_info in uploaded_files:

            file_path = file_info['file_path']

            file_content = file_info['content']

            file_name = Path(file_path).name

            

            # Generate security analysis

            security_issues = analyze_security_issues(file_content, file_path)

            

            # Generate Copilot prompt

            prompt_content = generate_copilot_prompt(file_path, file_content, security_issues, scan_id)

            

            # Save prompt to file

            prompt_file = prompts_dir / f"{Path(file_path).stem}_prompt.txt"

            with open(prompt_file, 'w', encoding='utf-8') as f:

                f.write(prompt_content)

            

            # Save original file for reference

            original_file = prompts_dir / f"{Path(file_path).stem}_original{Path(file_path).suffix}"

            with open(original_file, 'w', encoding='utf-8') as f:

                f.write(file_content)

            

            prompts_data['prompts'].append({

                'file_path': file_path,

                'file_name': file_name,

                'prompt_file': str(prompt_file),

                'original_file': str(original_file),

                'source_file_path': file_path,  # Add source file path

                'security_issues': security_issues,

                'status': 'pending',

                'markdown_file': str(markdown_file)  # Add reference to markdown file

            })

        

        # Save prompts metadata

        metadata_file = prompts_dir / 'prompts_metadata.json'

        with open(metadata_file, 'w', encoding='utf-8') as f:

            json.dump(prompts_data, f, indent=2)

        

        logging.info(f"Generated VS Code Copilot prompts for scan {scan_id}: {len(uploaded_files)} files")

        return prompts_data

        

    except Exception as e:

        logging.error(f"Error generating VS Code Copilot prompts: {e}")

        raise e



def generate_markdown_prompt_content(scan_id: str, uploaded_files: List[Dict]) -> str:

    """Generate markdown content for the prompt file"""

    

    # Get task.json content if it exists

    task_file = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

    task_data = {}

    

    if task_file.exists():

        try:

            with open(task_file, 'r', encoding='utf-8') as f:

                task_data = json.load(f)

        except Exception as e:

            print(f"[DEBUG] Error reading task.json: {e}")

    

    # Check for existing remediated files using the correct naming convention

    remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

    existing_remediated_files = {}

    if remediated_dir.exists():

        for file_path in remediated_dir.rglob('*'):

            if file_path.is_file() and '_original_original_remediated' in file_path.name:

                # Extract original filename by removing the '_original_original_remediated' pattern

                original_name = file_path.name.replace('_original_original_remediated', '')

                existing_remediated_files[original_name] = str(file_path)

    

    # Generate markdown content

    markdown_content = f"""# GitHub Copilot Security Remediation Prompt

## Scan ID: {scan_id}

## Generated: {datetime.now().isoformat()}

## AI-Generated Security Remediation with Alternative Solutions



## 📋 Project Overview

This prompt was generated by ThreatGuard Pro for automated security remediation using GitHub Copilot and AI-powered analysis with intelligent alternative solutions.



### Files to Remediate

"""

    

    # Add file information

    for file_info in uploaded_files:

        file_name = Path(file_info['file_path']).name

        file_path = file_info['file_path']

        

        # Analyze security issues

        security_issues = analyze_security_issues(file_info['content'], file_path)

        

        # Check if remediated file exists using correct naming

        remediated_file_path = existing_remediated_files.get(file_name, None)

        

        markdown_content += f"""

### {file_name}

- **Path**: {file_path}

- **Security Issues**: {len(security_issues)}

- **Language**: {detect_language_from_path(file_path)}

"""

        

        if remediated_file_path:

            markdown_content += f"- **Remediated File**: {remediated_file_path}\n"

        

        markdown_content += f"""

#### Security Issues Found:

"""

        

        for issue in security_issues:

            markdown_content += f"- **{issue['severity']}**: {issue['description']} (Line {issue['line']})\n"

        

        markdown_content += f"""

#### Original Code:

```{detect_language_from_path(file_path)}

{file_info['content']}

```

"""

        

        if remediated_file_path:

            try:

                with open(remediated_file_path, 'r', encoding='utf-8') as f:

                    remediated_content = f.read()

                markdown_content += f"""

#### AI-Remediated Code with Alternative Solutions:

```{detect_language_from_path(file_path)}

{remediated_content}

```

"""

            except Exception as e:

                markdown_content += f"""

#### AI-Remediated Code:

*Remediated file exists but could not be read: {remediated_file_path}*

"""

        

        markdown_content += f"""

#### AI Alternative Solutions Applied:

1. ✅ **Dangerous Operations**: Replaced with secure alternatives

   - `subprocess.call()` → `subprocess.run()` with proper validation

   - `os.system()` → `subprocess.run()` with shell=False

   - `eval()` → `ast.literal_eval()` or custom parsing

   - `exec()` → Function-based execution with sandboxing



2. ✅ **Input Validation**: Added comprehensive validation

   - Type checking and range validation

   - Input sanitization and encoding

   - SQL injection prevention with parameterized queries

   - XSS prevention with proper escaping



3. ✅ **Secure Alternatives**: Implemented OWASP best practices

   - Environment variables for secrets

   - Secure random number generation

   - HTTPS enforcement

   - Content Security Policy headers



4. ✅ **Error Handling**: Added secure error handling

   - Try-catch blocks with specific exceptions

   - Security event logging

   - Graceful degradation

   - No sensitive information in error messages



5. ✅ **Authentication & Authorization**: Enhanced security

   - Multi-factor authentication support

   - Role-based access control

   - Session management with secure tokens

   - Password hashing with bcrypt



6. ✅ **Data Protection**: Implemented data security

   - Encryption at rest and in transit

   - Data masking and anonymization

   - Secure file upload validation

   - Database connection pooling



7. ✅ **Monitoring & Logging**: Added security monitoring

   - Security event logging

   - Audit trails

   - Intrusion detection alerts

   - Performance monitoring



8. ✅ **Rate Limiting**: Implemented protection mechanisms

   - API rate limiting

   - Brute force protection

   - DDoS mitigation

   - Request throttling



9. ✅ **Secure Communication**: Enhanced network security

   - TLS/SSL enforcement

   - Certificate validation

   - Secure headers implementation

   - CORS policy configuration



10. ✅ **Code Quality**: Improved maintainability

    - Type hints and documentation

    - Unit tests for security functions

    - Code review guidelines

    - Dependency vulnerability scanning



---

"""

    

    # Add task.json content if available

    if task_data:

        markdown_content += f"""

## 📊 AI Threat Analysis

Based on the original task.json analysis:



### Threat Intelligence

- **Total Issues**: {task_data.get('total_issues', 0)}

- **Critical Issues**: {task_data.get('critical_issues', 0)}

- **High Issues**: {task_data.get('high_issues', 0)}

- **Medium Issues**: {task_data.get('medium_issues', 0)}

- **Low Issues**: {task_data.get('low_issues', 0)}



### Security Posture

- **Security Rating**: {task_data.get('security_rating', 'Unknown')}

- **Threat Level**: {task_data.get('threat_level', 'Unknown')}

- **Risk Score**: {task_data.get('risk_score', 0)}



### AI-Applied Alternative Solutions

"""

        

        # Add suggested remediations from task.json

        suggested_remediations = task_data.get('suggested_remediations', {})

        for file_path, remediations in suggested_remediations.items():

            if remediations:

                markdown_content += f"\n#### {Path(file_path).name}:\n"

                for remediation in remediations:

                    markdown_content += f"- **{remediation.get('severity', 'MEDIUM')}**: {remediation.get('message', 'Security issue')}\n"

                    markdown_content += f"  - Line: {remediation.get('line_number', 'Unknown')}\n"

                    markdown_content += f"  - Effort: {remediation.get('effort_minutes', 0)} minutes\n"

                    markdown_content += f"  - AI Alternative Solution: {remediation.get('suggested_fix', 'Implemented secure alternative')}\n"

    

    markdown_content += f"""



## 🤖 AI Alternative Solutions Summary



### AI-Powered Security Improvements Applied:

- **Intelligent Alternative Solutions**: AI provided secure alternatives instead of just removing code

- **Automated Vulnerability Detection**: AI identified {sum(len(analyze_security_issues(f['content'], f['file_path'])) for f in uploaded_files)} security issues

- **Smart Code Remediation**: AI applied intelligent security best practices to all files

- **OWASP Compliance**: All code now follows OWASP security guidelines

- **Defense in Depth**: Multiple security layers implemented

- **Secure by Default**: All dangerous operations replaced with secure alternatives



### AI-Generated Alternative Solutions:

- **Secure Subprocess Handling**: Replaced dangerous system calls with secure alternatives

- **Input Validation & Sanitization**: Added comprehensive validation with proper error handling

- **Environment Variable Management**: Replaced hardcoded secrets with secure configuration

- **Parameterized Query Implementation**: Prevented SQL injection with prepared statements

- **Rate Limiting & Protection**: Added brute force and DDoS protection

- **Secure Session Management**: Implemented proper authentication and authorization

- **Comprehensive Security Monitoring**: Added logging, auditing, and alerting



## 📁 File Locations

- **Original Files**: `uploaded_projects/{scan_id}/original/`

- **Remediated Files**: `uploaded_projects/{scan_id}/remediated_files/` (format: `filename_original_original_original_remediated.ext`)

- **Markdown Prompts**: `.github/prompts/{scan_id}.prompt.md`



**Note**: Delete existing files in the remediated_files directory and replace with the AI-remediated files shown in the markdown content below.



## 🎯 Copilot Integration



## 📝 Security Remediation Instructions

- **Think and Remediate**: Analyze each vulnerability independently and create your own secure solutions

- **Don't Just Append**: Avoid simply adding fixes - redesign the code with security in mind

- **Understand the Risk**: Study each security issue to understand why it's dangerous

- **Design Secure Alternatives**: Create robust, secure implementations from scratch

- **Follow Security Best Practices**: Implement OWASP guidelines and industry standards

- **Test Your Solutions**: Verify that your remediated code is both secure and functional

- **Document Your Changes**: Explain the security improvements you've made



---

*Generated by ThreatGuard Pro AI - Advanced Security Analysis System*

*Think and Remediate: Design Secure Solutions from Scratch*

"""

    

    return markdown_content



def analyze_security_issues(content: str, file_path: str) -> List[Dict]:

    """Analyze file content for security issues"""

    issues = []

    language = detect_language_from_path(file_path)

    

    # Check for dangerous operations

    dangerous_patterns = {

        'python': [

            (r'subprocess\.call\(', 'Dangerous subprocess call'),

            (r'os\.system\(', 'Dangerous system call'),

            (r'eval\(', 'Code injection vulnerability'),

            (r'exec\(', 'Code execution vulnerability'),

            (r'__import__\(', 'Dynamic import vulnerability'),

            (r'rm -rf', 'Destructive file operation'),

            (r'password\s*=', 'Hardcoded credentials'),

            (r'secret\s*=', 'Hardcoded secrets'),

        ],

        'javascript': [

            (r'eval\(', 'Code injection vulnerability'),

            (r'Function\(', 'Code execution vulnerability'),

            (r'innerHTML\s*=', 'XSS vulnerability'),

            (r'document\.write\(', 'XSS vulnerability'),

            (r'password\s*:', 'Hardcoded credentials'),

            (r'secret\s*:', 'Hardcoded secrets'),

        ],

        'java': [

            (r'Runtime\.getRuntime\(\)\.exec\(', 'Command injection'),

            (r'ProcessBuilder\(', 'Command injection'),

            (r'eval\(', 'Code injection vulnerability'),

            (r'password\s*=', 'Hardcoded credentials'),

        ]

    }

    

    patterns = dangerous_patterns.get(language, [])

    

    for pattern, description in patterns:

        matches = re.finditer(pattern, content, re.IGNORECASE)

        for match in matches:

            line_num = content[:match.start()].count('\n') + 1

            issues.append({

                'type': 'security_vulnerability',

                'description': description,

                'line': line_num,

                'code': match.group(),

                'severity': 'HIGH'

            })

    

    # Check for missing input validation

    if language == 'python':

        if re.search(r'def\s+\w+\([^)]*\):', content) and not re.search(r'if\s+.*:', content):

            issues.append({

                'type': 'missing_validation',

                'description': 'Missing input validation',

                'line': 1,

                'code': 'function definition',

                'severity': 'MEDIUM'

            })

    

    return issues



def generate_copilot_prompt(file_path: str, content: str, security_issues: List[Dict], scan_id: str) -> str:

    """Generate comprehensive Copilot prompt for security remediation"""

    language = detect_language_from_path(file_path)

    file_name = Path(file_path).name

    

    # Group issues by severity

    high_issues = [issue for issue in security_issues if issue['severity'] == 'HIGH']

    medium_issues = [issue for issue in security_issues if issue['severity'] == 'MEDIUM']

    low_issues = [issue for issue in security_issues if issue['severity'] == 'LOW']

    

    prompt = f"""# SECURITY VULNERABILITY FIX REQUEST

# File: {file_name}

# Language: {language}

# Scan ID: {scan_id}

# Generated: {datetime.now().isoformat()}



# SECURITY ISSUES DETECTED:

"""

    

    if high_issues:

        prompt += "\n## HIGH SEVERITY ISSUES:\n"

        for issue in high_issues:

            prompt += f"- Line {issue['line']}: {issue['description']}\n"

            prompt += f"  Code: {issue['code']}\n"

    

    if medium_issues:

        prompt += "\n## MEDIUM SEVERITY ISSUES:\n"

        for issue in medium_issues:

            prompt += f"- Line {issue['line']}: {issue['description']}\n"

            prompt += f"  Code: {issue['code']}\n"

    

    if low_issues:

        prompt += "\n## LOW SEVERITY ISSUES:\n"

        for issue in low_issues:

            prompt += f"- Line {issue['line']}: {issue['description']}\n"

            prompt += f"  Code: {issue['code']}\n"

    

    prompt += f"""



# TASK FOR GITHUB COPILOT:

Please provide a secure, fixed version of this code that addresses ALL the security vulnerabilities listed above.



# REQUIREMENTS:

1. Remove ALL dangerous operations (subprocess calls, system commands, eval, exec, etc.)

2. Add comprehensive input validation and sanitization

3. Use secure alternatives and best practices

4. Add proper error handling and logging

5. Follow OWASP security guidelines

6. Maintain the same functionality where possible

7. Add comments explaining security improvements

8. Replace hardcoded credentials with environment variables

9. Implement proper access controls

10. Add security event logging



# SECURITY FOCUS AREAS:

- Replace destructive operations with safe alternatives

- Remove code injection vulnerabilities

- Add input validation and sanitization

- Implement proper error handling

- Use secure file operations

- Add logging and monitoring

- Follow principle of least privilege

- Remove hardcoded secrets



# ORIGINAL CODE:

```{language}

{content}

```



# EXPECTED OUTPUT:

Please provide the complete fixed code with security improvements:



```{language}

"""

    

    return prompt



@app.route('/api/vscode-agent/process/<scan_id>', methods=['POST'])

def process_vscode_agent(scan_id):

    """Process VS Code agent remediation for a specific scan"""

    try:

        print(f"[DEBUG] Processing VS Code agent for scan: {scan_id}")

        print(f"[DEBUG] Request method: {request.method}")

        print(f"[DEBUG] Request URL: {request.url}")

        

        # Check if prompts exist for this scan

        prompts_dir = Path('uploaded_projects') / scan_id / 'vscode_prompts'

        metadata_file = prompts_dir / 'prompts_metadata.json'

        

        print(f"[DEBUG] Checking prompts directory: {prompts_dir}")

        print(f"[DEBUG] Metadata file exists: {metadata_file.exists()}")

        

        # If no prompts exist, generate them first

        if not metadata_file.exists():

            print(f"[DEBUG] No prompts found for scan {scan_id}, generating prompts...")

            

            # Check if original files exist

            original_dir = Path('uploaded_projects') / scan_id / 'original'

            print(f"[DEBUG] Checking original directory: {original_dir}")

            print(f"[DEBUG] Original directory exists: {original_dir.exists()}")

            

            if not original_dir.exists():

                print(f"[DEBUG] No original files found for scan {scan_id}")

                return jsonify({'error': f'No original files found for scan {scan_id}'}), 404

            

            # Get original files

            original_files = []

            for file_path in original_dir.rglob('*'):

                if file_path.is_file():

                    try:

                        with open(file_path, 'r', encoding='utf-8') as f:

                            content = f.read()

                        original_files.append({

                            'file_path': str(file_path),

                            'file_name': file_path.name,

                            'content': content

                        })

                        print(f"[DEBUG] Added file: {file_path.name}")

                    except Exception as e:

                        print(f"[DEBUG] Error reading file {file_path}: {e}")

            

            print(f"[DEBUG] Found {len(original_files)} original files")

            

            if not original_files:

                print(f"[DEBUG] No files found in original directory for scan {scan_id}")

                return jsonify({'error': f'No files found in original directory for scan {scan_id}'}), 404

            

            # Generate VS Code prompts (this will also create the markdown file)

            try:

                prompts_data = generate_vscode_copilot_prompts(scan_id, original_files)

                print(f"[DEBUG] Generated prompts for {len(original_files)} files")

                

                # Check if markdown file was created

                github_prompts_dir = Path('.github') / 'prompts'

                markdown_file = github_prompts_dir / f"{scan_id}.prompt.md"

                if markdown_file.exists():

                    print(f"[DEBUG] ✅ Markdown prompt file created: {markdown_file}")

                else:

                    print(f"[DEBUG] ⚠️ Markdown prompt file not found: {markdown_file}")

                    

            except Exception as e:

                print(f"[DEBUG] Error generating prompts: {e}")

                return jsonify({'error': f'Error generating prompts: {str(e)}'}), 500

        

        # Load prompts metadata

        try:

            with open(metadata_file, 'r', encoding='utf-8') as f:

                prompts_data = json.load(f)

            print(f"[DEBUG] Loaded prompts metadata with {len(prompts_data.get('prompts', []))} prompts")

        except Exception as e:

            print(f"[DEBUG] Error loading prompts metadata: {e}")

            return jsonify({'error': f'Error loading prompts metadata: {str(e)}'}), 500

        

        # Create remediated files directory

        remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

        remediated_dir.mkdir(parents=True, exist_ok=True)

        print(f"[DEBUG] Created remediated directory: {remediated_dir}")

        

        # Process each prompt

        processed_files = []

        for prompt_info in prompts_data.get('prompts', []):

            try:

                print(f"[DEBUG] Processing prompt for file: {prompt_info.get('file_name', 'unknown')}")

                

                # Check if remediated file already exists

                original_file_path = Path(prompt_info.get('original_file'))

                file_name = original_file_path.name

                file_name_without_ext = original_file_path.stem

                existing_remediated_file = remediated_dir / f"{file_name_without_ext}_original_original_remediated{original_file_path.suffix}"

                

                print(f"[DEBUG] Processing file: {file_name}")

                print(f"[DEBUG] Original file path: {original_file_path}")

                print(f"[DEBUG] Existing remediated file: {existing_remediated_file}")

                print(f"[DEBUG] Existing remediated file exists: {existing_remediated_file.exists()}")

                

                if existing_remediated_file.exists():

                    print(f"[DEBUG] Using existing remediated file: {existing_remediated_file}")

                    remediated_file = existing_remediated_file

                    

                    # Read existing remediated content

                    with open(remediated_file, 'r', encoding='utf-8') as f:

                        remediated_content = f.read()

                        

                else:

                    print(f"[DEBUG] No existing remediated file found, processing...")

                    

                    # Read prompt content

                    prompt_file = prompt_info.get('prompt_file')

                    if not prompt_file or not Path(prompt_file).exists():

                        print(f"[DEBUG] Prompt file not found: {prompt_file}")

                        continue

                        

                    with open(prompt_file, 'r', encoding='utf-8') as f:

                        prompt_content = f.read()

                    

                    # Read original file

                    original_file = prompt_info.get('original_file')

                    if not original_file or not Path(original_file).exists():

                        print(f"[DEBUG] Original file not found: {original_file}")

                        continue

                        

                    with open(original_file, 'r', encoding='utf-8') as f:

                        original_content = f.read()

                    

                    # Execute remediation (simulate Copilot processing)

                    remediated_content = execute_vscode_remediation(prompt_content, prompt_info['file_path'], detect_language_from_path(prompt_info['file_path']), original_content)

                    

                    # Save remediated file with proper naming for diff comparison

                    remediated_file = remediated_dir / f"{file_name_without_ext}_original_original_remediated{original_file_path.suffix}"

                    

                    print(f"[DEBUG] Saving remediated file: {remediated_file}")

                    with open(remediated_file, 'w', encoding='utf-8') as f:

                        f.write(remediated_content)

                

                # Update prompt status with source file path

                prompt_info['status'] = 'completed'

                prompt_info['remediated_file'] = str(remediated_file)

                prompt_info['source_file_path'] = str(original_file_path)

                prompt_info['processed_at'] = datetime.now().isoformat()

                prompt_info['ai_remediated'] = True

                

                processed_files.append({

                    'file_name': prompt_info.get('file_name', 'unknown'),

                    'original_file': prompt_info.get('original_file'),

                    'remediated_file': str(remediated_file),

                    'status': 'completed',

                    'ai_remediated': True

                })

                

                print(f"[DEBUG] Successfully processed: {prompt_info.get('file_name', 'unknown')}")

                

            except Exception as e:

                logging.error(f"Error processing prompt for {prompt_info.get('file_name', 'unknown')}: {e}")

                print(f"[DEBUG] Error processing {prompt_info.get('file_name', 'unknown')}: {e}")

                prompt_info['status'] = 'error'

                prompt_info['error'] = str(e)

        

        # Update metadata

        prompts_data['processed_at'] = datetime.now().isoformat()

        prompts_data['total_processed'] = len(processed_files)

        

        try:

            with open(metadata_file, 'w', encoding='utf-8') as f:

                json.dump(prompts_data, f, indent=2)

            print(f"[DEBUG] Updated prompts metadata")

        except Exception as e:

            print(f"[DEBUG] Error updating prompts metadata: {e}")

        

        # Check if markdown file exists and add to response

        github_prompts_dir = Path('.github') / 'prompts'

        markdown_file = github_prompts_dir / f"{scan_id}.prompt.md"

        markdown_file_info = None

        

        if markdown_file.exists():

            try:

                with open(markdown_file, 'r', encoding='utf-8') as f:

                    markdown_content = f.read()

                markdown_file_info = {

                    'file_path': str(markdown_file),

                    'file_name': markdown_file.name,

                    'size': len(markdown_content),

                    'created_at': datetime.fromtimestamp(markdown_file.stat().st_mtime).isoformat()

                }

                print(f"[DEBUG] ✅ Markdown file info: {markdown_file_info}")

            except Exception as e:

                print(f"[DEBUG] Error reading markdown file: {e}")

        

        print(f"[DEBUG] Processing completed for scan {scan_id}. Processed {len(processed_files)} files.")

        

        response_data = {

            'success': True,

            'scan_id': scan_id,

            'total_files': len(prompts_data.get('prompts', [])),

            'processed_files': processed_files,

            'timestamp': datetime.now().isoformat(),

            'ai_remediated': True,

            'remediation_type': 'AI-Powered Security Remediation'

        }

        

        if markdown_file_info:

            response_data['markdown_file'] = markdown_file_info

            response_data['markdown_file']['ai_content'] = True

            response_data['markdown_file']['includes_remediated_files'] = True

        

        return jsonify(response_data)

        

    except Exception as e:

        logging.error(f"Error processing VS Code agent for scan {scan_id}: {e}")

        print(f"[DEBUG] Error in process_vscode_agent: {e}")

        import traceback

        traceback.print_exc()

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/prompts/<scan_id>', methods=['GET'])

def get_vscode_agent_prompts(scan_id):

    """Get VS Code prompts for a specific scan"""

    try:

        prompts_dir = Path('uploaded_projects') / scan_id / 'vscode_prompts'

        metadata_file = prompts_dir / 'prompts_metadata.json'

        

        if not metadata_file.exists():

            return jsonify({'error': f'No prompts found for scan {scan_id}'}), 404

        

        with open(metadata_file, 'r', encoding='utf-8') as f:

            prompts_data = json.load(f)

        

        return jsonify(prompts_data)

        

    except Exception as e:

        logging.error(f"Error getting VS Code prompts for scan {scan_id}: {e}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/files/<scan_id>/<path:file_name>', methods=['GET'])

def get_vscode_agent_file(scan_id, file_name):

    """Get VS Code agent files (prompts, original, remediated)"""

    try:

        # Check different directories for the file

        possible_paths = [

            Path('uploaded_projects') / scan_id / 'vscode_prompts' / file_name,

            Path('uploaded_projects') / scan_id / 'remediated_files' / file_name,

            Path('uploaded_projects') / scan_id / 'original' / file_name

        ]

        

        for file_path in possible_paths:

            if file_path.exists():

                with open(file_path, 'r', encoding='utf-8') as f:

                    content = f.read()

                

                return jsonify({

                    'file_name': file_name,

                    'file_path': str(file_path),

                    'content': content,

                    'size': len(content)

                })

        

        return jsonify({'error': f'File {file_name} not found for scan {scan_id}'}), 404

        

    except Exception as e:

        logging.error(f"Error getting VS Code agent file {file_name} for scan {scan_id}: {e}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/diff/<scan_id>/<path:file_name>', methods=['GET'])

def get_vscode_agent_diff(scan_id, file_name):

    """Get diff between original and remediated files for VS Code agent"""

    try:

        print(f"[DEBUG] Getting diff for scan_id: {scan_id}, file_name: {file_name}")

        

        # First try to get file paths from copilot task JSON

        task_file_path = Path('uploaded_projects') / scan_id / 'copilot_tasks' / 'copilot_task.json'

        original_file_path = None

        remediated_file_path = None

        

        if task_file_path.exists():

            print(f"[DEBUG] Found copilot task file: {task_file_path}")

            with open(task_file_path, 'r', encoding='utf-8') as f:

                task_data = json.load(f)

            

            # Find the file in the file_paths mapping

            for file_path, file_info in task_data.get("file_paths", {}).items():

                print(f"[DEBUG] Checking file_path: {file_path}, file_info: {file_info}")

                if file_info.get("file_name") == file_name:

                    original_file_path = Path(file_info.get("source_file_path"))

                    # Use the remediated file path from the task data

                    remediated_file_path = Path(file_info.get("remediated_file_path"))

                    remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

                    file_extension = Path(file_name).suffix

                    file_name_without_ext = Path(file_name).stem

                    remediated_file_path = remediated_dir / f"{file_name_without_ext}_original_original_original_remediated{file_extension}"

                    print(f"[DEBUG] Found in copilot task - Original: {original_file_path}, Remediated: {remediated_file_path}")

                    break

        

        # If not found in copilot task, try prompts metadata

        if not original_file_path or not remediated_file_path:

            prompts_dir = Path('uploaded_projects') / scan_id / 'vscode_prompts'

            metadata_file = prompts_dir / 'prompts_metadata.json'

            

            print(f"[DEBUG] Checking prompts metadata: {metadata_file}")

            print(f"[DEBUG] Metadata file exists: {metadata_file.exists()}")

            

            if metadata_file.exists():

                with open(metadata_file, 'r', encoding='utf-8') as f:

                    prompts_data = json.load(f)

                

                print(f"[DEBUG] Loaded prompts data with {len(prompts_data.get('prompts', []))} prompts")

                

                # Find the prompt for this file

                target_prompt = None

                for prompt in prompts_data.get('prompts', []):

                    print(f"[DEBUG] Checking prompt - file_name: {prompt.get('file_name')}, looking for: {file_name}")

                    if prompt.get('file_name') == file_name:

                        target_prompt = prompt

                        print(f"[DEBUG] Found target prompt: {target_prompt}")

                        break

                

                if target_prompt:

                    original_file_path = Path(target_prompt.get('original_file'))

                    remediated_file_path = Path(target_prompt.get('remediated_file'))

                    

                    print(f"[DEBUG] From prompts metadata - Original: {original_file_path}, Remediated: {remediated_file_path}")

                    

                    # If remediated file path is not set or doesn't exist, construct it using the correct format

                    if not remediated_file_path or not remediated_file_path.exists():

                        remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

                        file_extension = Path(file_name).suffix

                        file_name_without_ext = Path(file_name).stem

                        remediated_file_path = remediated_dir / f"{file_name_without_ext}_original_original_remediated{file_extension}"

                        print(f"[DEBUG] Constructed remediated file path: {remediated_file_path}")

        

        # If still not found, try to construct paths directly

        if not original_file_path or not remediated_file_path:

            print(f"[DEBUG] File paths not found in metadata, constructing paths directly")

            

            # Try to find original file

            original_dir = Path('uploaded_projects') / scan_id / 'original'

            print(f"[DEBUG] Checking original directory: {original_dir}")

            print(f"[DEBUG] Original directory exists: {original_dir.exists()}")

            

            if original_dir.exists():

                # First try to find the file directly in the original directory (for single files)

                direct_file = original_dir / file_name

                if direct_file.exists() and direct_file.is_file():

                    print(f"[DEBUG] Found file directly in original dir: {direct_file}")

                    original_file_path = direct_file

                else:

                    # If not found directly, search recursively (for folder uploads)

                    for file_path in original_dir.rglob('*'):

                        if file_path.is_file():

                            print(f"[DEBUG] Found file in original dir: {file_path.name}")

                            if file_path.name == file_name:

                                original_file_path = file_path

                                print(f"[DEBUG] Matched original file: {original_file_path}")

                                break

            

            # Construct remediated file path

            if original_file_path:

                remediated_dir = Path('uploaded_projects') / scan_id / 'remediated_files'

                file_extension = Path(file_name).suffix

                file_name_without_ext = Path(file_name).stem

                remediated_file_path = remediated_dir / f"{file_name_without_ext}_original_original_remediated{file_extension}"

                print(f"[DEBUG] Constructed paths - Original: {original_file_path}, Remediated: {remediated_file_path}")

        

        if not original_file_path or not remediated_file_path:

            print(f"[DEBUG] ❌ File paths not found for {file_name} in scan {scan_id}")

            return jsonify({'error': f'File paths not found for {file_name} in scan {scan_id}'}), 404

        

        if not original_file_path.exists():

            print(f"[DEBUG] ❌ Original file not found: {original_file_path}")

            return jsonify({'error': f'Original file not found: {original_file_path}'}), 404

        

        if not remediated_file_path.exists():

            print(f"[DEBUG] ❌ Remediated file not found: {remediated_file_path}")

            return jsonify({'error': f'Remediated file not found: {remediated_file_path}'}), 404

        

        print(f"[DEBUG] ✅ Original file: {original_file_path}")

        print(f"[DEBUG] ✅ Remediated file: {remediated_file_path}")

        

        # Read original and remediated content

        with open(original_file_path, 'r', encoding='utf-8') as f:

            original_content = f.read()

        

        with open(remediated_file_path, 'r', encoding='utf-8') as f:

            remediated_content = f.read()

        

        # Generate diff

        diff_data = generate_file_diff(original_content, remediated_content)

        

        return jsonify({

            'scan_id': scan_id,

            'file_name': file_name,

            'original_file': str(original_file_path),

            'remediated_file': str(remediated_file_path),

            'original_content': original_content,

            'remediated_content': remediated_content,

            'diff': diff_data

        })

        

    except Exception as e:

        logging.error(f"Error getting VS Code agent diff for scan {scan_id}, file {file_name}: {e}")

        print(f"[DEBUG] Error in get_vscode_agent_diff: {e}")

        return jsonify({'error': str(e)}), 500



def generate_file_diff(original_content: str, remediated_content: str) -> Dict:

    """Generate diff between original and remediated content"""

    original_lines = original_content.split('\n')

    remediated_lines = remediated_content.split('\n')

    

    diff_result = {

        'added_lines': [],

        'removed_lines': [],

        'modified_lines': [],

        'statistics': {

            'total_original_lines': len(original_lines),

            'total_remediated_lines': len(remediated_lines),

            'added_count': 0,

            'removed_count': 0,

            'modified_count': 0

        }

    }

    

    # Simple line-by-line comparison

    max_lines = max(len(original_lines), len(remediated_lines))

    

    for i in range(max_lines):

        original_line = original_lines[i] if i < len(original_lines) else None

        remediated_line = remediated_lines[i] if i < len(remediated_lines) else None

        

        if original_line != remediated_line:

            if original_line is None:

                # Added line

                diff_result['added_lines'].append({

                    'line_number': i + 1,

                    'content': remediated_line

                })

                diff_result['statistics']['added_count'] += 1

            elif remediated_line is None:

                # Removed line

                diff_result['removed_lines'].append({

                    'line_number': i + 1,

                    'content': original_line

                })

                diff_result['statistics']['removed_count'] += 1

            else:

                # Modified line

                diff_result['modified_lines'].append({

                    'line_number': i + 1,

                    'original': original_line,

                    'remediated': remediated_line

                })

                diff_result['statistics']['modified_count'] += 1

    

    return diff_result



@app.route('/api/test', methods=['GET'])

def test_endpoint():

    """Simple test endpoint to check if server is running."""

    return jsonify({'status': 'ok', 'message': 'Server is running', 'timestamp': datetime.now().isoformat()})



@app.route('/api/scan/github', methods=['POST'])

def scan_github_repository():

    """Scan GitHub repository for logic bombs and security threats (legacy endpoint)"""

    try:

        data = request.get_json()

        # Convert to new unified format for backward compatibility

        data['repo_url'] = data.get('github_url')

        data['repo_token'] = data.get('github_token')

        data['scan_type'] = 'github'

        data['project_name'] = data.get('project_name', 'GitHub Repository Scan')

        data['repo_name'] = data.get('repo_name', 'GitHub Repo')

        

        # Call the unified repository scanner

        return scan_repository()

    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/scan/repository', methods=['POST'])

def scan_repository():

    """Scan a GitHub or Bitbucket repository for security threats"""

    try:

        data = request.get_json()

        repo_url = data.get('repo_url') or data.get('github_url') or data.get('bitbucket_url')

        repo_token = data.get('repo_token') or data.get('github_token') or data.get('bitbucket_token')

        scan_id = data.get('scan_id', str(uuid.uuid4()))

        scan_type = data.get('scan_type', 'repository')

        project_id = data.get('project_id', f'repo-scan-{int(datetime.now().timestamp())}')

        project_name = data.get('project_name', 'Repository Scan')

        ait_tag = data.get('ait_tag', 'AIT')

        spk_tag = data.get('spk_tag', 'SPK')

        repo_name = data.get('repo_name', 'Repository')



        if not repo_url:

            return jsonify({'error': 'Repository URL is required'}), 400



        # Extract repository information from URL

        import re

        

        # GitHub patterns

        github_pattern = r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'

        github_match = re.match(github_pattern, repo_url.strip())

        

        # Bitbucket patterns (both cloud and server)

        bitbucket_cloud_pattern = r'https://bitbucket\.org/([^/]+)/([^/]+?)(?:\.git)?/?$'

        bitbucket_server_pattern = r'https://([^/]+)/scm/([^/]+)/([^/]+?)(?:\.git)?/?$'

        

        bitbucket_cloud_match = re.match(bitbucket_cloud_pattern, repo_url.strip())

        bitbucket_server_match = re.match(bitbucket_server_pattern, repo_url.strip())

        

        repo_type = None

        owner = None

        repo = None

        server_url = None

        

        if github_match:

            repo_type = 'github'

            owner, repo = github_match.groups()

        elif bitbucket_cloud_match:

            repo_type = 'bitbucket_cloud'

            owner, repo = bitbucket_cloud_match.groups()

        elif bitbucket_server_match:

            repo_type = 'bitbucket_server'

            server_url, owner, repo = bitbucket_server_match.groups()

        else:

            return jsonify({

                'error': 'Invalid repository URL format. Supported formats:\n' +

                        '• GitHub: https://github.com/owner/repository\n' +

                        '• Bitbucket Cloud: https://bitbucket.org/owner/repository\n' +

                        '• Bitbucket Server: https://server.com/scm/owner/repository'

            }), 400

        

        # Clone the repository

        import tempfile

        import subprocess

        import shutil

        

        temp_dir = tempfile.mkdtemp()

        repo_path = os.path.join(temp_dir, repo)

        

        try:

            # Clone the repository with authentication if token provided

            clone_url = None

            clone_cmd = None

            

            if repo_type == 'github':

                if repo_token:

                    # For private GitHub repositories, use token authentication

                    clone_url = f"https://{repo_token}@github.com/{owner}/{repo}.git"

                else:

                    # For public GitHub repositories, use regular clone

                    clone_url = f"https://github.com/{owner}/{repo}.git"

                clone_cmd = ['git', 'clone', clone_url, repo_path]

                

            elif repo_type == 'bitbucket_cloud':

                if repo_token:

                    # For private Bitbucket Cloud repositories, use token authentication

                    clone_url = f"https://{repo_token}@bitbucket.org/{owner}/{repo}.git"

                else:

                    # For public Bitbucket Cloud repositories, use regular clone

                    clone_url = f"https://bitbucket.org/{owner}/{repo}.git"

                clone_cmd = ['git', 'clone', clone_url, repo_path]

                

            elif repo_type == 'bitbucket_server':

                if repo_token:

                    # For private Bitbucket Server repositories, use token authentication

                    clone_url = f"https://{repo_token}@{server_url}/scm/{owner}/{repo}.git"

                else:

                    # For public Bitbucket Server repositories, use regular clone

                    clone_url = f"https://{server_url}/scm/{owner}/{repo}.git"

                clone_cmd = ['git', 'clone', clone_url, repo_path]

            

            result = subprocess.run(clone_cmd, capture_output=True, text=True, timeout=settings.GIT_CLONE_TIMEOUT)

            

            if result.returncode != 0:

                error_msg = result.stderr.strip()

                

                # Enhanced error handling for different scenarios

                if "Authentication failed" in error_msg or "401" in error_msg:

                    return jsonify({

                        'error': 'Authentication failed. This appears to be a private repository.',

                        'details': 'Please provide a valid access token for this repository.',

                        'repo_type': repo_type,

                        'requires_auth': True

                    }), 401

                elif "Repository not found" in error_msg or "404" in error_msg:

                    return jsonify({

                        'error': 'Repository not found or access denied.',

                        'details': 'Check if the repository exists and you have access to it.',

                        'repo_type': repo_type,

                        'requires_auth': True

                    }), 404

                elif "Permission denied" in error_msg or "403" in error_msg:

                    return jsonify({

                        'error': 'Permission denied. This repository requires authentication.',

                        'details': 'Please provide a valid access token with appropriate permissions.',

                        'repo_type': repo_type,

                        'requires_auth': True

                    }), 403

                elif "fatal: repository" in error_msg and "not found" in error_msg:

                    return jsonify({

                        'error': 'Repository not found.',

                        'details': 'The repository URL is invalid or the repository does not exist.',

                        'repo_type': repo_type,

                        'requires_auth': False

                    }), 404

                else:

                    return jsonify({

                        'error': f'Failed to clone repository: {error_msg}',

                        'details': 'Please check the repository URL and try again.',

                        'repo_type': repo_type,

                        'requires_auth': False

                    }), 400

            

            # Save repository files to uploaded_projects/{scan_id}/original/

            base_upload_dir = Path('uploaded_projects') / scan_id / 'original'

            base_upload_dir.mkdir(parents=True, exist_ok=True)

            

            file_paths = []

            uploaded_files_for_prompts = []

            

            # Walk through the repository and collect all files

            for root, dirs, files in os.walk(repo_path):

                # Skip .git directory

                if '.git' in dirs:

                    dirs.remove('.git')

                

                for file in files:

                    file_path = os.path.join(root, file)

                    relative_path = os.path.relpath(file_path, repo_path)

                    

                    # Skip binary files and large files

                    try:

                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:

                            content = f.read()

                        

                        # Skip files larger than 1MB

                        if len(content) > settings.MAX_FILE_SIZE_MB * 1024 * 1024:

                            continue

                            

                        # Save file to uploaded_projects

                        target_path = base_upload_dir / relative_path

                        target_path.parent.mkdir(parents=True, exist_ok=True)

                        

                        with open(target_path, 'w', encoding='utf-8') as f:

                            f.write(content)

                        

                        file_paths.append({

                            'id': f"file_{len(file_paths)}",

                            'name': relative_path,

                            'path': str(target_path),

                            'type': get_file_language(relative_path)

                        })

                        

                        uploaded_files_for_prompts.append({

                            'file_path': str(target_path),

                            'content': content,

                            'file_name': relative_path

                        })

                        

                    except (UnicodeDecodeError, PermissionError, OSError):

                        # Skip binary files or files that can't be read

                        continue

            

            if not file_paths:

                return jsonify({'error': 'No readable files found in repository'}), 400

            

            # Enhanced file scan with comprehensive threat analysis

            scan_result = perform_enhanced_file_scan(

                scan_id=scan_id,

                project_id=project_id,

                project_name=project_name,

                file_paths=file_paths,

                scan_type=scan_type,

                ait_tag=ait_tag,

                spk_tag=spk_tag,

                repo_name=repo_name

            )

            

            # Add repository-specific information

            scan_result['repo_info'] = {

                'repo_type': repo_type,

                'owner': owner,

                'repo': repo,

                'url': repo_url,

                'files_count': len(file_paths),

                'is_private': bool(repo_token),  # Indicate if this was a private repo

                'auth_used': bool(repo_token),    # Indicate if authentication was used

                'server_url': server_url if repo_type == 'bitbucket_server' else None

            }

            

            # Generate VS Code Copilot prompts automatically

            try:

                prompts_data = generate_vscode_copilot_prompts(scan_id, uploaded_files_for_prompts)

                scan_result['prompts_generated'] = True

                scan_result['prompts_data'] = prompts_data

            except Exception as e:

                logging.error(f"Error generating prompts: {e}")

                scan_result['prompts_generated'] = False

                scan_result['prompts_error'] = str(e)

            

            return jsonify(scan_result)

            

        finally:

            # Clean up temporary directory

            try:

                shutil.rmtree(temp_dir)

            except Exception as e:

                logging.warning(f"Failed to clean up temp directory: {e}")

    

    except Exception as e:

        return jsonify({'error': str(e)}), 500



def get_file_language(filename: str) -> str:

    """Determine file language based on extension"""

    ext = filename.lower().split('.')[-1] if '.' in filename else ''

    

    language_map = {

        'py': 'python',

        'js': 'javascript',

        'ts': 'typescript',

        'jsx': 'javascript',

        'tsx': 'typescript',

        'java': 'java',

        'cpp': 'cpp',

        'c': 'c',

        'cs': 'csharp',

        'php': 'php',

        'rb': 'ruby',

        'go': 'go',

        'rs': 'rust',

        'swift': 'swift',

        'kt': 'kotlin',

        'scala': 'scala',

        'html': 'html',

        'css': 'css',

        'scss': 'scss',

        'sass': 'sass',

        'less': 'less',

        'json': 'json',

        'xml': 'xml',

        'yaml': 'yaml',

        'yml': 'yaml',

        'toml': 'toml',

        'ini': 'ini',

        'cfg': 'ini',

        'conf': 'ini',

        'sh': 'bash',

        'bash': 'bash',

        'zsh': 'bash',

        'fish': 'bash',

        'ps1': 'powershell',

        'bat': 'batch',

        'cmd': 'batch',

        'sql': 'sql',

        'md': 'markdown',

        'txt': 'text',

        'log': 'text'

    }

    

    return language_map.get(ext, 'text')



@app.route('/api/vscode-agent/markdown/<scan_id>', methods=['GET'])

def get_vscode_agent_markdown(scan_id):

    """Get the markdown prompt file for a scan"""

    try:

        # Check if markdown file exists

        github_prompts_dir = Path('.github') / 'prompts'

        markdown_file = github_prompts_dir / f"{scan_id}.prompt.md"

        

        if not markdown_file.exists():

            return jsonify({'error': f'Markdown prompt file not found for scan {scan_id}'}), 404

        

        # Read markdown content

        with open(markdown_file, 'r', encoding='utf-8') as f:

            content = f.read()

        

        # Get file stats

        stats = markdown_file.stat()

        

        return jsonify({

            'success': True,

            'scan_id': scan_id,

            'file_path': str(markdown_file),

            'file_name': markdown_file.name,

            'content': content,

            'size': len(content),

            'created_at': datetime.fromtimestamp(stats.st_mtime).isoformat(),

            'modified_at': datetime.fromtimestamp(stats.st_mtime).isoformat()

        })

        

    except Exception as e:

        logging.error(f"Error getting markdown file for scan {scan_id}: {e}")

        return jsonify({'error': str(e)}), 500



@app.route('/api/vscode-agent/test', methods=['GET'])

def test_vscode_agent_endpoint():

    """Test endpoint to verify VS Code agent routes are working"""

    return jsonify({

        'success': True,

        'message': 'VS Code agent endpoint is working',

        'timestamp': datetime.now().isoformat(),

        'available_endpoints': [

            '/api/vscode-agent/test',

            '/api/vscode-agent/process/<scan_id>',

            '/api/vscode-agent/prompts/<scan_id>',

            '/api/vscode-agent/files/<scan_id>/<file_name>',

            '/api/vscode-agent/diff/<scan_id>/<file_name>',

            '/api/vscode-agent/markdown/<scan_id>',

            '/api/vscode-agent/status'

        ]

    })



@app.route('/api/debug/issues')

def debug_issues():

    """Debug endpoint to check what issues are stored"""

    try:

        all_issues = list(detector.issue_manager.issues.values())

        

        # Count by type

        type_counts = {}

        for issue in all_issues:

            issue_type = getattr(issue, 'type', 'UNKNOWN')

            type_counts[issue_type] = type_counts.get(issue_type, 0) + 1

        

        # Get sample issues with full details

        sample_issues = []

        for issue in all_issues[:5]:

            file_name = os.path.basename(issue.file_path) if issue.file_path else 'unknown'

            sample_issues.append({

                'id': issue.id,

                'type': getattr(issue, 'type', 'UNKNOWN'),

                'rule_id': getattr(issue, 'rule_id', 'UNKNOWN'),

                'severity': getattr(issue, 'severity', 'UNKNOWN'),

                'file_path': issue.file_path,

                'file_name': file_name,

                'line_number': issue.line_number,

                'message': getattr(issue, 'message', 'UNKNOWN')[:100]

            })

        

        return jsonify({

            'total_issues': len(all_issues),

            'type_counts': type_counts,

            'sample_issues': sample_issues,

            'backend_version': '1.0.0',

            'timestamp': datetime.now().isoformat()

        })

    except Exception as e:

        return jsonify({'error': str(e)        }), 500



# ============================================================================

# Enhanced Vulnerability Management Endpoints

# ============================================================================



@app.route('/api/v1/vulnerabilities/enhanced/<vulnerability_id>/status', methods=['PUT'])

def update_vulnerability_status(vulnerability_id):

    """Update vulnerability status (ACTIVE/NEUTRALIZED)"""

    try:

        # Validate request data

        if not request.is_json:

            return jsonify({

                'success': False,

                'error': 'Request must be JSON'

            }), 400

        

        data = request.get_json()

        if not data or 'status' not in data:

            return jsonify({

                'success': False,

                'error': 'Status field is required'

            }), 400

        

        new_status = data['status']

        if new_status not in ['ACTIVE', 'NEUTRALIZED']:

            return jsonify({

                'success': False,

                'error': 'Status must be either ACTIVE or NEUTRALIZED'

            }), 400

        

        # Load sample vulnerabilities to find and update the vulnerability

        vulnerabilities_file = Path("sample_vulnerabilities.json")

        if not vulnerabilities_file.exists():

            return jsonify({

                'success': False,

                'error': 'Vulnerabilities data not found'

            }), 404

        

        with open(vulnerabilities_file, 'r') as f:

            data = json.load(f)

            vulnerabilities = data.get('vulnerabilities', [])

        

        # Find the vulnerability and update its status

        vulnerability_found = False

        for vuln in vulnerabilities:

            if vuln.get('id') == vulnerability_id:

                # Add or update the status field

                vuln['status'] = new_status

                vulnerability_found = True

                break

        

        if not vulnerability_found:

            return jsonify({

                'success': False,

                'error': 'Vulnerability not found'

            }), 404

        

        # Save the updated data back to file

        with open(vulnerabilities_file, 'w') as f:

            json.dump({'vulnerabilities': vulnerabilities}, f, indent=2)

        

        return jsonify({

            'success': True,

            'message': f'Vulnerability {vulnerability_id} status updated to {new_status}',

            'vulnerability_id': vulnerability_id,

            'new_status': new_status

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': 'Internal server error',

            'error_code': 'STATUS_UPDATE_ERROR'

        }), 500



@app.route('/api/v1/vulnerabilities/enhanced', methods=['GET'])

def get_enhanced_vulnerabilities():

    """Get enhanced vulnerability list with advanced filtering"""

    try:

        # Get query parameters

        severity = request.args.get('severity', 'ALL')

        priority = request.args.get('priority', 'ALL')

        wave_assignment = request.args.get('wave_assignment', 'ALL')

        page = int(request.args.get('page', 1))

        per_page = int(request.args.get('per_page', 20))

        

        # Get vulnerabilities from SQLite database

        db_path = Path("threatguard_data/vulnerabilities.db")

        if not db_path.exists():

            return jsonify({

                'success': True,

                'vulnerabilities': [],

                'total_count': 0,

                'page': page,

                'per_page': per_page,

                'total_pages': 0

            })

        

        with sqlite3.connect(db_path) as conn:

            cursor = conn.cursor()

            

            # Build WHERE clause for filtering

            where_conditions = []

            params = []

            

            if severity != 'ALL':

                where_conditions.append("severity = ?")

                params.append(severity)

            

            if priority != 'ALL':

                where_conditions.append("priority = ?")

                params.append(priority)

            

            if wave_assignment != 'ALL':

                if wave_assignment == 'ASSIGNED':

                    where_conditions.append("wave_assignment != 'UNASSIGNED' AND wave_assignment IS NOT NULL")

                elif wave_assignment == 'UNASSIGNED':

                    where_conditions.append("(wave_assignment = 'UNASSIGNED' OR wave_assignment IS NULL)")

            

            where_clause = ""

            if where_conditions:

                where_clause = "WHERE " + " AND ".join(where_conditions)

            

            # Get total count

            count_query = f"SELECT COUNT(*) FROM enhanced_vulnerabilities {where_clause}"

            cursor.execute(count_query, params)

            total_count = cursor.fetchone()[0]

            

            # Get paginated results

            offset = (page - 1) * per_page

            query = f'''

                SELECT id, gis_id, ait_tag, title, description, severity,

                       remediation_action, priority, wave_assignment, cost_impact,

                       status, created_date, updated_date, source, risk_score,

                       remediation_priority, fte_requirement, business_impact,

                       technical_debt_category

                FROM enhanced_vulnerabilities

                {where_clause}

                ORDER BY created_date DESC

                LIMIT ? OFFSET ?

            '''

            

            cursor.execute(query, params + [per_page, offset])

            rows = cursor.fetchall()

            

            # Convert rows to dictionaries

            vulnerabilities = []

            for row in rows:

                vuln = {

                    'id': row[0],

                    'gis_id': row[1],

                    'ait_tag': row[2],

                    'title': row[3],

                    'description': row[4],

                    'severity': row[5],

                    'remediation_action': row[6],

                    'priority': row[7],

                    'wave_assignment': row[8],

                    'cost_impact': row[9] or 0,

                    'status': row[10],

                    'created_date': row[11],

                    'updated_date': row[12],

                    'source': row[13],

                    'risk_score': row[14] or 5,

                    'remediation_priority': row[15],

                    'fte_requirement': row[16] or 0,

                    'business_impact': row[17],

                    'technical_debt_category': row[18]

                }

                vulnerabilities.append(vuln)

        

        # Add enhanced metadata to vulnerabilities (data is already filtered by SQL)

        for vuln in vulnerabilities:

            # Add enhanced metadata if not already present

            if 'risk_score' not in vuln or vuln['risk_score'] is None:

                vuln['risk_score'] = _calculate_risk_score(vuln)

            if 'remediation_priority' not in vuln or vuln['remediation_priority'] is None:

                vuln['remediation_priority'] = _calculate_remediation_priority(vuln)

            if 'cost_impact' not in vuln or vuln['cost_impact'] is None:

                vuln['cost_impact'] = _estimate_cost_impact(vuln)

            if 'fte_requirement' not in vuln or vuln['fte_requirement'] is None:

                vuln['fte_requirement'] = _estimate_fte_requirement(vuln)

        

        # Data is already paginated by SQL query

        return jsonify({

            'success': True,

            'vulnerabilities': vulnerabilities,

            'total_count': total_count,

            'page': page,

            'per_page': per_page,

            'total_pages': (total_count + per_page - 1) // per_page,

            'filters_applied': {

                'severity': severity,

                'priority': priority,

                'wave_assignment': wave_assignment

            }

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/vulnerabilities/enhanced/test', methods=['POST'])

def test_enhanced_vulnerabilities_endpoint():

    """Test endpoint to verify connection"""

    try:

        logger.info("Test endpoint called")

        return jsonify({

            'success': True,

            'message': 'Test endpoint working',

            'received_data': request.get_json() if request.is_json else None

        })

    except Exception as e:

        logger.error(f"Test endpoint error: {e}")

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/vulnerabilities/enhanced', methods=['POST'])

def save_enhanced_vulnerabilities():

    """Save enhanced vulnerabilities from Excel import or other sources"""

    try:

        # Validate request data
        logger.info(f"Request content type: {request.content_type}")
        logger.info(f"Request headers: {dict(request.headers)}")
        logger.info(f"Request method: {request.method}")
        logger.info(f"Request URL: {request.url}")
        
        if not request.is_json:
            logger.error("Request is not JSON")
            return jsonify({

                'success': False,

                'error': 'Request must be JSON',

                'error_code': 'INVALID_CONTENT_TYPE'

            }), 400

        try:
            data = request.get_json()
            logger.info(f"Successfully parsed JSON data: {data}")
        except Exception as e:
            logger.error(f"Failed to parse JSON: {e}")
            return jsonify({
                'success': False,
                'error': f'Invalid JSON: {str(e)}',
                'error_code': 'INVALID_JSON'
            }), 400
        
        logger.info(f"Received POST request data: {data}")
        logger.info(f"Data type: {type(data)}")
        logger.info(f"Data keys: {list(data.keys()) if isinstance(data, dict) else 'Not a dict'}")

        vulnerabilities = data.get('vulnerabilities', [])
        
        logger.info(f"Extracted vulnerabilities: {len(vulnerabilities)} items")
        logger.info(f"Vulnerabilities type: {type(vulnerabilities)}")
        if vulnerabilities:
            logger.info(f"First vulnerability: {vulnerabilities[0]}")

        

        if not vulnerabilities:

            return jsonify({

                'success': False,

                'error': 'No vulnerabilities provided',

                'error_code': 'NO_VULNERABILITIES'

            }), 400

        

        # Validate vulnerability structure

        required_fields = ['id', 'title', 'severity', 'ait_tag']

        for vuln in vulnerabilities:

            for field in required_fields:

                if field not in vuln:

                    return jsonify({

                        'success': False,

                        'error': f'Missing required field: {field}',

                        'error_code': 'MISSING_FIELD'

                    }), 400

        

        # Save to SQLite database

        db_path = Path("threatguard_data/vulnerabilities.db")

        db_path.parent.mkdir(exist_ok=True)

        

        with sqlite3.connect(db_path) as conn:

            cursor = conn.cursor()

            

            # Create table if it doesn't exist

            cursor.execute('''

                CREATE TABLE IF NOT EXISTS enhanced_vulnerabilities (

                    id TEXT PRIMARY KEY,

                    gis_id TEXT,

                    ait_tag TEXT NOT NULL,

                    title TEXT NOT NULL,

                    description TEXT,

                    severity TEXT NOT NULL,

                    remediation_action TEXT,

                    priority TEXT,

                    wave_assignment TEXT,

                    cost_impact REAL DEFAULT 0,

                    status TEXT DEFAULT 'ACTIVE_THREAT',

                    created_date TEXT,

                    updated_date TEXT,

                    source TEXT DEFAULT 'excel_import',

                    risk_score INTEGER DEFAULT 5,

                    remediation_priority TEXT,

                    fte_requirement REAL DEFAULT 0,

                    business_impact TEXT,

                    technical_debt_category TEXT

                )

            ''')

            

            # Track counts

            added_count = 0

            updated_count = 0

            

            for vuln in vulnerabilities:

                # Check if vulnerability already exists

                cursor.execute('SELECT id FROM enhanced_vulnerabilities WHERE id = ?', (vuln['id'],))

                exists = cursor.fetchone()

                

                if exists:

                    # Update existing vulnerability

                    cursor.execute('''

                        UPDATE enhanced_vulnerabilities SET

                            gis_id = ?, ait_tag = ?, title = ?, description = ?,

                            severity = ?, remediation_action = ?, priority = ?,

                            wave_assignment = ?, cost_impact = ?, status = ?,

                            updated_date = ?, source = ?, risk_score = ?,

                            remediation_priority = ?, fte_requirement = ?,

                            business_impact = ?, technical_debt_category = ?

                        WHERE id = ?

                    ''', (

                        vuln.get('gis_id'), vuln.get('ait_tag'), vuln.get('title'),

                        vuln.get('description'), vuln.get('severity'), vuln.get('remediation_action'),

                        vuln.get('priority'), vuln.get('wave_assignment'), vuln.get('cost_impact', 0),

                        vuln.get('status', 'ACTIVE_THREAT'), datetime.now().isoformat(),

                        vuln.get('source', 'excel_import'), vuln.get('risk_score', 5),

                        vuln.get('remediation_priority'), vuln.get('fte_requirement', 0),

                        vuln.get('business_impact'), vuln.get('technical_debt_category'),

                        vuln['id']

                    ))

                    updated_count += 1

                else:

                    # Insert new vulnerability

                    cursor.execute('''

                        INSERT INTO enhanced_vulnerabilities (

                            id, gis_id, ait_tag, title, description, severity,

                            remediation_action, priority, wave_assignment, cost_impact,

                            status, created_date, updated_date, source, risk_score,

                            remediation_priority, fte_requirement, business_impact,

                            technical_debt_category

                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

                    ''', (

                        vuln['id'], vuln.get('gis_id'), vuln.get('ait_tag'),

                        vuln.get('title'), vuln.get('description'), vuln.get('severity'),

                        vuln.get('remediation_action'), vuln.get('priority'),

                        vuln.get('wave_assignment'), vuln.get('cost_impact', 0),

                        vuln.get('status', 'ACTIVE_THREAT'), vuln.get('created_date', datetime.now().isoformat()),

                        datetime.now().isoformat(), vuln.get('source', 'excel_import'),

                        vuln.get('risk_score', 5), vuln.get('remediation_priority'),

                        vuln.get('fte_requirement', 0), vuln.get('business_impact'),

                        vuln.get('technical_debt_category')

                    ))

                    added_count += 1

            

            conn.commit()

            

            # Get total count

            cursor.execute('SELECT COUNT(*) FROM enhanced_vulnerabilities')

            total_count = cursor.fetchone()[0]

        

        logger.info(f"Saved {len(vulnerabilities)} vulnerabilities to SQLite: {added_count} added, {updated_count} updated")

        

        return jsonify({

            'success': True,

            'message': f'Successfully saved {len(vulnerabilities)} vulnerabilities',

            'added_count': added_count,

            'updated_count': updated_count,

            'total_count': total_count

        })

        

    except Exception as e:

        logger.error(f"Error saving vulnerabilities: {e}")

        return jsonify({

            'success': False,

            'error': str(e),

            'error_code': 'SAVE_ERROR'

        }), 500



@app.route('/api/v1/vulnerabilities/<vulnerability_id>/details', methods=['GET'])

def get_vulnerability_details(vulnerability_id):

    """Get detailed information about a specific vulnerability"""

    try:

        # Get vulnerability from threatguard data

        vulnerabilities_file = Path("threatguard_data/threat_issues.json")

        if not vulnerabilities_file.exists():

            return jsonify({

                'success': False,

                'error': 'Vulnerability not found'

            }), 404

        

        with open(vulnerabilities_file, 'r') as f:

            vulnerabilities = json.load(f)

        

        vulnerability = next((v for v in vulnerabilities if v.get('id') == vulnerability_id), None)

        if not vulnerability:

            return jsonify({

                'success': False,

                'error': 'Vulnerability not found'

            }), 404

        

        # Add enhanced information

        vulnerability['risk_score'] = _calculate_risk_score(vulnerability)

        vulnerability['remediation_priority'] = _calculate_remediation_priority(vulnerability)

        vulnerability['cost_impact'] = _estimate_cost_impact(vulnerability)

        vulnerability['fte_requirement'] = _estimate_fte_requirement(vulnerability)

        

        # Get wave assignment if any

        wave_assignments = wave_manager.get_vulnerability_assignments(vulnerability_id)

        if wave_assignments:

            vulnerability['wave_assignment'] = wave_assignments[0]

        

        return jsonify({

            'success': True,

            'vulnerability': vulnerability

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



# ============================================================================

# Wave Management Endpoints

# ============================================================================



@app.route('/api/v1/waves', methods=['GET'])

def get_waves():

    """Get all remediation waves"""

    try:

        waves = wave_manager.get_all_waves()

        return jsonify({

            'success': True,

            'waves': waves

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/waves', methods=['POST'])

def create_wave():

    """Create a new remediation wave"""

    try:

        data = request.get_json()

        required_fields = ['name', 'description', 'target_start_date', 'target_completion_date', 'priority', 'business_impact', 'team_owner']

        

        for field in required_fields:

            if field not in data:

                return jsonify({

                    'success': False,

                    'error': f'Missing required field: {field}'

                }), 400

        

        wave_id = wave_manager.create_wave(

            name=data['name'],

            description=data['description'],

            target_start_date=data['target_start_date'],

            target_completion_date=data['target_completion_date'],

            priority=data['priority'],

            business_impact=data['business_impact'],

            team_owner=data['team_owner'],

            budget_allocation=data.get('budget_allocation', 0.0),

            fte_requirement=data.get('fte_requirement', 1.0)

        )

        

        return jsonify({

            'success': True,

            'wave_id': wave_id,

            'message': 'Wave created successfully'

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/waves/<wave_id>', methods=['GET'])

def get_wave_details(wave_id):

    """Get detailed information about a specific wave"""

    try:

        wave = wave_manager.get_wave(wave_id)

        if not wave:

            return jsonify({

                'success': False,

                'error': 'Wave not found'

            }), 404

        

        # Get wave assignments

        assignments = wave_manager.get_wave_assignments(wave_id)

        

        return jsonify({

            'success': True,

            'wave': wave,

            'assignments': assignments

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/waves/<wave_id>/status', methods=['PUT'])

def update_wave_status(wave_id):

    """Update wave status"""

    try:

        data = request.get_json()

        if 'status' not in data:

            return jsonify({

                'success': False,

                'error': 'Missing status field'

            }), 400

        

        success = wave_manager.update_wave_status(wave_id, data['status'])

        if not success:

            return jsonify({

                'success': False,

                'error': 'Failed to update wave status'

            }), 400

        

        return jsonify({

            'success': True,

            'message': 'Wave status updated successfully'

        })

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/vulnerabilities/<vulnerability_id>/assign-wave', methods=['POST'])

def assign_vulnerability_to_wave(vulnerability_id):

    """Assign a vulnerability to a remediation wave"""

    try:

        data = request.get_json()

        if 'wave_id' not in data:

            return jsonify({

                'success': False,

                'error': 'Missing wave_id field'

            }), 400

        

        wave_id = data['wave_id']

        assigned_by = data.get('assigned_by', 'system')

        estimated_effort_hours = data.get('estimated_effort_hours', 8.0)

        

        success = wave_manager.assign_vulnerability_to_wave(

            vulnerability_id, wave_id, assigned_by, estimated_effort_hours

        )

        

        if success:

            return jsonify({

                'success': True,

                'message': f'Vulnerability {vulnerability_id} assigned to wave {wave_id}'

            })

        else:

            return jsonify({

                'success': False,

                'error': 'Failed to assign vulnerability to wave'

            }), 400

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



# ============================================================================

# Health Monitoring Endpoints

# ============================================================================



@app.route('/api/v1/health/status', methods=['GET'])

def get_health_status():

    """Get overall system health status"""

    try:

        health_status = health_monitor.get_overall_health()

        return jsonify({

            'success': True,

            'health_status': health_status

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



@app.route('/api/v1/health/metrics', methods=['GET'])

def get_health_metrics():

    """Get system metrics"""

    try:

        metrics_type = request.args.get('type', 'system')

        duration = request.args.get('duration', '24h')

        

        metrics = health_monitor.get_metrics(metrics_type, duration)

        return jsonify({

            'success': True,

            'metrics': metrics

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': str(e)

        }), 500



# ============================================================================

# Helper Functions for Enhanced Vulnerability Management

# ============================================================================



def _calculate_risk_score(vulnerability):

    """Calculate risk score for vulnerability"""

    base_score = 0

    

    # Severity scoring

    severity_scores = {

        'CRITICAL_BOMB': 10,

        'HIGH_RISK': 8,

        'MEDIUM_RISK': 5,

        'LOW_RISK': 2,

        'SUSPICIOUS': 3

    }

    

    base_score += severity_scores.get(vulnerability.get('severity', 'MEDIUM_RISK'), 5)

    

    # Priority scoring

    priority_scores = {

        'CRITICAL': 3,

        'HIGH': 2,

        'MEDIUM': 1,

        'LOW': 0

    }

    

    base_score += priority_scores.get(vulnerability.get('priority', 'MEDIUM'), 1)

    

    # Business impact scoring

    impact_scores = {

        'Critical': 3,

        'High': 2,

        'Medium': 1,

        'Low': 0

    }

    

    base_score += impact_scores.get(vulnerability.get('business_impact', 'Medium'), 1)

    

    return min(base_score, 10)  # Cap at 10



def _calculate_remediation_priority(vulnerability):

    """Calculate remediation priority"""

    risk_score = _calculate_risk_score(vulnerability)

    

    if risk_score >= 8:

        return 'IMMEDIATE'

    elif risk_score >= 6:

        return 'HIGH'

    elif risk_score >= 4:

        return 'MEDIUM'

    else:

        return 'LOW'



def _estimate_cost_impact(vulnerability):

    """Estimate cost impact of vulnerability"""

    severity = vulnerability.get('severity', 'MEDIUM_RISK')

    

    cost_estimates = {

        'CRITICAL_BOMB': 50000,

        'HIGH_RISK': 25000,

        'MEDIUM_RISK': 10000,

        'LOW_RISK': 5000,

        'SUSPICIOUS': 3000

    }

    

    return cost_estimates.get(severity, 10000)



def _estimate_fte_requirement(vulnerability):

    """Estimate FTE requirement for remediation"""

    severity = vulnerability.get('severity', 'MEDIUM_RISK')

    

    fte_estimates = {

        'CRITICAL_BOMB': 2.0,

        'HIGH_RISK': 1.5,

        'MEDIUM_RISK': 1.0,

        'LOW_RISK': 0.5,

        'SUSPICIOUS': 0.3

    }

    

    return fte_estimates.get(severity, 1.0)



@app.route('/api/cicd-pipeline-data', methods=['GET'])

def get_cicd_pipeline_data():

    """Get CI/CD pipeline security data"""

    try:

        # Load configurable CI/CD data from JSON file

        cicd_data_file = Path("threatguard_data/cicd_pipelines.json")

        

        if cicd_data_file.exists():

            with open(cicd_data_file, 'r') as f:

                cicd_data = json.load(f)

        else:

            # Default CI/CD pipeline data if file doesn't exist

            cicd_data = [

                {

                    "id": "cicd-001",

                    "pipeline_name": "Production Deployment",

                    "status": "success",

                    "last_run": "2024-01-15T10:30:00Z",

                    "threats_found": 0,

                    "security_score": 95,

                    "environment": "production",

                    "build_number": "2024.1.15.1",

                    "commit_hash": "abc123def456",

                    "branch": "main"

                },

                {

                    "id": "cicd-002",

                    "pipeline_name": "Staging Build",

                    "status": "warning",

                    "last_run": "2024-01-15T09:15:00Z",

                    "threats_found": 2,

                    "security_score": 78,

                    "environment": "staging",

                    "build_number": "2024.1.15.2",

                    "commit_hash": "def456ghi789",

                    "branch": "develop"

                },

                {

                    "id": "cicd-003",

                    "pipeline_name": "Development Branch",

                    "status": "error",

                    "last_run": "2024-01-15T08:45:00Z",

                    "threats_found": 5,

                    "security_score": 45,

                    "environment": "development",

                    "build_number": "2024.1.15.3",

                    "commit_hash": "ghi789jkl012",

                    "branch": "feature/security-fixes"

                },

                {

                    "id": "cicd-004",

                    "pipeline_name": "Security Testing",

                    "status": "success",

                    "last_run": "2024-01-15T07:30:00Z",

                    "threats_found": 0,

                    "security_score": 98,

                    "environment": "testing",

                    "build_number": "2024.1.15.4",

                    "commit_hash": "jkl012mno345",

                    "branch": "security-test"

                },

                {

                    "id": "cicd-005",

                    "pipeline_name": "Integration Tests",

                    "status": "warning",

                    "last_run": "2024-01-15T06:15:00Z",

                    "threats_found": 1,

                    "security_score": 82,

                    "environment": "integration",

                    "build_number": "2024.1.15.5",

                    "commit_hash": "mno345pqr678",

                    "branch": "integration"

                }

            ]

            

            # Save default data to file

            cicd_data_file.parent.mkdir(exist_ok=True)

            with open(cicd_data_file, 'w') as f:

                json.dump(cicd_data, f, indent=2)

        

        return jsonify({

            "status": "success",

            "data": cicd_data,

            "total_pipelines": len(cicd_data),

            "timestamp": datetime.now().isoformat()

        })

        

    except Exception as e:

        return jsonify({

            "status": "error",

            "message": f"Failed to load CI/CD pipeline data: {str(e)}",

            "data": []

        }), 500



@app.route('/api/cicd-pipeline-data', methods=['POST'])

def update_cicd_pipeline_data():

    """Update CI/CD pipeline configuration data"""

    try:

        data = request.get_json()

        

        if not data or not isinstance(data, list):

            return jsonify({

                "status": "error",

                "message": "Invalid data format. Expected array of pipeline objects."

            }), 400

        

        # Validate pipeline data structure

        required_fields = ['id', 'pipeline_name', 'status', 'last_run', 'threats_found', 'security_score', 'environment']

        

        for pipeline in data:

            if not all(field in pipeline for field in required_fields):

                return jsonify({

                    "status": "error",

                    "message": f"Missing required fields in pipeline data. Required: {required_fields}"

                }), 400

        

        # Save to file

        cicd_data_file = Path("threatguard_data/cicd_pipelines.json")

        cicd_data_file.parent.mkdir(exist_ok=True)

        

        with open(cicd_data_file, 'w') as f:

            json.dump(data, f, indent=2)

        

        return jsonify({

            "status": "success",

            "message": f"Updated {len(data)} CI/CD pipeline configurations",

            "timestamp": datetime.now().isoformat()

        })

        

    except Exception as e:

        return jsonify({

            "status": "error",

            "message": f"Failed to update CI/CD pipeline data: {str(e)}"

        }), 500



# Admin Data Management API Endpoints

@app.route('/api/admin/import-excel', methods=['POST'])

def admin_import_excel():

    """Import AIT-SPK-Repo mappings from Excel file"""

    try:

        if 'file' not in request.files:

            return jsonify({

                'success': False,

                'error': 'No file uploaded'

            }), 400

        

        file = request.files['file']

        if file.filename == '':

            return jsonify({

                'success': False,

                'error': 'No file selected'

            }), 400

        

        if not file.filename.endswith(('.xlsx', '.xls')):

            return jsonify({

                'success': False,

                'error': 'Invalid file format. Please upload Excel file (.xlsx or .xls)'

            }), 400

        

        # Save uploaded file temporarily

        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')

        file.save(temp_file.name)

        temp_file.close()

        

        # Import data

        result = admin_data_manager.import_excel_data(temp_file.name)

        

        # Clean up temp file

        os.unlink(temp_file.name)

        

        if result['success']:

            # Export to JSON for frontend use

            admin_data_manager.export_to_json("threatguard_data/hierarchical_data.json")

            

            return jsonify(result)

        else:

            return jsonify(result), 400

            

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Import failed: {str(e)}'

        }), 500



@app.route('/api/admin/ait-list', methods=['GET'])

def admin_get_ait_list():

    """Get list of all AITs"""

    try:

        ait_list = admin_data_manager.get_ait_list()

        return jsonify({

            'success': True,

            'data': ait_list

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to get AIT list: {str(e)}'

        }), 500



@app.route('/api/admin/spk-list/<ait_tag>', methods=['GET'])

def admin_get_spk_list(ait_tag):

    """Get list of SPKs for a specific AIT"""

    try:

        spk_list = admin_data_manager.get_spk_list(ait_tag)

        return jsonify({

            'success': True,

            'data': spk_list

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to get SPK list: {str(e)}'

        }), 500



@app.route('/api/admin/repo-list/<spk_tag>', methods=['GET'])

def admin_get_repo_list(spk_tag):

    """Get list of repositories for a specific SPK"""

    try:

        repo_list = admin_data_manager.get_repo_list(spk_tag)

        return jsonify({

            'success': True,

            'data': repo_list

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to get repository list: {str(e)}'

        }), 500



@app.route('/api/admin/hierarchical-data', methods=['GET'])

def admin_get_hierarchical_data():

    """Get complete hierarchical data"""

    try:

        data = admin_data_manager.get_hierarchical_data()

        return jsonify({

            'success': True,

            'data': data

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to get hierarchical data: {str(e)}'

        }), 500



@app.route('/api/admin/statistics', methods=['GET'])

def admin_get_statistics():

    """Get database statistics"""

    try:

        stats = admin_data_manager.get_statistics()

        return jsonify({

            'success': True,

            'data': stats

        })

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to get statistics: {str(e)}'

        }), 500



@app.route('/api/admin/export-json', methods=['POST'])

def admin_export_json():

    """Export hierarchical data to JSON file"""

    try:

        output_path = request.json.get('output_path', 'hierarchical_data.json')

        success = admin_data_manager.export_to_json(output_path)

        

        if success:

            return jsonify({

                'success': True,

                'message': f'Data exported to {output_path}'

            })

        else:

            return jsonify({

                'success': False,

                'error': 'Failed to export data'

            }), 500

            

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Export failed: {str(e)}'

        }), 500



@app.route('/api/admin/download-template', methods=['GET'])

def admin_download_template():

    """Download Excel template for AIT-SPK-Repo mappings"""

    try:

        # Create sample Excel template

        import pandas as pd

        from io import BytesIO

        

        # Sample data for template

        sample_data = {

            'AIT_ID': ['100', '100', '29828', '29828'],

            'SPK': ['AAR', 'AAR', 'AAVS', 'AAVS'],

            'REPOSITORY_NAME': ['aar_shl', 'aar_sql', 'aavs_autosys', 'aavs_bat']

        }

        

        df = pd.DataFrame(sample_data)

        

        # Create Excel file in memory

        output = BytesIO()

        with pd.ExcelWriter(output, engine='openpyxl') as writer:

            df.to_excel(writer, sheet_name='RawData', index=False)

            

            # Auto-adjust column widths

            worksheet = writer.sheets['RawData']

            for column in worksheet.columns:

                max_length = 0

                column_letter = column[0].column_letter

                for cell in column:

                    try:

                        if len(str(cell.value)) > max_length:

                            max_length = len(str(cell.value))

                    except:

                        pass

                adjusted_width = min(max_length + 2, 50)

                worksheet.column_dimensions[column_letter].width = adjusted_width

        

        output.seek(0)

        

        return send_file(

            output,

            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',

            as_attachment=True,

            download_name='ait_spk_repo_template.xlsx'

        )

        

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to generate template: {str(e)}'

        }), 500



@app.route('/api/admin/clear-data', methods=['POST'])

def admin_clear_data():

    """Clear all AIT-SPK-Repo data from the database"""

    try:

        result = admin_data_manager.clear_all_data()

        

        if result['success']:

            return jsonify({

                'success': True,

                'message': result['message']

            })

        else:

            return jsonify({

                'success': False,

                'error': result['error']

            }), 500

            

    except Exception as e:

        return jsonify({

            'success': False,

            'error': f'Failed to clear data: {str(e)}'

        }), 500



# Job Management Endpoints

@app.route('/api/jobs/scan-repository', methods=['POST'])

def create_repository_scan_job():

    """Create a new asynchronous repository scan job"""

    try:

        data = request.get_json()

        repo_url = data.get('repo_url') or data.get('github_url') or data.get('bitbucket_url')

        repo_token = data.get('repo_token') or data.get('github_token') or data.get('bitbucket_token')

        scan_id = data.get('scan_id', str(uuid.uuid4()))

        scan_type = data.get('scan_type', 'repository')

        project_id = data.get('project_id', f'repo-scan-{int(datetime.now().timestamp())}')

        project_name = data.get('project_name', 'Repository Scan')

        ait_tag = data.get('ait_tag', 'AIT')

        spk_tag = data.get('spk_tag', 'SPK')

        repo_name = data.get('repo_name', 'Repository')



        if not repo_url:

            return jsonify({'error': 'Repository URL is required'}), 400



        # Extract repository information from URL

        import re



        # GitHub patterns

        github_pattern = r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'

        github_match = re.match(github_pattern, repo_url.strip())



        # Bitbucket patterns (both cloud and server)

        bitbucket_cloud_pattern = r'https://bitbucket\.org/([^/]+)/([^/]+?)(?:\.git)?/?$'

        bitbucket_server_pattern = r'https://([^/]+)/scm/([^/]+)/([^/]+?)(?:\.git)?/?$'



        bitbucket_cloud_match = re.match(bitbucket_cloud_pattern, repo_url.strip())

        bitbucket_server_match = re.match(bitbucket_server_pattern, repo_url.strip())



        repo_type = None

        if github_match:

            repo_type = 'github'

        elif bitbucket_cloud_match:

            repo_type = 'bitbucket_cloud'

        elif bitbucket_server_match:

            repo_type = 'bitbucket_server'

        else:

            return jsonify({

                'error': 'Invalid repository URL format. Supported formats:\n' +

                        '• GitHub: https://github.com/owner/repository\n' +

                        '• Bitbucket Cloud: https://bitbucket.org/owner/repository\n' +

                        '• Bitbucket Server: https://server.com/scm/owner/repository'

            }), 400



        # Create scan job data

        scan_data = {

            'scan_id': scan_id,

            'scan_type': scan_type,

            'project_id': project_id,

            'project_name': project_name,

            'repo_url': repo_url,

            'repo_token': repo_token,

            'repo_type': repo_type,

            'ait_tag': ait_tag,

            'spk_tag': spk_tag,

            'repo_name': repo_name

        }



        # Create job

        job_id = job_manager.create_job(scan_data)



        # Start async scan

        async_repo_scanner.start_scan_job(job_id, scan_data)



        return jsonify({

            'job_id': job_id,

            'status': 'pending',

            'message': 'Repository scan job created successfully',

            'scan_id': scan_id

        })



    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/jobs/<job_id>/status', methods=['GET'])

def get_job_status(job_id):

    """Get the status of a specific job"""

    try:

        job = job_manager.get_job_status(job_id)

        if not job:

            return jsonify({'error': 'Job not found'}), 404



        # Parse result data if available

        result_data = None

        if job.get('result_data'):

            try:

                result_data = json.loads(job['result_data'])

            except:

                pass



        return jsonify({

            'job_id': job['job_id'],

            'status': job['status'],

            'progress': job['progress'],

            'created_at': job['created_at'],

            'started_at': job['started_at'],

            'completed_at': job['completed_at'],

            'error_message': job.get('error_message'),

            'result_data': result_data,

            'repo_url': job['repo_url'],

            'repo_type': job['repo_type']

        })



    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/jobs', methods=['GET'])

def get_all_jobs():

    """Get all jobs with optional filtering"""

    try:

        limit = request.args.get('limit', 50, type=int)

        status = request.args.get('status')

        

        jobs = job_manager.get_all_jobs(limit)

        

        # Filter by status if provided

        if status:

            jobs = [job for job in jobs if job['status'] == status]

        

        # Parse result data for each job

        for job in jobs:

            if job.get('result_data'):

                try:

                    job['result_data'] = json.loads(job['result_data'])

                except:

                    job['result_data'] = None



        return jsonify({

            'jobs': jobs,

            'total': len(jobs),

            'active_jobs': async_repo_scanner.get_active_jobs_count()

        })



    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/jobs/<job_id>/cancel', methods=['POST'])

def cancel_job(job_id):

    """Cancel a running job"""

    try:

        success = async_repo_scanner.cancel_job(job_id)

        if success:

            return jsonify({'message': 'Job cancelled successfully'})

        else:

            return jsonify({'error': 'Job not found or already completed'}), 404



    except Exception as e:

        return jsonify({'error': str(e)}), 500



@app.route('/api/jobs/cleanup', methods=['POST'])

def cleanup_old_jobs():

    """Clean up old completed/failed jobs"""

    try:

        days = request.args.get('days', 7, type=int)

        status = request.args.get('status', None)  # New parameter for status-specific cleanup
        
        # Validate days parameter (allow 0 for "all jobs")
        if days < 0:
            return jsonify({'error': 'Days parameter must be 0 or greater'}), 400
        
        # Perform cleanup and get count
        if status:
            # Status-specific cleanup
            deleted_count = job_manager.cleanup_jobs_by_status(status)
            message = f'Successfully cleaned up {deleted_count} {status} jobs'
        else:
            # Time-based cleanup (existing functionality)
            deleted_count = job_manager.cleanup_old_jobs(days)
            if days == 0:
                message = f'Successfully cleaned up {deleted_count} completed/failed/cancelled jobs'
            else:
                message = f'Successfully cleaned up {deleted_count} jobs older than {days} days'
        
        return jsonify({
            'message': message,
            'deleted_count': deleted_count,
            'days': days,
            'status': status
        })

    except Exception as e:

        logger.error(f"Cleanup API error: {e}")
        return jsonify({'error': f'Cleanup failed: {str(e)}'}), 500


@app.route('/api/detector/reload', methods=['POST'])
def reload_detector_data():
    """Reload detector data from files - used by async workers to update API server"""
    try:
        # Reload the detector's data from files
        detector.issue_manager.load_issues()
        detector.load_scan_history()
        
        logger.info(f"✅ Detector data reloaded: {len(detector.issue_manager.issues)} issues, {len(detector.scan_history)} scans")
        
        return jsonify({
            'message': 'Detector data reloaded successfully',
            'issues_count': len(detector.issue_manager.issues),
            'scans_count': len(detector.scan_history)
        })
        
    except Exception as e:
        logger.error(f"Detector reload error: {e}")
        return jsonify({'error': f'Detector reload failed: {str(e)}'}), 500



@app.route('/api/admin/cleanup-vulnerabilities', methods=['POST'])
def admin_cleanup_vulnerabilities():
    """Clean up vulnerability records"""
    try:
        data = request.get_json() or {}
        cleanup_type = data.get('type', 'all')  # 'all', 'threat_issues', 'scan_history', 'jobs', 'uploaded_projects', 'in_memory'
        keep_days = data.get('keep_days', 30)  # Keep records from last N days
        
        from cleanup_vulnerabilities import VulnerabilityCleanup
        cleanup = VulnerabilityCleanup()
        
        results = {}
        
        if cleanup_type == 'all' or cleanup_type == 'threat_issues':
            # Clean up threat_issues.json
            results['threat_issues'] = cleanup.cleanup_threat_issues(keep_days)
        
        if cleanup_type == 'all' or cleanup_type == 'scan_history':
            # Clean up scan_history.json
            results['scan_history'] = cleanup.cleanup_scan_history(keep_days)
        
        if cleanup_type == 'all' or cleanup_type == 'jobs':
            # Clean up jobs.db
            results['jobs'] = cleanup.cleanup_jobs_database(keep_days)
        
        if cleanup_type == 'all' or cleanup_type == 'uploaded_projects':
            # Clean up uploaded_projects directory
            results['uploaded_projects'] = cleanup.cleanup_uploaded_projects(keep_days)
        
        if cleanup_type == 'all' or cleanup_type == 'in_memory':
            # Clear in-memory detector data
            results['in_memory'] = cleanup.clear_in_memory_data()
        
        return jsonify({
            'success': True,
            'message': f'Vulnerability cleanup completed successfully',
            'cleanup_type': cleanup_type,
            'keep_days': keep_days,
            'results': results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Failed to cleanup vulnerabilities: {str(e)}'
        }), 500



@app.route('/api/github/test', methods=['GET'])
def test_github_api():
    """Test endpoint to verify GitHub API is working"""
    try:
        current_dir = os.getcwd()
        return jsonify({
            'success': True,
            'message': 'GitHub API is working',
            'current_directory': current_dir,
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/github/create-vulnerability-prompt', methods=['POST'])
def create_vulnerability_prompt():
    """Create .github/vulnerability folder and vulnerability prompt .md file"""
    try:
        print(f"🔍 Starting vulnerability prompt creation...")
        data = request.get_json() or {}
        print(f"📥 Received data: {data}")
        vulnerability_data = data.get('vulnerability', {})
        print(f"📋 Vulnerability data: {vulnerability_data}")
        
        if not vulnerability_data:
            return jsonify({
                'success': False,
                'error': 'Vulnerability data is required'
            }), 400
        
        # Create .github directory if it doesn't exist
        # Use the current working directory as base
        current_dir = os.getcwd()
        github_dir = os.path.join(current_dir, '.github')
        vulnerability_dir = os.path.join(github_dir, 'vulnerability', 'application')
        
        print(f"📁 Current directory: {current_dir}")
        print(f"📁 GitHub directory: {github_dir}")
        print(f"📁 Vulnerability directory: {vulnerability_dir}")
        
        try:
            os.makedirs(vulnerability_dir, exist_ok=True)
            print(f"✅ Created directory structure: {vulnerability_dir}")
        except PermissionError as pe:
            print(f"❌ Permission error: {pe}")
            return jsonify({
                'success': False,
                'error': f'Permission denied creating directory: {str(pe)}'
            }), 403
        except Exception as e:
            print(f"❌ Directory creation error: {e}")
            return jsonify({
                'success': False,
                'error': f'Failed to create directory: {str(e)}'
            }), 500
        
        # Generate the markdown content
        ait_tag = vulnerability_data.get('ait_tag', 'AIT-Unknown')
        gis_id = vulnerability_data.get('gis_id', 'GIS-Unknown')
        vulnerability_id = vulnerability_data.get('id', 'unknown')  # Keep for internal reference
        title = vulnerability_data.get('title', vulnerability_data.get('description', 'Unknown Vulnerability'))
        severity = vulnerability_data.get('severity', 'Unknown')
        risk_score = vulnerability_data.get('risk_score', 'N/A')
        remediation_action = vulnerability_data.get('remediation_action', 'Update to latest version')
        timestamp = datetime.now().strftime('%Y-%m-%d')
        
        # Create a clean filename using GIS ID, AIT, and vulnerability title
        import re
        clean_title = re.sub(r'[^a-zA-Z0-9\s-]', '', title).replace(' ', '_')[:50] if title else 'Vulnerability'
        
        markdown_content = f"""# Vulnerability Remediation Action Prompt

## Context
This prompt is for GitHub Copilot to generate a Terraform remediation file for a security vulnerability.

## Vulnerability Details
- **GIS ID**: {gis_id}
- **AIT Tag**: {ait_tag}
- **Title**: {title}
- **Severity**: {severity}
- **Risk Score**: {risk_score}
- **Remediation Action**: {remediation_action}
- **Generated Date**: {timestamp}

## Instructions for GitHub Copilot
1. **Generate a complete Terraform (.tf) file** that addresses this specific vulnerability
2. **Save the generated file** in the `remediated_vulnerability` folder
3. **Use the AIT tag** ({ait_tag}) as a prefix for resource naming
4. **Include proper security configurations** based on the vulnerability type
5. **Add comprehensive documentation** in comments
6. **Follow AWS best practices** for infrastructure security
7. **Include monitoring and alerting** via CloudWatch
8. **Provide automated backup solutions** where applicable

## File Naming Convention
Save the generated Terraform file as: `{ait_tag}_{gis_id}_remediation.tf`

## Expected Output
A complete, production-ready Terraform configuration that can be applied to remediate the vulnerability.

## Important Notes
- The file must be saved in the `remediated_vulnerability` folder
- Use the exact AIT tag and vulnerability ID for naming
- Ensure the configuration is secure and follows compliance standards
- Include proper error handling and validation

Please generate the Terraform configuration now and save it to the specified location.
"""
        
        # Create the markdown file
        filename = f"{ait_tag}_{gis_id}_{clean_title}_action_prompt.md"
        file_path = os.path.join(vulnerability_dir, filename)
        
        print(f"📄 Creating file: {filename}")
        print(f"📄 Full file path: {file_path}")
        
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(markdown_content)
            print(f"✅ Created vulnerability prompt file: {file_path}")
        except PermissionError as pe:
            print(f"❌ File permission error: {pe}")
            return jsonify({
                'success': False,
                'error': f'Permission denied creating file: {str(pe)}'
            }), 403
        except Exception as e:
            print(f"❌ File creation error: {e}")
            return jsonify({
                'success': False,
                'error': f'Failed to create file: {str(e)}'
            }), 500
        
        print(f"🎉 Successfully created vulnerability prompt for {ait_tag} - {vulnerability_id}")
        
        return jsonify({
            'success': True,
            'message': f'Vulnerability prompt created successfully',
            'file_path': file_path,
            'filename': filename,
            'directory': vulnerability_dir,
            'vulnerability_id': vulnerability_id,
            'ait_tag': ait_tag
        })
        
    except Exception as e:
        print(f"Error creating vulnerability prompt: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to create vulnerability prompt: {str(e)}'
        }), 500

@app.route('/api/github/check-vulnerability-folder', methods=['GET'])
def check_vulnerability_folder():
    """Check if .github/vulnerability folder exists and list its contents"""
    try:
        # Use the current working directory as base
        current_dir = os.getcwd()
        github_dir = os.path.join(current_dir, '.github')
        vulnerability_dir = os.path.join(github_dir, 'vulnerability')
        
        if not os.path.exists(vulnerability_dir):
            return jsonify({
                'success': True,
                'exists': False,
                'directory': vulnerability_dir,
                'files': [],
                'message': 'Vulnerability folder does not exist'
            })
        
        # List files in the vulnerability directory
        files = []
        if os.path.exists(vulnerability_dir):
            for filename in os.listdir(vulnerability_dir):
                if filename.endswith('.md'):
                    file_path = os.path.join(vulnerability_dir, filename)
                    file_stat = os.stat(file_path)
                    files.append({
                        'filename': filename,
                        'size': file_stat.st_size,
                        'created': datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
                        'modified': datetime.fromtimestamp(file_stat.st_mtime).isoformat()
                    })
        
        return jsonify({
            'success': True,
            'exists': True,
            'directory': vulnerability_dir,
            'files': files,
            'file_count': len(files),
            'message': f'Found {len(files)} vulnerability prompt files'
        })
        
    except Exception as e:
        print(f"Error checking vulnerability folder: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to check vulnerability folder: {str(e)}'
        }), 500

@app.route('/api/github/check-remediated-folder', methods=['GET'])
def check_remediated_folder():
    """Check if remediated_vulnerability folder exists and list its Terraform files"""
    try:
        # Use the current working directory as base
        current_dir = os.getcwd()
        remediated_dir = os.path.join(current_dir, 'remediated_vulnerability')
        
        print(f"🔍 Checking remediated folder: {remediated_dir}")
        
        if not os.path.exists(remediated_dir):
            return jsonify({
                'success': True,
                'exists': False,
                'directory': remediated_dir,
                'files': [],
                'message': 'Remediated vulnerability folder does not exist'
            })
        
        # List Terraform files in the remediated directory
        files = []
        if os.path.exists(remediated_dir):
            for filename in os.listdir(remediated_dir):
                if filename.endswith('.tf'):
                    file_path = os.path.join(remediated_dir, filename)
                    file_stat = os.stat(file_path)
                    files.append({
                        'filename': filename,
                        'size': file_stat.st_size,
                        'created': datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
                        'modified': datetime.fromtimestamp(file_stat.st_mtime).isoformat()
                    })
        
        print(f"✅ Found {len(files)} Terraform files in remediated folder")
        
        return jsonify({
            'success': True,
            'exists': True,
            'directory': remediated_dir,
            'files': files,
            'file_count': len(files),
            'message': f'Found {len(files)} Terraform remediation files'
        })
        
    except Exception as e:
        print(f"Error checking remediated folder: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to check remediated folder: {str(e)}'
        }), 500

@app.route('/api/github/read-vulnerability-file/<filename>', methods=['GET'])
def read_vulnerability_file(filename):
    """Read the content of a specific vulnerability prompt file"""
    try:
        # Validate filename to prevent path traversal
        if '..' in filename or '/' in filename or '\\' in filename:
            return jsonify({
                'success': False,
                'error': 'Invalid filename'
            }), 400
        
        # Use the current working directory as base
        current_dir = os.getcwd()
        vulnerability_dir = os.path.join(current_dir, '.github', 'vulnerability')
        file_path = os.path.join(vulnerability_dir, filename)
        
        if not os.path.exists(file_path):
            return jsonify({
                'success': False,
                'error': 'File not found'
            }), 404
        
        # Read the file content
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Get file stats
        file_stat = os.stat(file_path)
        
        return jsonify({
            'success': True,
            'filename': filename,
            'content': content,
            'size': file_stat.st_size,
            'created': datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
            'modified': datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
            'file_path': file_path
        })
        
    except Exception as e:
        print(f"Error reading vulnerability file {filename}: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to read file: {str(e)}'
        }), 500

@app.route('/api/github/read-remediated-tf/<filename>', methods=['GET'])
def read_remediated_tf_file(filename):
    """Read the content of a specific Terraform remediation file from remediated_vulnerability folder"""
    try:
        # Validate filename to prevent path traversal
        if '..' in filename or '/' in filename or '\\' in filename:
            return jsonify({
                'success': False,
                'error': 'Invalid filename'
            }), 400
        
        # Use the current working directory as base
        current_dir = os.getcwd()
        remediated_dir = os.path.join(current_dir, 'remediated_vulnerability')
        file_path = os.path.join(remediated_dir, filename)
        
        print(f"🔍 Looking for Terraform file: {file_path}")
        
        if not os.path.exists(file_path):
            return jsonify({
                'success': False,
                'error': f'File not found: {file_path}'
            }), 404
        
        # Read the file content
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Get file stats
        file_stat = os.stat(file_path)
        
        print(f"✅ Successfully read Terraform file: {filename}")
        
        return jsonify({
            'success': True,
            'filename': filename,
            'content': content,
            'size': file_stat.st_size,
            'created': datetime.fromtimestamp(file_stat.st_ctime).isoformat(),
            'modified': datetime.fromtimestamp(file_stat.st_mtime).isoformat(),
            'file_path': file_path
        })
        
    except Exception as e:
        print(f"Error reading Terraform file {filename}: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to read Terraform file: {str(e)}'
        }), 500

@app.route('/api/github/list-remediated-tf-files', methods=['GET'])
def list_remediated_tf_files():
    """List all Terraform remediation files in the remediated_vulnerability folder"""
    try:
        # Use the current working directory as base
        current_dir = os.getcwd()
        remediated_dir = os.path.join(current_dir, 'remediated_vulnerability')
        
        print(f"🔍 Listing files in: {remediated_dir}")
        
        if not os.path.exists(remediated_dir):
            return jsonify({
                'success': True,
                'files': [],
                'message': 'remediated_vulnerability folder does not exist'
            })
        
        # Get all .tf files in the directory
        tf_files = []
        for filename in os.listdir(remediated_dir):
            if filename.endswith('.tf') and os.path.isfile(os.path.join(remediated_dir, filename)):
                tf_files.append(filename)
        
        print(f"✅ Found {len(tf_files)} Terraform files: {tf_files}")
        
        return jsonify({
            'success': True,
            'files': tf_files,
            'directory': remediated_dir,
            'count': len(tf_files)
        })
        
    except Exception as e:
        print(f"Error listing Terraform files: {e}")
        return jsonify({
            'success': False,
            'error': f'Failed to list Terraform files: {str(e)}'
        }), 500

@app.route('/api/diagnostic/scan-status', methods=['GET'])
def diagnostic_scan_status():
    """Run diagnostic on scan status and system health"""
    try:
        diagnostic = ScanDiagnostic()
        report = diagnostic.run_diagnostic()
        
        return jsonify({
            'success': True,
            'diagnostic_report': report,
            'timestamp': report['timestamp']
        })
        
    except Exception as e:
        logger.error(f"Diagnostic API error: {e}")
        return jsonify({
            'success': False,
            'error': f'Diagnostic failed: {str(e)}'
        }), 500



# Knowledge Base API Endpoints
@app.route('/api/knowledge-base/templates', methods=['GET'])
def get_knowledge_base_templates():
    """Get all knowledge base templates"""
    try:
        templates = knowledge_base_manager.get_all_templates()
        return jsonify({
            'success': True,
            'templates': templates,
            'count': len(templates)
        })
    except Exception as e:
        logger.error(f"Error getting knowledge base templates: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/knowledge-base/templates', methods=['POST'])
def add_knowledge_base_template():
    """Add new knowledge base template"""
    try:
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        category = request.form.get('category', 'application').strip()
        content_type = request.form.get('content_type', 'url').strip()
        
        if not title or not description:
            return jsonify({
                'success': False,
                'error': 'Title and description are required'
            }), 400
        
        template_id = None
        
        if content_type == 'url':
            content = request.form.get('content', '').strip()
            if not content:
                return jsonify({
                    'success': False,
                    'error': 'URL content is required'
                }), 400
            
            template_id = knowledge_base_manager.add_template_from_url(
                title, description, category, content
            )
        else:  # file
            if 'file' not in request.files:
                return jsonify({
                    'success': False,
                    'error': 'File is required'
                }), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({
                    'success': False,
                    'error': 'No file selected'
                }), 400
            
            # Check if it's an Excel file
            if file.filename.lower().endswith(('.xlsx', '.xls')):
                # Handle Excel file for Jira data analysis
                file_content = file.read()  # Read as bytes for Excel
                template_id = knowledge_base_manager.add_template_from_excel(
                    title, description, file_content
                )
            else:
                # Handle other file types
                file_content = file.read().decode('utf-8', errors='ignore')
                template_id = knowledge_base_manager.add_template_from_file(
                    title, description, category, file_content, file.filename
                )
        
        if template_id:
            return jsonify({
                'success': True,
                'template_id': template_id,
                'message': 'Template added successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to add template'
            }), 500
            
    except Exception as e:
        logger.error(f"Error adding knowledge base template: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/knowledge-base/templates/<template_id>', methods=['GET'])
def get_knowledge_base_template(template_id):
    """Get specific knowledge base template"""
    try:
        template = knowledge_base_manager.get_template_by_id(template_id)
        if template:
            return jsonify({
                'success': True,
                'template': template
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Template not found'
            }), 404
    except Exception as e:
        logger.error(f"Error getting knowledge base template: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/knowledge-base/templates/<template_id>/download', methods=['GET'])
def download_knowledge_base_template(template_id):
    """Download knowledge base template"""
    try:
        template = knowledge_base_manager.get_template_by_id(template_id)
        if not template:
            return jsonify({
                'success': False,
                'error': 'Template not found'
            }), 404
        
        # Create download content in Markdown format
        download_content = f"""# {template['title']}

**Category:** {template['category']}  
**Generated:** {template['created_at']}  
**Created By:** {template['created_by']}

## Description

{template['description']}

## Metadata

| Field | Value |
|-------|-------|
| **Tags** | {', '.join(template['tags'])} |
| **Severity Levels** | {', '.join(template['severity_levels'])} |
| **Applicable Languages** | {', '.join(template['applicable_languages'])} |
| **Content Type** | {template['content_type']} |

---

## AI Copilot Prompt

```markdown
{template['ai_copilot_prompt']}
```

---

## Remediation Template

```markdown
{template['remediation_template']}
```

---

## Usage Instructions

1. **For AI Copilot:**
   - Copy the AI Copilot prompt above
   - Paste it into your code editor with AI assistance enabled
   - Follow the generated suggestions for secure implementation

2. **For Manual Remediation:**
   - Follow the step-by-step remediation template
   - Check off each item as completed
   - Verify implementation with testing requirements

3. **For Team Sharing:**
   - Share this markdown file with your development team
   - Use as a reference for security best practices
   - Include in your security documentation

---

*Generated by ThreatGuard Pro Knowledge Base*
"""
        
        # Return as file download
        output = io.BytesIO()
        output.write(download_content.encode('utf-8'))
        output.seek(0)
        
        return send_file(
            output,
            as_attachment=True,
            download_name=f"{template['title'].replace(' ', '_')}_remediation_template.md",
            mimetype='text/markdown'
        )
        
    except Exception as e:
        logger.error(f"Error downloading knowledge base template: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/knowledge-base/templates/search', methods=['GET'])
def search_knowledge_base_templates():
    """Search knowledge base templates"""
    try:
        query = request.args.get('q', '').strip()
        category = request.args.get('category', '').strip()
        
        if category and category != 'all':
            templates = knowledge_base_manager.get_templates_by_category(category)
        else:
            templates = knowledge_base_manager.get_all_templates()
        
        if query:
            # Filter by search query
            query_lower = query.lower()
            templates = [
                template for template in templates
                if (query_lower in template['title'].lower() or
                    query_lower in template['description'].lower() or
                    any(query_lower in tag.lower() for tag in template['tags']))
            ]
        
        return jsonify({
            'success': True,
            'templates': templates,
            'count': len(templates),
            'query': query,
            'category': category
        })
        
    except Exception as e:
        logger.error(f"Error searching knowledge base templates: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/knowledge-base/templates/python311-migration', methods=['POST'])
def create_python311_migration_template():
    """Create Python 3.11 migration template"""
    try:
        template_id = knowledge_base_manager.create_python311_migration_template()
        
        if template_id:
            return jsonify({
                'success': True,
                'template_id': template_id,
                'message': 'Python 3.11 migration template created successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Template may already exist or creation failed'
            }), 400
    except Exception as e:
        logger.error(f"Error creating Python 3.11 migration template: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':

    print("🚀 Starting ThreatGuard Pro Enhanced Dashboard...")

    print("🛡️ Advanced Logic Bomb Detection & Threat Intelligence enabled:")

    print("  • Enhanced Threat Pattern Detection")

    print("  • Real-time Logic Bomb Analysis")

    print("  • Advanced Threat Intelligence")

    print("  • Comprehensive Threat Shields")

    print("  • Financial Fraud Detection")

    print("  • User-targeted Attack Detection")

    print("  • Time-based Trigger Detection")

    print("  • Destructive Payload Analysis")

    print("  • [COPILOT] Automated Copilot Agent")

    print("\n🌐 ThreatGuard Command Center available at: http://localhost:5000")

    print("📋 Enhanced API endpoints:")

    print("  • GET  /api/command-center/metrics - Enhanced threat metrics")

    print("  • POST /api/logic-bomb-scan - Advanced logic bomb scan")

    print("  • GET  /api/threats - Comprehensive threat management")

    print("  • GET  /api/threat-shields - Threat protection shields")

    print("  • GET  /api/threat-intelligence - Threat intelligence data")

    print("  • POST /api/scan/files - Enhanced file scanning")

    print("  • GET  /api/health - System health monitoring")

    print("  • POST /api/copilot/agent/start - Start automated Copilot agent")

    print("  • POST /api/copilot/agent/stop - Stop automated Copilot agent")

    print("  • GET  /api/copilot/agent/status - Get agent status")

    print("="*80)

    

    # Start the automated Copilot agent

    try:

        start_copilot_agent()

        print("[COPILOT] Automated Copilot Agent started successfully")

    except Exception as e:

        print(f"⚠️ Warning: Could not start Copilot agent: {e}")

    

    app.run(host='127.0.0.1', port=5000, debug=True)