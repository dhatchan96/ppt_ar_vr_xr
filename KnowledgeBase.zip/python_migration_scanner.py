#!/usr/bin/env python3
"""
Python Migration Scanner Worker
Scans repositories for Python packages to migrate
"""

import threading
import time
import tempfile
import subprocess
import shutil
import os
import re
from pathlib import Path
from typing import Dict, List, Optional
import logging
from job_manager import job_manager, JobStatus
from config import settings
from knowledge_base_manager import knowledge_base_manager

logger = logging.getLogger(__name__)

class PythonMigrationScanner:
    """Python migration scanner worker"""
    
    def __init__(self):
        self.active_jobs = {}
        self.worker_threads = {}
    
    def start_scan_job(self, job_id: str, scan_data: Dict):
        """Start a Python migration scan job in a background thread"""
        if job_id in self.active_jobs:
            logger.warning(f"Job {job_id} is already running")
            return
        
        # Mark job as active
        self.active_jobs[job_id] = scan_data
        
        # Start worker thread
        worker_thread = threading.Thread(
            target=self._scan_migration_worker,
            args=(job_id, scan_data),
            daemon=True
        )
        worker_thread.start()
        
        self.worker_threads[job_id] = worker_thread
        logger.info(f"Started async Python migration scan job {job_id}")
    
    def _scan_migration_worker(self, job_id: str, scan_data: Dict):
        """Worker function that performs the actual Python package scanning"""
        try:
            # Update status to running
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Starting Python migration package scan...")
            
            repo_url = scan_data.get('repo_url')
            scan_id = scan_data.get('scan_id')
            ait_tag = scan_data.get('ait_tag')
            spk_tag = scan_data.get('spk_tag')
            repo_name = scan_data.get('repo_name')
            
            # Parse repository URL
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Analyzing repository URL...")
            repo_type, owner, repo, server_url = self._parse_repo_url(repo_url)
            logger.info(f"Parsed repository URL: type={repo_type}, owner={owner}, repo={repo}, server={server_url}")
            
            if not repo_type:
                raise ValueError("Invalid repository URL format")
            
            # Clone repository
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Cloning repository...")
            
            # Use job_id in temp directory name to avoid conflicts
            temp_dir = tempfile.mkdtemp(prefix=f"python_migration_{job_id}_")
            repo_path = os.path.join(temp_dir, repo)
            
            try:
                # Clone the repository
                clone_url, clone_cmd = self._get_clone_command(repo_type, owner, repo, None, server_url)
                
                # Change to temp directory and clone there
                original_cwd = os.getcwd()
                os.chdir(temp_dir)
                
                result = subprocess.run(clone_cmd, capture_output=True, text=True, timeout=settings.GIT_CLONE_TIMEOUT)
                
                # Change back to original directory
                os.chdir(original_cwd)
                
                if result.returncode != 0:
                    error_msg = result.stderr.strip()
                    raise Exception(f"Failed to clone repository: {error_msg}")
                
                # Detect Python packages
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Detecting Python packages...")
                package_info = knowledge_base_manager.detect_python_packages_from_repo(repo_path)
                
                # Compile results
                result_data = {
                    'scan_id': scan_id,
                    'scan_type': 'migration',
                    'project_id': scan_data.get('project_id', f'python-migration-{scan_id}'),
                    'project_name': scan_data.get('project_name', 'Python Migration Scan'),
                    'repo_url': repo_url,
                    'repo_name': repo_name,
                    'ait_tag': ait_tag,
                    'spk_tag': spk_tag,
                    'packages': package_info['packages'],
                    'detected_files': package_info['detected_files'],
                    'total_packages': package_info['total_packages'],
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Update job status to completed
                job_manager.update_job_status(
                    job_id, 
                    JobStatus.COMPLETED, 
                    f"Scan completed: Found {package_info['total_packages']} Python packages in {len(package_info['detected_files'])} file(s)",
                    result_data=result_data
                )
                
                logger.info(f"Python migration scan job {job_id} completed successfully")
                
            finally:
                # Clean up temporary directory
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up temp directory: {e}")
                
        except Exception as e:
            logger.error(f"Error in Python migration scan job {job_id}: {e}", exc_info=True)
            job_manager.update_job_status(
                job_id, 
                JobStatus.FAILED, 
                f"Scan failed: {str(e)}",
                error_message=str(e)
            )
        finally:
            # Clean up
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            if job_id in self.worker_threads:
                del self.worker_threads[job_id]
    
    def _parse_repo_url(self, repo_url: str) -> tuple:
        """Parse repository URL and return (repo_type, owner, repo, server_url)"""
        # GitHub patterns
        github_pattern = r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'
        github_match = re.match(github_pattern, repo_url.strip())
        
        # Bitbucket patterns
        bitbucket_cloud_pattern = r'https://bitbucket\.org/([^/]+)/([^/]+?)(?:\.git)?/?$'
        bitbucket_server_pattern = r'https://([^/]+)/scm/([^/]+)/([^/]+?)(?:\.git)?/?$'
        
        bitbucket_cloud_match = re.match(bitbucket_cloud_pattern, repo_url.strip())
        bitbucket_server_match = re.match(bitbucket_server_pattern, repo_url.strip())
        
        if github_match:
            return 'github', github_match.group(1), github_match.group(2), None
        elif bitbucket_cloud_match:
            return 'bitbucket_cloud', bitbucket_cloud_match.group(1), bitbucket_cloud_match.group(2), None
        elif bitbucket_server_match:
            return 'bitbucket_server', bitbucket_server_match.group(2), bitbucket_server_match.group(3), bitbucket_server_match.group(1)
        
        return None, None, None, None
    
    def _get_clone_command(self, repo_type: str, owner: str, repo: str, repo_token: str, server_url: str = None) -> tuple:
        """Get git clone command for repository type"""
        if repo_type == 'github':
            if repo_token:
                clone_url = f"https://{repo_token}@github.com/{owner}/{repo}.git"
            else:
                clone_url = f"https://github.com/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
            
        elif repo_type == 'bitbucket_cloud':
            if repo_token:
                clone_url = f"https://{repo_token}@bitbucket.org/{owner}/{repo}.git"
            else:
                clone_url = f"https://bitbucket.org/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
            
        elif repo_type == 'bitbucket_server':
            if repo_token:
                clone_url = f"https://{repo_token}@{server_url}/scm/{owner}/{repo}.git"
            else:
                clone_url = f"https://{server_url}/scm/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
        
        raise ValueError(f"Unsupported repository type: {repo_type}")
    
    def get_active_jobs_count(self) -> int:
        """Get number of active jobs"""
        return len(self.active_jobs)
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job"""
        if job_id in self.active_jobs:
            job_manager.update_job_status(job_id, JobStatus.CANCELLED, "Job cancelled by user")
            
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            if job_id in self.worker_threads:
                del self.worker_threads[job_id]
            
            return True
        return False

# Global Python migration scanner instance
python_migration_scanner = PythonMigrationScanner()

