import React, { useState, useEffect } from 'react';
import API from '../api';

const KnowledgeBase = () => {
    const [templates, setTemplates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [activeTab, setActiveTab] = useState('all');
    const [showAddModal, setShowAddModal] = useState(false);
    const [newTemplate, setNewTemplate] = useState({
        title: '',
        description: '',
        category: 'application',
        content_type: 'url',
        content: '',
        file: null
    });
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [showViewModal, setShowViewModal] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCategory, setFilterCategory] = useState('all');

    useEffect(() => {
        fetchTemplates();
    }, []);

    // Auto-dismiss success messages after 5 seconds
    useEffect(() => {
        if (success) {
            const timer = setTimeout(() => {
                setSuccess(null);
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [success]);

    const fetchTemplates = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await API.get('/api/knowledge-base/templates');
            if (response.data && response.data.success) {
                setTemplates(response.data.templates || []);
            } else {
                setError(response.data?.error || 'Failed to fetch templates');
            }
        } catch (error) {
            console.error('Error fetching templates:', error);
            setError('Failed to load templates. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleAddTemplate = async () => {
        try {
            setError(null);
            setSuccess(null);
            const formData = new FormData();
            formData.append('title', newTemplate.title);
            formData.append('description', newTemplate.description);
            formData.append('category', newTemplate.category);
            formData.append('content_type', newTemplate.content_type);
            
            if (newTemplate.content_type === 'url') {
                formData.append('content', newTemplate.content);
            } else if (newTemplate.file) {
                formData.append('file', newTemplate.file);
            }

            const response = await API.post('/api/knowledge-base/templates', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.data && response.data.success) {
                setShowAddModal(false);
                setNewTemplate({
                    title: '',
                    description: '',
                    category: 'application',
                    content_type: 'url',
                    content: '',
                    file: null
                });
                fetchTemplates();
                setSuccess('Template added successfully!');
                setShowAddModal(false);
            }
        } catch (error) {
            console.error('Error adding template:', error);
            setError('Error adding template: ' + (error.response?.data?.error || error.message));
        }
    };

    const handleDownloadTemplate = async (templateId, templateName) => {
        try {
            const response = await API.get(`/api/knowledge-base/templates/${templateId}/download`, {
                responseType: 'blob'
            });
            
            const url = window.URL.createObjectURL(new Blob([response.data], { type: 'text/markdown' }));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `${templateName.replace(/\s+/g, '_')}_remediation_template.md`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Error downloading template:', error);
            setError('Error downloading template: ' + (error.response?.data?.error || error.message));
        }
    };

    const handleViewTemplate = (template) => {
        setSelectedTemplate(template);
        setShowViewModal(true);
    };

    const filteredTemplates = templates.filter(template => {
        const matchesSearch = template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            template.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = filterCategory === 'all' || template.category === filterCategory;
        const matchesTab = activeTab === 'all' || template.category === activeTab;
        
        return matchesSearch && matchesCategory && matchesTab;
    });

    const getCategoryColor = (category) => {
        const colors = {
            'application': '#007bff',
            'infrastructure': '#28a745',
            'security': '#dc3545',
            'network': '#ffc107',
            'database': '#6f42c1',
            'data-analysis': '#17a2b8',
            'migration': '#fd7e14'
        };
        return colors[category] || '#6c757d';
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-12">
                    <div className="card shadow-sm">
                        <div className="card-header bg-white border-bottom">
                            <div className="row align-items-center">
                                <div className="col-md-6">
                                    <h4 className="mb-0 text-dark">Knowledge Base</h4>
                                    <p className="text-muted mb-0">Remediation templates and security guidance</p>
                                </div>
                                <div className="col-md-6 text-end">
                                    <button 
                                        className="btn btn-primary"
                                        onClick={() => {
                                            setShowAddModal(true);
                                            setError(null);
                                            setSuccess(null);
                                        }}
                                    >
                                        Add New Template
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="card-body">
                            {/* Success Message */}
                            {success && (
                                <div className="alert alert-success-subtle border-success-subtle text-success-emphasis mb-3" role="alert">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div className="d-flex align-items-center">
                                            <i className="bi bi-check-circle-fill me-2"></i>
                                            <span>{success}</span>
                                        </div>
                                        <button 
                                            type="button" 
                                            className="btn-close" 
                                            onClick={() => setSuccess(null)}
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                </div>
                            )}
                            
                            {/* Error Message */}
                            {error && (
                                <div className="alert alert-danger-subtle border-danger-subtle text-danger-emphasis mb-3" role="alert">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div className="d-flex align-items-center">
                                            <i className="bi bi-exclamation-triangle-fill me-2"></i>
                                            <span>{error}</span>
                                        </div>
                                        <button 
                                            type="button" 
                                            className="btn-close" 
                                            onClick={() => setError(null)}
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                </div>
                            )}

                            {/* Search and Filter */}
                            <div className="row mb-4">
                                <div className="col-md-6">
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search templates..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                                <div className="col-md-3">
                                    <select
                                        className="form-select"
                                        value={filterCategory}
                                        onChange={(e) => setFilterCategory(e.target.value)}
                                    >
                                        <option value="all">All Categories</option>
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                                <div className="col-md-3">
                                    <select
                                        className="form-select"
                                        value={activeTab}
                                        onChange={(e) => setActiveTab(e.target.value)}
                                    >
                                        <option value="all">All Templates</option>
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                            </div>

                            {/* Templates List */}
                            {loading ? (
                                <div className="text-center py-5">
                                    <div className="spinner-border text-primary" role="status">
                                        <span className="visually-hidden">Loading...</span>
                                    </div>
                                    <p className="mt-2 text-muted">Loading templates...</p>
                                </div>
                            ) : error ? (
                                <div className="alert alert-danger-subtle border-danger-subtle text-danger-emphasis" role="alert">
                                    <div className="d-flex align-items-center">
                                        <i className="bi bi-exclamation-triangle-fill me-2"></i>
                                        <div>
                                            <strong>Error loading templates:</strong>
                                            <div className="mt-1">{error}</div>
                                            <button 
                                                className="btn btn-sm btn-outline-danger mt-2"
                                                onClick={fetchTemplates}
                                            >
                                                Try Again
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ) : filteredTemplates.length === 0 ? (
                                <div className="text-center py-5">
                                    <p className="text-muted">No templates found</p>
                                </div>
                            ) : (
                                <div className="row">
                                    {filteredTemplates.map((template) => (
                                        <div key={template.id} className="col-md-6 col-lg-4 mb-4">
                                            <div className="card h-100 border-0 shadow-sm">
                                                <div className="card-header bg-light border-bottom">
                                                    <div className="d-flex justify-content-between align-items-start">
                                                        <div>
                                                            <h6 className="mb-1 text-dark">{template.title}</h6>
                                                            <span 
                                                                className="badge"
                                                                style={{ 
                                                                    backgroundColor: getCategoryColor(template.category),
                                                                    color: 'white'
                                                                }}
                                                            >
                                                                {template.category}
                                                            </span>
                                                        </div>
                                                    </div>
                        </div>
                        <div className="card-body">
                                                    <p className="card-text text-muted small">
                                                        {template.description.length > 100 
                                                            ? template.description.substring(0, 100) + '...'
                                                            : template.description
                                                        }
                                                    </p>
                                                    <div className="mb-2">
                                                        <small className="text-muted">
                                                            Created: {formatDate(template.created_at)}
                                                        </small>
                                                    </div>
                                                    <div className="mb-2">
                                                        <small className="text-muted">
                                                            Type: {
                                                                template.content_type === 'url' ? 'Web Content' :
                                                                template.content_type === 'excel' ? 'Excel Data Analysis' :
                                                                'File Upload'
                                                            }
                                                        </small>
                                                    </div>
                                                    {template.content_type === 'excel' && template.metadata && (
                                                        <div className="mb-2">
                                                            <small className="text-info">
                                                                Rows: {template.metadata.excel_rows || 'N/A'} | 
                                                                Tickets: {template.metadata.jira_tickets || 'N/A'}
                                                            </small>
                                                        </div>
                                                    )}
                                                    {template.ai_copilot_prompt && (
                                                        <div className="mb-2">
                                                            <small className="text-success">
                                                                {template.content_type === 'excel' ? 'Root Cause Explorer Ready' : 'AI Copilot Ready'}
                                                            </small>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="card-footer bg-white border-top">
                                                    <div className="btn-group w-100" role="group">
                                                        <button 
                                                            className="btn btn-outline-primary btn-sm"
                                                            onClick={() => handleViewTemplate(template)}
                                                        >
                                                            View
                                                        </button>
                                                        {template.content_type === 'excel' ? (
                                                            <button 
                                                                className="btn btn-outline-info btn-sm"
                                                                onClick={() => handleViewTemplate(template)}
                                                                title="Root Cause Analysis"
                                                            >
                                                                Analyze
                                                            </button>
                                                        ) : (
                                                            <button 
                                                                className="btn btn-outline-success btn-sm"
                                                                onClick={() => handleDownloadTemplate(template.id, template.title)}
                                                            >
                                                                Download MD
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Add Template Modal */}
            {showAddModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add New Template</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => setShowAddModal(false)}
                                ></button>
                            </div>
                            <div className="modal-body">
                                <div className="mb-3">
                                    <label className="form-label">Template Title</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={newTemplate.title}
                                        onChange={(e) => setNewTemplate({...newTemplate, title: e.target.value})}
                                        placeholder="Enter template title"
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Description</label>
                                    <textarea
                                        className="form-control"
                                        rows="3"
                                        value={newTemplate.description}
                                        onChange={(e) => setNewTemplate({...newTemplate, description: e.target.value})}
                                        placeholder="Enter template description"
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Category</label>
                                    <select
                                        className="form-select"
                                        value={newTemplate.category}
                                        onChange={(e) => setNewTemplate({...newTemplate, category: e.target.value})}
                                    >
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Content Source</label>
                                    <select
                                        className="form-select"
                                        value={newTemplate.content_type}
                                        onChange={(e) => setNewTemplate({...newTemplate, content_type: e.target.value})}
                                    >
                                        <option value="url">Web Page URL</option>
                                        <option value="file">File Upload</option>
                                    </select>
                                </div>
                                {newTemplate.content_type === 'url' ? (
                                    <div className="mb-3">
                                        <label className="form-label">Web Page URL</label>
                                        <input
                                            type="url"
                                            className="form-control"
                                            value={newTemplate.content}
                                            onChange={(e) => setNewTemplate({...newTemplate, content: e.target.value})}
                                            placeholder="https://example.com/security-issue"
                                        />
                                    </div>
                                ) : (
                                    <div className="mb-3">
                                        <label className="form-label">Upload File</label>
                                        <input
                                            type="file"
                                            className="form-control"
                                            onChange={(e) => setNewTemplate({...newTemplate, file: e.target.files[0]})}
                                            accept=".txt,.md,.pdf,.doc,.docx,.xlsx,.xls"
                                        />
                                        <div className="form-text">
                                            <strong>For Jira Data Analysis:</strong> Upload Excel files with columns: Jira ID, Jira Title, Jira Comments
                                        </div>
                                        <div className="form-text">
                                            <strong>Supported formats:</strong> .xlsx, .xls, .txt, .md, .pdf, .doc, .docx
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => setShowAddModal(false)}
                                >
                                    Cancel
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-primary"
                                    onClick={handleAddTemplate}
                                >
                                    Add Template
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* View Template Modal */}
            {showViewModal && selectedTemplate && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedTemplate.title}</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => setShowViewModal(false)}
                                ></button>
                            </div>
                            <div className="modal-body">
                                <div className="row mb-3">
                                    <div className="col-md-6">
                                        <strong>Category:</strong> 
                                        <span 
                                            className="badge ms-2"
                                            style={{ 
                                                backgroundColor: getCategoryColor(selectedTemplate.category),
                                                color: 'white'
                                            }}
                                        >
                                            {selectedTemplate.category}
                                        </span>
                                    </div>
                                    <div className="col-md-6">
                                        <strong>Created:</strong> {formatDate(selectedTemplate.created_at)}
                                    </div>
                                </div>
                                <div className="mb-3">
                                    <strong>Description:</strong>
                                    <p className="mt-1">{selectedTemplate.description}</p>
                                </div>
                                {selectedTemplate.ai_copilot_prompt && (
                                    <div className="mb-3">
                                        <strong>AI Copilot Prompt:</strong>
                                        <pre className="bg-light p-3 rounded mt-2" style={{ fontSize: '0.9rem' }}>
                                            {selectedTemplate.ai_copilot_prompt}
                                        </pre>
                                    </div>
                                )}
                                {selectedTemplate.remediation_template && (
                                    <div className="mb-3">
                                        <strong>Remediation Template:</strong>
                                        <pre className="bg-light p-3 rounded mt-2" style={{ fontSize: '0.9rem' }}>
                                            {selectedTemplate.remediation_template}
                                        </pre>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => setShowViewModal(false)}
                                >
                                    Close
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-primary"
                                    onClick={() => {
                                        navigator.clipboard.writeText(selectedTemplate.ai_copilot_prompt || selectedTemplate.remediation_template);
                                        alert('Template copied to clipboard!');
                                    }}
                                >
                                    Copy to Clipboard
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-success"
                                    onClick={() => handleDownloadTemplate(selectedTemplate.id, selectedTemplate.title)}
                                >
                                    Download Markdown
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default KnowledgeBase;
