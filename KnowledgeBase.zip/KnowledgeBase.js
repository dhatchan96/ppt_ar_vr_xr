import React, { useState, useEffect } from 'react';
import API from '../api';
import { 
    getAitData,
    getSpkData, 
    getRepoData,
    getAITName, 
    getSPKName, 
    getRepoName,
    initializeDropdownData
} from '../config/dropdownData';

const KnowledgeBase = () => {
    const [templates, setTemplates] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [activeTab, setActiveTab] = useState('all');
    const [mainTab, setMainTab] = useState('templates'); // 'templates', 'usage', or 'comparisons'
    const [showAddModal, setShowAddModal] = useState(false);
    const [newTemplate, setNewTemplate] = useState({
        title: '',
        description: '',
        category: 'application',
        content_type: 'url',
        content: '',
        file: null
    });
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [showViewModal, setShowViewModal] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCategory, setFilterCategory] = useState('all');
    
    // Usage tracking state
    const [usageStats, setUsageStats] = useState(null);
    const [usageLoading, setUsageLoading] = useState(false);
    const [usageFilter, setUsageFilter] = useState('all'); // 'all', 'username', 'template'
    const [usageSearchTerm, setUsageSearchTerm] = useState('');
    const [selectedUsername, setSelectedUsername] = useState('');
    const [selectedTemplateForUsage, setSelectedTemplateForUsage] = useState('');
    
    // Python Migration state
    const [showPythonMigrationModal, setShowPythonMigrationModal] = useState(false);
    const [pythonMigrationAIT, setPythonMigrationAIT] = useState('');
    const [pythonMigrationSPK, setPythonMigrationSPK] = useState('');
    const [pythonMigrationRepo, setPythonMigrationRepo] = useState('');
    const [pythonMigrationRepoUrl, setPythonMigrationRepoUrl] = useState('');
    const [scanningPackages, setScanningPackages] = useState(false);
    
    // File Comparison state
    const [showFileCompareModal, setShowFileCompareModal] = useState(false);
    const [fileCompareAIT, setFileCompareAIT] = useState('');
    const [fileCompareSPK, setFileCompareSPK] = useState('');
    const [fileCompareRepo, setFileCompareRepo] = useState('');
    const [originalZipFile, setOriginalZipFile] = useState(null);
    const [modifiedZipFile, setModifiedZipFile] = useState(null);
    const [comparingFiles, setComparingFiles] = useState(false);
    const [comparisonResult, setComparisonResult] = useState(null);
    const [comparisonHistory, setComparisonHistory] = useState([]);
    const [loadingComparisonHistory, setLoadingComparisonHistory] = useState(false);
    const [selectedComparison, setSelectedComparison] = useState(null);
    const [showComparisonDetails, setShowComparisonDetails] = useState(false);

    useEffect(() => {
        fetchTemplates();
        if (mainTab === 'usage') {
            fetchUsageStats();
        } else if (mainTab === 'comparisons') {
            fetchComparisonHistory();
        }
        // Initialize dropdown data when component mounts
        initializeDropdownData();
    }, [mainTab]);

    // Fetch usage stats when filter changes
    useEffect(() => {
        if (mainTab === 'usage') {
            fetchUsageStats();
        }
    }, [usageFilter, selectedUsername, selectedTemplateForUsage]);

    // Auto-dismiss success messages after 5 seconds
    useEffect(() => {
        if (success) {
            const timer = setTimeout(() => {
                setSuccess(null);
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [success]);

    const fetchTemplates = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await API.get('/api/knowledge-base/templates');
            if (response.data && response.data.success) {
                setTemplates(response.data.templates || []);
            } else {
                setError(response.data?.error || 'Failed to fetch templates');
            }
        } catch (error) {
            console.error('Error fetching templates:', error);
            setError('Failed to load templates. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const handleAddTemplate = async () => {
        try {
            setError(null);
            setSuccess(null);
            const formData = new FormData();
            formData.append('title', newTemplate.title);
            formData.append('description', newTemplate.description);
            formData.append('category', newTemplate.category);
            formData.append('content_type', newTemplate.content_type);
            
            if (newTemplate.content_type === 'url') {
                formData.append('content', newTemplate.content);
            } else if (newTemplate.file) {
                formData.append('file', newTemplate.file);
            }

            const response = await API.post('/api/knowledge-base/templates', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.data && response.data.success) {
                setShowAddModal(false);
                setNewTemplate({
                    title: '',
                    description: '',
                    category: 'application',
                    content_type: 'url',
                    content: '',
                    file: null
                });
                fetchTemplates();
                setSuccess('Template added successfully!');
                setShowAddModal(false);
            }
        } catch (error) {
            console.error('Error adding template:', error);
            setError('Error adding template: ' + (error.response?.data?.error || error.message));
        }
    };

    const handleDownloadTemplate = async (templateId, templateName) => {
        try {
            const response = await API.get(`/api/knowledge-base/templates/${templateId}/download`, {
                responseType: 'blob'
            });
            
            const url = window.URL.createObjectURL(new Blob([response.data], { type: 'text/markdown' }));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `${templateName.replace(/\s+/g, '_')}_remediation_template.md`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
            
            // Track download usage
            try {
                const username = localStorage.getItem('username') || 
                                localStorage.getItem('user') || 
                                'web_user';
                await API.post('/api/knowledge-base/track-usage', {
                    template_id: templateId,
                    username: username,
                    template_title: templateName,
                    usage_type: 'downloaded',
                    metadata: {
                        action: 'download',
                        format: 'markdown',
                        timestamp: new Date().toISOString()
                    },
                    source: 'web_app'
                });
                console.log(`Template download tracked: ${templateName} by ${username}`);
            } catch (trackError) {
                console.error('Failed to track template download:', trackError);
                // Don't show error to user, just log it
            }
        } catch (error) {
            console.error('Error downloading template:', error);
            setError('Error downloading template: ' + (error.response?.data?.error || error.message));
        }
    };

    const handleViewTemplate = async (template) => {
        setSelectedTemplate(template);
        setShowViewModal(true);
        
        // Track view usage
        try {
            const username = localStorage.getItem('username') || 
                            localStorage.getItem('user') || 
                            'web_user';
            await API.post('/api/knowledge-base/track-usage', {
                template_id: template.id,
                username: username,
                template_title: template.title,
                usage_type: 'viewed',
                metadata: {
                    action: 'view',
                    category: template.category,
                    content_type: template.content_type,
                    timestamp: new Date().toISOString()
                },
                source: 'web_app'
            });
            console.log(`Template view tracked: ${template.title} by ${username}`);
        } catch (trackError) {
            console.error('Failed to track template view:', trackError);
            // Don't show error to user, just log it
        }
    };

    const filteredTemplates = templates.filter(template => {
        const matchesSearch = template.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            template.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = filterCategory === 'all' || template.category === filterCategory;
        const matchesTab = activeTab === 'all' || template.category === activeTab;
        
        return matchesSearch && matchesCategory && matchesTab;
    });

    const getCategoryColor = (category) => {
        const colors = {
            'application': '#007bff',
            'infrastructure': '#28a745',
            'security': '#dc3545',
            'network': '#ffc107',
            'database': '#6f42c1',
            'data-analysis': '#17a2b8',
            'migration': '#fd7e14'
        };
        return colors[category] || '#6c757d';
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const fetchUsageStats = async () => {
        try {
            setUsageLoading(true);
            setError(null);
            
            let url = '/api/knowledge-base/usage-stats';
            const params = new URLSearchParams();
            
            if (usageFilter === 'username' && selectedUsername) {
                params.append('username', selectedUsername);
            } else if (usageFilter === 'template' && selectedTemplateForUsage) {
                params.append('template_id', selectedTemplateForUsage);
            }
            
            if (params.toString()) {
                url += '?' + params.toString();
            }
            
            const response = await API.get(url);
            if (response.data && response.data.success) {
                setUsageStats(response.data.stats);
            } else {
                setError(response.data?.error || 'Failed to fetch usage stats');
            }
        } catch (error) {
            console.error('Error fetching usage stats:', error);
            setError('Failed to load usage statistics. Please try again.');
        } finally {
            setUsageLoading(false);
        }
    };

    // Get unique usernames and templates for filters
    const getUniqueUsernames = () => {
        if (!usageStats?.usage_records) return [];
        const usernames = new Set();
        usageStats.usage_records.forEach(record => {
            if (record.username) usernames.add(record.username);
        });
        return Array.from(usernames).sort();
    };

    const getUniqueTemplates = () => {
        if (!usageStats?.usage_records) return [];
        const templateMap = new Map();
        usageStats.usage_records.forEach(record => {
            if (record.template_id && record.template_title) {
                templateMap.set(record.template_id, record.template_title);
            }
        });
        return Array.from(templateMap.entries()).map(([id, title]) => ({ id, title }));
    };

    // Filter usage records
    const filteredUsageRecords = () => {
        if (!usageStats?.usage_records) return [];
        
        let filtered = usageStats.usage_records;
        
        // Apply search filter
        if (usageSearchTerm) {
            const searchLower = usageSearchTerm.toLowerCase();
            filtered = filtered.filter(record => 
                record.template_title?.toLowerCase().includes(searchLower) ||
                record.username?.toLowerCase().includes(searchLower) ||
                record.template_id?.toLowerCase().includes(searchLower)
            );
        }
        
        return filtered;
    };

    // Calculate statistics
    const calculateUsageStats = () => {
        if (!usageStats?.usage_records) {
            return {
                totalUsage: 0,
                uniqueUsers: 0,
                uniqueTemplates: 0,
                mostUsedTemplate: null,
                mostActiveUser: null
            };
        }
        
        const records = usageStats.usage_records;
        const uniqueUsers = new Set(records.map(r => r.username)).size;
        const uniqueTemplates = new Set(records.map(r => r.template_id)).size;
        
        // Most used template
        const templateCounts = {};
        records.forEach(r => {
            if (r.template_id) {
                templateCounts[r.template_id] = (templateCounts[r.template_id] || 0) + 1;
            }
        });
        const mostUsedTemplateId = Object.keys(templateCounts).reduce((a, b) => 
            templateCounts[a] > templateCounts[b] ? a : b, null
        );
        const mostUsedTemplate = mostUsedTemplateId ? records.find(r => r.template_id === mostUsedTemplateId) : null;
        
        // Most active user
        const userCounts = {};
        records.forEach(r => {
            if (r.username) {
                userCounts[r.username] = (userCounts[r.username] || 0) + 1;
            }
        });
        const mostActiveUsername = Object.keys(userCounts).reduce((a, b) => 
            userCounts[a] > userCounts[b] ? a : b, null
        );
        
        return {
            totalUsage: records.length,
            uniqueUsers,
            uniqueTemplates,
            mostUsedTemplate: mostUsedTemplate ? {
                id: mostUsedTemplate.template_id,
                title: mostUsedTemplate.template_title,
                count: templateCounts[mostUsedTemplateId]
            } : null,
            mostActiveUser: mostActiveUsername ? {
                username: mostActiveUsername,
                count: userCounts[mostActiveUsername]
            } : null
        };
    };

    // File Comparison Functions
    const fetchComparisonHistory = async () => {
        try {
            setLoadingComparisonHistory(true);
            setError(null);
            const response = await API.get('/api/knowledge-base/python-migration/compare-history');
            if (response.data && response.data.success) {
                setComparisonHistory(response.data.comparisons || []);
            } else {
                setError(response.data?.error || 'Failed to fetch comparison history');
            }
        } catch (error) {
            console.error('Error fetching comparison history:', error);
            setError('Failed to load comparison history. Please try again.');
        } finally {
            setLoadingComparisonHistory(false);
        }
    };

    const handleFileCompare = async () => {
        if (!originalZipFile || !modifiedZipFile) {
            alert('Please upload both original and modified ZIP files');
            return;
        }
        // AIT, SPK, and Repository are optional for file comparison

        try {
            setComparingFiles(true);
            setError(null);
            const formData = new FormData();
            formData.append('original_zip', originalZipFile);
            formData.append('modified_zip', modifiedZipFile);
            formData.append('ait_tag', fileCompareAIT);
            formData.append('spk_tag', fileCompareSPK);
            formData.append('repo_name', fileCompareRepo);
            formData.append('comparison_name', `Comparison_${new Date().toISOString().replace(/[:.]/g, '-')}`);

            const response = await API.post('/api/knowledge-base/python-migration/compare-files', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.data && response.data.success) {
                setComparisonResult(response.data);
                setSuccess('File comparison completed successfully!');
                // Refresh comparison history if on comparisons tab
                if (mainTab === 'comparisons') {
                    fetchComparisonHistory();
                }
                // Close modal after showing result
                setTimeout(() => {
                    setShowFileCompareModal(false);
                    setOriginalZipFile(null);
                    setModifiedZipFile(null);
                    setComparisonResult(null);
                }, 3000);
            } else {
                setError(response.data?.error || 'Failed to compare files');
            }
        } catch (err) {
            console.error('Error comparing files:', err);
            setError(err.response?.data?.error || 'Failed to compare files');
        } finally {
            setComparingFiles(false);
        }
    };

    const handleViewComparisonDetails = async (comparisonId) => {
        try {
            const response = await API.get(`/api/knowledge-base/python-migration/compare-details/${comparisonId}`);
            if (response.data && response.data.success) {
                setSelectedComparison(response.data.comparison);
                setShowComparisonDetails(true);
            } else {
                setError(response.data?.error || 'Failed to fetch comparison details');
            }
        } catch (err) {
            console.error('Error fetching comparison details:', err);
            setError('Failed to load comparison details');
        }
    };

    // Prepare diff lines for side-by-side view
    const prepareSideBySideDiff = (diffLines) => {
        if (!diffLines || !Array.isArray(diffLines)) return { left: [], right: [] };
        
        const leftLines = [];
        const rightLines = [];
        let leftLineNum = 0;
        let rightLineNum = 0;
        let i = 0;
        
        while (i < diffLines.length) {
            const line = diffLines[i];
            
            if (line.type === 'context') {
                // Context line - show on both sides
                leftLineNum++;
                rightLineNum++;
                leftLines.push({
                    ...line,
                    line_number: leftLineNum,
                    pair_index: leftLines.length
                });
                rightLines.push({
                    ...line,
                    line_number: rightLineNum,
                    pair_index: rightLines.length
                });
                i++;
            } else if (line.type === 'removed') {
                // Check if next line is 'added' (replacement)
                if (i + 1 < diffLines.length && diffLines[i + 1].type === 'added') {
                    // Replacement: show removed and added side by side
                    leftLineNum++;
                    rightLineNum++;
                    leftLines.push({
                        ...line,
                        line_number: leftLineNum,
                        pair_index: leftLines.length
                    });
                    rightLines.push({
                        ...diffLines[i + 1],
                        line_number: rightLineNum,
                        pair_index: rightLines.length
                    });
                    i += 2;
                } else {
                    // Just removed - show on left only
                    leftLineNum++;
                    leftLines.push({
                        ...line,
                        line_number: leftLineNum,
                        pair_index: leftLines.length
                    });
                    rightLines.push({
                        type: 'empty',
                        line_number: null,
                        content: '',
                        pair_index: rightLines.length
                    });
                    i++;
                }
            } else if (line.type === 'added') {
                // Just added - show on right only
                rightLineNum++;
                leftLines.push({
                    type: 'empty',
                    line_number: null,
                    content: '',
                    pair_index: leftLines.length
                });
                rightLines.push({
                    ...line,
                    line_number: rightLineNum,
                    pair_index: rightLines.length
                });
                i++;
            } else {
                i++;
            }
        }
        
        // Ensure both arrays have the same length
        while (leftLines.length < rightLines.length) {
            leftLines.push({
                type: 'empty',
                line_number: null,
                content: '',
                pair_index: leftLines.length
            });
        }
        while (rightLines.length < leftLines.length) {
            rightLines.push({
                type: 'empty',
                line_number: null,
                content: '',
                pair_index: rightLines.length
            });
        }
        
        return { left: leftLines, right: rightLines };
    };

    // Render side-by-side diff
    const renderSideBySideDiff = (diffLines) => {
        const { left, right } = prepareSideBySideDiff(diffLines);
        const maxLines = Math.max(left.length, right.length);
        
        return (
            <div className="row g-0">
                <div className="col-6 border-end">
                    <div className="bg-light p-2 text-center fw-bold border-bottom">Original</div>
                    <div style={{ maxHeight: '600px', overflowY: 'auto', fontFamily: 'monospace', fontSize: '0.85rem' }}>
                        {left.map((line, idx) => {
                            const bgClass = line.type === 'removed' ? 'bg-danger bg-opacity-25' : 
                                          line.type === 'empty' ? '' : '';
                            const textClass = line.type === 'removed' ? 'text-danger' : 'text-muted';
                            
                            return (
                                <div key={idx} className={`d-flex ${bgClass} ${textClass}`} style={{ minHeight: '20px' }}>
                                    <span className="text-muted me-2" style={{ width: '50px', textAlign: 'right', flexShrink: 0 }}>
                                        {line.line_number || ''}
                                    </span>
                                    <span className="me-2" style={{ width: '20px', flexShrink: 0 }}>
                                        {line.type === 'removed' ? '-' : ' '}
                                    </span>
                                    <span style={{ flex: 1, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                                        {line.content || ' '}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
                <div className="col-6">
                    <div className="bg-light p-2 text-center fw-bold border-bottom">Modified</div>
                    <div style={{ maxHeight: '600px', overflowY: 'auto', fontFamily: 'monospace', fontSize: '0.85rem' }}>
                        {right.map((line, idx) => {
                            const bgClass = line.type === 'added' ? 'bg-success bg-opacity-25' : 
                                          line.type === 'empty' ? '' : '';
                            const textClass = line.type === 'added' ? 'text-success' : 'text-muted';
                            
                            return (
                                <div key={idx} className={`d-flex ${bgClass} ${textClass}`} style={{ minHeight: '20px' }}>
                                    <span className="text-muted me-2" style={{ width: '50px', textAlign: 'right', flexShrink: 0 }}>
                                        {line.line_number || ''}
                                    </span>
                                    <span className="me-2" style={{ width: '20px', flexShrink: 0 }}>
                                        {line.type === 'added' ? '+' : ' '}
                                    </span>
                                    <span style={{ flex: 1, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                                        {line.content || ' '}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-12">
                    <div className="card shadow-sm">
                        <div className="card-header bg-white border-bottom">
                            <div className="row align-items-center">
                                <div className="col-md-6">
                                    <h4 className="mb-0 text-dark">Knowledge Base</h4>
                                    <p className="text-muted mb-0">Remediation templates and security guidance</p>
                                </div>
                                <div className="col-md-6 text-end">
                                    <button 
                                        className="btn btn-primary"
                                        onClick={() => {
                                            setShowAddModal(true);
                                            setError(null);
                                            setSuccess(null);
                                        }}
                                    >
                                        Add New Template
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="card-body">
                            {/* Tab Navigation */}
                            <ul className="nav nav-tabs mb-4" role="tablist">
                                <li className="nav-item" role="presentation">
                                    <button
                                        className={`nav-link ${mainTab === 'templates' ? 'active' : ''}`}
                                        onClick={() => setMainTab('templates')}
                                        type="button"
                                    >
                                        <i className="bi bi-file-text me-2"></i>
                                        Templates
                                    </button>
                                </li>
                                <li className="nav-item" role="presentation">
                                    <button
                                        className={`nav-link ${mainTab === 'usage' ? 'active' : ''}`}
                                        onClick={() => setMainTab('usage')}
                                        type="button"
                                    >
                                        <i className="bi bi-bar-chart me-2"></i>
                                        Usage Tracking
                                    </button>
                                </li>
                                <li className="nav-item" role="presentation">
                                    <button
                                        className={`nav-link ${mainTab === 'comparisons' ? 'active' : ''}`}
                                        onClick={() => setMainTab('comparisons')}
                                        type="button"
                                    >
                                        <i className="bi bi-file-diff me-2"></i>
                                        File Comparisons
                                    </button>
                                </li>
                            </ul>

                            {/* Success Message */}
                            {success && (
                                <div className="alert alert-success-subtle border-success-subtle text-success-emphasis mb-3" role="alert">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div className="d-flex align-items-center">
                                            <i className="bi bi-check-circle-fill me-2"></i>
                                            <span>{success}</span>
                                        </div>
                                        <button 
                                            type="button" 
                                            className="btn-close" 
                                            onClick={() => setSuccess(null)}
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                </div>
                            )}
                            
                            {/* Error Message */}
                            {error && (
                                <div className="alert alert-danger-subtle border-danger-subtle text-danger-emphasis mb-3" role="alert">
                                    <div className="d-flex align-items-center justify-content-between">
                                        <div className="d-flex align-items-center">
                                            <i className="bi bi-exclamation-triangle-fill me-2"></i>
                                            <span>{error}</span>
                                        </div>
                                        <button 
                                            type="button" 
                                            className="btn-close" 
                                            onClick={() => setError(null)}
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                </div>
                            )}

                            {/* Templates Tab Content */}
                            {mainTab === 'templates' && (
                                <>
                            {/* Search and Filter */}
                            <div className="row mb-4">
                                <div className="col-md-6">
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search templates..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                                <div className="col-md-3">
                                    <select
                                        className="form-select"
                                        value={filterCategory}
                                        onChange={(e) => setFilterCategory(e.target.value)}
                                    >
                                        <option value="all">All Categories</option>
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                                <div className="col-md-3">
                                    <select
                                        className="form-select"
                                        value={activeTab}
                                        onChange={(e) => setActiveTab(e.target.value)}
                                    >
                                        <option value="all">All Templates</option>
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                            </div>

                            {/* Templates List */}
                            {loading ? (
                                <div className="text-center py-5">
                                    <div className="spinner-border text-primary" role="status">
                                        <span className="visually-hidden">Loading...</span>
                                    </div>
                                    <p className="mt-2 text-muted">Loading templates...</p>
                                </div>
                            ) : error ? (
                                <div className="alert alert-danger-subtle border-danger-subtle text-danger-emphasis" role="alert">
                                    <div className="d-flex align-items-center">
                                        <i className="bi bi-exclamation-triangle-fill me-2"></i>
                                        <div>
                                            <strong>Error loading templates:</strong>
                                            <div className="mt-1">{error}</div>
                                            <button 
                                                className="btn btn-sm btn-outline-danger mt-2"
                                                onClick={fetchTemplates}
                                            >
                                                Try Again
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ) : filteredTemplates.length === 0 ? (
                                <div className="text-center py-5">
                                    <p className="text-muted">No templates found</p>
                                </div>
                            ) : (
                                <div className="row">
                                    {filteredTemplates.map((template) => (
                                        <div key={template.id} className="col-md-6 col-lg-4 mb-4">
                                            <div className="card h-100 border-0 shadow-sm">
                                                <div className="card-header bg-light border-bottom">
                                                    <div className="d-flex justify-content-between align-items-start">
                                                        <div>
                                                            <h6 className="mb-1 text-dark">{template.title}</h6>
                                                            <span 
                                                                className="badge"
                                                                style={{ 
                                                                    backgroundColor: getCategoryColor(template.category),
                                                                    color: 'white'
                                                                }}
                                                            >
                                                                {template.category}
                                                            </span>
                                                        </div>
                                                    </div>
                        </div>
                        <div className="card-body">
                                                    <p className="card-text text-muted small">
                                                        {template.description.length > 100 
                                                            ? template.description.substring(0, 100) + '...'
                                                            : template.description
                                                        }
                                                    </p>
                                                    <div className="mb-2">
                                                        <small className="text-muted">
                                                            Created: {formatDate(template.created_at)}
                                                        </small>
                                                    </div>
                                                    <div className="mb-2">
                                                        <small className="text-muted">
                                                            Type: {
                                                                template.content_type === 'url' ? 'Web Content' :
                                                                template.content_type === 'excel' ? 'Excel Data Analysis' :
                                                                'File Upload'
                                                            }
                                                        </small>
                                                    </div>
                                                    {template.content_type === 'excel' && template.metadata && (
                                                        <div className="mb-2">
                                                            <small className="text-info">
                                                                Rows: {template.metadata.excel_rows || 'N/A'} | 
                                                                Tickets: {template.metadata.jira_tickets || 'N/A'}
                                                            </small>
                                                        </div>
                                                    )}
                                                    {template.ai_copilot_prompt && (
                                                        <div className="mb-2">
                                                            <small className="text-success">
                                                                {template.content_type === 'excel' ? 'Root Cause Explorer Ready' : 'AI Copilot Ready'}
                                                            </small>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="card-footer bg-white border-top">
                                                    <div className="btn-group w-100" role="group">
                                                        {template.title !== 'Python Migration Assistant' && (
                                                            <button 
                                                                className="btn btn-outline-primary btn-sm"
                                                                onClick={() => handleViewTemplate(template)}
                                                            >
                                                                View
                                                            </button>
                                                        )}
                                                        {template.title === 'Python Migration Assistant' ? (
                                                            <button 
                                                                className="btn btn-outline-primary btn-sm"
                                                                onClick={() => {
                                                                    setShowPythonMigrationModal(true);
                                                                    setSelectedTemplate(template);
                                                                }}
                                                                title="Python Migration with Package Scanning"
                                                            >
                                                                Migrate
                                                            </button>
                                                        ) : template.content_type === 'excel' ? (
                                                            <button 
                                                                className="btn btn-outline-info btn-sm"
                                                                onClick={() => handleViewTemplate(template)}
                                                                title="Root Cause Analysis"
                                                            >
                                                                Analyze
                                                            </button>
                                                        ) : (
                                                            <button 
                                                                className="btn btn-outline-success btn-sm"
                                                                onClick={() => handleDownloadTemplate(template.id, template.title)}
                                                            >
                                                                Download MD
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                            </>
                            )}

                            {/* Usage Tracking Tab Content */}
                            {mainTab === 'usage' && (
                                <>
                                    {/* Usage Statistics Cards */}
                                    {(() => {
                                        const stats = calculateUsageStats();
                                        return (
                                            <div className="row mb-4">
                                                <div className="col-md-3">
                                                    <div className="card bg-primary text-white">
                                                        <div className="card-body">
                                                            <h5 className="card-title">Total Usage</h5>
                                                            <h2>{stats.totalUsage}</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="card bg-success text-white">
                                                        <div className="card-body">
                                                            <h5 className="card-title">Active Users</h5>
                                                            <h2>{stats.uniqueUsers}</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="card bg-info text-white">
                                                        <div className="card-body">
                                                            <h5 className="card-title">Templates Used</h5>
                                                            <h2>{stats.uniqueTemplates}</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="card bg-warning text-white">
                                                        <div className="card-body">
                                                            <h5 className="card-title">Most Active User</h5>
                                                            <h6>{stats.mostActiveUser?.username || 'N/A'}</h6>
                                                            <small>{stats.mostActiveUser?.count || 0} uses</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })()}

                                    {/* Usage Filters */}
                                    <div className="row mb-4">
                                        <div className="col-md-4">
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Search by template name, username, or ID..."
                                                value={usageSearchTerm}
                                                onChange={(e) => setUsageSearchTerm(e.target.value)}
                                            />
                                        </div>
                                        <div className="col-md-3">
                                            <select
                                                className="form-select"
                                                value={usageFilter}
                                                onChange={(e) => setUsageFilter(e.target.value)}
                                            >
                                                <option value="all">All Usage</option>
                                                <option value="username">Filter by User</option>
                                                <option value="template">Filter by Template</option>
                                            </select>
                                        </div>
                                        {usageFilter === 'username' && (
                                            <div className="col-md-3">
                                                <select
                                                    className="form-select"
                                                    value={selectedUsername}
                                                    onChange={(e) => setSelectedUsername(e.target.value)}
                                                >
                                                    <option value="">Select User...</option>
                                                    {getUniqueUsernames().map(username => (
                                                        <option key={username} value={username}>{username}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        )}
                                        {usageFilter === 'template' && (
                                            <div className="col-md-3">
                                                <select
                                                    className="form-select"
                                                    value={selectedTemplateForUsage}
                                                    onChange={(e) => setSelectedTemplateForUsage(e.target.value)}
                                                >
                                                    <option value="">Select Template...</option>
                                                    {getUniqueTemplates().map(template => (
                                                        <option key={template.id} value={template.id}>{template.title}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        )}
                                        <div className="col-md-2">
                                            <button
                                                className="btn btn-outline-primary w-100"
                                                onClick={fetchUsageStats}
                                                disabled={usageLoading}
                                            >
                                                {usageLoading ? (
                                                    <>
                                                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                                                        Loading...
                                                    </>
                                                ) : (
                                                    <>
                                                        <i className="bi bi-arrow-clockwise me-2"></i>
                                                        Refresh
                                                    </>
                                                )}
                                            </button>
                                        </div>
                                    </div>

                                    {/* Most Used Templates */}
                                    {(() => {
                                        const stats = calculateUsageStats();
                                        if (stats.mostUsedTemplate) {
                                            return (
                                                <div className="alert alert-info mb-4">
                                                    <strong>Most Used Template:</strong> {stats.mostUsedTemplate.title} ({stats.mostUsedTemplate.count} uses)
                                                </div>
                                            );
                                        }
                                        return null;
                                    })()}

                                    {/* Usage Records Table */}
                                    {usageLoading ? (
                                        <div className="text-center py-5">
                                            <div className="spinner-border text-primary" role="status">
                                                <span className="visually-hidden">Loading...</span>
                                            </div>
                                            <p className="mt-2 text-muted">Loading usage statistics...</p>
                                        </div>
                                    ) : filteredUsageRecords().length === 0 ? (
                                        <div className="text-center py-5">
                                            <i className="bi bi-bar-chart" style={{ fontSize: '3rem', color: '#ccc' }}></i>
                                            <p className="text-muted mt-2">No usage records found</p>
                                        </div>
                                    ) : (
                                        <div className="table-responsive">
                                            <table className="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Timestamp</th>
                                                        <th>Username</th>
                                                        <th>Template Title</th>
                                                        <th>Usage Type</th>
                                                        <th>Source</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {filteredUsageRecords().map((record, index) => (
                                                        <tr key={record.id || index}>
                                                            <td>{formatDate(record.timestamp)}</td>
                                                            <td>
                                                                <span className="badge bg-primary">
                                                                    <i className="bi bi-person me-1"></i>
                                                                    {record.username || 'Unknown'}
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <strong>{record.template_title || 'N/A'}</strong>
                                                            </td>
                                                            <td>
                                                                <span className={`badge bg-${
                                                                    record.usage_type === 'used' ? 'success' :
                                                                    record.usage_type === 'viewed' ? 'info' :
                                                                    'secondary'
                                                                }`}>
                                                                    {record.usage_type || 'used'}
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <span className="badge bg-secondary">
                                                                    {record.source === 'vscode_extension' ? (
                                                                        <>
                                                                            <i className="bi bi-code-square me-1"></i>
                                                                            VSCode
                                                                        </>
                                                                    ) : (
                                                                        <>
                                                                            <i className="bi bi-browser-chrome me-1"></i>
                                                                            Web App
                                                                        </>
                                                                    )}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}
                                </>
                            )}

                            {/* File Comparisons Tab Content */}
                            {mainTab === 'comparisons' && (
                                <>
                                    <div className="d-flex justify-content-between align-items-center mb-4">
                                        <h5>File Comparison History</h5>
                                        <button
                                            className="btn btn-primary"
                                            onClick={() => {
                                                setShowFileCompareModal(true);
                                                setFileCompareAIT('');
                                                setFileCompareSPK('');
                                                setFileCompareRepo('');
                                                setOriginalZipFile(null);
                                                setModifiedZipFile(null);
                                                setComparisonResult(null);
                                            }}
                                        >
                                            <i className="bi bi-file-diff me-2"></i>
                                            New Comparison
                                        </button>
                                    </div>

                                    {loadingComparisonHistory ? (
                                        <div className="text-center py-5">
                                            <div className="spinner-border text-primary" role="status">
                                                <span className="visually-hidden">Loading...</span>
                                            </div>
                                            <p className="mt-2 text-muted">Loading comparison history...</p>
                                        </div>
                                    ) : comparisonHistory.length === 0 ? (
                                        <div className="text-center py-5">
                                            <i className="bi bi-file-diff" style={{ fontSize: '3rem', color: '#ccc' }}></i>
                                            <p className="text-muted mt-2">No file comparisons found</p>
                                            <button
                                                className="btn btn-primary mt-3"
                                                onClick={() => setShowFileCompareModal(true)}
                                            >
                                                Create First Comparison
                                            </button>
                                        </div>
                                    ) : (
                                        <div className="table-responsive">
                                            <table className="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>AIT</th>
                                                        <th>SPK</th>
                                                        <th>Repository</th>
                                                        <th>Files Compared</th>
                                                        <th>Files Changed</th>
                                                        <th>Lines Added</th>
                                                        <th>Lines Removed</th>
                                                        <th>Created</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {comparisonHistory.map((comparison) => (
                                                        <tr key={comparison.id}>
                                                            <td><strong>{comparison.comparison_name}</strong></td>
                                                            <td><span className="badge bg-info">{comparison.ait_tag || 'N/A'}</span></td>
                                                            <td><span className="badge bg-info">{comparison.spk_tag || 'N/A'}</span></td>
                                                            <td>{comparison.repo_name || 'N/A'}</td>
                                                            <td>{comparison.total_files_compared}</td>
                                                            <td><span className="badge bg-warning">{comparison.total_files_changed}</span></td>
                                                            <td><span className="badge bg-success">{comparison.total_lines_added}</span></td>
                                                            <td><span className="badge bg-danger">{comparison.total_lines_removed}</span></td>
                                                            <td>{formatDate(comparison.created_at)}</td>
                                                            <td>
                                                                <button
                                                                    className="btn btn-sm btn-primary"
                                                                    onClick={() => handleViewComparisonDetails(comparison.id)}
                                                                    title="View Details"
                                                                    style={{ minWidth: '40px' }}
                                                                >
                                                                    <i className="bi bi-eye-fill"></i> View
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Add Template Modal */}
            {showAddModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Add New Template</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => setShowAddModal(false)}
                                ></button>
                            </div>
                            <div className="modal-body">
                                <div className="mb-3">
                                    <label className="form-label">Template Title</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={newTemplate.title}
                                        onChange={(e) => setNewTemplate({...newTemplate, title: e.target.value})}
                                        placeholder="Enter template title"
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Description</label>
                                    <textarea
                                        className="form-control"
                                        rows="3"
                                        value={newTemplate.description}
                                        onChange={(e) => setNewTemplate({...newTemplate, description: e.target.value})}
                                        placeholder="Enter template description"
                                    />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Category</label>
                                    <select
                                        className="form-select"
                                        value={newTemplate.category}
                                        onChange={(e) => setNewTemplate({...newTemplate, category: e.target.value})}
                                    >
                                        <option value="application">Application</option>
                                        <option value="infrastructure">Infrastructure</option>
                                        <option value="security">Security</option>
                                        <option value="network">Network</option>
                                        <option value="database">Database</option>
                                        <option value="data-analysis">Data Analysis</option>
                                        <option value="migration">Migration</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Content Source</label>
                                    <select
                                        className="form-select"
                                        value={newTemplate.content_type}
                                        onChange={(e) => setNewTemplate({...newTemplate, content_type: e.target.value})}
                                    >
                                        <option value="url">Web Page URL</option>
                                        <option value="file">File Upload</option>
                                    </select>
                                </div>
                                {newTemplate.content_type === 'url' ? (
                                    <div className="mb-3">
                                        <label className="form-label">Web Page URL</label>
                                        <input
                                            type="url"
                                            className="form-control"
                                            value={newTemplate.content}
                                            onChange={(e) => setNewTemplate({...newTemplate, content: e.target.value})}
                                            placeholder="https://example.com/security-issue"
                                        />
                                    </div>
                                ) : (
                                    <div className="mb-3">
                                        <label className="form-label">Upload File</label>
                                        <input
                                            type="file"
                                            className="form-control"
                                            onChange={(e) => setNewTemplate({...newTemplate, file: e.target.files[0]})}
                                            accept=".txt,.md,.pdf,.doc,.docx,.xlsx,.xls"
                                        />
                                        <div className="form-text">
                                            <strong>For Jira Data Analysis:</strong> Upload Excel files with columns: Jira ID, Jira Title, Jira Comments
                                        </div>
                                        <div className="form-text">
                                            <strong>Supported formats:</strong> .xlsx, .xls, .txt, .md, .pdf, .doc, .docx
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => setShowAddModal(false)}
                                >
                                    Cancel
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-primary"
                                    onClick={handleAddTemplate}
                                >
                                    Add Template
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Python Migration Modal */}
            {showPythonMigrationModal && selectedTemplate && selectedTemplate.title === 'Python Migration Assistant' && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Python Migration Assistant - Package Migration</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => {
                                        setShowPythonMigrationModal(false);
                                        setPythonMigrationRepoUrl('');
                                        setPythonMigrationAIT('');
                                        setPythonMigrationSPK('');
                                        setPythonMigrationRepo('');
                                    }}
                                ></button>
                            </div>
                            <div className="modal-body">
                                {/* Repository Information */}
                                <div className="card mb-3">
                                    <div className="card-header">
                                        <strong>Repository Information</strong>
                                    </div>
                                    <div className="card-body">
                                        <div className="row mb-3">
                                            <div className="col-md-4">
                                                <label className="form-label">AIT</label>
                                                <select 
                                                    className="form-select" 
                                                    value={pythonMigrationAIT}
                                                    onChange={(e) => {
                                                        setPythonMigrationAIT(e.target.value);
                                                        setPythonMigrationSPK('');
                                                        setPythonMigrationRepo('');
                                                    }}
                                                >
                                                    <option value="">Select AIT</option>
                                                    {getAitData().map(ait => (
                                                        <option key={ait.value} value={ait.value}>{ait.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label">SPK</label>
                                                <select 
                                                    className="form-select" 
                                                    value={pythonMigrationSPK}
                                                    onChange={(e) => {
                                                        setPythonMigrationSPK(e.target.value);
                                                        setPythonMigrationRepo('');
                                                    }}
                                                    disabled={!pythonMigrationAIT}
                                                >
                                                    <option value="">Select SPK</option>
                                                    {pythonMigrationAIT && getSpkData(pythonMigrationAIT).map(spk => (
                                                        <option key={spk.value} value={spk.value}>{spk.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label">Repository</label>
                                                <select 
                                                    className="form-select" 
                                                    value={pythonMigrationRepo}
                                                    onChange={(e) => setPythonMigrationRepo(e.target.value)}
                                                    disabled={!pythonMigrationSPK}
                                                >
                                                    <option value="">Select Repository</option>
                                                    {pythonMigrationSPK && getRepoData(pythonMigrationSPK).map(repo => (
                                                        <option key={repo.value} value={repo.value}>{repo.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-12">
                                                <label className="form-label">Repository URL</label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    placeholder="https://github.com/owner/repo or https://bitbucket.org/owner/repo"
                                                    value={pythonMigrationRepoUrl}
                                                    onChange={(e) => setPythonMigrationRepoUrl(e.target.value)}
                                                />
                                            </div>
                                        </div>
                                        <div className="mt-3">
                                            <div className="btn-group" role="group">
                                                <button
                                                    className="btn btn-primary"
                                                    onClick={async () => {
                                                        if (!pythonMigrationRepoUrl) {
                                                            alert('Please enter repository URL');
                                                            return;
                                                        }
                                                        if (!pythonMigrationAIT || !pythonMigrationSPK || !pythonMigrationRepo) {
                                                            alert('Please select AIT, SPK, and Repository');
                                                            return;
                                                        }
                                                        try {
                                                            setScanningPackages(true);
                                                            setError(null);
                                                            const response = await API.post('/api/jobs/python-migration-scan', {
                                                                repo_url: pythonMigrationRepoUrl,
                                                                ait_tag: pythonMigrationAIT,
                                                                spk_tag: pythonMigrationSPK,
                                                                repo_name: pythonMigrationRepo
                                                            });
                                                            if (response.data.job_id) {
                                                                setSuccess(`Scan job created successfully! Job ID: ${response.data.job_id}. Check Job Monitor for progress.`);
                                                                // Close modal and redirect to job monitor or show job ID
                                                                setTimeout(() => {
                                                                    setShowPythonMigrationModal(false);
                                                                    // Optionally redirect to job monitor
                                                                    window.location.href = '/job-monitor';
                                                                }, 2000);
                                                            } else {
                                                                setError(response.data.error || 'Failed to create scan job');
                                                            }
                                                        } catch (err) {
                                                            console.error('Error creating scan job:', err);
                                                            setError(err.response?.data?.error || 'Failed to create scan job');
                                                        } finally {
                                                            setScanningPackages(false);
                                                        }
                                                    }}
                                                    disabled={scanningPackages || !pythonMigrationRepoUrl || !pythonMigrationAIT || !pythonMigrationSPK || !pythonMigrationRepo}
                                                >
                                                    {scanningPackages ? (
                                                        <>
                                                            <span className="spinner-border spinner-border-sm me-2"></span>
                                                            Creating Job...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <i className="bi bi-search me-2"></i>
                                                            Scan Repository
                                                        </>
                                                    )}
                                                </button>
                                                <button
                                                    className="btn btn-outline-primary"
                                                    onClick={() => {
                                                        setShowFileCompareModal(true);
                                                        setFileCompareAIT(pythonMigrationAIT);
                                                        setFileCompareSPK(pythonMigrationSPK);
                                                        setFileCompareRepo(pythonMigrationRepo);
                                                    }}
                                                    title="Compare File Changes"
                                                >
                                                    <i className="bi bi-file-diff me-2"></i>
                                                    Compare File Changes
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="alert alert-info mt-3">
                                    <i className="bi bi-info-circle me-2"></i>
                                    <strong>Note:</strong> After clicking "Scan Repository", a job will be created and you'll be redirected to Job Monitor. 
                                    Once the scan completes, you'll be able to view detected packages and generate migration prompts there.
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => {
                                        setShowPythonMigrationModal(false);
                                        setPythonMigrationRepoUrl('');
                                        setPythonMigrationAIT('');
                                        setPythonMigrationSPK('');
                                        setPythonMigrationRepo('');
                                    }}
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* File Comparison Modal */}
            {showFileCompareModal && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">Compare File Changes</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => {
                                        setShowFileCompareModal(false);
                                        setOriginalZipFile(null);
                                        setModifiedZipFile(null);
                                        setComparisonResult(null);
                                    }}
                                ></button>
                            </div>
                            <div className="modal-body">
                                {/* Repository Information */}
                                <div className="card mb-3">
                                    <div className="card-header">
                                        <strong>Repository Information (Optional)</strong>
                                    </div>
                                    <div className="card-body">
                                        <div className="alert alert-info mb-3">
                                            <i className="bi bi-info-circle me-2"></i>
                                            <small>Selecting AIT, SPK, and Repository is optional. These help organize and filter your comparisons.</small>
                                        </div>
                                        <div className="row mb-3">
                                            <div className="col-md-4">
                                                <label className="form-label">AIT <span className="text-muted">(Optional)</span></label>
                                                <select 
                                                    className="form-select" 
                                                    value={fileCompareAIT}
                                                    onChange={(e) => {
                                                        setFileCompareAIT(e.target.value);
                                                        setFileCompareSPK('');
                                                        setFileCompareRepo('');
                                                    }}
                                                >
                                                    <option value="">Select AIT (Optional)</option>
                                                    {getAitData().map(ait => (
                                                        <option key={ait.value} value={ait.value}>{ait.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label">SPK <span className="text-muted">(Optional)</span></label>
                                                <select 
                                                    className="form-select" 
                                                    value={fileCompareSPK}
                                                    onChange={(e) => {
                                                        setFileCompareSPK(e.target.value);
                                                        setFileCompareRepo('');
                                                    }}
                                                    disabled={!fileCompareAIT}
                                                >
                                                    <option value="">Select SPK (Optional)</option>
                                                    {fileCompareAIT && getSpkData(fileCompareAIT).map(spk => (
                                                        <option key={spk.value} value={spk.value}>{spk.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <label className="form-label">Repository <span className="text-muted">(Optional)</span></label>
                                                <select 
                                                    className="form-select" 
                                                    value={fileCompareRepo}
                                                    onChange={(e) => setFileCompareRepo(e.target.value)}
                                                    disabled={!fileCompareSPK}
                                                >
                                                    <option value="">Select Repository (Optional)</option>
                                                    {fileCompareSPK && getRepoData(fileCompareSPK).map(repo => (
                                                        <option key={repo.value} value={repo.value}>{repo.label}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* File Upload Section */}
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="card">
                                            <div className="card-header bg-light">
                                                <strong>Original Project (Left)</strong>
                                            </div>
                                            <div className="card-body">
                                                <input
                                                    type="file"
                                                    className="form-control"
                                                    accept=".zip"
                                                    onChange={(e) => setOriginalZipFile(e.target.files[0])}
                                                />
                                                {originalZipFile && (
                                                    <div className="mt-2">
                                                        <small className="text-success">
                                                            <i className="bi bi-check-circle me-1"></i>
                                                            {originalZipFile.name}
                                                        </small>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="card">
                                            <div className="card-header bg-light">
                                                <strong>Modified Project (Right)</strong>
                                            </div>
                                            <div className="card-body">
                                                <input
                                                    type="file"
                                                    className="form-control"
                                                    accept=".zip"
                                                    onChange={(e) => setModifiedZipFile(e.target.files[0])}
                                                />
                                                {modifiedZipFile && (
                                                    <div className="mt-2">
                                                        <small className="text-success">
                                                            <i className="bi bi-check-circle me-1"></i>
                                                            {modifiedZipFile.name}
                                                        </small>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Comparison Result */}
                                {comparisonResult && (
                                    <div className="card mt-3">
                                        <div className="card-header bg-success text-white">
                                            <strong>Comparison Complete</strong>
                                        </div>
                                        <div className="card-body">
                                            <div className="row mb-3">
                                                <div className="col-md-3">
                                                    <strong>Files Compared:</strong> {comparisonResult.summary.files_compared}
                                                </div>
                                                <div className="col-md-3">
                                                    <strong>Files Changed:</strong> {comparisonResult.summary.files_changed}
                                                </div>
                                                <div className="col-md-3">
                                                    <strong className="text-success">Lines Added:</strong> {comparisonResult.summary.total_lines_added}
                                                </div>
                                                <div className="col-md-3">
                                                    <strong className="text-danger">Lines Removed:</strong> {comparisonResult.summary.total_lines_removed}
                                                </div>
                                            </div>
                                            <div className="alert alert-info">
                                                Comparison saved. View it in the "File Comparisons" tab.
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => {
                                        setShowFileCompareModal(false);
                                        setOriginalZipFile(null);
                                        setModifiedZipFile(null);
                                        setComparisonResult(null);
                                    }}
                                >
                                    Close
                                </button>
                                <button
                                    type="button"
                                    className="btn btn-primary"
                                    onClick={handleFileCompare}
                                    disabled={comparingFiles || !originalZipFile || !modifiedZipFile}
                                >
                                    {comparingFiles ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2"></span>
                                            Comparing...
                                        </>
                                    ) : (
                                        <>
                                            <i className="bi bi-arrow-left-right me-2"></i>
                                            Compare
                                        </>
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Comparison Details Modal */}
            {showComparisonDetails && selectedComparison && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedComparison.comparison_name}</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => {
                                        setShowComparisonDetails(false);
                                        setSelectedComparison(null);
                                    }}
                                ></button>
                            </div>
                            <div className="modal-body">
                                {/* Summary */}
                                <div className="card mb-3">
                                    <div className="card-header">
                                        <strong>Summary</strong>
                                    </div>
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="col-md-3">
                                                <strong>Files Compared:</strong> {selectedComparison.total_files_compared}
                                            </div>
                                            <div className="col-md-3">
                                                <strong>Files Changed:</strong> {selectedComparison.total_files_changed}
                                            </div>
                                            <div className="col-md-3">
                                                <strong className="text-success">Lines Added:</strong> {selectedComparison.total_lines_added}
                                            </div>
                                            <div className="col-md-3">
                                                <strong className="text-danger">Lines Removed:</strong> {selectedComparison.total_lines_removed}
                                            </div>
                                        </div>
                                        <div className="row mt-2">
                                            <div className="col-md-4">
                                                <strong>AIT:</strong> {selectedComparison.ait_tag || 'N/A'}
                                            </div>
                                            <div className="col-md-4">
                                                <strong>SPK:</strong> {selectedComparison.spk_tag || 'N/A'}
                                            </div>
                                            <div className="col-md-4">
                                                <strong>Repository:</strong> {selectedComparison.repo_name || 'N/A'}
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* File Diffs */}
                                {selectedComparison.comparison_result && selectedComparison.comparison_result.file_diffs && (
                                    <div className="card">
                                        <div className="card-header d-flex justify-content-between align-items-center">
                                            <strong>File Differences</strong>
                                            <small className="text-muted">Side-by-Side View</small>
                                        </div>
                                        <div className="card-body p-0">
                                            <div className="accordion accordion-flush" id="fileDiffsAccordion">
                                                {Object.entries(selectedComparison.comparison_result.file_diffs).map(([filePath, diffData], idx) => (
                                                    <div key={idx} className="accordion-item">
                                                        <h2 className="accordion-header">
                                                            <button
                                                                className="accordion-button collapsed"
                                                                type="button"
                                                                data-bs-toggle="collapse"
                                                                data-bs-target={`#diff-${idx}`}
                                                                aria-expanded="false"
                                                                aria-controls={`diff-${idx}`}
                                                            >
                                                                <div className="d-flex align-items-center w-100">
                                                                    <span className="me-2 flex-grow-1 text-truncate">{filePath}</span>
                                                                    <span className={`badge ${diffData.status === 'added' ? 'bg-success' : diffData.status === 'removed' ? 'bg-danger' : 'bg-warning'} me-2`}>
                                                                        {diffData.status}
                                                                    </span>
                                                                    {diffData.status === 'modified' && (
                                                                        <>
                                                                            <span className="badge bg-success me-1">+{diffData.added_lines}</span>
                                                                            <span className="badge bg-danger">-{diffData.removed_lines}</span>
                                                                        </>
                                                                    )}
                                                                </div>
                                                            </button>
                                                        </h2>
                                                        <div 
                                                            id={`diff-${idx}`} 
                                                            className="accordion-collapse collapse" 
                                                            data-bs-parent="#fileDiffsAccordion"
                                                        >
                                                            <div className="accordion-body p-0">
                                                                <div className="border">
                                                                    {diffData.diff && diffData.diff.lines && renderSideBySideDiff(diffData.diff.lines)}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => {
                                        setShowComparisonDetails(false);
                                        setSelectedComparison(null);
                                    }}
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* View Template Modal */}
            {showViewModal && selectedTemplate && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{selectedTemplate.title}</h5>
                                <button 
                                    type="button" 
                                    className="btn-close"
                                    onClick={() => setShowViewModal(false)}
                                ></button>
                            </div>
                            <div className="modal-body">
                                <div className="row mb-3">
                                    <div className="col-md-6">
                                        <strong>Category:</strong> 
                                        <span 
                                            className="badge ms-2"
                                            style={{ 
                                                backgroundColor: getCategoryColor(selectedTemplate.category),
                                                color: 'white'
                                            }}
                                        >
                                            {selectedTemplate.category}
                                        </span>
                                    </div>
                                    <div className="col-md-6">
                                        <strong>Created:</strong> {formatDate(selectedTemplate.created_at)}
                                    </div>
                                </div>
                                <div className="mb-3">
                                    <strong>Description:</strong>
                                    <p className="mt-1">{selectedTemplate.description}</p>
                                </div>
                                {selectedTemplate.ai_copilot_prompt && (
                                    <div className="mb-3">
                                        <strong>AI Copilot Prompt:</strong>
                                        <pre className="bg-light p-3 rounded mt-2" style={{ fontSize: '0.9rem' }}>
                                            {selectedTemplate.ai_copilot_prompt}
                                        </pre>
                                    </div>
                                )}
                                {selectedTemplate.remediation_template && (
                                    <div className="mb-3">
                                        <strong>Remediation Template:</strong>
                                        <pre className="bg-light p-3 rounded mt-2" style={{ fontSize: '0.9rem' }}>
                                            {selectedTemplate.remediation_template}
                                        </pre>
                                    </div>
                                )}
                            </div>
                            <div className="modal-footer">
                                <button 
                                    type="button" 
                                    className="btn btn-secondary"
                                    onClick={() => setShowViewModal(false)}
                                >
                                    Close
                                </button>
                                <button 
                                    type="button" 
                                    className="btn btn-primary"
                                    onClick={() => {
                                        navigator.clipboard.writeText(selectedTemplate.ai_copilot_prompt || selectedTemplate.remediation_template);
                                        alert('Template copied to clipboard!');
                                    }}
                                >
                                    Copy to Clipboard
                                </button>
                                <button 
                                    type="button"
                                    className="btn btn-success"
                                    onClick={async () => {
                                        await handleDownloadTemplate(selectedTemplate.id, selectedTemplate.title);
                                    }}
                                >
                                    Download Markdown
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default KnowledgeBase;
