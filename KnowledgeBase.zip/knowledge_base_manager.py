import json
import uuid
import requests
import pandas as pd
import io
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import logging

from knowledge_base_db import KnowledgeBaseDB

logger = logging.getLogger(__name__)

@dataclass
class KnowledgeTemplate:
    id: str
    title: str
    description: str
    category: str
    content_type: str
    content: str
    ai_copilot_prompt: str
    remediation_template: str
    created_at: str
    updated_at: str
    created_by: str
    tags: List[str] = field(default_factory=list)
    severity_levels: List[str] = field(default_factory=list)
    applicable_languages: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    version: int = 1

class KnowledgeBaseManager:
    def __init__(self):
        self.db = KnowledgeBaseDB()
        self.templates = {}
        self.load_templates()
    
    def load_templates(self):
        """Load templates from database"""
        try:
            templates_data = self.db.get_all_templates()
            if not templates_data:
                logger.info("No templates found in database, creating default templates")
                self._create_default_templates()
            else:
                logger.info(f"Loaded {len(templates_data)} templates from database")
                for template_data in templates_data:
                    try:
                        template = KnowledgeTemplate(**template_data)
                        self.templates[template.id] = template
                    except Exception as e:
                        logger.error(f"Error loading template {template_data.get('id', 'unknown')}: {e}")
                # Ensure all default templates exist (add missing ones)
                self._ensure_default_templates()
        except Exception as e:
            logger.error(f"Error loading templates from database: {e}")
            self._create_default_templates()
    
    def save_template_to_db(self, template: KnowledgeTemplate):
        """Save template to database"""
        try:
            template_dict = {
                'id': template.id,
                'title': template.title,
                'description': template.description,
                'category': template.category,
                'content_type': template.content_type,
                'content': template.content,
                'ai_copilot_prompt': template.ai_copilot_prompt,
                'remediation_template': template.remediation_template,
                'created_at': template.created_at,
                'updated_at': template.updated_at,
                'created_by': template.created_by,
                'tags': json.dumps(template.tags),
                'severity_levels': json.dumps(template.severity_levels),
                'applicable_languages': json.dumps(template.applicable_languages),
                'metadata': json.dumps(template.metadata),
                'is_active': template.is_active,
                'version': template.version
            }
            self.db.save_template(template_dict)
            logger.info(f"Saved template {template.id} to database")
        except Exception as e:
            logger.error(f"Error saving template to database: {e}")
    
    def _ensure_default_templates(self):
        """Ensure all default templates exist, creating missing ones"""
        default_template_titles = [
            "SQL Injection Remediation",
            "Root Cause Explorer - Jira Data Analysis",
            "Python 3.11 Migration Assistant"
        ]
        
        existing_titles = {t.get('title', '') for t in self.db.get_all_templates()}
        
        for title in default_template_titles:
            if title not in existing_titles:
                logger.info(f"Creating missing default template: {title}")
                if title == "Python 3.11 Migration Assistant":
                    self.create_python311_migration_template()
                # Add other template creation methods here as needed
    
    def _create_default_templates(self):
        """Create default remediation templates"""
        # Check if default templates already exist to prevent duplicates
        existing_templates = self.db.get_all_templates()
        if existing_templates:
            logger.info(f"Found {len(existing_templates)} existing templates, skipping default template creation")
            return
        
        logger.info("Creating default templates")
        default_templates = [
            {
                "id": str(uuid.uuid4()),
                "title": "SQL Injection Remediation",
                "description": "Comprehensive guide for fixing SQL injection vulnerabilities",
                "category": "application",
                "content_type": "template",
                "content": "SQL injection template content",
                "ai_copilot_prompt": self._generate_sql_injection_copilot_prompt(),
                "remediation_template": self._generate_sql_injection_remediation_template(),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": "system",
                "tags": ["sql", "injection", "database", "security"],
                "severity_levels": ["CRITICAL_BOMB", "HIGH_RISK"],
                "applicable_languages": ["python", "javascript", "java", "php", "csharp"],
                "metadata": {"confidence": 0.95, "source": "system_template"},
                "is_active": True,
                "version": 1
            },
            {
                "id": str(uuid.uuid4()),
                "title": "Root Cause Explorer - Jira Data Analysis",
                "description": "AI-powered root cause analysis template for analyzing Jira tickets, comments, and historical data to identify patterns and provide remediation suggestions",
                "category": "data-analysis",
                "content_type": "template",
                "content": "Root cause analysis template for Jira data",
                "ai_copilot_prompt": self._generate_root_cause_explorer_copilot_prompt(),
                "remediation_template": self._generate_root_cause_explorer_remediation_template(),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": "system",
                "tags": ["root-cause", "jira", "analysis", "remediation", "ai-powered", "historical-data"],
                "severity_levels": ["HIGH_RISK", "MEDIUM_RISK", "LOW_RISK"],
                "applicable_languages": ["python", "javascript", "sql", "json"],
                "metadata": {"confidence": 0.98, "source": "system_template", "supports_excel_upload": True},
                "is_active": True,
                "version": 1
            },
            {
                "id": str(uuid.uuid4()),
                "title": "Python 3.11 Migration Assistant",
                "description": "Comprehensive Python 3.11 migration prompt with role-based Chain of Thought, few-shot examples, self-consistency, and loss-in-the-middle handling",
                "category": "migration",
                "content_type": "template",
                "content": "Python 3.11 migration guidance",
                "ai_copilot_prompt": self._generate_python311_migration_copilot_prompt(),
                "remediation_template": self._generate_python311_migration_remediation_template(),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": "system",
                "tags": ["python", "migration", "python3.11", "upgrade", "modernization", "code-migration"],
                "severity_levels": ["MEDIUM_RISK", "LOW_RISK"],
                "applicable_languages": ["python"],
                "metadata": {
                    "python_version_target": "3.11",
                    "migration_approach": "role-based-cot-fewshot-selfconsistency",
                    "handles_loss_in_middle": True,
                    "confidence": 0.95,
                    "source": "system_template"
                },
                "is_active": True,
                "version": 1
            }
        ]
        
        for template_data in default_templates:
            template = KnowledgeTemplate(**template_data)
            self.templates[template.id] = template
            self.save_template_to_db(template)
    
    def _check_duplicate_template(self, title: str, category: str) -> bool:
        """Check if a template with the same title and category already exists"""
        try:
            existing_templates = self.db.get_all_templates({'category': category})
            for template in existing_templates:
                if template['title'].lower() == title.lower():
                    return True
            return False
        except Exception as e:
            logger.error(f"Error checking for duplicate template: {e}")
            return False
    
    def _generate_copilot_prompt_from_content(self, content: str, title: str, category: str) -> str:
        """Generate AI Copilot prompt from content"""
        return f"""# AI Copilot Prompt: {title}

## CONTEXT:
You are analyzing content related to {category} issues.

## CONTENT:
{content[:1000]}{'...' if len(content) > 1000 else ''}

## YOUR TASK:
Provide remediation suggestions and analysis for this {category} issue.

## EXPECTED OUTPUT:
Provide specific, actionable solutions with step-by-step instructions."""
    
    def _generate_remediation_template_from_content(self, content: str, title: str, category: str) -> str:
        """Generate remediation template from content"""
        return f"""# {title} - Remediation Template

## Overview
This template provides remediation guidance for {category} issues.

## Content Analysis
{content[:500]}{'...' if len(content) > 500 else ''}

## Remediation Steps
1. **Immediate Actions**
   - Analyze the issue based on the content above
   - Identify root causes
   - Implement quick fixes

2. **Long-term Solutions**
   - Prevent similar issues
   - Implement monitoring
   - Update processes

## Best Practices
- Follow security guidelines
- Test solutions in non-production first
- Document changes"""
    
    def _extract_tags_from_content(self, content: str) -> List[str]:
        """Extract tags from content"""
        tags = []
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['security', 'vulnerability', 'auth']):
            tags.append('security')
        if any(word in content_lower for word in ['performance', 'slow', 'timeout']):
            tags.append('performance')
        if any(word in content_lower for word in ['database', 'sql', 'query']):
            tags.append('database')
        if any(word in content_lower for word in ['api', 'endpoint', 'service']):
            tags.append('api')
        
        return tags[:5]  # Limit to 5 tags
    
    def _determine_severity_from_content(self, content: str) -> List[str]:
        """Determine severity from content"""
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['critical', 'urgent', 'emergency']):
            return ["CRITICAL_BOMB"]
        elif any(word in content_lower for word in ['high', 'important', 'security']):
            return ["HIGH_RISK"]
        elif any(word in content_lower for word in ['medium', 'moderate']):
            return ["MEDIUM_RISK"]
        else:
            return ["LOW_RISK"]
    
    def _detect_languages_from_content(self, content: str) -> List[str]:
        """Detect programming languages from content"""
        languages = []
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['python', 'py']):
            languages.append('python')
        if any(word in content_lower for word in ['javascript', 'js', 'node']):
            languages.append('javascript')
        if any(word in content_lower for word in ['java', 'jvm']):
            languages.append('java')
        if any(word in content_lower for word in ['sql', 'database']):
            languages.append('sql')
        
        return languages[:3]  # Limit to 3 languages
    
    def add_template_from_excel(self, title: str, description: str, excel_file_content: bytes) -> Optional[str]:
        """Add template from Excel file with Jira data"""
        try:
            # Check for duplicates first
            if self._check_duplicate_template(title, "data-analysis"):
                logger.warning(f"Template '{title}' already exists in data-analysis category")
                return None
            
            # Parse Excel file
            df = pd.read_excel(io.BytesIO(excel_file_content))
            
            # Validate required columns
            required_columns = ['Jira ID', 'Jira Title', 'Jira Comments']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Process Jira data
            jira_data = self._process_jira_data(df)
            
            # Generate template
            template_id = str(uuid.uuid4())
            ai_copilot_prompt = self._generate_jira_analysis_copilot_prompt(jira_data)
            remediation_template = self._generate_jira_remediation_template(jira_data)
            
            template = KnowledgeTemplate(
                id=template_id,
                title=title,
                description=description,
                category="data-analysis",
                content_type="excel",
                content=json.dumps(jira_data, indent=2),
                ai_copilot_prompt=ai_copilot_prompt,
                remediation_template=remediation_template,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="user",
                tags=self._extract_tags_from_jira_data(jira_data),
                severity_levels=self._analyze_jira_severity(jira_data),
                applicable_languages=["python", "javascript", "sql", "json"],
                metadata={
                    "excel_rows": len(df),
                    "jira_tickets": len(jira_data['tickets']),
                    "analysis_date": datetime.now().isoformat(),
                    "confidence": 0.95
                }
            )
            
            self.templates[template_id] = template
            self.save_template_to_db(template)
            
            return template_id
            
        except Exception as e:
            logger.error(f"Error adding template from Excel: {e}")
            return None
    
    def add_template_from_file(self, title: str, description: str, category: str, file_content: str, filename: str) -> Optional[str]:
        """Add template from file content"""
        try:
            # Check for duplicates first
            if self._check_duplicate_template(title, category):
                logger.warning(f"Template '{title}' already exists in {category} category")
                return None
            
            # Generate template
            template_id = str(uuid.uuid4())
            ai_copilot_prompt = self._generate_copilot_prompt_from_content(file_content, title, category)
            remediation_template = self._generate_remediation_template_from_content(file_content, title, category)
            
            template = KnowledgeTemplate(
                id=template_id,
                title=title,
                description=description,
                category=category,
                content_type="file",
                content=file_content,
                ai_copilot_prompt=ai_copilot_prompt,
                remediation_template=remediation_template,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="user",
                tags=self._extract_tags_from_content(file_content),
                severity_levels=self._determine_severity_from_content(file_content),
                applicable_languages=self._detect_languages_from_content(file_content),
                metadata={"filename": filename, "file_size": len(file_content)}
            )
            
            self.templates[template_id] = template
            self.save_template_to_db(template)
            
            return template_id
            
        except Exception as e:
            logger.error(f"Error adding template from file: {e}")
            return None
    
    def _process_jira_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Process Jira data from Excel DataFrame"""
        tickets = []
        
        for _, row in df.iterrows():
            ticket = {
                "jira_id": str(row['Jira ID']),
                "title": str(row['Jira Title']),
                "comments": str(row['Jira Comments']),
                "analysis": {
                    "keywords": self._extract_keywords_from_text(str(row['Jira Comments'])),
                    "sentiment": self._analyze_sentiment(str(row['Jira Comments'])),
                    "category": self._categorize_issue(str(row['Jira Title']), str(row['Jira Comments']))
                }
            }
            tickets.append(ticket)
        
        return {
            "total_tickets": len(tickets),
            "tickets": tickets,
            "summary": {
                "categories": self._get_category_summary(tickets),
                "common_keywords": self._get_common_keywords(tickets),
                "sentiment_distribution": self._get_sentiment_distribution(tickets)
            }
        }
    
    def _extract_keywords_from_text(self, text: str) -> List[str]:
        """Extract keywords from text"""
        # Simple keyword extraction - can be enhanced with NLP
        keywords = []
        common_technical_terms = [
            'bug', 'error', 'issue', 'problem', 'fix', 'solution', 'update', 'patch',
            'security', 'performance', 'database', 'api', 'frontend', 'backend',
            'authentication', 'authorization', 'validation', 'exception', 'timeout'
        ]
        
        text_lower = text.lower()
        for term in common_technical_terms:
            if term in text_lower:
                keywords.append(term)
        
        return keywords[:10]  # Limit to top 10
    
    def _analyze_sentiment(self, text: str) -> str:
        """Simple sentiment analysis"""
        positive_words = ['fixed', 'resolved', 'working', 'good', 'improved', 'success']
        negative_words = ['broken', 'failed', 'error', 'issue', 'problem', 'bug', 'critical']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"
    
    def _categorize_issue(self, title: str, comments: str) -> str:
        """Categorize issue based on title and comments"""
        text = (title + " " + comments).lower()
        
        if any(word in text for word in ['security', 'vulnerability', 'auth', 'permission']):
            return "security"
        elif any(word in text for word in ['performance', 'slow', 'timeout', 'memory']):
            return "performance"
        elif any(word in text for word in ['ui', 'frontend', 'display', 'interface']):
            return "ui"
        elif any(word in text for word in ['database', 'sql', 'query', 'data']):
            return "database"
        elif any(word in text for word in ['api', 'endpoint', 'service', 'integration']):
            return "api"
        else:
            return "general"
    
    def _get_category_summary(self, tickets: List[Dict]) -> Dict[str, int]:
        """Get summary of issue categories"""
        categories = {}
        for ticket in tickets:
            category = ticket['analysis']['category']
            categories[category] = categories.get(category, 0) + 1
        return categories
    
    def _get_common_keywords(self, tickets: List[Dict]) -> List[str]:
        """Get most common keywords across all tickets"""
        all_keywords = []
        for ticket in tickets:
            all_keywords.extend(ticket['analysis']['keywords'])
        
        keyword_counts = {}
        for keyword in all_keywords:
            keyword_counts[keyword] = keyword_counts.get(keyword, 0) + 1
        
        # Sort by frequency and return top 10
        sorted_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)
        return [keyword for keyword, count in sorted_keywords[:10]]
    
    def _get_sentiment_distribution(self, tickets: List[Dict]) -> Dict[str, int]:
        """Get sentiment distribution"""
        sentiments = {}
        for ticket in tickets:
            sentiment = ticket['analysis']['sentiment']
            sentiments[sentiment] = sentiments.get(sentiment, 0) + 1
        return sentiments
    
    def _extract_tags_from_jira_data(self, jira_data: Dict) -> List[str]:
        """Extract tags from Jira data analysis"""
        tags = ["jira-analysis", "root-cause", "data-driven"]
        
        # Add category tags
        for category in jira_data['summary']['categories'].keys():
            tags.append(f"category-{category}")
        
        # Add keyword tags
        for keyword in jira_data['summary']['common_keywords'][:5]:
            tags.append(f"keyword-{keyword}")
        
        return tags
    
    def _analyze_jira_severity(self, jira_data: Dict) -> List[str]:
        """Analyze severity levels based on Jira data"""
        severities = ["MEDIUM_RISK"]  # Default
        
        # Add HIGH_RISK if there are many security or critical issues
        security_count = jira_data['summary']['categories'].get('security', 0)
        if security_count > 0:
            severities.append("HIGH_RISK")
        
        # Add LOW_RISK if most issues are minor
        total_tickets = jira_data['total_tickets']
        if total_tickets > 50:  # Large dataset
            severities.append("LOW_RISK")
        
        return severities
    
    def _create_matching_tickets_section(self, tickets: List[Dict]) -> str:
        """Create the matching JIRA tickets section for the prompt"""
        tickets_section = ""
        
        for i, ticket in enumerate(tickets, 1):
            # Extract key information from comments
            comments = ticket['comments']
            title = ticket['title']
            jira_id = ticket['jira_id']
            
            # Try to extract resolution information from comments
            resolution_info = self._extract_resolution_info(comments)
            
            tickets_section += f"""
{i}. **{jira_id}: {title}**
   - **Comments:** {comments[:200]}{'...' if len(comments) > 200 else ''}
   - **RCA:** {resolution_info['rca']}
   - **Solution:** {resolution_info['solution']}
"""
        
        return tickets_section
    
    def _extract_resolution_info(self, comments: str) -> Dict[str, str]:
        """Extract resolution information from Jira comments"""
        comments_lower = comments.lower()
        
        # Try to identify RCA and solution patterns
        rca_patterns = [
            'rca:', 'root cause:', 'root cause analysis:', 'cause:', 'reason:'
        ]
        solution_patterns = [
            'solution:', 'fix:', 'resolved:', 'workaround:', 'action taken:'
        ]
        
        rca = "Not specified"
        solution = "Not specified"
        
        # Look for RCA patterns
        for pattern in rca_patterns:
            if pattern in comments_lower:
                # Try to extract text after the pattern
                start_idx = comments_lower.find(pattern) + len(pattern)
                end_idx = min(start_idx + 100, len(comments))
                rca = comments[start_idx:end_idx].strip()
                if len(comments) > start_idx + 100:
                    rca += "..."
                break
        
        # Look for solution patterns
        for pattern in solution_patterns:
            if pattern in comments_lower:
                # Try to extract text after the pattern
                start_idx = comments_lower.find(pattern) + len(pattern)
                end_idx = min(start_idx + 100, len(comments))
                solution = comments[start_idx:end_idx].strip()
                if len(comments) > start_idx + 100:
                    solution += "..."
                break
        
        # If no specific patterns found, use the first part of comments
        if rca == "Not specified" and solution == "Not specified":
            # Try to infer from common resolution keywords
            if any(word in comments_lower for word in ['restart', 'reboot', 'bounce']):
                solution = "System restart/reboot required"
            elif any(word in comments_lower for word in ['patch', 'update', 'upgrade']):
                solution = "Application patch or update"
            elif any(word in comments_lower for word in ['config', 'configuration']):
                solution = "Configuration change required"
            elif any(word in comments_lower for word in ['memory', 'oom', 'out of memory']):
                rca = "Memory/resource exhaustion"
                solution = "Increase memory allocation or restart services"
        
        return {
            'rca': rca,
            'solution': solution
        }
    
    def _create_historical_tickets_reference(self, tickets: List[Dict]) -> str:
        """Create historical tickets reference for the remediation template"""
        reference_section = ""
        
        for ticket in tickets:
            jira_id = ticket['jira_id']
            title = ticket['title']
            category = ticket['analysis']['category']
            keywords = ', '.join(ticket['analysis']['keywords'][:3])
            
            reference_section += f"""
- **{jira_id}**: {title} (Category: {category}, Keywords: {keywords})"""
        
        return reference_section
    
    def _generate_jira_analysis_copilot_prompt(self, jira_data: Dict) -> str:
        """Generate AI Copilot prompt for Jira data analysis"""
        
        # Create the matching JIRA tickets section
        matching_tickets_section = self._create_matching_tickets_section(jira_data['tickets'])
        
        return f"""# AI Copilot Prompt: Root Cause Analysis for Jira Data

## CONTEXT:
You are analyzing {jira_data['total_tickets']} Jira tickets to identify root causes and provide remediation suggestions.

## DATA SUMMARY:
- **Total Tickets**: {jira_data['total_tickets']}
- **Issue Categories**: {jira_data['summary']['categories']}
- **Common Keywords**: {jira_data['summary']['common_keywords'][:10]}
- **Sentiment Distribution**: {jira_data['summary']['sentiment_distribution']}

## MATCHING JIRA TICKETS:
{matching_tickets_section}

## YOUR TASK:
1. **Pattern Recognition**: Identify recurring patterns in the ticket data above
2. **Root Cause Analysis**: Determine underlying causes of issues based on historical tickets
3. **Prioritization**: Rank issues by impact and frequency
4. **Remediation Suggestions**: Provide specific, actionable solutions based on successful resolutions

## ANALYSIS FRAMEWORK:
- **Frequency Analysis**: Which issues occur most often in the historical data?
- **Category Clustering**: Group similar issues together based on the tickets above
- **Success Patterns**: What solutions worked for similar issues?
- **Impact Assessment**: Which issues have the highest business impact?

## EXPECTED OUTPUT FORMAT:
When a user reports a new issue, provide:

### Matching JIRA Tickets:
[List relevant historical tickets from the data above]

### Proposed Solution:
1. **Immediate Actions:**
   - [Specific actions based on successful historical resolutions]
2. **Monitoring:**
   - [What to monitor based on past issues]
3. **Preventive Measures:**
   - [How to prevent similar issues based on historical data]

## INSTRUCTIONS:
- Always reference specific JIRA ticket IDs when providing solutions
- Use successful resolution patterns from historical data
- Provide context-aware recommendations based on similar past issues
- Include root cause analysis (RCA) insights from historical tickets

Focus on actionable insights that leverage the historical ticket data to provide immediate, context-aware solutions."""

    def _generate_jira_remediation_template(self, jira_data: Dict) -> str:
        """Generate remediation template for Jira data"""
        
        # Create the historical tickets reference
        historical_tickets_section = self._create_historical_tickets_reference(jira_data['tickets'])
        
        return f"""# Root Cause Explorer - Remediation Template

## Executive Summary
Based on analysis of {jira_data['total_tickets']} Jira tickets, this template provides a systematic approach to addressing root causes and preventing recurring issues.

## Historical Data Reference
{historical_tickets_section}

## Issue Categories Identified
{chr(10).join([f"- **{category}**: {count} tickets" for category, count in jira_data['summary']['categories'].items()])}

## Common Patterns
{chr(10).join([f"- {keyword}" for keyword in jira_data['summary']['common_keywords'][:10]])}

## Remediation Strategy

### Phase 1: Immediate Actions (Week 1-2)
1. **High-Frequency Issues**
   - Identify top 3 most common issues from historical data
   - Implement quick fixes for critical paths (reference similar tickets above)
   - Add monitoring for early detection

2. **Security Issues**
   - Review and patch security vulnerabilities (see security tickets above)
   - Implement additional security checks
   - Update authentication mechanisms

### Phase 2: Systematic Improvements (Week 3-6)
1. **Code Quality**
   - Implement automated testing for common failure points
   - Add code review checklists based on historical issues
   - Enhance error handling

2. **Infrastructure**
   - Optimize performance bottlenecks (reference performance tickets)
   - Implement proper logging and monitoring
   - Add health checks and alerts

### Phase 3: Long-term Prevention (Month 2-3)
1. **Process Improvements**
   - Establish incident response procedures
   - Create knowledge base for common issues (using historical data above)
   - Implement regular health assessments

2. **Monitoring & Alerting**
   - Set up proactive monitoring
   - Create escalation procedures
   - Implement predictive analytics

## Success Metrics
- 50% reduction in recurring issues within 30 days
- 75% faster resolution time for known issues
- 90% reduction in critical incidents

## Template Usage
This template can be customized based on:
- Specific issue categories in your data
- Business priorities and constraints
- Available resources and timeline
- Technology stack and architecture

## AI Copilot Integration
Use the generated AI prompts to:
- Query specific issue patterns from historical data
- Get remediation suggestions for new tickets (reference similar tickets above)
- Analyze trends and predict future issues
- Generate automated reports and insights

## How to Use This Template
1. When a new issue is reported, search the historical tickets above for similar issues
2. Reference the RCA and Solution from matching tickets
3. Apply proven solutions from historical data
4. Update this template with new resolution patterns"""
    
    def _generate_root_cause_explorer_copilot_prompt(self) -> str:
        """Generate AI Copilot prompt for Root Cause Explorer"""
        return """# AI Copilot Prompt: Root Cause Explorer

## CONTEXT:
You are a Root Cause Explorer AI assistant designed to analyze historical ticket data, identify patterns, and provide actionable remediation suggestions.

## CAPABILITIES:
- **Historical Analysis**: Process large datasets of tickets and comments
- **Pattern Recognition**: Identify recurring issues and root causes
- **Smart Recommendations**: Provide context-aware remediation suggestions
- **Automated Insights**: Generate reports and trend analysis

## WORKFLOW:
1. **Data Ingestion**: Accept Excel files with Jira data (ID, Title, Comments)
2. **Pattern Analysis**: Identify common issues, keywords, and categories
3. **Root Cause Identification**: Determine underlying causes
4. **Remediation Generation**: Create specific, actionable solutions
5. **Knowledge Base Creation**: Build searchable repository of solutions

## QUERY TYPES SUPPORTED:
- "Show me all security-related issues from the last 30 days"
- "What are the most common performance problems?"
- "Generate remediation steps for authentication failures"
- "Analyze trends in database connectivity issues"
- "Create a prevention strategy for UI bugs"

## EXPECTED RESPONSES:
- **Immediate**: Direct answers with specific solutions
- **Comprehensive**: Detailed analysis with multiple approaches
- **Actionable**: Step-by-step remediation instructions
- **Contextual**: Tailored to your specific technology stack

## SAMPLE INTERACTION:
```
User: "I'm seeing repeated authentication failures in our system"
AI: "Based on your historical data, authentication failures occur in 3 main patterns:
1. Token expiration (40% of cases) - Solution: Implement refresh token logic
2. Invalid credentials (35% of cases) - Solution: Add credential validation
3. Network timeouts (25% of cases) - Solution: Implement retry mechanisms
[Detailed remediation steps follow]"
```

## DATA REQUIREMENTS:
- Jira ID, Title, and Comments (minimum)
- Additional metadata (priority, assignee, dates) preferred
- Historical data for better pattern recognition

## BENEFITS:
- **Time Savings**: Reduce manual analysis from hours to minutes
- **Accuracy**: AI-powered insights reduce human error
- **Scalability**: Handle large volumes of data effortlessly
- **Consistency**: Standardized analysis across all tickets

Use this template to transform your ticket data into actionable intelligence!"""

    def _generate_root_cause_explorer_remediation_template(self) -> str:
        """Generate remediation template for Root Cause Explorer"""
        return """# Root Cause Explorer - Implementation Guide

## Overview
The Root Cause Explorer automates ticket analysis, saving significant time and cost by reducing manual effort from hours to minutes. It improves accuracy and provides actionable insights, enabling teams to quickly resolve recurring issues.

## Implementation Steps

### 1. Data Preparation
- Export Jira data to Excel with columns: Jira ID, Jira Title, Jira Comments
- Include additional metadata if available (Priority, Assignee, Created Date)
- Ensure data is clean and properly formatted

### 2. Knowledge Base Creation
- Upload Excel file through the Knowledge Base interface
- System automatically processes and categorizes data
- AI analyzes patterns and creates searchable repository

### 3. Query Interface Setup
- Use natural language queries to search historical data
- Ask questions like:
  - "What are the most common issues in the last quarter?"
  - "Show me all authentication-related problems"
  - "Generate remediation steps for performance issues"

### 4. Automated Analysis
- **Pattern Recognition**: Identify recurring issues and root causes
- **Trend Analysis**: Track issue frequency and impact over time
- **Categorization**: Automatically classify issues by type and severity
- **Sentiment Analysis**: Understand resolution success rates

## Benefits for Different Teams

### Developers
- Quick access to similar past issues and solutions
- Automated code suggestions based on historical fixes
- Pattern recognition to prevent recurring bugs

### Testers
- Identify test coverage gaps based on historical issues
- Generate test cases for common failure scenarios
- Prioritize testing based on issue frequency

### Support Teams
- Faster issue resolution with historical context
- Automated escalation based on issue patterns
- Knowledge base for common troubleshooting steps

## Success Metrics
- **Time Reduction**: 75% faster issue resolution
- **Accuracy Improvement**: 90% reduction in repeated triages
- **Productivity Gain**: Teams focus on higher-value tasks
- **Knowledge Retention**: Preserve institutional knowledge

## Advanced Features
- **Predictive Analysis**: Forecast potential issues
- **Automated Reports**: Generate regular insights
- **Integration**: Connect with existing tools and workflows
- **Customization**: Tailor analysis to specific business needs

## Best Practices
1. **Regular Updates**: Keep knowledge base current with new tickets
2. **Quality Data**: Ensure clean, comprehensive ticket data
3. **Team Training**: Educate teams on effective query techniques
4. **Continuous Improvement**: Refine analysis based on feedback

## Getting Started
1. Upload your Excel file with Jira data
2. Review the generated analysis and insights
3. Start querying with natural language questions
4. Implement suggested remediations
5. Track improvements and iterate

Transform your historical ticket data into a powerful root cause analysis engine!"""
    
    def _generate_sql_injection_copilot_prompt(self) -> str:
        """Generate AI Copilot prompt for SQL injection remediation"""
        return """# AI Copilot Prompt: SQL Injection Remediation

## CONTEXT:
You are fixing SQL injection vulnerabilities in code. SQL injection occurs when user input is directly concatenated into SQL queries without proper sanitization.

## VULNERABILITY PATTERN:
```python
# VULNERABLE CODE:
query = f"SELECT * FROM users WHERE id = {user_id}"
cursor.execute(query)
```

## YOUR TASK:
1. Identify SQL injection vulnerabilities
2. Replace with parameterized queries
3. Add input validation
4. Implement proper error handling
5. Add security logging

## SECURE PATTERNS:
```python
# SECURE: Parameterized queries
query = "SELECT * FROM users WHERE id = %s"
cursor.execute(query, (user_id,))

# SECURE: Input validation
if not user_id.isdigit():
    raise ValueError("Invalid user ID")
```

## EXPECTED OUTPUT:
Provide secure, production-ready code with proper error handling and validation."""
    
    def _generate_sql_injection_remediation_template(self) -> str:
        """Generate SQL injection remediation template"""
        return """# SQL Injection Remediation Template

## Overview
SQL injection vulnerabilities occur when user input is directly concatenated into SQL queries without proper sanitization.

## Common Vulnerable Patterns
```python
# VULNERABLE
query = f"SELECT * FROM users WHERE id = {user_id}"
cursor.execute(query)

# VULNERABLE
query = "SELECT * FROM users WHERE name = '" + username + "'"
cursor.execute(query)
```

## Secure Implementation
```python
# SECURE: Parameterized queries
query = "SELECT * FROM users WHERE id = %s"
cursor.execute(query, (user_id,))

# SECURE: Input validation
def validate_user_id(user_id):
    if not user_id.isdigit():
        raise ValueError("Invalid user ID")
    return int(user_id)

# SECURE: Error handling
try:
    user_id = validate_user_id(user_id)
    query = "SELECT * FROM users WHERE id = %s"
    cursor.execute(query, (user_id,))
    result = cursor.fetchone()
except ValueError as e:
    logger.error(f"Validation error: {e}")
    return None
except Exception as e:
    logger.error(f"Database error: {e}")
    return None
```

## Prevention Strategies
1. **Always use parameterized queries**
2. **Validate and sanitize all inputs**
3. **Implement least privilege database access**
4. **Use stored procedures when possible**
5. **Add comprehensive logging and monitoring**

## Testing
```python
def test_sql_injection_prevention():
    # Test malicious input
    malicious_input = "1; DROP TABLE users; --"
    result = get_user_by_id(malicious_input)
    assert result is None  # Should be handled gracefully
```

## Monitoring
- Log all database queries
- Monitor for unusual query patterns
- Set up alerts for potential injection attempts
- Regular security audits

This template provides a comprehensive approach to preventing and fixing SQL injection vulnerabilities."""
    
    def get_all_templates(self) -> List[Dict]:
        """Get all templates"""
        try:
            templates_data = self.db.get_all_templates()
            return templates_data
        except Exception as e:
            logger.error(f"Error getting all templates: {e}")
            return []
    
    def get_template_by_id(self, template_id: str) -> Optional[Dict]:
        """Get template by ID"""
        try:
            template_data = self.db.get_template(template_id)
            return template_data
        except Exception as e:
            logger.error(f"Error getting template by ID: {e}")
            return None
    
    def get_templates_by_category(self, category: str) -> List[Dict]:
        """Get templates by category"""
        try:
            templates_data = self.db.get_templates_by_category(category)
            return templates_data
        except Exception as e:
            logger.error(f"Error getting templates by category: {e}")
            return []
    
    def search_templates(self, query: str) -> List[Dict]:
        """Search templates by query"""
        try:
            templates_data = self.db.search_templates(query)
            return templates_data
        except Exception as e:
            logger.error(f"Error searching templates: {e}")
            return []

    def create_python311_migration_template(self) -> Optional[str]:
        """Create Python 3.11 migration template with role-based CoT, few-shot, and self-consistency"""
        try:
            # Check for duplicates
            if self._check_duplicate_template("Python 3.11 Migration Assistant", "migration"):
                logger.warning("Python 3.11 Migration template already exists")
                return None
            
            template_id = str(uuid.uuid4())
            template = KnowledgeTemplate(
                id=template_id,
                title="Python 3.11 Migration Assistant",
                description="Comprehensive Python 3.11 migration prompt with role-based Chain of Thought, few-shot examples, self-consistency, and loss-in-the-middle handling",
                category="migration",
                content_type="template",
                content="Python 3.11 migration guidance",
                ai_copilot_prompt=self._generate_python311_migration_copilot_prompt(),
                remediation_template=self._generate_python311_migration_remediation_template(),
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="system",
                tags=["python", "migration", "python3.11", "upgrade", "modernization", "code-migration"],
                severity_levels=["MEDIUM_RISK", "LOW_RISK"],
                applicable_languages=["python"],
                metadata={
                    "python_version_target": "3.11",
                    "migration_approach": "role-based-cot-fewshot-selfconsistency",
                    "handles_loss_in_middle": True,
                    "confidence": 0.95
                },
                is_active=True,
                version=1
            )
            
            self.templates[template_id] = template
            self.save_template_to_db(template)
            logger.info(f"Created Python 3.11 migration template: {template_id}")
            return template_id
            
        except Exception as e:
            logger.error(f"Error creating Python 3.11 migration template: {e}")
            return None
    
    def _generate_python311_migration_copilot_prompt(self) -> str:
        """Generate comprehensive Python 3.11 migration prompt with role-based CoT, few-shot, and self-consistency"""
        # Use triple single quotes to avoid conflicts with code blocks that use triple backticks
        return '''# AI Copilot Prompt: Python 3.11 Migration Assistant
## Role: Senior Python Migration Specialist

You are an expert Python migration specialist with 15+ years of experience in Python version upgrades, code modernization, and large-scale codebase migrations. Your expertise includes:
- Deep understanding of Python version differences (2.7 → 3.x → 3.11)
- Pattern recognition for deprecated features and breaking changes
- Systematic code analysis and transformation strategies
- Ensuring zero functionality loss during migration
- Handling edge cases and complex dependency scenarios

---

## TASK: Python 3.11 Migration with Complete Coverage

### PRIMARY OBJECTIVE:
1. **Check Current Python Version**: Detect the Python version used in the workspace
2. **Version Comparison**: If current version < 3.11, proceed with migration
3. **Complete Migration**: Migrate ALL source code files in the workspace to Python 3.11
4. **Zero Loss Guarantee**: Ensure no code, functionality, or logic is lost during migration
5. **Self-Consistency Check**: Verify migration correctness through multiple validation passes

---

## CHAIN OF THOUGHT (CoT) APPROACH

### STEP 1: Environment Analysis
**Think through:**
- How do I detect the current Python version?
- What files indicate Python version? (pyproject.toml, setup.py, requirements.txt, .python-version, runtime.txt, Dockerfile, CI/CD configs)
- What version detection methods are reliable? (sys.version, __version__, version files)

**Action:**
```python
# Example detection logic
import sys
import os
from pathlib import Path

def detect_python_version():
    # Method 1: Check sys.version
    current_version = sys.version_info
    version_str = f"{current_version.major}.{current_version.minor}.{current_version.micro}"
    
    # Method 2: Check version files
    version_files = ['.python-version', 'runtime.txt', 'pyproject.toml', 'setup.py']
    for vfile in version_files:
        if os.path.exists(vfile):
            # Parse version from file
            pass
    
    return version_str, current_version
```

### STEP 2: Workspace Discovery
**Think through:**
- How do I find ALL Python files in the workspace?
- What directories should be excluded? (venv, .git, node_modules, __pycache__, .pytest_cache)
- How do I handle nested directories and large codebases?
- How do I ensure I don't miss any files?

**Action:**
```python
def discover_python_files(workspace_root):
    """Discover all Python files with comprehensive coverage"""
    python_files = []
    exclude_dirs = {'.git', '__pycache__', 'venv', 'env', '.venv', 
                   'node_modules', '.pytest_cache', '.mypy_cache', 
                   'dist', 'build', '.eggs'}
    
    for root, dirs, files in os.walk(workspace_root):
        # Remove excluded directories from dirs list
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file.endswith('.py'):
                full_path = os.path.join(root, file)
                python_files.append(full_path)
    
    return python_files
```

### STEP 3: Version-Specific Migration Rules
**Think through:**
- What are the key differences between Python < 3.11 and Python 3.11?
- What deprecated features need updating?
- What new features can be leveraged?
- What breaking changes exist?

**Key Migration Areas:**
1. **Type Hints & Annotations** (PEP 563, PEP 604, PEP 585, PEP 604)
2. **Exception Handling** (ExceptionGroup, except* syntax in 3.11)
3. **Performance Features** (Faster CPython, tomllib)
4. **Deprecated Modules** (distutils → setuptools)
5. **String Formatting** (f-strings preferred, % formatting deprecated patterns)
6. **Import System** (relative imports, __future__ imports)
7. **Async/Await** (async generator improvements)
8. **Dataclasses** (field() improvements)
9. **Typing** (Generic types, Literal, TypedDict improvements)

### STEP 4: File-by-File Migration with Loss Prevention
**Think through:**
- How do I ensure I process every file?
- How do I track which files have been migrated?
- How do I prevent losing code during transformation?
- How do I handle files that can't be automatically migrated?

**Migration Process:**
```python
def migrate_file(file_path, source_version, target_version):
    """
    Migrate a single Python file with loss prevention
    """
    # Step 1: Read original file
    with open(file_path, 'r', encoding='utf-8') as f:
        original_content = f.read()
    
    # Step 2: Create backup
    backup_path = f"{file_path}.backup_{source_version}"
    with open(backup_path, 'w', encoding='utf-8') as f:
        f.write(original_content)
    
    # Step 3: Parse AST to understand structure
    try:
        tree = ast.parse(original_content, filename=file_path)
    except SyntaxError as e:
        # Handle syntax errors - mark for manual review
        log_manual_review_needed(file_path, str(e))
        return False
    
    # Step 4: Apply transformations
    migrated_content = apply_migrations(tree, original_content)
    
    # Step 5: Verify no loss
    if not verify_no_loss(original_content, migrated_content):
        # Restore from backup
        restore_from_backup(file_path, backup_path)
        log_migration_failed(file_path, "Content loss detected")
        return False
    
    # Step 6: Write migrated file
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(migrated_content)
    
    return True
```

### STEP 5: Self-Consistency Validation
**Think through:**
- How do I verify the migration is correct?
- How do I check for syntax errors?
- How do I ensure functionality is preserved?
- How do I validate type hints are correct?

**Validation Steps:**
1. **Syntax Check**: Run `python -m py_compile` on migrated files
2. **AST Comparison**: Compare AST structure (excluding version-specific nodes)
3. **Import Check**: Verify all imports are valid
4. **Type Check**: Run mypy or pyright if available
5. **Test Execution**: Run existing tests if available
6. **Code Coverage**: Ensure same code paths exist

---

## FEW-SHOT EXAMPLES

### Example 1: Type Hint Migration (Python 3.9 → 3.11)

**BEFORE (Python 3.9):**
```python
from typing import List, Dict, Union, Optional
from typing import Tuple as TupleType

def process_data(items: List[Dict[str, Union[int, str]]]) -> Optional[TupleType[int, str]]:
    if not items:
        return None
    result = items[0]
    return (result.get('id', 0), result.get('name', ''))
```

**AFTER (Python 3.11):**
```python
from typing import Optional

# Use built-in generics (PEP 585)
def process_data(items: list[dict[str, int | str]]) -> tuple[int, str] | None:
    if not items:
        return None
    result = items[0]
    return (result.get('id', 0), result.get('name', ''))
```

**Reasoning:**
- Python 3.9+ supports `list`, `dict` directly (PEP 585)
- Python 3.10+ supports `X | Y` union syntax (PEP 604)
- Removed unnecessary `from typing import` statements
- `Optional[T]` → `T | None` (more readable)

### Example 2: Exception Handling (Python 3.10 → 3.11)

**BEFORE (Python 3.10):**
```python
try:
    result = complex_operation()
except (ValueError, TypeError, KeyError) as e:
    if isinstance(e, ValueError):
        handle_value_error(e)
    elif isinstance(e, TypeError):
        handle_type_error(e)
    else:
        handle_key_error(e)
```

**AFTER (Python 3.11):**
```python
try:
    result = complex_operation()
except* ValueError as eg:
    for e in eg.exceptions:
        handle_value_error(e)
except* TypeError as eg:
    for e in eg.exceptions:
        handle_type_error(e)
except* KeyError as eg:
    for e in eg.exceptions:
        handle_key_error(e)
```

**Reasoning:**
- Python 3.11 introduces ExceptionGroup and `except*` syntax
- Allows handling multiple exceptions of the same type
- More explicit and cleaner than isinstance checks

### Example 3: String Formatting Modernization

**BEFORE:**
```python
name = "John"
age = 30
message = "Name: %s, Age: %d" % (name, age)
message2 = "Name: {}, Age: {}".format(name, age)
```

**AFTER:**
```python
name = "John"
age = 30
message = f"Name: {name}, Age: {age}"
message2 = f"Name: {name}, Age: {age}"  # Consistent f-string usage
```

**Reasoning:**
- F-strings (PEP 498) are faster and more readable
- Python 3.6+ feature, but migration ensures consistency
- Better performance in Python 3.11

### Example 4: Import Modernization

**BEFORE:**
```python
from typing import List, Dict
from collections import OrderedDict
import sys
if sys.version_info < (3, 8):
    from typing_extensions import Literal
else:
    from typing import Literal
```

**AFTER:**
```python
from collections import OrderedDict
from typing import Literal  # Available since 3.8, no version check needed in 3.11
```

**Reasoning:**
- Remove version checks for features available in 3.11
- Clean up unnecessary imports
- Use standard library when available

### Example 5: Dataclass Improvements

**BEFORE (Python 3.7):**
```python
from dataclasses import dataclass, field
from typing import List

@dataclass
class User:
    name: str
    age: int
    tags: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if self.age < 0:
            raise ValueError("Age cannot be negative")
```

**AFTER (Python 3.11):**
```python
from dataclasses import dataclass, field

@dataclass
class User:
    name: str
    age: int
    tags: list[str] = field(default_factory=list)
    
    def __post_init__(self):
        if self.age < 0:
            raise ValueError("Age cannot be negative")
```

**Reasoning:**
- Use `list[str]` instead of `List[str]` (PEP 585)
- Leverage dataclass improvements in 3.11
- Cleaner type annotations

---

## HANDLING "LOSS IN THE MIDDLE" PROBLEM

### Problem:
When processing large codebases, there's a risk of:
1. Missing files during migration
2. Losing code during transformation
3. Incomplete migrations
4. Overlooking edge cases

### Solution Strategy:

#### 1. Comprehensive File Tracking
```python
class MigrationTracker:
    def __init__(self):
        self.discovered_files = set()
        self.processed_files = set()
        self.failed_files = set()
        self.skipped_files = set()
        self.migration_log = []
    
    def track_file(self, file_path, status):
        """Track file migration status"""
        self.discovered_files.add(file_path)
        if status == 'processed':
            self.processed_files.add(file_path)
        elif status == 'failed':
            self.failed_files.add(file_path)
        elif status == 'skipped':
            self.skipped_files.add(file_path)
        
        self.migration_log.append({
            'file': file_path,
            'status': status,
            'timestamp': datetime.now().isoformat()
        })
    
    def verify_completeness(self):
        """Verify all files were processed"""
        missing = self.discovered_files - (self.processed_files | self.failed_files | self.skipped_files)
        if missing:
            raise MigrationIncompleteError(f"Files not processed: {missing}")
        return True
```

#### 2. Content Preservation Checks
```python
def verify_no_content_loss(original: str, migrated: str) -> bool:
    """Verify no content was lost during migration"""
    # Check 1: Line count should be same or increased (comments/formatting)
    original_lines = len([l for l in original.split('\n') if l.strip()])
    migrated_lines = len([l for l in migrated.split('\n') if l.strip()])
    
    # Allow some increase (added type hints, etc.) but not significant decrease
    if migrated_lines < original_lines * 0.9:  # Allow 10% reduction max
        return False
    
    # Check 2: Function/class definitions should be preserved
    original_defs = extract_definitions(original)
    migrated_defs = extract_definitions(migrated)
    
    if len(original_defs) != len(migrated_defs):
        return False
    
    # Check 3: Import statements should be preserved or improved
    original_imports = extract_imports(original)
    migrated_imports = extract_imports(migrated)
    
    # Imports can change (typing → built-in), but functionality should remain
    if not verify_import_equivalence(original_imports, migrated_imports):
        return False
    
    return True
```

#### 3. Incremental Migration with Checkpoints
```python
def migrate_workspace_incremental(workspace_root):
    """Migrate workspace with checkpoints to prevent loss"""
    tracker = MigrationTracker()
    checkpoint_file = os.path.join(workspace_root, '.migration_checkpoint.json')
    
    # Load previous checkpoint if exists
    if os.path.exists(checkpoint_file):
        tracker = load_checkpoint(checkpoint_file)
    
    python_files = discover_python_files(workspace_root)
    
    for file_path in python_files:
        if file_path in tracker.processed_files:
            continue  # Skip already processed
        
        try:
            success = migrate_file(file_path, '3.9', '3.11')
            if success:
                tracker.track_file(file_path, 'processed')
            else:
                tracker.track_file(file_path, 'failed')
        except Exception as e:
            tracker.track_file(file_path, 'failed')
            log_error(file_path, str(e))
        
        # Save checkpoint every 10 files
        if len(tracker.processed_files) % 10 == 0:
            save_checkpoint(tracker, checkpoint_file)
    
    # Final verification
    tracker.verify_completeness()
    return tracker
```

#### 4. Multi-Pass Validation
```python
def validate_migration_multipass(workspace_root):
    """Multiple validation passes to ensure correctness"""
    results = {
        'syntax_check': [],
        'import_check': [],
        'type_check': [],
        'test_check': []
    }
    
    # Pass 1: Syntax validation
    for file_path in get_python_files(workspace_root):
        if not validate_syntax(file_path):
            results['syntax_check'].append(file_path)
    
    # Pass 2: Import validation
    for file_path in get_python_files(workspace_root):
        if not validate_imports(file_path):
            results['import_check'].append(file_path)
    
    # Pass 3: Type checking (if available)
    if has_mypy():
        for file_path in get_python_files(workspace_root):
            if not validate_types(file_path):
                results['type_check'].append(file_path)
    
    # Pass 4: Test execution (if available)
    if has_tests():
        test_results = run_tests()
        if not test_results.success:
            results['test_check'] = test_results.failed_files
    
    return results
```

---

## SELF-CONSISTENCY MECHANISM

### Approach:
1. **Multiple Reasoning Paths**: Generate migration using different strategies
2. **Cross-Validation**: Compare results from different approaches
3. **Consensus Building**: Use majority vote or best-of-N selection
4. **Verification Loop**: Iterate until consistency is achieved

```python
def migrate_with_self_consistency(file_path):
    """Migrate file with self-consistency checks"""
    original = read_file(file_path)
    
    # Strategy 1: AST-based transformation
    migrated_ast = ast_based_migration(original)
    
    # Strategy 2: Pattern-based transformation
    migrated_pattern = pattern_based_migration(original)
    
    # Strategy 3: Rule-based transformation
    migrated_rule = rule_based_migration(original)
    
    # Compare results
    results = [migrated_ast, migrated_pattern, migrated_rule]
    
    # Find consensus
    consensus = find_consensus(results)
    
    # Verify consistency
    if not verify_consistency(consensus, results):
        # If inconsistent, use most conservative approach
        consensus = most_conservative_migration(original)
    
    return consensus
```

---

## COMPLETE MIGRATION WORKFLOW

### Phase 1: Discovery & Analysis
1. Detect current Python version
2. Discover all Python files in workspace
3. Analyze codebase structure
4. Identify migration complexity

### Phase 2: Preparation
1. Create backup of entire workspace
2. Set up version tracking
3. Initialize migration log
4. Create checkpoint system

### Phase 3: Migration Execution
1. Process files in batches
2. Apply transformations systematically
3. Track progress with checkpoints
4. Handle errors gracefully

### Phase 4: Validation
1. Syntax validation
2. Import validation
3. Type checking
4. Test execution
5. Content preservation verification

### Phase 5: Self-Consistency Check
1. Multiple validation passes
2. Cross-reference results
3. Fix inconsistencies
4. Final verification

### Phase 6: Cleanup & Documentation
1. Update version files
2. Update dependencies
3. Generate migration report
4. Document changes

---

## EXPECTED OUTPUT FORMAT

When executing this migration, provide:

1. **Migration Summary**:
   - Current Python version detected
   - Target Python version (3.11)
   - Total files discovered
   - Files successfully migrated
   - Files requiring manual review
   - Files that failed migration

2. **Detailed Migration Log**:
   - Per-file migration status
   - Transformations applied
   - Issues encountered
   - Recommendations

3. **Validation Report**:
   - Syntax check results
   - Import validation results
   - Type checking results
   - Test execution results

4. **Self-Consistency Report**:
   - Consistency check results
   - Discrepancies found
   - Resolution actions taken

---

## CRITICAL REQUIREMENTS

1. **Zero Loss**: Every line of code must be accounted for
2. **Complete Coverage**: All Python files in workspace must be processed
3. **Backward Compatibility**: Ensure migrated code works in Python 3.11
4. **Self-Verification**: Multiple validation passes
5. **Error Handling**: Graceful handling of edge cases
6. **Documentation**: Comprehensive migration report
7. **Rollback Capability**: Ability to restore from backup

---

## INSTRUCTIONS FOR EXECUTION

1. **Start with version detection**: Check current Python version
2. **If version < 3.11**: Proceed with migration
3. **Discover all files**: Use comprehensive file discovery
4. **Migrate systematically**: File by file with tracking
5. **Validate continuously**: Check after each batch
6. **Verify completeness**: Ensure no files are missed
7. **Self-consistency check**: Multiple validation passes
8. **Generate report**: Document all changes

**Remember**: The goal is a complete, lossless migration to Python 3.11 with full workspace coverage and self-verified correctness.'''

    def _generate_python311_migration_remediation_template(self) -> str:
        """Generate remediation template for Python 3.11 migration"""
        return '''# Python 3.11 Migration - Remediation Template

## Overview
This template provides a comprehensive guide for migrating Python codebases from versions < 3.11 to Python 3.11, ensuring zero functionality loss and complete workspace coverage.

## Migration Checklist

### Pre-Migration
- [ ] Backup entire workspace
- [ ] Document current Python version
- [ ] List all dependencies
- [ ] Review breaking changes in Python 3.11
- [ ] Set up testing environment

### During Migration
- [ ] Detect current Python version
- [ ] Discover all Python files
- [ ] Migrate type hints (PEP 585, PEP 604)
- [ ] Update exception handling (if using 3.11 features)
- [ ] Modernize string formatting
- [ ] Update imports
- [ ] Remove version checks for 3.11+ features
- [ ] Update dataclasses
- [ ] Verify no content loss

### Post-Migration
- [ ] Run syntax validation
- [ ] Run import validation
- [ ] Run type checking
- [ ] Execute test suite
- [ ] Update version files
- [ ] Update dependencies
- [ ] Generate migration report

## Common Migration Patterns

### Type Hints
- `List[T]` → `list[T]`
- `Dict[K, V]` → `dict[K, V]`
- `Tuple[T, ...]` → `tuple[T, ...]`
- `Optional[T]` → `T | None`
- `Union[A, B]` → `A | B`

### Exception Handling
- Use `except*` for ExceptionGroup (3.11+)
- Leverage ExceptionGroup for multiple exceptions

### String Formatting
- Prefer f-strings over % formatting
- Prefer f-strings over .format()

### Imports
- Remove typing imports where built-ins are available
- Remove version checks for 3.11+ features

## Validation Steps

1. **Syntax Check**: `python -m py_compile <file>`
2. **Import Check**: Verify all imports resolve
3. **Type Check**: Run mypy/pyright
4. **Test Execution**: Run test suite
5. **Content Verification**: Compare AST structures

## Troubleshooting

### Common Issues
- **Syntax Errors**: Review AST parsing errors
- **Import Errors**: Check import paths and dependencies
- **Type Errors**: Update type hints to 3.11 syntax
- **Test Failures**: Review breaking changes

### Rollback Procedure
1. Restore from backup
2. Review migration log
3. Identify problematic files
4. Fix issues manually
5. Re-run migration

## Best Practices

1. **Incremental Migration**: Migrate in small batches
2. **Checkpoint System**: Save progress regularly
3. **Validation Loops**: Multiple validation passes
4. **Error Tracking**: Log all issues
5. **Documentation**: Document all changes

## Resources

- Python 3.11 Release Notes
- PEP 585 (Type Hinting Generics)
- PEP 604 (Union Types)
- Python Migration Guide
- Type Checking Tools (mypy, pyright)'''

# Global instance
knowledge_base_manager = KnowledgeBaseManager()
