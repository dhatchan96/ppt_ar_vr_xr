import React, { useState, useEffect } from 'react';
import { FaSpinner, FaCheck, FaTimes, FaEye, FaTrash, FaPlay, FaPause, FaFilter, FaDownload, FaArrowLeft, FaTrashAlt, FaCheckSquare, FaSquare, FaFile, FaFolder, FaChevronDown, FaChevronUp, FaFlask, FaMagic, FaCopy } from 'react-icons/fa';
import API from '../api';

const JobMonitorPage = ({ onJobComplete, onBack }) => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [cleanupInProgress, setCleanupInProgress] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);
  const [showErrorDetails, setShowErrorDetails] = useState(false);
  const [selectedError, setSelectedError] = useState(null);
  const [expandedTestAutomationJobs, setExpandedTestAutomationJobs] = useState(new Set());
  const [selectedLocatorFiles, setSelectedLocatorFiles] = useState({}); // { jobId: Set of selected file indices }
  const [loadingJobDetails, setLoadingJobDetails] = useState(false); // Track if we're loading job details
  const [generatedPrompt, setGeneratedPrompt] = useState(null); // Store generated prompt
  const [showPromptModal, setShowPromptModal] = useState(false); // Show prompt in modal
  const [expandedMigrationJobs, setExpandedMigrationJobs] = useState(new Set());
  const [selectedPackages, setSelectedPackages] = useState({}); // { jobId: Set of selected package names }
  const [pythonVersion, setPythonVersion] = useState('3.11'); // Default Python version for migration prompts
  const [promptType, setPromptType] = useState('full'); // 'full' or 'package-only' for migration prompts
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Unique values for dropdowns
  const [uniqueAITs, setUniqueAITs] = useState([]);
  const [uniqueSPKs, setUniqueSPKs] = useState([]);
  const [uniqueRepos, setUniqueRepos] = useState([]);
  const [uniqueStatuses, setUniqueStatuses] = useState([]);

  useEffect(() => {
    loadJobs();
    // Poll for job updates every 5 seconds
    const interval = setInterval(loadJobs, 5000);
    setPollingInterval(interval);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [jobs, filterAIT, filterSPK, filterRepo, filterStatus]);

  const loadJobs = async () => {
    try {
      setLoading(true);
      console.log('🔄 Loading jobs...');
      
      // Add cache-busting parameter to ensure fresh data
      const timestamp = Date.now();
      const response = await API.get(`/api/jobs?limit=50&_t=${timestamp}`);
      const jobsData = response.data.jobs || [];
      
      // Parse result_data if it's a string
      const parsedJobs = jobsData.map(job => {
        if (job.result_data && typeof job.result_data === 'string') {
          try {
            job.result_data = JSON.parse(job.result_data);
          } catch (e) {
            console.warn('Failed to parse result_data for job:', job.job_id, e);
            job.result_data = null;
          }
        }
        return job;
      });
      
      console.log(`📋 Loaded ${parsedJobs.length} jobs:`, parsedJobs.map(job => ({ 
        id: job.job_id, 
        status: job.status,
        isTestAutomation: isTestAutomationJob(job),
        hasResultData: !!job.result_data
      })));
      setJobs(parsedJobs);
      
      // Extract unique values for filters
      const aits = Array.from(new Set(jobsData.map(job => job.ait_tag).filter(Boolean)));
      const spks = Array.from(new Set(jobsData.map(job => job.spk_tag).filter(Boolean)));
      const repos = Array.from(new Set(jobsData.map(job => job.repo_name).filter(Boolean)));
      const statuses = Array.from(new Set(jobsData.map(job => job.status).filter(Boolean)));
      
      setUniqueAITs(aits);
      setUniqueSPKs(spks);
      setUniqueRepos(repos);
      setUniqueStatuses(statuses);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...jobs];
    
    if (filterAIT) {
      filtered = filtered.filter(job => job.ait_tag === filterAIT);
    }
    
    if (filterSPK) {
      filtered = filtered.filter(job => job.spk_tag === filterSPK);
    }
    
    if (filterRepo) {
      filtered = filtered.filter(job => job.repo_name === filterRepo);
    }
    
    if (filterStatus) {
      filtered = filtered.filter(job => job.status === filterStatus);
    }
    
    setFilteredJobs(filtered);
  };

  const clearFilters = () => {
    setFilterAIT('');
    setFilterSPK('');
    setFilterRepo('');
    setFilterStatus('');
  };

  const getDisplayName = (value, type) => {
    if (!value) return 'Unknown';
    
    switch (type) {
      case 'ait':
        return value === 'AIT' ? 'Default AIT' : value;
      case 'spk':
        return value === 'SPK-DEFAULT' ? 'Default SPK' : value;
      case 'repo':
        return value === 'unknown-repo' ? 'Unknown Repository' : value;
      default:
        return value;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <FaPause className="text-warning" />;
      case 'running':
        return <FaSpinner className="text-primary fa-spin" />;
      case 'completed':
        return <FaCheck className="text-success" />;
      case 'failed':
        return <FaTimes className="text-danger" />;
      case 'cancelled':
        return <FaTimes className="text-secondary" />;
      default:
        return <FaEye className="text-muted" />;
    }
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'badge bg-warning text-dark',
      running: 'badge bg-primary',
      completed: 'badge bg-success',
      failed: 'badge bg-danger',
      cancelled: 'badge bg-secondary'
    };
    return statusClasses[status] || 'badge bg-secondary';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  const getDuration = (startedAt, completedAt) => {
    if (!startedAt) return 'N/A';
    const start = new Date(startedAt);
    const end = completedAt ? new Date(completedAt) : new Date();
    const duration = Math.round((end - start) / 1000);
    return `${duration}s`;
  };

  const isTestAutomationJob = (job) => {
    // Check if job is a test automation job
    // First, ensure result_data is parsed if it's a string
    let resultData = job.result_data;
    if (resultData && typeof resultData === 'string') {
      try {
        resultData = JSON.parse(resultData);
      } catch (e) {
        return false;
      }
    }
    
    // Check multiple indicators for test automation jobs
    if (resultData && typeof resultData === 'object' && resultData !== null) {
      return resultData.scan_type === 'test_automation' || 
             resultData.scan_type === 'test_automation_scan' ||
             resultData.locator_files !== undefined ||
             resultData.test_locators_path !== undefined ||
             resultData.total_test_cases !== undefined;
    }
    
    // Also check progress message as fallback (for jobs that might not have result_data yet)
    // Only check if result_data doesn't exist or doesn't have scan_type
    if (!resultData || (resultData && typeof resultData === 'object' && !resultData.scan_type)) {
      if (job.progress && typeof job.progress === 'string') {
        const progressLower = job.progress.toLowerCase();
        // More specific check - must contain both "test cases" or "locator files" to be test automation
        const isTestAutoProgress = (progressLower.includes('test cases') && progressLower.includes('found')) || 
               (progressLower.includes('locator files') && progressLower.includes('found')) ||
               progressLower.includes('test automation scan');
        if (isTestAutoProgress) {
          console.log('✅ Test Automation detected via progress message:', job.job_id, job.progress);
          return true;
        }
      }
    }
    
    return false;
  };

  const isMigrationJob = (job) => {
    // Check if job is a Python migration job
    let resultData = job.result_data;
    if (resultData && typeof resultData === 'string') {
      try {
        resultData = JSON.parse(resultData);
      } catch (e) {
        return false;
      }
    }
    
    // Check multiple indicators for migration jobs
    if (resultData && typeof resultData === 'object' && resultData !== null) {
      return resultData.scan_type === 'migration' ||
             resultData.packages !== undefined ||
             resultData.detected_files !== undefined ||
             resultData.total_packages !== undefined;
    }
    
    // Also check progress message as fallback
    if (!resultData || (resultData && typeof resultData === 'object' && !resultData.scan_type)) {
      if (job.progress && typeof job.progress === 'string') {
        const progressLower = job.progress.toLowerCase();
        if (progressLower.includes('python migration') ||
            progressLower.includes('python packages') ||
            progressLower.includes('migration scan')) {
          return true;
        }
      }
    }
    
    return false;
  };

  const toggleMigrationPackages = (jobId) => {
    const newExpanded = new Set(expandedMigrationJobs);
    if (newExpanded.has(jobId)) {
      newExpanded.delete(jobId);
    } else {
      newExpanded.add(jobId);
    }
    setExpandedMigrationJobs(newExpanded);
  };

  const togglePackageSelection = (jobId, packageName) => {
    const newSelected = { ...selectedPackages };
    if (!newSelected[jobId]) {
      newSelected[jobId] = new Set();
    }
    const packageSet = new Set(newSelected[jobId]);
    if (packageSet.has(packageName)) {
      packageSet.delete(packageName);
    } else {
      packageSet.add(packageName);
    }
    newSelected[jobId] = packageSet;
    setSelectedPackages(newSelected);
  };

  const selectAllPackages = (jobId, packages) => {
    const newSelected = { ...selectedPackages };
    const allPackageNames = new Set(packages.map(p => p.name));
    newSelected[jobId] = allPackageNames;
    setSelectedPackages(newSelected);
  };

  const deselectAllPackages = (jobId) => {
    const newSelected = { ...selectedPackages };
    newSelected[jobId] = new Set();
    setSelectedPackages(newSelected);
  };

  const isPackageSelected = (jobId, packageName) => {
    return selectedPackages[jobId]?.has(packageName) || false;
  };

  const getSelectedPackagesCount = (jobId) => {
    return selectedPackages[jobId]?.size || 0;
  };

  // Generate Python migration prompt
  const generateMigrationPrompt = async (jobId, resultData, pythonVersion, promptType = 'full') => {
    const selectedPackageNames = Array.from(selectedPackages[jobId] || []);
    if (selectedPackageNames.length === 0) {
      alert('Please select at least one package to generate the migration prompt.');
      return;
    }

    try {
      const response = await API.post('/api/knowledge-base/python-migration/generate-prompt', {
        python_version: pythonVersion,
        selected_packages: selectedPackageNames,
        prompt_type: promptType // 'full' or 'package-only'
      });

      if (response.data.success) {
        setGeneratedPrompt(response.data.prompt);
        setShowPromptModal(true);
      } else {
        alert('Failed to generate migration prompt: ' + (response.data.error || 'Unknown error'));
      }
    } catch (err) {
      console.error('Error generating migration prompt:', err);
      alert('Failed to generate migration prompt: ' + (err.response?.data?.error || err.message));
    }
  };

  const toggleTestAutomationFiles = (jobId) => {
    const newExpanded = new Set(expandedTestAutomationJobs);
    if (newExpanded.has(jobId)) {
      newExpanded.delete(jobId);
    } else {
      newExpanded.add(jobId);
    }
    setExpandedTestAutomationJobs(newExpanded);
  };

  const toggleLocatorFileSelection = (jobId, fileIndex) => {
    const newSelected = { ...selectedLocatorFiles };
    if (!newSelected[jobId]) {
      newSelected[jobId] = new Set();
    }
    const fileSet = new Set(newSelected[jobId]);
    if (fileSet.has(fileIndex)) {
      fileSet.delete(fileIndex);
    } else {
      fileSet.add(fileIndex);
    }
    newSelected[jobId] = fileSet;
    setSelectedLocatorFiles(newSelected);
  };

  const selectAllLocatorFiles = (jobId, locatorFiles) => {
    const newSelected = { ...selectedLocatorFiles };
    const allIndices = new Set(locatorFiles.map((_, index) => index));
    newSelected[jobId] = allIndices;
    setSelectedLocatorFiles(newSelected);
  };

  const deselectAllLocatorFiles = (jobId) => {
    const newSelected = { ...selectedLocatorFiles };
    newSelected[jobId] = new Set();
    setSelectedLocatorFiles(newSelected);
  };

  const isLocatorFileSelected = (jobId, fileIndex) => {
    return selectedLocatorFiles[jobId]?.has(fileIndex) || false;
  };

  const getSelectedLocatorFilesCount = (jobId) => {
    return selectedLocatorFiles[jobId]?.size || 0;
  };

  // Generate automation unit test creation prompt
  const generatePrompt = (jobId, resultData) => {
    const selectedIndices = selectedLocatorFiles[jobId] || new Set();
    if (selectedIndices.size === 0) {
      alert('Please select at least one locator file to generate the prompt.');
      return;
    }

    // Get selected locator files
    const selectedFiles = resultData.locator_files.filter((file, index) => selectedIndices.has(index));
    
    // Get markdown content
    const markdownContent = resultData.markdown_content || '';

    // Build the prompt using best practices
    let prompt = `# Automation Unit Test Creation Prompt

## Context
You are an expert test automation engineer tasked with creating comprehensive unit tests for a web application. This prompt provides you with:
1. Test case specifications (from functional test cases)
2. Locator files containing element selectors and component code
3. Application context and structure

## Objective
Generate production-ready, maintainable unit tests that:
- Follow best practices and industry standards
- Are well-structured and easy to understand
- Include proper setup, teardown, and error handling
- Use appropriate testing frameworks and patterns
- Cover positive and negative test scenarios
- Include meaningful assertions and validations

---

## Test Case Specifications

The following test cases have been extracted from functional test documentation:

\`\`\`markdown
${markdownContent}
\`\`\`

---

## Locator Files and Component Code

The following locator files contain element selectors and component implementations that should be used in the tests:

`;

    // Add each selected locator file
    selectedFiles.forEach((file, index) => {
      prompt += `### File ${index + 1}: ${file.file_name}\n`;
      prompt += `**Path:** \`${file.file_path}\`\n`;
      prompt += `**Size:** ${(file.file_size / 1024).toFixed(2)} KB\n`;
      prompt += `**Extension:** ${file.file_extension || 'N/A'}\n`;
      
      // Show warning if content was truncated
      if (file.is_truncated) {
        prompt += `**Note:** File content was truncated (file size: ${(file.file_size / 1024).toFixed(2)} KB exceeds 50KB limit)\n`;
      }
      prompt += `\n`;
      
      if (file.file_content) {
        const language = file.file_extension === '.js' || file.file_extension === '.jsx' ? 'javascript' 
          : file.file_extension === '.ts' || file.file_extension === '.tsx' ? 'typescript' 
          : file.file_extension === '.py' ? 'python'
          : file.file_extension === '.java' ? 'java'
          : file.file_extension === '.css' ? 'css'
          : file.file_extension === '.html' ? 'html'
          : file.file_extension === '.json' ? 'json'
          : file.file_extension === '.yaml' || file.file_extension === '.yml' ? 'yaml'
          : file.file_extension === '.xml' ? 'xml'
          : file.file_extension === '.md' ? 'markdown'
          : 'text';
        prompt += `**File Content:**\n\`\`\`${language}\n${file.file_content}\n\`\`\`\n\n`;
      } else {
        prompt += `**File Content:** Not available (binary file or read error)\n\n`;
      }
    });

    prompt += `---

## Instructions

Based on the test case specifications and locator files provided above, please generate:

1. **Test Structure**: Organize tests using appropriate testing frameworks (e.g., Jest, Mocha, Cypress, Playwright, Selenium)
2. **Test Cases**: Create unit tests for each test case specified in the markdown documentation
3. **Locator Usage**: Use the element selectors and component code from the locator files to interact with the application
4. **Best Practices**: 
   - Use Page Object Model (POM) pattern where applicable
   - Implement proper wait strategies
   - Include data-driven testing where relevant
   - Add meaningful test descriptions and comments
   - Ensure tests are independent and can run in any order
   - Include proper error handling and cleanup
5. **Assertions**: Include comprehensive assertions to validate:
   - Element visibility and interactions
   - Data validation
   - State changes
   - Expected behaviors
6. **Code Quality**: 
   - Follow DRY (Don't Repeat Yourself) principles
   - Use descriptive variable and function names
   - Add appropriate comments and documentation
   - Ensure code is maintainable and extensible

## Output Format

Please provide:
1. Complete test code files ready for execution
2. Brief explanation of the test structure and approach
3. Any dependencies or setup requirements
4. Recommendations for test data management
5. Suggestions for test maintenance and improvements

## Additional Context

- **Repository:** ${resultData.repo_name || 'N/A'}
- **Locators Path:** ${resultData.test_locators_path || 'N/A'}
- **Total Test Cases:** ${resultData.total_test_cases || 0}
- **Selected Locator Files:** ${selectedFiles.length} of ${resultData.locator_files.length}

---

Please generate the automation unit tests following the specifications above.`;

    setGeneratedPrompt(prompt);
    return prompt;
  };

  // Download prompt as text file
  const downloadPrompt = () => {
    if (!generatedPrompt) return;
    
    const blob = new Blob([generatedPrompt], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `automation_test_prompt_${selectedJob?.job_id || 'prompt'}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Copy prompt to clipboard
  const copyPromptToClipboard = () => {
    if (!generatedPrompt) return;
    navigator.clipboard.writeText(generatedPrompt).then(() => {
      alert('Prompt copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy prompt:', err);
      alert('Failed to copy prompt to clipboard.');
    });
  };

  // Simple markdown to HTML converter
  const renderMarkdown = (markdown) => {
    if (!markdown) return null;
    
    // Split into lines
    const lines = markdown.split('\n');
    const elements = [];
    let inTable = false;
    let tableRows = [];
    
    lines.forEach((line, index) => {
      line = line.trim();
      
      // Headers
      if (line.startsWith('# ')) {
        elements.push(<h1 key={index} style={{ fontSize: '1.5rem', fontWeight: 'bold', marginTop: '1rem', marginBottom: '0.5rem' }}>{line.substring(2)}</h1>);
      } else if (line.startsWith('## ')) {
        elements.push(<h2 key={index} style={{ fontSize: '1.25rem', fontWeight: 'bold', marginTop: '1rem', marginBottom: '0.5rem' }}>{line.substring(3)}</h2>);
      } else if (line.startsWith('### ')) {
        elements.push(<h3 key={index} style={{ fontSize: '1.1rem', fontWeight: 'bold', marginTop: '0.75rem', marginBottom: '0.5rem' }}>{line.substring(4)}</h3>);
      }
      // Table rows
      else if (line.startsWith('|') && line.endsWith('|')) {
        if (!inTable) {
          inTable = true;
          tableRows = [];
        }
        const cells = line.split('|').map(c => c.trim()).filter(c => c);
        // Skip separator rows (|---|---|)
        if (cells.every(c => c.match(/^[-:]+$/))) {
          return; // Skip separator row
        }
        tableRows.push(cells);
      }
      // End of table or empty line
      else {
        if (inTable && tableRows.length > 0) {
          elements.push(
            <div key={`table-${index}`} className="table-responsive mb-3">
              <table className="table table-bordered table-sm">
                <thead>
                  <tr>
                    {tableRows[0].map((cell, i) => (
                      <th key={i} style={{ backgroundColor: '#f8f9fa', fontWeight: 'bold' }}>{cell}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tableRows.slice(1).map((row, rowIdx) => (
                    <tr key={rowIdx}>
                      {row.map((cell, cellIdx) => (
                        <td key={cellIdx}>{cell.replace(/\\\|/g, '|')}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
          tableRows = [];
          inTable = false;
        }
        if (line) {
          // Regular paragraph
          elements.push(<p key={index} style={{ marginBottom: '0.5rem' }}>{line.replace(/\\\|/g, '|')}</p>);
        } else if (elements.length > 0) {
          // Empty line - add spacing
          elements.push(<br key={`br-${index}`} />);
        }
      }
    });
    
    // Handle table at end of document
    if (inTable && tableRows.length > 0) {
      elements.push(
        <div key="table-end" className="table-responsive mb-3">
          <table className="table table-bordered table-sm">
            <thead>
              <tr>
                {tableRows[0].map((cell, i) => (
                  <th key={i} style={{ backgroundColor: '#f8f9fa', fontWeight: 'bold' }}>{cell}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableRows.slice(1).map((row, rowIdx) => (
                <tr key={rowIdx}>
                  {row.map((cell, cellIdx) => (
                    <td key={cellIdx}>{cell.replace(/\\\|/g, '|')}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }
    
    return <div>{elements}</div>;
  };

  const truncateError = (errorMessage, maxLength = 3) => {
    if (!errorMessage) return '';
    if (errorMessage.length <= maxLength) return errorMessage;
    return errorMessage.substring(0, maxLength) + '...';
  };

  const cancelJob = async (jobId) => {
    try {
      await API.post(`/api/jobs/${jobId}/cancel`);
      showToast('Job cancelled successfully', 'success');
      loadJobs();
    } catch (error) {
      showToast('Failed to cancel job', 'error');
    }
  };

  const showJobDetails = async (job) => {
    // Reset generated prompt when opening a new job
    setGeneratedPrompt(null);
    setShowPromptModal(false);
    
    // Ensure result_data is parsed if it's a string
    const jobCopy = { ...job };
    if (jobCopy.result_data && typeof jobCopy.result_data === 'string') {
      try {
        jobCopy.result_data = JSON.parse(jobCopy.result_data);
      } catch (e) {
        console.warn('Failed to parse result_data in showJobDetails:', job.job_id, e);
      }
    }
    
    // For test automation and migration jobs, always fetch fresh data to ensure we have the latest result_data
    // For other jobs, only fetch if result_data is missing
    const isTestAuto = isTestAutomationJob(job);
    const isMigration = isMigrationJob(job);
    const shouldFetch = isTestAuto || isMigration || !jobCopy.result_data;
    
    // Show modal immediately with current data
    setSelectedJob(jobCopy);
    setShowDetails(true);
    
    // If we need to fetch, show loading state and fetch in background
    if (shouldFetch && job.job_id) {
      setLoadingJobDetails(true);
      try {
        console.log('📥 Fetching fresh job data for:', job.job_id, isTestAuto ? '(test automation - always fetch)' : isMigration ? '(migration - always fetch)' : '(missing result_data)');
        const response = await API.get(`/api/jobs/${job.job_id}/status`);
        
        // Parse response.data if it's a string (some API configurations return JSON as string)
        let responseData = response.data;
        if (typeof responseData === 'string') {
          try {
            console.log('📦 Parsing response.data from string, length:', responseData.length);
            // Replace NaN values with null before parsing (NaN is not valid JSON)
            // Handle NaN in various contexts: "key": NaN, "key": NaN, "key": NaN]
            const cleanedString = responseData
              .replace(/:\s*NaN\s*([,}\]])/g, ': null$1')  // Replace NaN with null
              .replace(/:\s*Infinity\s*([,}\]])/g, ': null$1')  // Replace Infinity with null
              .replace(/:\s*-Infinity\s*([,}\]])/g, ': null$1');  // Replace -Infinity with null
            responseData = JSON.parse(cleanedString);
            console.log('✅ Successfully parsed response.data from string');
          } catch (e) {
            console.error('❌ Failed to parse response.data from string:', e);
            console.error('String preview:', responseData.substring(0, 500));
            // Try to fix common JSON issues and retry
            try {
              console.log('🔄 Attempting to fix JSON string...');
              let fixedString = responseData
                .replace(/:\s*NaN\s*([,}])/g, ': null$1')  // Replace NaN with null
                .replace(/:\s*Infinity\s*([,}])/g, ': null$1')  // Replace Infinity with null
                .replace(/:\s*-Infinity\s*([,}])/g, ': null$1');  // Replace -Infinity with null
              responseData = JSON.parse(fixedString);
              console.log('✅ Successfully parsed after fixing JSON string');
            } catch (e2) {
              console.error('❌ Failed to parse even after fixing:', e2);
              responseData = null;
            }
          }
        }
        
        console.log('📥 API Response - Summary:', {
          status: response.status,
          has_data: !!responseData,
          data_type: typeof responseData,
          data_is_object: typeof responseData === 'object' && responseData !== null && !Array.isArray(responseData),
          data_is_string: typeof responseData === 'string',
          data_keys: responseData && typeof responseData === 'object' && !Array.isArray(responseData) ? Object.keys(responseData) : 'not an object',
          has_result_data: responseData && typeof responseData === 'object' && !Array.isArray(responseData) ? 'result_data' in responseData : false,
          result_data_value: responseData?.result_data,
          result_data_type: typeof responseData?.result_data,
          result_data_is_string: typeof responseData?.result_data === 'string',
          result_data_is_object: typeof responseData?.result_data === 'object' && responseData?.result_data !== null,
          result_data_is_null: responseData?.result_data === null,
          result_data_is_undefined: responseData?.result_data === undefined
        });
        
        if (responseData) {
          // Create updated job copy with fresh data
          const updatedJob = { ...jobCopy };
          
          // Update all fields from the fresh data
          if (responseData.status) updatedJob.status = responseData.status;
          if (responseData.progress) updatedJob.progress = responseData.progress;
          if (responseData.created_at) updatedJob.created_at = responseData.created_at;
          if (responseData.started_at) updatedJob.started_at = responseData.started_at;
          if (responseData.completed_at) updatedJob.completed_at = responseData.completed_at;
          if (responseData.error_message) updatedJob.error_message = responseData.error_message;
          
          // Check if result_data exists (could be string, object, or null)
          const resultDataRaw = responseData.result_data;
          console.log('🔍 Processing result_data from API:', {
            exists: resultDataRaw !== null && resultDataRaw !== undefined,
            type: typeof resultDataRaw,
            is_string: typeof resultDataRaw === 'string',
            is_object: typeof resultDataRaw === 'object' && resultDataRaw !== null,
            is_null: resultDataRaw === null,
            is_undefined: resultDataRaw === undefined,
            value_preview: resultDataRaw ? (typeof resultDataRaw === 'string' ? resultDataRaw.substring(0, 200) : JSON.stringify(resultDataRaw).substring(0, 200)) : 'null/undefined'
          });
          
          // Handle result_data - it could be null, undefined, string, or object
          if (resultDataRaw !== null && resultDataRaw !== undefined) {
            let freshResultData = resultDataRaw;
            if (typeof freshResultData === 'string') {
              try {
                console.log('📦 Parsing result_data from string, length:', freshResultData.length);
                freshResultData = JSON.parse(freshResultData);
                console.log('✅ Successfully parsed result_data from string');
              } catch (e) {
                console.error('❌ Failed to parse fresh result_data:', e);
                console.error('String preview:', freshResultData.substring(0, 500));
                freshResultData = null;
              }
            } else if (typeof freshResultData === 'object' && freshResultData !== null) {
              console.log('✅ result_data is already an object, no parsing needed');
            }
            // Ensure we're setting the result_data properly
            updatedJob.result_data = freshResultData;
            console.log('✅ Got fresh result_data:', {
              result_data_type: typeof freshResultData,
              is_object: typeof freshResultData === 'object' && freshResultData !== null,
              is_null: freshResultData === null,
              is_undefined: freshResultData === undefined,
              has_locator_files: !!freshResultData?.locator_files,
              locator_files_type: typeof freshResultData?.locator_files,
              locator_files_is_array: Array.isArray(freshResultData?.locator_files),
              locator_files_length: freshResultData?.locator_files?.length || 0,
              has_markdown: !!freshResultData?.markdown_content,
              all_keys: freshResultData && typeof freshResultData === 'object' ? Object.keys(freshResultData) : []
            });
            console.log('✅ Updated job.result_data:', {
              has_result_data: !!updatedJob.result_data,
              result_data_type: typeof updatedJob.result_data,
              result_data_keys: updatedJob.result_data && typeof updatedJob.result_data === 'object' ? Object.keys(updatedJob.result_data) : []
            });
          } else {
            console.warn('⚠️ No result_data in API response for job:', job.job_id);
          }
          
          // Update the selected job with fresh data (this will trigger re-render)
          setSelectedJob(updatedJob);
        }
      } catch (error) {
        console.error('❌ Failed to fetch fresh job data:', error);
        console.error('Error details:', error.response?.data || error.message);
      } finally {
        setLoadingJobDetails(false);
      }
    }
  };

  const handleShowErrorDetails = (errorMessage, job) => {
    setSelectedError({ errorMessage, job });
    setShowErrorDetails(true);
  };

  const showToast = (message, type = 'info') => {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  const cleanupOldJobs = async (days = 7) => {
    let cleanupMessage = '';
    let cleanupType = '';
    const counts = getJobCountsByStatus();
    
    if (days === 0) {
      cleanupType = 'all_completed';
      const jobsToClean = getJobsToBeCleanedUp(0);
      cleanupMessage = `Are you sure you want to clean up ALL completed/failed/cancelled jobs?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs with status:\n` +
                      `• COMPLETED\n` +
                      `• FAILED\n` +
                      `• CANCELLED\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    } else if (days === 1) {
      cleanupType = 'time_based_24h';
      const jobsToClean = getJobsToBeCleanedUp(1);
      cleanupMessage = `Are you sure you want to clean up completed/failed/cancelled jobs from the last 24 hours?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs that are completed, failed, or cancelled.\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    } else {
      cleanupType = 'time_based';
      const jobsToClean = getJobsToBeCleanedUp(days);
      cleanupMessage = `Are you sure you want to clean up completed/failed/cancelled jobs older than ${days} days?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs that are completed, failed, or cancelled.\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    }
    
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Cleanup cancelled by user');
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cleanup');
      }
      
      console.log(`🧹 Starting cleanup - Type: ${cleanupType}, Days: ${days}`);
      const response = await API.post(`/api/jobs/cleanup?days=${days}`);
      const data = response.data;
      
      console.log('✅ Cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} old jobs`, 'success');
        console.log(`🧹 Cleanup completed: ${data.deleted_count} jobs removed`);
      } else {
        showToast('No old jobs found to clean up', 'info');
        console.log('🧹 Cleanup completed: No jobs to remove');
      }
      
      await loadJobs();
      
      setTimeout(async () => {
        console.log('🔄 Second reload after cleanup...');
        await loadJobs();
      }, 1000);
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cleanup');
      
    } catch (error) {
      console.error('Cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup jobs';
      showToast(errorMessage, 'error');
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  const getJobCountsByStatus = () => {
    const counts = {
      completed: 0,
      failed: 0,
      cancelled: 0,
      running: 0,
      pending: 0,
      other: 0
    };
    
    jobs.forEach(job => {
      const status = job.status?.toLowerCase();
      if (status === 'completed') counts.completed++;
      else if (status === 'failed') counts.failed++;
      else if (status === 'cancelled') counts.cancelled++;
      else if (status === 'running') counts.running++;
      else if (status === 'pending') counts.pending++;
      else counts.other++;
    });
    
    return counts;
  };

  const getJobsToBeCleanedUp = (days) => {
    const now = new Date();
    const jobsToClean = [];
    
    jobs.forEach(job => {
      const status = job.status?.toLowerCase();
      if (status === 'completed' || status === 'failed' || status === 'cancelled') {
        if (days === 0) {
          // All completed/failed/cancelled jobs
          jobsToClean.push(job);
        } else {
          // Time-based cleanup
          const jobDate = new Date(job.created_at);
          const diffTime = Math.abs(now - jobDate);
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          
          if (diffDays > days) {
            jobsToClean.push(job);
          }
        }
      }
    });
    
    return jobsToClean;
  };

  const cleanupCancelledJobsOnly = async () => {
    const counts = getJobCountsByStatus();
    const cleanupMessage = `Are you sure you want to clean up ONLY cancelled jobs?\n\n` +
                          `Current job counts:\n` +
                          `• CANCELLED: ${counts.cancelled} jobs (will be cleaned up)\n` +
                          `• COMPLETED: ${counts.completed} jobs (will NOT be affected)\n` +
                          `• FAILED: ${counts.failed} jobs (will NOT be affected)\n` +
                          `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                          `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                          `This will permanently delete jobs with status:\n` +
                          `• CANCELLED\n\n` +
                          `⚠️  This will NOT affect:\n` +
                          `• COMPLETED jobs\n` +
                          `• FAILED jobs\n` +
                          `• RUNNING jobs\n` +
                          `• PENDING jobs\n` +
                          `• Any other active jobs\n\n` +
                          `This action cannot be undone.`;
    
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Cancelled jobs cleanup cancelled by user');
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cancelled jobs cleanup');
      }
      
      console.log('🧹 Starting cancelled jobs cleanup');
      const response = await API.post('/api/jobs/cleanup?status=cancelled');
      const data = response.data;
      
      console.log('✅ Cancelled jobs cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} cancelled jobs`, 'success');
        console.log(`🧹 Cancelled jobs cleanup completed: ${data.deleted_count} jobs removed`);
      } else {
        showToast('No cancelled jobs found to clean up', 'info');
        console.log('🧹 Cancelled jobs cleanup completed: No jobs to remove');
      }
      
      await loadJobs();
      
      setTimeout(async () => {
        console.log('🔄 Second reload after cancelled jobs cleanup...');
        await loadJobs();
      }, 1000);
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cancelled jobs cleanup');
      
    } catch (error) {
      console.error('Cancelled jobs cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup cancelled jobs';
      showToast(errorMessage, 'error');
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  const cleanupTestAutomationJobsOnly = async () => {
    // Count test automation jobs
    const testAutomationJobs = jobs.filter(job => isTestAutomationJob(job));
    const testAutoByStatus = {
      completed: testAutomationJobs.filter(j => j.status?.toLowerCase() === 'completed').length,
      failed: testAutomationJobs.filter(j => j.status?.toLowerCase() === 'failed').length,
      cancelled: testAutomationJobs.filter(j => j.status?.toLowerCase() === 'cancelled').length,
      running: testAutomationJobs.filter(j => j.status?.toLowerCase() === 'running').length,
      pending: testAutomationJobs.filter(j => j.status?.toLowerCase() === 'pending').length
    };
    
    const totalToCleanup = testAutoByStatus.completed + testAutoByStatus.failed + testAutoByStatus.cancelled;
    
    const cleanupMessage = `Are you sure you want to clean up ONLY test automation jobs?\n\n` +
                          `Test Automation Jobs:\n` +
                          `• COMPLETED: ${testAutoByStatus.completed} jobs (will be cleaned up)\n` +
                          `• FAILED: ${testAutoByStatus.failed} jobs (will be cleaned up)\n` +
                          `• CANCELLED: ${testAutoByStatus.cancelled} jobs (will be cleaned up)\n` +
                          `• RUNNING: ${testAutoByStatus.running} jobs (will NOT be affected)\n` +
                          `• PENDING: ${testAutoByStatus.pending} jobs (will NOT be affected)\n\n` +
                          `Total test automation jobs to be cleaned: ${totalToCleanup}\n\n` +
                          `All Other Jobs (will NOT be affected):\n` +
                          `• Total: ${jobs.length - testAutomationJobs.length} jobs\n\n` +
                          `This will permanently delete test automation jobs with status:\n` +
                          `• COMPLETED\n` +
                          `• FAILED\n` +
                          `• CANCELLED\n\n` +
                          `⚠️  This will NOT affect:\n` +
                          `• Non-test-automation jobs (code scans, plugin scans, etc.)\n` +
                          `• Test automation jobs that are RUNNING or PENDING\n\n` +
                          `This action cannot be undone.`;
    
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Test automation jobs cleanup cancelled by user');
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during test automation jobs cleanup');
      }
      
      console.log('🧹 Starting test automation jobs cleanup');
      const response = await API.post('/api/jobs/cleanup?job_type=test_automation');
      const data = response.data;
      
      console.log('✅ Test automation jobs cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} test automation jobs`, 'success');
        console.log(`🧹 Test automation jobs cleanup completed: ${data.deleted_count} jobs removed`);
      } else {
        showToast('No test automation jobs found to clean up', 'info');
        console.log('🧹 Test automation jobs cleanup completed: No jobs to remove');
      }
      
      await loadJobs();
      
      setTimeout(async () => {
        console.log('🔄 Second reload after test automation jobs cleanup...');
        await loadJobs();
      }, 1000);
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after test automation jobs cleanup');
      
    } catch (error) {
      console.error('Test automation jobs cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup test automation jobs';
      showToast(errorMessage, 'error');
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  return (
    <div className="container-fluid mt-4 px-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div className="d-flex align-items-center">
          {onBack && (
            <button 
              className="btn btn-outline-secondary me-3"
              onClick={onBack}
            >
              <FaArrowLeft className="me-1" />
              Back
            </button>
          )}
          <h2>🔍 Job Monitor</h2>
        </div>
        <div className="d-flex gap-2">
          <button 
            className={`btn btn-outline-primary btn-sm ${showFilters ? 'active' : ''}`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <FaFilter className="me-1" />
            Filters
          </button>
          <button 
            className="btn btn-outline-secondary btn-sm"
            onClick={clearFilters}
            disabled={!filterAIT && !filterSPK && !filterRepo && !filterStatus}
          >
            Clear
          </button>
          <button 
            className="btn btn-outline-info btn-sm" 
            onClick={loadJobs}
            disabled={loading}
          >
            {loading ? <FaSpinner className="fa-spin" /> : 'Refresh'}
          </button>
        </div>
      </div>

             {/* Filter Section */}
       {showFilters && !showDetails && (
         <div className="card mb-4">
           <div className="card-header">
             <h6 className="mb-0">
               <FaFilter className="me-2" />
               Filter Jobs
             </h6>
           </div>
           <div className="card-body">
             <div className="row g-3">
               <div className="col-md-3">
                 <label className="form-label">AIT (Application Integration Team)</label>
                 <select
                   className="form-select"
                   value={filterAIT}
                   onChange={(e) => setFilterAIT(e.target.value)}
                 >
                   <option value="">All AITs</option>
                   {uniqueAITs.map(ait => (
                     <option key={ait} value={ait}>
                       {getDisplayName(ait, 'ait')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">SPK (Specific Product/Workstream Key)</label>
                 <select
                   className="form-select"
                   value={filterSPK}
                   onChange={(e) => setFilterSPK(e.target.value)}
                 >
                   <option value="">All SPKs</option>
                   {uniqueSPKs.map(spk => (
                     <option key={spk} value={spk}>
                       {getDisplayName(spk, 'spk')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">Repository Name</label>
                 <select
                   className="form-select"
                   value={filterRepo}
                   onChange={(e) => setFilterRepo(e.target.value)}
                 >
                   <option value="">All Repositories</option>
                   {uniqueRepos.map(repo => (
                     <option key={repo} value={repo}>
                       {getDisplayName(repo, 'repo')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">Job Status</label>
                 <select
                   className="form-select"
                   value={filterStatus}
                   onChange={(e) => setFilterStatus(e.target.value)}
                 >
                   <option value="">All Statuses</option>
                   {uniqueStatuses.map(status => (
                     <option key={status} value={status}>
                       {status.charAt(0).toUpperCase() + status.slice(1)}
                     </option>
                   ))}
                 </select>
               </div>
             </div>
             
             {/* Active Filters Display */}
             {(filterAIT || filterSPK || filterRepo || filterStatus) && (
               <div className="mt-3">
                 <small className="text-muted">Active filters:</small>
                 <div className="d-flex flex-wrap gap-2 mt-1">
                   {filterAIT && (
                     <span className="badge bg-primary">
                       AIT: {getDisplayName(filterAIT, 'ait')}
                     </span>
                   )}
                   {filterSPK && (
                     <span className="badge bg-info">
                       SPK: {getDisplayName(filterSPK, 'spk')}
                     </span>
                   )}
                   {filterRepo && (
                     <span className="badge bg-success">
                       Repo: {getDisplayName(filterRepo, 'repo')}
                     </span>
                   )}
                   {filterStatus && (
                     <span className="badge bg-warning">
                       Status: {filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1)}
                     </span>
                   )}
                 </div>
               </div>
             )}
           </div>
         </div>
       )}

       {/* Statistics Summary */}
       {!showDetails && (
         <div className="row mb-4">
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-primary">{filteredJobs.length}</h4>
                 <small className="text-muted">Filtered Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-success">{jobs.length}</h4>
                 <small className="text-muted">Total Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-warning">
                   {filteredJobs.filter(job => job.status === 'running').length}
                 </h4>
                 <small className="text-muted">Running Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-info">
                   {filteredJobs.filter(job => job.status === 'completed').length}
                 </h4>
                 <small className="text-muted">Completed Jobs</small>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Cleanup Controls */}
       {!showDetails && (
         <div className="card mb-4">
           <div className="card-header">
             <h6 className="mb-0">
               <FaTrash className="me-2" />
               Job Management
             </h6>
           </div>
           <div className="card-body">
             <div className="alert alert-info mb-3">
               <strong>⚠️  Important:</strong> Cleanup operations only affect jobs with status COMPLETED, FAILED, or CANCELLED. 
               Running, pending, and other active jobs are never affected by cleanup operations.
             </div>
             
             {/* Job Counts Summary */}
             <div className="row mb-3">
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-success fw-bold">{getJobCountsByStatus().completed}</div>
                   <small className="text-muted">Completed</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-danger fw-bold">{getJobCountsByStatus().failed}</div>
                   <small className="text-muted">Failed</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-warning fw-bold">{getJobCountsByStatus().cancelled}</div>
                   <small className="text-muted">Cancelled</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-primary fw-bold">{getJobCountsByStatus().running}</div>
                   <small className="text-muted">Running</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-info fw-bold">{getJobCountsByStatus().pending}</div>
                   <small className="text-muted">Pending</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-secondary fw-bold">{getJobCountsByStatus().other}</div>
                   <small className="text-muted">Other</small>
                 </div>
               </div>
             </div>
             <div className="d-flex gap-2">
               <div className="btn-group">
                 <button 
                   className="btn btn-outline-warning dropdown-toggle" 
                   data-bs-toggle="dropdown"
                   aria-expanded="false"
                   disabled={cleanupInProgress}
                 >
                   {cleanupInProgress ? (
                     <>
                       <FaSpinner className="fa-spin me-1" />
                       Cleaning...
                     </>
                   ) : (
                     <>
                       <FaTrash className="me-1" />
                       Cleanup Jobs
                     </>
                   )}
                 </button>
                 <ul className="dropdown-menu">
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(0.04)} disabled={cleanupInProgress}>Last 1 hour</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(1)} disabled={cleanupInProgress}>Last 24 hours</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(3)} disabled={cleanupInProgress}>Last 3 days</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(7)} disabled={cleanupInProgress}>Last 7 days</button></li>
                  <li><button className="dropdown-item" onClick={() => cleanupOldJobs(30)} disabled={cleanupInProgress}>Last 30 days</button></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><button className="dropdown-item text-warning" onClick={() => cleanupCancelledJobsOnly()} disabled={cleanupInProgress}>
                    <FaTimes className="me-2" />Only Cancelled Jobs
                  </button></li>
                  <li><button className="dropdown-item text-info" onClick={() => cleanupTestAutomationJobsOnly()} disabled={cleanupInProgress}>
                    <FaFlask className="me-2" />Only Test Automation Jobs
                  </button></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><button className="dropdown-item text-danger" onClick={() => cleanupOldJobs(0)} disabled={cleanupInProgress}>All Completed/Failed/Cancelled Jobs</button></li>
                </ul>
               </div>
               
               {/* Cleanup Options Explanation */}
               <div className="mt-3">
                <small className="text-muted">
                  <strong>Cleanup Options:</strong><br/>
                  • <strong>Time-based:</strong> Removes completed/failed/cancelled jobs older than specified time<br/>
                  • <strong>Only Cancelled:</strong> Removes only cancelled jobs (keeps completed/failed jobs)<br/>
                  • <strong>Only Test Automation:</strong> Removes only test automation jobs that are completed/failed/cancelled<br/>
                  • <strong>All Completed/Failed/Cancelled:</strong> Removes all jobs with these statuses regardless of age
                </small>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Jobs Table */}
       {!showDetails && (
         <div className="card">
           <div className="card-header">
             <h6 className="mb-0">
               <FaEye className="me-2" />
               Job Results ({filteredJobs.length} of {jobs.length} jobs)
             </h6>
           </div>
           <div className="card-body p-0">
             {cleanupInProgress && (
               <div className="alert alert-info text-center m-3">
                 <FaSpinner className="fa-spin me-2" />
                 Cleaning up old jobs... Please wait.
               </div>
             )}
             
             {filteredJobs.length === 0 ? (
               <div className="text-center text-muted py-5">
                 <FaEye className="mb-3" style={{ fontSize: '3rem' }} />
                 <p>{jobs.length === 0 ? 'No scan jobs found' : 'No jobs match the current filters'}</p>
                 <small>Repository scans will appear here</small>
               </div>
             ) : (
                               <div className="table-responsive">
                  <table className="table table-hover mb-0 job-monitor-table">
                   <thead className="table-light">
                     <tr>
                       <th>Status</th>
                       <th>Repository</th>
                       <th>ID</th>
                       <th>Type</th>
                       <th>Progress</th>
                       <th>Created</th>
                       <th>Duration</th>
                       <th>Actions</th>
                     </tr>
                   </thead>
                  <tbody>
                    {filteredJobs.map((job) => {
                      // Ensure result_data is parsed
                      let resultData = job.result_data;
                      if (resultData && typeof resultData === 'string') {
                        try {
                          resultData = JSON.parse(resultData);
                          job.result_data = resultData;
                        } catch (e) {
                          console.warn('Failed to parse result_data in render:', job.job_id);
                        }
                      }
                      
                      const isTestAutomation = isTestAutomationJob(job);
                      const isMigration = isMigrationJob(job);
                      const isExpanded = expandedTestAutomationJobs.has(job.job_id);
                      const isMigrationExpanded = expandedMigrationJobs.has(job.job_id);
                      const locatorFiles = (resultData && typeof resultData === 'object') ? (resultData.locator_files || []) : [];
                      const packages = (resultData && typeof resultData === 'object') ? (resultData.packages || []) : [];
                      
                      // Debug logging for all completed jobs to help troubleshoot
                      if (job.status === 'completed') {
                        console.log('📊 Job Analysis:', {
                          job_id: job.job_id,
                          isTestAutomation,
                          progress: job.progress,
                          has_result_data: !!job.result_data,
                          result_data_type: typeof job.result_data,
                          scan_type: resultData?.scan_type,
                          has_locator_files: !!resultData?.locator_files,
                          locator_files_count: locatorFiles.length,
                          has_clone_url: !!resultData?.clone_url,
                          repo_url: job.repo_url,
                          will_show_view_results: !isTestAutomation && !!job.result_data,
                          will_show_chevron: isTestAutomation && !!job.result_data
                        });
                      }
                      
                      return (
                        <React.Fragment key={job.job_id}>
                          <tr>
                            <td>
                              <div className="d-flex align-items-center">
                                {getStatusIcon(job.status)}
                                <span className={`ms-2 ${getStatusBadge(job.status)}`}>
                                  {job.status}
                                </span>
                              </div>
                            </td>
                            <td>
                              <div>
                                {(() => {
                                  // Get repository name/URL - prioritize result_data for test automation
                                  let repoName = 'Unknown';
                                  let repoUrl = '';
                                  
                                  // Ensure result_data is an object
                                  const resultData = (job.result_data && typeof job.result_data === 'object') 
                                    ? job.result_data 
                                    : (typeof job.result_data === 'string' ? JSON.parse(job.result_data) : null);
                                  
                                  if ((isTestAutomation || isMigration) && resultData) {
                                    repoUrl = resultData.clone_url || resultData.repo_url || job.repo_url || '';
                                    repoName = repoUrl ? repoUrl.split('/').pop().replace('.git', '') : (resultData.repo_name || job.repo_name || 'Unknown');
                                  } else {
                                    repoUrl = job.repo_url || '';
                                    repoName = repoUrl ? repoUrl.split('/').pop().replace('.git', '') : (job.repo_name || 'Unknown');
                                  }
                                  
                                  return (
                                    <>
                                      <strong>{repoName}</strong>
                                      {repoUrl && (
                                        <>
                                          <br />
                                          <small className="text-muted">{repoUrl}</small>
                                        </>
                                      )}
                                      {isTestAutomation && job.status === 'completed' && (
                                        <div className="mt-1">
                                          <span className="badge bg-warning text-dark">
                                            <FaFlask className="me-1" />
                                            Test Automation
                                          </span>
                                        </div>
                                      )}
                                      {isMigration && job.status === 'completed' && (
                                        <div className="mt-1">
                                          <span className="badge bg-info text-dark">
                                            <FaMagic className="me-1" />
                                            Migration
                                          </span>
                                        </div>
                                      )}
                                    </>
                                  );
                                })()}
                              </div>
                            </td>
                            <td>
                              {(() => {
                                // Try to get ID from result_data first, then scan_id, then job_id
                                const idValue = job.result_data?.scan_id || job.scan_id || job.job_id;
                                // Extract numeric part or use first part of UUID
                                const numericId = idValue.match(/\d+/)?.[0] || idValue.substring(0, 8);
                                return (
                                  <span className="badge bg-secondary">
                                    {numericId}
                                  </span>
                                );
                              })()}
                            </td>
                            <td>
                              <span className="badge bg-info">
                                {getDisplayName(job.spk_tag, 'spk')}
                              </span>
                            </td>
                            <td>
                              <div className="progress-container">
                                <div className="progress" style={{ height: '8px', borderRadius: '4px' }}>
                                  <div 
                                    className={`progress-bar ${
                                      job.status === 'completed' ? 'bg-success' :
                                      job.status === 'failed' ? 'bg-danger' :
                                      job.status === 'running' ? 'bg-primary' :
                                      'bg-secondary'
                                    }`}
                                    style={{ 
                                      width: job.status === 'completed' ? '100%' :
                                             job.status === 'failed' ? '100%' :
                                             job.status === 'running' ? '50%' : '0%',
                                      borderRadius: '4px',
                                      transition: 'width 0.3s ease'
                                    }}
                                  >
                                  </div>
                                </div>
                                <small className="job-progress-text">
                                  {job.progress}
                                </small>
                                {job.error_message && (
                                  <div className="error-container" style={{ maxWidth: '160px', width: '160px', overflow: 'hidden', justifyContent: 'center' }}>
                                    <button 
                                      className="error-info-btn"
                                      onClick={() => handleShowErrorDetails(job.error_message, job)}
                                      title="View Error Details"
                                      style={{ flexShrink: 0, width: '16px', height: '16px' }}
                                    >
                                      i
                                    </button>
                                  </div>
                                )}
                              </div>
                            </td>
                            <td>
                              <small>
                                {new Date(job.created_at).toLocaleDateString()}<br/>
                                {new Date(job.created_at).toLocaleTimeString()}
                              </small>
                            </td>
                            <td>
                              <small>{getDuration(job.started_at, job.completed_at)}</small>
                            </td>
                            <td>
                              <div className="btn-group btn-group-sm">
                                <button
                                  className="btn btn-outline-primary"
                                  onClick={() => showJobDetails(job)}
                                  title="View Details"
                                >
                                  <FaEye />
                                </button>
                                {job.status === 'running' && (
                                  <button
                                    className="btn btn-outline-warning"
                                    onClick={() => cancelJob(job.job_id)}
                                    title="Cancel Job"
                                  >
                                    <FaTimes />
                                  </button>
                                )}
                                {job.status === 'completed' && (
                                  <>
                                    {/* Show chevron button for test automation jobs with result_data */}
                                    {isTestAutomation && job.result_data && (
                                      <button
                                        className="btn btn-outline-info"
                                        onClick={() => {
                                          console.log('🔍 Toggle locator files for test automation job:', job.job_id, 'Current expanded:', isExpanded);
                                          toggleTestAutomationFiles(job.job_id);
                                        }}
                                        title={isExpanded ? "Hide Locator Files" : "Show Locator Files"}
                                      >
                                        {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
                                      </button>
                                    )}
                                    {/* Show chevron button for migration jobs with result_data */}
                                    {isMigration && job.result_data && (
                                      <button
                                        className="btn btn-outline-info"
                                        onClick={() => {
                                          console.log('🔍 Toggle packages for migration job:', job.job_id, 'Current expanded:', isMigrationExpanded);
                                          toggleMigrationPackages(job.job_id);
                                        }}
                                        title={isMigrationExpanded ? "Hide Packages" : "Show Packages"}
                                      >
                                        {isMigrationExpanded ? <FaChevronUp /> : <FaChevronDown />}
                                      </button>
                                    )}
                                    {/* Show View Results button for regular (non-test-automation, non-migration) jobs */}
                                    {/* Show button if job has result_data OR has scan_id (for jobs where results are stored separately) */}
                                    {!isTestAutomation && !isMigration && (job.result_data || job.scan_id) && (
                                      <button
                                        className="btn btn-outline-success"
                                        onClick={async () => {
                                          console.log('🔍 View Results clicked for job:', job.job_id);
                                          
                                          // If result_data exists, use it directly
                                          if (job.result_data) {
                                            onJobComplete(job.result_data);
                                            return;
                                          }
                                          
                                          // If result_data is null but scan_id exists, fetch results from metrics endpoint
                                          if (job.scan_id) {
                                            try {
                                              console.log('📥 Fetching scan results from /api/command-center/metrics for scan_id:', job.scan_id);
                                              // Use the metrics endpoint with scan_id parameter (same as ThreatGuardDashboard does)
                                              const metricsResponse = await API.get(`/api/command-center/metrics?scan_id=${job.scan_id}`);
                                              
                                              if (metricsResponse.data && !metricsResponse.data.error) {
                                                console.log('✅ Found metrics data for scan_id:', job.scan_id);
                                                // The metrics endpoint returns the full scan data structure
                                                onJobComplete(metricsResponse.data);
                                              } else {
                                                console.warn('⚠️ No metrics data found for scan_id:', job.scan_id);
                                                // Fallback: try scan-history
                                                try {
                                                  const historyResponse = await API.get('/api/scan-history');
                                                  const scanHistory = historyResponse.data || [];
                                                  const matchingScan = scanHistory.find(scan => scan.scan_id === job.scan_id);
                                                  if (matchingScan) {
                                                    console.log('✅ Found matching scan in history:', matchingScan.scan_id);
                                                    onJobComplete(matchingScan);
                                                  } else {
                                                    // Final fallback: create minimal object with scan_id
                                                    onJobComplete({ scan_id: job.scan_id, job_id: job.job_id });
                                                  }
                                                } catch (historyError) {
                                                  console.error('❌ Error fetching from scan-history:', historyError);
                                                  onJobComplete({ scan_id: job.scan_id, job_id: job.job_id });
                                                }
                                              }
                                            } catch (error) {
                                              console.error('❌ Error fetching metrics:', error);
                                              // Fallback: create minimal object with scan_id
                                              onJobComplete({ scan_id: job.scan_id, job_id: job.job_id });
                                            }
                                          } else {
                                            // No scan_id either, just pass minimal data
                                            onJobComplete({ job_id: job.job_id });
                                          }
                                        }}
                                        title="View Results"
                                      >
                                        <FaDownload />
                                      </button>
                                    )}
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                          {/* Expanded row for test automation locator files */}
                          {isTestAutomation && isExpanded && job.status === 'completed' && (() => {
                            // Ensure result_data is parsed
                            const resultData = (job.result_data && typeof job.result_data === 'object') 
                              ? job.result_data 
                              : (typeof job.result_data === 'string' ? JSON.parse(job.result_data) : null);
                            const files = resultData?.locator_files || [];
                            
                            return (
                            <tr key={`${job.job_id}-expanded`}>
                              <td colSpan="8" className="bg-light">
                                <div className="p-3">
                                  <h6 className="mb-3">
                                    <FaFolder className="me-2" />
                                    Locator Files Found ({files.length} files)
                                  </h6>
                                  {resultData?.test_locators_path && (
                                    <div className="mb-3">
                                      <strong>Locators Path:</strong> 
                                      <code className="ms-2">{resultData.test_locators_path}</code>
                                    </div>
                                  )}
                                  {files.length > 0 ? (
                                    <div>
                                      <div className="d-flex justify-content-between align-items-center mb-2">
                                        <div>
                                          <small className="text-muted">
                                            {getSelectedLocatorFilesCount(job.job_id)} of {files.length} files selected
                                          </small>
                                        </div>
                                        <div className="btn-group btn-group-sm">
                                          <button
                                            className="btn btn-outline-primary btn-sm"
                                            onClick={() => selectAllLocatorFiles(job.job_id, files)}
                                            title="Select All"
                                          >
                                            Select All
                                          </button>
                                          <button
                                            className="btn btn-outline-secondary btn-sm"
                                            onClick={() => deselectAllLocatorFiles(job.job_id)}
                                            title="Deselect All"
                                          >
                                            Deselect All
                                          </button>
                                        </div>
                                      </div>
                                      <div className="table-responsive" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                                        <table className="table table-sm table-hover">
                                          <thead className="table-light sticky-top">
                                            <tr>
                                              <th style={{ width: '40px' }}>
                                                <input
                                                  type="checkbox"
                                                  checked={getSelectedLocatorFilesCount(job.job_id) === files.length && files.length > 0}
                                                  onChange={(e) => {
                                                    if (e.target.checked) {
                                                      selectAllLocatorFiles(job.job_id, files);
                                                    } else {
                                                      deselectAllLocatorFiles(job.job_id);
                                                    }
                                                  }}
                                                  title="Select/Deselect All"
                                                />
                                              </th>
                                              <th>File Name</th>
                                              <th>Path</th>
                                              <th>Size</th>
                                              <th>Extension</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {files.map((file, index) => (
                                              <tr key={index} className={isLocatorFileSelected(job.job_id, index) ? 'table-active' : ''}>
                                                <td>
                                                  <input
                                                    type="checkbox"
                                                    checked={isLocatorFileSelected(job.job_id, index)}
                                                    onChange={() => toggleLocatorFileSelection(job.job_id, index)}
                                                    title={`Select ${file.file_name}`}
                                                  />
                                                </td>
                                                <td>
                                                  <FaFile className="me-2 text-muted" />
                                                  {file.file_name}
                                                </td>
                                                <td>
                                                  <code style={{ fontSize: '0.85rem' }}>{file.file_path}</code>
                                                </td>
                                                <td>
                                                  <small>{(file.file_size / 1024).toFixed(2)} KB</small>
                                                </td>
                                                <td>
                                                  <span className="badge bg-secondary">{file.file_extension || 'N/A'}</span>
                                                </td>
                                              </tr>
                                            ))}
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="alert alert-info mb-0">
                                      No locator files found in the specified path.
                                    </div>
                                  )}
                                  {resultData?.total_test_cases && (
                                    <div className="mt-3">
                                      <strong>Test Cases Processed:</strong> {resultData.total_test_cases}
                                    </div>
                                  )}
                                </div>
                              </td>
                            </tr>
                            );
                          })()}
                          {/* Expanded row for migration packages */}
                          {isMigration && isMigrationExpanded && job.status === 'completed' && (() => {
                            // Ensure result_data is parsed
                            let resultData = null;
                            if (job.result_data) {
                              if (typeof job.result_data === 'object') {
                                resultData = job.result_data;
                              } else if (typeof job.result_data === 'string') {
                                try {
                                  resultData = JSON.parse(job.result_data);
                                } catch (e) {
                                  console.warn('Failed to parse result_data in expanded row:', job.job_id, e);
                                  resultData = null;
                                }
                              }
                            }
                            const packages = resultData?.packages || [];
                            
                            // If no result data, show message
                            if (!resultData) {
                              return (
                                <tr key={`${job.job_id}-migration-expanded`}>
                                  <td colSpan="8" className="bg-light">
                                    <div className="p-3">
                                      <div className="alert alert-warning mb-0">
                                        <small>No result data available. The job may still be processing or data is not available yet.</small>
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              );
                            }
                            
                            return (
                            <tr key={`${job.job_id}-migration-expanded`}>
                              <td colSpan="8" className="bg-light">
                                <div className="p-3">
                                  <h6 className="mb-3">
                                    <FaMagic className="me-2" />
                                    Python Packages Found ({packages.length} packages)
                                  </h6>
                                  {resultData?.detected_files && resultData.detected_files.length > 0 && (
                                    <div className="mb-3">
                                      <strong>Detected in files:</strong> 
                                      <code className="ms-2">{resultData.detected_files.join(', ')}</code>
                                    </div>
                                  )}
                                  {packages.length > 0 ? (
                                    <div>
                                      <div className="row mb-3">
                                        <div className="col-md-6">
                                          <label className="form-label"><strong>Select Python Version:</strong></label>
                                          <div className="btn-group w-100" role="group">
                                            <button
                                              type="button"
                                              className={`btn ${pythonVersion === '3.11' ? 'btn-primary' : 'btn-outline-primary'}`}
                                              onClick={() => setPythonVersion('3.11')}
                                            >
                                              Python 3.11
                                            </button>
                                            <button
                                              type="button"
                                              className={`btn ${pythonVersion === '3.13' ? 'btn-primary' : 'btn-outline-primary'}`}
                                              onClick={() => setPythonVersion('3.13')}
                                            >
                                              Python 3.13
                                            </button>
                                          </div>
                                        </div>
                                        <div className="col-md-6">
                                          <label className="form-label"><strong>Prompt Type:</strong></label>
                                          <div className="btn-group w-100" role="group">
                                            <button
                                              type="button"
                                              className={`btn ${promptType === 'full' ? 'btn-primary' : 'btn-outline-primary'}`}
                                              onClick={() => setPromptType('full')}
                                              title="Full migration prompt with complete instructions"
                                            >
                                              Full Prompt
                                            </button>
                                            <button
                                              type="button"
                                              className={`btn ${promptType === 'package-only' ? 'btn-primary' : 'btn-outline-primary'}`}
                                              onClick={() => setPromptType('package-only')}
                                              title="Simple prompt to upgrade selected packages only"
                                            >
                                              Package Only
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                      <div className="d-flex justify-content-between align-items-center mb-2">
                                        <div>
                                          <small className="text-muted">
                                            {getSelectedPackagesCount(job.job_id)} of {packages.length} packages selected
                                          </small>
                                        </div>
                                        <div className="btn-group btn-group-sm">
                                          <button
                                            className="btn btn-outline-primary btn-sm"
                                            onClick={() => selectAllPackages(job.job_id, packages)}
                                            title="Select All"
                                          >
                                            Select All
                                          </button>
                                          <button
                                            className="btn btn-outline-secondary btn-sm"
                                            onClick={() => deselectAllPackages(job.job_id)}
                                            title="Deselect All"
                                          >
                                            Deselect All
                                          </button>
                                          <button
                                            className="btn btn-success btn-sm"
                                            onClick={() => generateMigrationPrompt(job.job_id, resultData, pythonVersion, promptType)}
                                            disabled={getSelectedPackagesCount(job.job_id) === 0}
                                            title="Generate Migration Prompt"
                                          >
                                            <FaMagic className="me-1" />
                                            Generate Prompt
                                          </button>
                                        </div>
                                      </div>
                                      <div className="table-responsive" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                                        <table className="table table-sm table-hover">
                                          <thead className="table-light sticky-top">
                                            <tr>
                                              <th style={{ width: '40px' }}>
                                                <FaCheckSquare />
                                              </th>
                                              <th>Package Name</th>
                                              <th>Source</th>
                                              <th>Type</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {packages.map((pkg, index) => (
                                              <tr key={index}>
                                                <td>
                                                  <button
                                                    className="btn btn-sm p-0"
                                                    onClick={() => togglePackageSelection(job.job_id, pkg.name)}
                                                    title={isPackageSelected(job.job_id, pkg.name) ? "Deselect" : "Select"}
                                                  >
                                                    {isPackageSelected(job.job_id, pkg.name) ? (
                                                      <FaCheckSquare className="text-primary" />
                                                    ) : (
                                                      <FaSquare className="text-muted" />
                                                    )}
                                                  </button>
                                                </td>
                                                <td>
                                                  <strong>{pkg.name}</strong>
                                                </td>
                                                <td>
                                                  <small className="text-muted">{pkg.source}</small>
                                                </td>
                                                <td>
                                                  <span className="badge bg-secondary">{pkg.type}</span>
                                                </td>
                                              </tr>
                                            ))}
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="alert alert-info">
                                      <FaMagic className="me-2" />
                                      No Python packages detected in this repository.
                                    </div>
                                  )}
                                </div>
                              </td>
                            </tr>
                            );
                          })()}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                 </table>
               </div>
             )}
           </div>
         </div>
       )}

      {/* Job Details Modal */}
      {showDetails && selectedJob && (
        <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
          <div className="modal-dialog modal-xl modal-dialog-scrollable" style={{ zIndex: 1055, maxWidth: '90vw' }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Job Details</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowDetails(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row g-3 g-md-4">
                  <div className="col-12 col-lg-6">
                    <div className="card h-100">
                      <div className="card-header">
                        <h6 className="mb-0">Job Information</h6>
                      </div>
                      <div className="card-body">
                        <div className="table-responsive">
                          <table className="table table-sm mb-0">
                            <tbody>
                              <tr>
                                <td className="text-nowrap" style={{ width: '25%' }}><strong>Job ID:</strong></td>
                                <td style={{ wordBreak: 'break-all' }}>
                                  <code style={{ fontSize: '0.8rem' }} className="d-block">{selectedJob.job_id}</code>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Status:</strong></td>
                                <td>
                                  <span className={getStatusBadge(selectedJob.status)}>
                                    {selectedJob.status}
                                  </span>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Repository:</strong></td>
                                <td style={{ wordBreak: 'break-all' }}>
                                  {(() => {
                                    const isTestAuto = isTestAutomationJob(selectedJob);
                                    const isMigration = isMigrationJob(selectedJob);
                                    const repoUrl = (isTestAuto || isMigration) && selectedJob.result_data 
                                      ? (selectedJob.result_data.clone_url || selectedJob.result_data.repo_url)
                                      : selectedJob.repo_url;
                                    return repoUrl ? (
                                      <small className="text-muted d-block">{repoUrl}</small>
                                    ) : (
                                      <small className="text-muted d-block">N/A</small>
                                    );
                                  })()}
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Type:</strong></td>
                                <td>
                                  {isTestAutomationJob(selectedJob) ? (
                                    <span className="badge bg-warning text-dark">
                                      <FaFlask className="me-1" />
                                      Test Automation
                                    </span>
                                  ) : isMigrationJob(selectedJob) ? (
                                    <span className="badge bg-info text-dark">
                                      <FaMagic className="me-1" />
                                      Migration
                                    </span>
                                  ) : (
                                    selectedJob.repo_type || 'repository'
                                  )}
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>AIT:</strong></td>
                                <td>{getDisplayName(selectedJob.ait_tag, 'ait')}</td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>SPK:</strong></td>
                                <td>{getDisplayName(selectedJob.spk_tag, 'spk')}</td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Created:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.created_at)}</small>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Started:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.started_at)}</small>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Completed:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.completed_at)}</small>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-lg-6">
                    <div className="card h-100">
                      <div className="card-header">
                        <h6 className="mb-0">Progress & Results</h6>
                      </div>
                      <div className="card-body">
                        <div className="mb-3">
                          <strong>Progress:</strong>
                          <p className="text-muted mt-1 mb-2">{selectedJob.progress}</p>
                        </div>
                        {selectedJob.error_message && (
                          <div className="mb-3">
                            <strong>Error:</strong>
                            <div className="alert alert-danger mt-1">
                              <small>{selectedJob.error_message}</small>
                            </div>
                          </div>
                        )}
                        {(selectedJob.result_data || isTestAutomationJob(selectedJob) || isMigrationJob(selectedJob)) && (
                          <div className="mb-3">
                            <strong>Results:</strong>
                            {(() => {
                              // Ensure result_data is an object (parse if needed)
                              // Also check if it's already parsed but might need re-parsing
                              let resultData = selectedJob.result_data;
                              
                              console.log('🔍 Modal rendering - initial resultData:', {
                                type: typeof resultData,
                                is_null: resultData === null,
                                is_undefined: resultData === undefined,
                                is_object: typeof resultData === 'object' && resultData !== null,
                                is_array: Array.isArray(resultData),
                                keys: resultData && typeof resultData === 'object' ? Object.keys(resultData) : [],
                                value: resultData
                              });
                              
                              // If it's a string, parse it
                              if (typeof resultData === 'string') {
                                try {
                                  resultData = JSON.parse(resultData);
                                  console.log('📦 Parsed result_data from string in modal');
                                } catch (e) {
                                  console.warn('Failed to parse result_data in modal:', e);
                                  resultData = null;
                                }
                              }
                              
                              // If resultData is null or undefined, try to get it from jobs state
                              if (!resultData) {
                                const jobFromState = jobs.find(j => j.job_id === selectedJob.job_id);
                                if (jobFromState && jobFromState.result_data) {
                                  resultData = jobFromState.result_data;
                                  if (typeof resultData === 'string') {
                                    try {
                                      resultData = JSON.parse(resultData);
                                    } catch (e) {
                                      console.warn('Failed to parse result_data from jobs state:', e);
                                    }
                                  }
                                  console.log('📦 Using result_data from jobs state');
                                }
                              }
                              
                              console.log('🔍 Modal rendering - final resultData:', {
                                type: typeof resultData,
                                is_null: resultData === null,
                                is_undefined: resultData === undefined,
                                is_object: typeof resultData === 'object' && resultData !== null,
                                has_locator_files: !!resultData?.locator_files,
                                locator_files_type: typeof resultData?.locator_files,
                                locator_files_is_array: Array.isArray(resultData?.locator_files),
                                locator_files_length: resultData?.locator_files?.length || 0,
                                has_markdown: !!resultData?.markdown_content,
                                all_keys: resultData && typeof resultData === 'object' ? Object.keys(resultData) : []
                              });
                              
                              const isTestAuto = isTestAutomationJob(selectedJob);
                              const isMigration = isMigrationJob(selectedJob);
                              
                              if (isTestAuto) {
                                // Debug logging
                                console.log('🔍 Test Automation Job Modal - Full Debug:', {
                                  job_id: selectedJob.job_id,
                                  result_data_type: typeof selectedJob.result_data,
                                  result_data_raw: selectedJob.result_data,
                                  resultData_parsed: resultData,
                                  has_locator_files: !!resultData?.locator_files,
                                  locator_files_type: typeof resultData?.locator_files,
                                  locator_files_is_array: Array.isArray(resultData?.locator_files),
                                  locator_files_length: resultData?.locator_files?.length || 0,
                                  locator_files: resultData?.locator_files,
                                  total_locator_files: resultData?.total_locator_files,
                                  total_test_cases: resultData?.total_test_cases,
                                  has_markdown: !!resultData?.markdown_content,
                                  all_keys: resultData && typeof resultData === 'object' ? Object.keys(resultData) : []
                                });
                                
                                // Check if resultData is valid (not null, not undefined, is object with keys)
                                const hasValidData = resultData && 
                                  typeof resultData === 'object' && 
                                  resultData !== null && 
                                  !Array.isArray(resultData) &&
                                  Object.keys(resultData).length > 0;
                                
                                // If no resultData yet and we're loading, show loading message
                                if (!hasValidData && loadingJobDetails) {
                                  return (
                                    <div className="alert alert-info mt-2">
                                      <FaSpinner className="fa-spin me-2" />
                                      <small>Loading job results... Please wait.</small>
                                    </div>
                                  );
                                }
                                
                                // If no resultData and not loading, show error message
                                if (!hasValidData && !loadingJobDetails) {
                                  console.warn('⚠️ No valid resultData for test automation job:', {
                                    resultData,
                                    type: typeof resultData,
                                    is_null: resultData === null,
                                    is_undefined: resultData === undefined,
                                    is_object: typeof resultData === 'object',
                                    is_array: Array.isArray(resultData),
                                    keys: resultData && typeof resultData === 'object' ? Object.keys(resultData) : [],
                                    selectedJob_result_data: selectedJob.result_data,
                                    selectedJob_result_data_type: typeof selectedJob.result_data
                                  });
                                  return (
                                    <div className="alert alert-warning mt-2">
                                      <small>No result data available for this job. The job may still be processing or the data may not have been saved.</small>
                                    </div>
                                  );
                                }
                                
                                // If we don't have valid data yet, don't render anything (wait for data)
                                if (!hasValidData) {
                                  return null;
                                }
                                
                                return (
                                  <div className="mt-2">
                                    <div className="alert alert-info">
                                      <div className="row g-3 mb-3">
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-primary fs-4">{resultData.total_test_cases || 0}</div>
                                            <small className="text-muted">Test Cases</small>
                                          </div>
                                        </div>
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-success fs-4">{resultData.total_locator_files || 0}</div>
                                            <small className="text-muted">Locator Files</small>
                                          </div>
                                        </div>
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-info fs-4">
                                              <FaFolder className="me-1" />
                                              {resultData.test_locators_path || 'N/A'}
                                            </div>
                                            <small className="text-muted">Locators Path</small>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    {resultData.locator_files && Array.isArray(resultData.locator_files) && resultData.locator_files.length > 0 && (
                                      <div className="mt-3">
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                          <h6 className="mb-0">
                                            <FaFolder className="me-2" />
                                            Locator Files ({resultData.locator_files.length})
                                          </h6>
                                          <div className="btn-group btn-group-sm">
                                            <button
                                              className="btn btn-outline-primary btn-sm"
                                              onClick={() => selectAllLocatorFiles(selectedJob.job_id, resultData.locator_files)}
                                              title="Select All"
                                            >
                                              Select All
                                            </button>
                                            <button
                                              className="btn btn-outline-secondary btn-sm"
                                              onClick={() => deselectAllLocatorFiles(selectedJob.job_id)}
                                              title="Deselect All"
                                            >
                                              Deselect All
                                            </button>
                                          </div>
                                        </div>
                                        <div className="mb-2">
                                          <small className="text-muted">
                                            {getSelectedLocatorFilesCount(selectedJob.job_id)} of {resultData.locator_files.length} files selected
                                          </small>
                                        </div>
                                        <div className="table-responsive" style={{ maxHeight: '300px', overflowY: 'auto' }}>
                                          <table className="table table-sm table-hover">
                                            <thead className="table-light sticky-top">
                                              <tr>
                                                <th style={{ width: '40px' }}>
                                                  <input
                                                    type="checkbox"
                                                    checked={getSelectedLocatorFilesCount(selectedJob.job_id) === resultData.locator_files.length && resultData.locator_files.length > 0}
                                                    onChange={(e) => {
                                                      if (e.target.checked) {
                                                        selectAllLocatorFiles(selectedJob.job_id, resultData.locator_files);
                                                      } else {
                                                        deselectAllLocatorFiles(selectedJob.job_id);
                                                      }
                                                    }}
                                                    title="Select/Deselect All"
                                                  />
                                                </th>
                                                <th>File Name</th>
                                                <th>Path</th>
                                                <th>Size</th>
                                                <th>Extension</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              {resultData.locator_files.map((file, index) => (
                                            <tr key={index} className={isLocatorFileSelected(selectedJob.job_id, index) ? 'table-active' : ''}>
                                              <td>
                                                <input
                                                  type="checkbox"
                                                  checked={isLocatorFileSelected(selectedJob.job_id, index)}
                                                  onChange={() => toggleLocatorFileSelection(selectedJob.job_id, index)}
                                                  title={`Select ${file.file_name}`}
                                                />
                                              </td>
                                              <td>
                                                <FaFile className="me-2 text-muted" />
                                                {file.file_name}
                                              </td>
                                              <td>
                                                <code style={{ fontSize: '0.85rem' }}>{file.file_path}</code>
                                              </td>
                                              <td>
                                                <small>{(file.file_size / 1024).toFixed(2)} KB</small>
                                              </td>
                                              <td>
                                                <span className="badge bg-secondary">{file.file_extension || 'N/A'}</span>
                                              </td>
                                            </tr>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                    {/* Generate Prompt Button */}
                                    <div className="mt-3 d-flex justify-content-between align-items-center">
                                      <div>
                                        <small className="text-muted">
                                          {getSelectedLocatorFilesCount(selectedJob.job_id) > 0 
                                            ? `${getSelectedLocatorFilesCount(selectedJob.job_id)} file(s) selected for prompt generation`
                                            : 'Select locator files to generate automation test prompt'}
                                        </small>
                                      </div>
                                      <button
                                        className="btn btn-primary btn-sm"
                                        onClick={() => generatePrompt(selectedJob.job_id, resultData)}
                                        disabled={getSelectedLocatorFilesCount(selectedJob.job_id) === 0}
                                        title={getSelectedLocatorFilesCount(selectedJob.job_id) === 0 ? 'Please select at least one locator file' : 'Generate automation test prompt'}
                                      >
                                        <FaMagic className="me-2" />
                                        Generate Prompt
                                      </button>
                                    </div>
                                    {/* View and Download buttons (shown after prompt is generated) */}
                                    {generatedPrompt && (
                                      <div className="mt-3 d-flex gap-2 justify-content-end">
                                        <button
                                          className="btn btn-outline-info btn-sm"
                                          onClick={() => setShowPromptModal(true)}
                                          title="View Generated Prompt"
                                        >
                                          <FaEye className="me-2" />
                                          View Prompt
                                        </button>
                                        <button
                                          className="btn btn-outline-success btn-sm"
                                          onClick={downloadPrompt}
                                          title="Download Prompt as Text File"
                                        >
                                          <FaDownload className="me-2" />
                                          Download
                                        </button>
                                        <button
                                          className="btn btn-outline-secondary btn-sm"
                                          onClick={copyPromptToClipboard}
                                          title="Copy Prompt to Clipboard"
                                        >
                                          <FaCopy className="me-2" />
                                          Copy
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                    )}
                                    {(!resultData || !resultData.locator_files || !Array.isArray(resultData.locator_files) || resultData.locator_files.length === 0) && (
                                      <div className="mt-3">
                                        <div className="alert alert-warning">
                                          <small>
                                            {resultData && resultData.total_locator_files > 0 
                                              ? `Expected ${resultData.total_locator_files} locator files, but data is not available. This job was created before the fix was applied. Please create a new test automation scan to see locator files.`
                                              : !resultData
                                              ? 'Result data is not available for this job. This may be an older job created before the fix. Please create a new test automation scan.'
                                              : 'No locator files found.'}
                                          </small>
                                        </div>
                                      </div>
                                    )}
                                    {/* Markdown Content Display */}
                                    {resultData?.markdown_content && (
                                      <div className="mt-4">
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                          <h6 className="mb-0">
                                            <FaFile className="me-2" />
                                            Test Cases Documentation (Markdown)
                                          </h6>
                                        </div>
                                        <div 
                                          className="border rounded p-3 bg-light" 
                                          style={{ 
                                            maxHeight: '400px', 
                                            overflowY: 'auto',
                                            fontSize: '0.9rem',
                                            lineHeight: '1.6'
                                          }}
                                        >
                                          {renderMarkdown(resultData.markdown_content)}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              } else if (isMigration) {
                                // Migration job results
                                // Check if resultData is valid (not null, not undefined, is object with keys)
                                const hasValidData = resultData && 
                                  typeof resultData === 'object' && 
                                  resultData !== null && 
                                  !Array.isArray(resultData) &&
                                  Object.keys(resultData).length > 0;
                                
                                // If no resultData yet and we're loading, show loading message
                                if (!hasValidData && loadingJobDetails) {
                                  return (
                                    <div className="alert alert-info mt-2">
                                      <FaSpinner className="fa-spin me-2" />
                                      <small>Loading job results... Please wait.</small>
                                    </div>
                                  );
                                }
                                
                                // If no resultData and not loading, show error message
                                if (!hasValidData && !loadingJobDetails) {
                                  console.warn('⚠️ No valid resultData for migration job:', {
                                    resultData,
                                    type: typeof resultData,
                                    is_null: resultData === null,
                                    is_undefined: resultData === undefined,
                                    is_object: typeof resultData === 'object',
                                    is_array: Array.isArray(resultData),
                                    keys: resultData && typeof resultData === 'object' ? Object.keys(resultData) : [],
                                    selectedJob_result_data: selectedJob.result_data,
                                    selectedJob_result_data_type: typeof selectedJob.result_data
                                  });
                                  return (
                                    <div className="alert alert-warning mt-2">
                                      <small>No result data available for this job. The job may still be processing or the data may not have been saved.</small>
                                    </div>
                                  );
                                }
                                
                                // If we don't have valid data yet, don't render anything (wait for data)
                                if (!hasValidData) {
                                  return null;
                                }
                                
                                const packages = resultData?.packages || [];
                                return (
                                  <div className="mt-2">
                                    <div className="alert alert-info">
                                      <div className="row g-3 mb-3">
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-primary fs-4">{resultData?.total_packages || 0}</div>
                                            <small className="text-muted">Packages Found</small>
                                          </div>
                                        </div>
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-success fs-4">{resultData?.detected_files?.length || 0}</div>
                                            <small className="text-muted">Files Scanned</small>
                                          </div>
                                        </div>
                                        <div className="col-4">
                                          <div className="text-center p-2">
                                            <div className="fw-bold text-info fs-4">
                                              <FaMagic className="me-1" />
                                              Python Migration
                                            </div>
                                            <small className="text-muted">Scan Type</small>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    {packages.length > 0 ? (
                                      <div className="mt-3">
                                        <div className="row mb-3">
                                          <div className="col-md-6">
                                            <label className="form-label"><strong>Select Python Version:</strong></label>
                                            <div className="btn-group w-100" role="group">
                                              <button
                                                type="button"
                                                className={`btn ${pythonVersion === '3.11' ? 'btn-primary' : 'btn-outline-primary'}`}
                                                onClick={() => setPythonVersion('3.11')}
                                              >
                                                Python 3.11
                                              </button>
                                              <button
                                                type="button"
                                                className={`btn ${pythonVersion === '3.13' ? 'btn-primary' : 'btn-outline-primary'}`}
                                                onClick={() => setPythonVersion('3.13')}
                                              >
                                                Python 3.13
                                              </button>
                                            </div>
                                          </div>
                                          <div className="col-md-6">
                                            <label className="form-label"><strong>Prompt Type:</strong></label>
                                            <div className="btn-group w-100" role="group">
                                              <button
                                                type="button"
                                                className={`btn ${promptType === 'full' ? 'btn-primary' : 'btn-outline-primary'}`}
                                                onClick={() => setPromptType('full')}
                                                title="Full migration prompt with complete instructions"
                                              >
                                                Full Prompt
                                              </button>
                                              <button
                                                type="button"
                                                className={`btn ${promptType === 'package-only' ? 'btn-primary' : 'btn-outline-primary'}`}
                                                onClick={() => setPromptType('package-only')}
                                                title="Simple prompt to upgrade selected packages only"
                                              >
                                                Package Only
                                              </button>
                                            </div>
                                          </div>
                                        </div>
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                          <div>
                                            <small className="text-muted">
                                              {getSelectedPackagesCount(selectedJob.job_id)} of {packages.length} packages selected
                                            </small>
                                          </div>
                                          <div className="btn-group btn-group-sm">
                                            <button
                                              className="btn btn-outline-primary btn-sm"
                                              onClick={() => selectAllPackages(selectedJob.job_id, packages)}
                                              title="Select All"
                                            >
                                              Select All
                                            </button>
                                            <button
                                              className="btn btn-outline-secondary btn-sm"
                                              onClick={() => deselectAllPackages(selectedJob.job_id)}
                                              title="Deselect All"
                                            >
                                              Deselect All
                                            </button>
                                            <button
                                              className="btn btn-success btn-sm"
                                              onClick={() => generateMigrationPrompt(selectedJob.job_id, resultData, pythonVersion, promptType)}
                                              disabled={getSelectedPackagesCount(selectedJob.job_id) === 0}
                                              title="Generate Migration Prompt"
                                            >
                                              <FaMagic className="me-1" />
                                              Generate Prompt
                                            </button>
                                          </div>
                                        </div>
                                        <div className="table-responsive" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                                          <table className="table table-sm table-hover">
                                            <thead className="table-light sticky-top">
                                              <tr>
                                                <th style={{ width: '40px' }}>
                                                  <input
                                                    type="checkbox"
                                                    checked={getSelectedPackagesCount(selectedJob.job_id) === packages.length && packages.length > 0}
                                                    onChange={(e) => {
                                                      if (e.target.checked) {
                                                        selectAllPackages(selectedJob.job_id, packages);
                                                      } else {
                                                        deselectAllPackages(selectedJob.job_id);
                                                      }
                                                    }}
                                                    title="Select/Deselect All"
                                                  />
                                                </th>
                                                <th>Package Name</th>
                                                <th>Source</th>
                                                <th>Type</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              {packages.map((pkg, index) => (
                                                <tr key={index} className={isPackageSelected(selectedJob.job_id, pkg.name) ? 'table-active' : ''}>
                                                  <td>
                                                    <input
                                                      type="checkbox"
                                                      checked={isPackageSelected(selectedJob.job_id, pkg.name)}
                                                      onChange={() => togglePackageSelection(selectedJob.job_id, pkg.name)}
                                                      title={`Select ${pkg.name}`}
                                                    />
                                                  </td>
                                                  <td>
                                                    <strong>{pkg.name}</strong>
                                                  </td>
                                                  <td>
                                                    <small className="text-muted">{pkg.source}</small>
                                                  </td>
                                                  <td>
                                                    <span className="badge bg-secondary">{pkg.type}</span>
                                                  </td>
                                                </tr>
                                              ))}
                                            </tbody>
                                          </table>
                                        </div>
                                        {generatedPrompt && (
                                          <div className="mt-3 d-flex gap-2 justify-content-end">
                                            <button
                                              className="btn btn-outline-info btn-sm"
                                              onClick={() => setShowPromptModal(true)}
                                              title="View Generated Prompt"
                                            >
                                              <FaEye className="me-2" />
                                              View Prompt
                                            </button>
                                            <button
                                              className="btn btn-outline-success btn-sm"
                                              onClick={() => {
                                                const blob = new Blob([generatedPrompt], { type: 'text/plain' });
                                                const url = window.URL.createObjectURL(blob);
                                                const link = document.createElement('a');
                                                link.href = url;
                                                link.download = `python_migration_prompt_${pythonVersion}.txt`;
                                                link.click();
                                                window.URL.revokeObjectURL(url);
                                              }}
                                              title="Download Prompt as Text File"
                                            >
                                              <FaDownload className="me-2" />
                                              Download
                                            </button>
                                            <button
                                              className="btn btn-outline-secondary btn-sm"
                                              onClick={() => {
                                                navigator.clipboard.writeText(generatedPrompt);
                                                alert('Prompt copied to clipboard!');
                                              }}
                                              title="Copy Prompt to Clipboard"
                                            >
                                              <FaCopy className="me-2" />
                                              Copy
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    ) : (
                                      <div className="alert alert-warning mt-3">
                                        <small>No Python packages detected in this repository.</small>
                                      </div>
                                    )}
                                  </div>
                                );
                              } else {
                                // Regular job results
                                return (
                                  <div className="alert alert-success mt-1">
                                    <div className="row g-3">
                                      <div className="col-4">
                                        <div className="text-center p-2">
                                          <div className="fw-bold text-success fs-4">{resultData.files_scanned || 'N/A'}</div>
                                          <small className="text-muted">Files Scanned</small>
                                        </div>
                                      </div>
                                      <div className="col-4">
                                        <div className="text-center p-2">
                                          <div className="fw-bold text-warning fs-4">{resultData.summary?.total_issues || 0}</div>
                                          <small className="text-muted">Threats Found</small>
                                        </div>
                                      </div>
                                      <div className="col-4">
                                        <div className="text-center p-2">
                                          <div className="fw-bold text-info fs-4">{resultData.summary?.logic_bomb_risk_score || 0}/100</div>
                                          <small className="text-muted">Risk Score</small>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                );
                              }
                            })()}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowDetails(false)}
                >
                  Close
                </button>
                {selectedJob.status === 'completed' && selectedJob.result_data && !isTestAutomationJob(selectedJob) && !isMigrationJob(selectedJob) && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => {
                      console.log('🔍 View Results clicked for job:', selectedJob.job_id);
                      onJobComplete(selectedJob.result_data);
                      setShowDetails(false);
                    }}
                  >
                    View Results
                  </button>
                )}
              </div>
            </div>
          </div>
                     <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
         </div>
       )}

       {/* Prompt View Modal */}
       {showPromptModal && generatedPrompt && (
         <div className="modal fade show" style={{ display: 'block', zIndex: 1060 }} tabIndex="-1">
           <div className="modal-dialog modal-xl modal-dialog-scrollable" style={{ zIndex: 1065, maxWidth: '90vw' }}>
             <div className="modal-content">
               <div className="modal-header">
                 <h5 className="modal-title">
                   <FaMagic className="me-2" />
                   Generated Automation Test Prompt
                 </h5>
                 <button
                   type="button"
                   className="btn-close"
                   onClick={() => setShowPromptModal(false)}
                 ></button>
               </div>
               <div className="modal-body">
                 <div className="mb-3 d-flex gap-2 justify-content-end">
                   <button
                     className="btn btn-outline-success btn-sm"
                     onClick={downloadPrompt}
                     title="Download Prompt as Text File"
                   >
                     <FaDownload className="me-2" />
                     Download
                   </button>
                   <button
                     className="btn btn-outline-secondary btn-sm"
                     onClick={copyPromptToClipboard}
                     title="Copy Prompt to Clipboard"
                   >
                     <FaCopy className="me-2" />
                     Copy
                   </button>
                 </div>
                 <div 
                   className="border rounded p-3 bg-light" 
                   style={{ 
                     maxHeight: '70vh', 
                     overflowY: 'auto',
                     fontSize: '0.9rem',
                     lineHeight: '1.6',
                     fontFamily: 'monospace',
                     whiteSpace: 'pre-wrap',
                     wordBreak: 'break-word'
                   }}
                 >
                   {generatedPrompt}
                 </div>
               </div>
               <div className="modal-footer">
                 <button
                   type="button"
                   className="btn btn-secondary"
                   onClick={() => setShowPromptModal(false)}
                 >
                   Close
                 </button>
               </div>
             </div>
           </div>
           <div className="modal-backdrop fade show" style={{ zIndex: 1059 }}></div>
         </div>
       )}

       {/* Error Details Modal */}
       {showErrorDetails && selectedError && (
         <div className="modal fade show error-details-modal" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
           <div className="modal-dialog" style={{ zIndex: 1055 }}>
             <div className="modal-content">
               <div className="modal-header">
                 <h5 className="modal-title">
                   <span className="text-danger">⚠️</span> Error Details
                 </h5>
                 <button
                   type="button"
                   className="btn-close"
                   onClick={() => setShowErrorDetails(false)}
                 ></button>
               </div>
               <div className="modal-body">
                 <table className="table table-bordered error-details-table">
                   <tbody>
                     <tr>
                       <th>Job ID</th>
                       <td><code>{selectedError.job.job_id}</code></td>
                     </tr>
                     <tr>
                       <th>Repository</th>
                       <td>{selectedError.job.repo_url}</td>
                     </tr>
                     <tr>
                       <th>Status</th>
                       <td>
                         <span className={getStatusBadge(selectedError.job.status)}>
                           {selectedError.job.status}
                         </span>
                       </td>
                     </tr>
                     <tr>
                       <th>Created</th>
                       <td>{formatDate(selectedError.job.created_at)}</td>
                     </tr>
                     <tr>
                       <th>Error Message</th>
                       <td className="error-message-cell">{selectedError.errorMessage}</td>
                     </tr>
                   </tbody>
                 </table>
               </div>
               <div className="modal-footer">
                 <button
                   type="button"
                   className="btn btn-secondary"
                   onClick={() => setShowErrorDetails(false)}
                 >
                   Close
                 </button>
               </div>
             </div>
           </div>
           <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
         </div>
       )}
     </div>
   );
 };

export default JobMonitorPage;
