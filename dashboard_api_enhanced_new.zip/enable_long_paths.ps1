# Enable Long Path Support in Windows
# Run this script as Administrator

Write-Host "Enabling long path support in Windows..." -ForegroundColor Green

# Set the registry value
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1

Write-Host "Long path support enabled!" -ForegroundColor Green
Write-Host "You may need to restart your computer for changes to take effect." -ForegroundColor Yellow
