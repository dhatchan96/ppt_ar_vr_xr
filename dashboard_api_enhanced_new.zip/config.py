"""
ThreatGuard Pro - Configuration Management
Simplified configuration for enhanced vulnerability management
"""

import os
from pathlib import Path

class Settings:
    """Application settings"""
    
    # Flask settings
    FLASK_ENV = os.getenv("FLASK_ENV", "development")
    FLASK_DEBUG = os.getenv("FLASK_DEBUG", "True").lower() == "true"
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    
    # Database settings
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///threatguard.db")
    
    # File storage settings
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "./uploaded_projects")
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", 16 * 1024 * 1024))
    
    # Scan settings
    MAX_SCAN_WORKERS = int(os.getenv("MAX_SCAN_WORKERS", 4))
    # Performance settings for large projects
    MAX_FILES_PER_SCAN = int(os.getenv("MAX_FILES_PER_SCAN", 5000))  # Increased from 1000
    MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", 5))  # Increased from 1MB
    # Timeout configurations for large repositories
    SCAN_TIMEOUT_SECONDS = int(os.getenv("SCAN_TIMEOUT_SECONDS", 1800))  # Increased to 30 minutes for large repos
    GIT_CLONE_TIMEOUT = int(os.getenv("GIT_CLONE_TIMEOUT", 1200))  # Increased to 20 minutes for large repos
    FILE_ANALYSIS_TIMEOUT = int(os.getenv("FILE_ANALYSIS_TIMEOUT", 900))  # Increased to 15 minutes for large repos
    PARALLEL_FILE_PROCESSING = os.getenv("PARALLEL_FILE_PROCESSING", "True").lower() == "true"
    MAX_WORKERS_FOR_PARALLEL = int(os.getenv("MAX_WORKERS_FOR_PARALLEL", 8))
    
    # Terraform settings
    TERRAFORM_BINARY_PATH = os.getenv("TERRAFORM_BINARY_PATH", "/usr/local/bin/terraform")
    TERRAFORM_WORKSPACE_PATH = os.getenv("TERRAFORM_WORKSPACE_PATH", "./terraform_workspaces")

# Global settings instance
settings = Settings()

# Ensure directories exist
def ensure_directories():
    """Ensure required directories exist"""
    directories = [
        Path(settings.UPLOAD_FOLDER),
        Path("./threatguard_data"),
        Path("./logs"),
        Path("./temp")
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)

# Initialize directories on import
ensure_directories()
