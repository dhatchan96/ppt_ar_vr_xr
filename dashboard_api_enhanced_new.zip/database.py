"""
ThreatGuard Pro - Database Management
Enhanced database operations with SQLite support for vulnerability management
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Enhanced database manager with SQLite support for vulnerabilities"""
    
    def __init__(self):
        self.data_dir = Path("threatguard_data")
        self.data_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "vulnerabilities.db"
        self.init_sqlite_database()
    
    def init_sqlite_database(self):
        """Initialize SQLite database for vulnerabilities"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create enhanced_vulnerabilities table (matching API expectations)
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS enhanced_vulnerabilities (
                        id TEXT PRIMARY KEY,
                        gis_id TEXT,
                        ait_tag TEXT,
                        title TEXT,
                        description TEXT,
                        remediation_action TEXT,
                        status TEXT,
                        severity TEXT,
                        risk_score INTEGER,
                        wave_assignment TEXT,
                        cost_impact REAL,
                        created_date TEXT,
                        source TEXT,
                        vulnerability_type TEXT,
                        import_date TEXT
                    )
                ''')
                
                # Create vulnerabilities table (for backward compatibility)
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS vulnerabilities (
                        id TEXT PRIMARY KEY,
                        gis_id TEXT,
                        ait_tag TEXT,
                        title TEXT,
                        description TEXT,
                        remediation_action TEXT,
                        status TEXT,
                        severity TEXT,
                        risk_score INTEGER,
                        wave_assignment TEXT,
                        cost_impact REAL,
                        created_date TEXT,
                        source TEXT,
                        vulnerability_type TEXT,
                        import_date TEXT
                    )
                ''')
                
                conn.commit()
                logger.info("SQLite database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize SQLite database: {e}")
    
    def get_vulnerabilities(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get vulnerabilities from SQLite with optional filtering"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                query = "SELECT * FROM enhanced_vulnerabilities"
                params = []
                
                if filters:
                    conditions = []
                    for key, value in filters.items():
                        conditions.append(f"{key} = ?")
                        params.append(value)
                    
                    if conditions:
                        query += " WHERE " + " AND ".join(conditions)
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"Error getting vulnerabilities from SQLite: {e}")
            return []
    
    def save_vulnerability(self, vulnerability: Dict[str, Any]) -> bool:
        """Save a vulnerability to SQLite"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO enhanced_vulnerabilities 
                    (id, gis_id, ait_tag, title, description, remediation_action, 
                     status, severity, risk_score, wave_assignment, cost_impact, 
                     created_date, source, vulnerability_type, import_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    vulnerability.get('id'),
                    vulnerability.get('gis_id'),
                    vulnerability.get('ait_tag'),
                    vulnerability.get('title'),
                    vulnerability.get('description'),
                    vulnerability.get('remediation_action'),
                    vulnerability.get('status'),
                    vulnerability.get('severity'),
                    vulnerability.get('risk_score'),
                    vulnerability.get('wave_assignment'),
                    vulnerability.get('cost_impact'),
                    vulnerability.get('created_date'),
                    vulnerability.get('source'),
                    vulnerability.get('vulnerability_type'),
                    vulnerability.get('import_date')
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving vulnerability to SQLite: {e}")
            return False
    
    def save_enhanced_vulnerability(self, vulnerability: Dict[str, Any]) -> bool:
        """Save a vulnerability to enhanced_vulnerabilities table"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO enhanced_vulnerabilities 
                    (id, gis_id, ait_tag, title, description, remediation_action, 
                     status, severity, risk_score, wave_assignment, cost_impact, 
                     created_date, source, vulnerability_type, import_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    vulnerability.get('id'),
                    vulnerability.get('gis_id'),
                    vulnerability.get('ait_tag'),
                    vulnerability.get('title'),
                    vulnerability.get('description'),
                    vulnerability.get('remediation_action'),
                    vulnerability.get('status'),
                    vulnerability.get('severity'),
                    vulnerability.get('risk_score'),
                    vulnerability.get('wave_assignment'),
                    vulnerability.get('cost_impact'),
                    vulnerability.get('created_date'),
                    vulnerability.get('source'),
                    vulnerability.get('vulnerability_type'),
                    vulnerability.get('import_date')
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving enhanced vulnerability to SQLite: {e}")
            return False
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get database health status"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM enhanced_vulnerabilities")
                count = cursor.fetchone()[0]
                
                return {
                    "status": "healthy",
                    "total_vulnerabilities": count,
                    "last_updated": datetime.now().isoformat(),
                    "database_type": "SQLite"
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "database_type": "SQLite"
            }

# Global database manager instance
db_manager = DatabaseManager()

