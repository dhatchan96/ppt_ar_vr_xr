#!/usr/bin/env python3
"""
Check and fix database issues
"""

import sqlite3
import os
from job_manager import job_manager

def check_database():
    """Check database status and create tables if needed"""
    try:
        # Check if database file exists
        db_path = "threatguard_data/jobs.db"
        if not os.path.exists(db_path):
            print(f"Database file {db_path} does not exist. Creating...")
            job_manager.init_database()
            print("Database created successfully!")
            return
        
        # Check database connection
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if scan_jobs table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='scan_jobs'")
        if not cursor.fetchone():
            print("scan_jobs table does not exist. Creating...")
            job_manager.init_database()
            print("scan_jobs table created successfully!")
        else:
            print("scan_jobs table exists.")
            
        # Check table structure
        cursor.execute("PRAGMA table_info(scan_jobs)")
        columns = cursor.fetchall()
        print(f"scan_jobs table has {len(columns)} columns:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
            
        # Check for any existing jobs
        cursor.execute("SELECT COUNT(*) FROM scan_jobs")
        job_count = cursor.fetchone()[0]
        print(f"Total jobs in database: {job_count}")
        
        conn.close()
        print("Database check completed successfully!")
        
    except Exception as e:
        print(f"Database check failed: {e}")
        print("Attempting to recreate database...")
        try:
            job_manager.init_database()
            print("Database recreated successfully!")
        except Exception as e2:
            print(f"Failed to recreate database: {e2}")

if __name__ == "__main__":
    check_database()
