#!/usr/bin/env python3
"""
Cancel a stuck job
"""

import requests
import json

def cancel_job(job_id):
    try:
        response = requests.post(f"http://localhost:5000/api/jobs/{job_id}/cancel", timeout=10)
        if response.status_code == 200:
            result = response.json()
            print(f"Job {job_id} cancelled: {result.get('message', '')}")
        else:
            print(f"Failed to cancel job: {response.status_code}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    cancel_job("d63005c7-7484-4963-ac0a-3e9b4e77ef05")
