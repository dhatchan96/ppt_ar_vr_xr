import { InProgressPerformanceEvent, Logger } from "@azure/msal-common/browser";
export declare function collectInstanceStats(currentClientId: string, performanceEvent: InProgressPerformanceEvent, logger: Logger): void;
//# sourceMappingURL=MsalFrameStatsUtils.d.ts.map