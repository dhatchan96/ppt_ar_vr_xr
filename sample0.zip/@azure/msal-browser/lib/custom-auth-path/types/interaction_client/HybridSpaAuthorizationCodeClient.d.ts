import { AuthorizationCodeClient, ClientConfiguration } from "@azure/msal-common/browser";
export declare class HybridSpaAuthorizationCodeClient extends AuthorizationCodeClient {
    constructor(config: ClientConfiguration);
}
//# sourceMappingURL=HybridSpaAuthorizationCodeClient.d.ts.map