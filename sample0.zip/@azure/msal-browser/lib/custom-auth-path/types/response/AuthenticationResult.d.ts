import { AccountInfo, AuthenticationResult as CommonAuthenticationResult } from "@azure/msal-common/browser";
export type AuthenticationResult = CommonAuthenticationResult & {
    account: AccountInfo;
};
//# sourceMappingURL=AuthenticationResult.d.ts.map