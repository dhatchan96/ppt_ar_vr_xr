export interface BridgeCapabilities {
    queryAccount?: boolean;
}
//# sourceMappingURL=BridgeCapabilities.d.ts.map