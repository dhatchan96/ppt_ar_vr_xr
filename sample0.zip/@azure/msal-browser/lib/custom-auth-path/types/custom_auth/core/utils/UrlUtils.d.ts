export declare function parseUrl(url: string): URL;
export declare function buildUrl(baseUrl: string, path: string, queryParams?: Record<string, string>): URL;
//# sourceMappingURL=UrlUtils.d.ts.map