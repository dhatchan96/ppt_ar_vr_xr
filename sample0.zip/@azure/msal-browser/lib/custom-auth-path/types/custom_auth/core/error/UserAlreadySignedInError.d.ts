import { CustomAuthError } from "./CustomAuthError.js";
export declare class UserAlreadySignedInError extends CustomAuthError {
    constructor(correlationId?: string);
}
//# sourceMappingURL=UserAlreadySignedInError.d.ts.map