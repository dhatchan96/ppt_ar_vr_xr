export declare const MissingConfiguration = "missing_configuration";
export declare const InvalidAuthority = "invalid_authority";
export declare const InvalidChallengeType = "invalid_challenge_type";
//# sourceMappingURL=InvalidConfigurationErrorCodes.d.ts.map