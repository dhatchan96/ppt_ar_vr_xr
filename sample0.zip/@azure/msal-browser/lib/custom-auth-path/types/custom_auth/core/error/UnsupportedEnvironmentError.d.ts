import { CustomAuthError } from "./CustomAuthError.js";
export declare class UnsupportedEnvironmentError extends CustomAuthError {
    constructor(correlationId?: string);
}
//# sourceMappingURL=UnsupportedEnvironmentError.d.ts.map