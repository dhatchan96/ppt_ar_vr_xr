export declare const NoNetworkConnectivity = "no_network_connectivity";
export declare const FailedSendRequest = "failed_send_request";
//# sourceMappingURL=HttpErrorCodes.d.ts.map