# ThreatGuard Pro - Enhanced Logic Bomb Detection System

A comprehensive security analysis tool designed to detect malicious code patterns, particularly "logic bombs" - malicious code that triggers destructive actions under specific conditions.

## 🚀 Quick Start

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Installation

1. **Clone or navigate to the project directory:**
   ```bash
   cd dashboard_api_enhanced
   ```

2. **Install required dependencies:**
   ```bash
   pip install flask flask-cors
   ```

3. **Verify the project structure:**
   ```
   dashboard_api_enhanced/
   ├── threatguard_main_enhanced.py      # Main detection engine
   ├── dashboard_api_enhanced.py         # Flask API server
   ├── sample_threat_test.py            # Test file with threats
   ├── threatguard_data/                # Data directory
   │   ├── logic_bomb_rules.json
   │   ├── threat_shields.json
   │   ├── threat_issues.json
   │   └── scan_history.json
   └── *.js files                       # Frontend components
   ```

## 🏃‍♂️ Running the Project

### Option 1: Run the Main Detection Engine (Standalone)

```bash
python threatguard_main_enhanced.py
```

This will:
- Initialize the detection system
- Scan the current directory for threats
- Display comprehensive results
- Show threat intelligence metrics

### Option 2: Run the Web Dashboard API

```bash
python dashboard_api_enhanced.py
```

This will:
- Start a Flask web server (usually on http://localhost:5000)
- Provide REST API endpoints for threat detection
- Enable web-based dashboard access

### Option 3: Test with Sample Threats

```bash
python sample_threat_test.py
```

This will:
- Run the sample file containing various threat patterns
- Demonstrate the detection capabilities

## 📊 Available Endpoints (Web API)

When running the web dashboard, you can access:

- **GET** `/api/command-center/metrics` - Get comprehensive threat metrics
- **POST** `/api/logic-bomb-scan` - Start a logic bomb scan
- **POST** `/api/scan` - Start a general security scan
- **GET** `/api/threats` - Get all detected threats
- **GET** `/api/issues` - Get all security issues
- **GET** `/api/threat-intelligence` - Get threat intelligence report
- **GET** `/api/rules` - Get detection rules
- **GET** `/api/health` - Health check endpoint

## 🔍 Detection Capabilities

The system detects various threat types:

### 1. Time-based Logic Bombs
```python
if datetime.now() > target_date: delete_files()
```

### 2. User-targeted Attacks
```python
if current_user == "admin": destroy_system()
```

### 3. Counter-based Logic
```python
if execution_count > 100: corrupt_data()
```

### 4. Destructive Operations
```python
shutil.rmtree("/")  # System destruction
```

### 5. Financial Fraud
```python
bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
```

## 📈 Threat Intelligence Features

### Risk Scoring (0-100 scale):
- **CRITICAL_BOMB**: 25 points
- **HIGH_RISK**: 15 points  
- **MEDIUM_RISK**: 8 points
- **LOW_RISK**: 3 points
- **SUSPICIOUS**: 1 point

### Security Ratings:
- **A**: No threats detected
- **B**: Low-level threats
- **C**: Multiple minor threats
- **D**: High-risk threats
- **E**: Multiple high-risk threats
- **F**: Critical bombs detected

## 🛡️ Threat Categories

- **SCHEDULED_THREAT**: Time-based triggers
- **TARGETED_ATTACK**: User-specific attacks
- **EXECUTION_TRIGGER**: Counter-based triggers
- **DESTRUCTIVE_PAYLOAD**: Direct damage operations
- **FINANCIAL_FRAUD**: Money-related threats
- **SYSTEM_SPECIFIC_THREAT**: Environment-based triggers

## 📁 Data Files

The system maintains several JSON files in `threatguard_data/`:

- `logic_bomb_rules.json`: Detection rules and patterns
- `threat_shields.json`: Protection configurations
- `threat_issues.json`: Detected security issues
- `scan_history.json`: Historical scan results

## 🔧 Configuration

### Custom Rules
You can add custom detection rules by modifying `threatguard_data/logic_bomb_rules.json`:

```json
{
  "id": "custom-rule-id",
  "name": "Custom Threat Pattern",
  "description": "Description of the threat",
  "severity": "HIGH_RISK",
  "type": "CUSTOM_THREAT",
  "language": "*",
  "pattern": "your_regex_pattern_here",
  "remediation_effort": 60,
  "tags": ["custom", "threat"],
  "enabled": true
}
```

### Threat Shields
Configure protection levels in `threatguard_data/threat_shields.json`:

```json
{
  "id": "custom-shield",
  "name": "Custom Protection Shield",
  "protection_rules": [
    {
      "threat_type": "SCHEDULED_THREAT",
      "risk_threshold": "HIGH_RISK",
      "block": true,
      "alert": true
    }
  ]
}
```

## 🚨 Example Usage

### Python Script Example
```python
from threatguard_main_enhanced import LogicBombDetector

# Initialize detector
detector = LogicBombDetector()

# Scan a project
result = detector.scan_project("./my-project", "project-id")

# Get metrics
metrics = detector.get_command_center_metrics()

print(f"Threats found: {len(result.issues)}")
print(f"Risk score: {result.logic_bomb_risk_score}")
print(f"Security rating: {result.security_rating}")
```

### API Usage Example
```bash
# Start a scan
curl -X POST http://localhost:5000/api/logic-bomb-scan \
  -H "Content-Type: application/json" \
  -d '{"project_path": "./my-project", "project_id": "test-project"}'

# Get metrics
curl http://localhost:5000/api/command-center/metrics
```

## 🎯 Key Features

1. **Comprehensive Detection**: Covers multiple threat types
2. **Detailed Analysis**: Provides trigger and payload analysis
3. **Intelligent Scoring**: Risk-based prioritization
4. **Actionable Intelligence**: Specific neutralization guides
5. **Historical Tracking**: Maintains scan history
6. **Configurable Protection**: Customizable threat shields
7. **Web Dashboard**: REST API for integration
8. **Multi-language Support**: Detects threats in various programming languages

## 🔒 Security Focus Areas

The system is particularly effective against:
- **Logic Bombs**: Malicious conditional code
- **Time-based Attacks**: Scheduled destructive actions
- **Targeted Malware**: User-specific threats
- **Financial Fraud**: Payment redirections
- **System Destruction**: File deletion, formatting

## 🛠️ Troubleshooting

### Common Issues:

1. **Import Errors**: Ensure all dependencies are installed
   ```bash
   pip install flask flask-cors
   ```

2. **Permission Errors**: Ensure write access to `threatguard_data/` directory

3. **Port Already in Use**: Change the port in `dashboard_api_enhanced.py`
   ```python
   app.run(host='0.0.0.0', port=5001, debug=True)
   ```

4. **No Threats Detected**: Check if the scan path contains files with supported extensions

## 📝 License

Copyright 2025 - Enhanced with comprehensive security features

## 🤝 Contributing

This is a security-focused project. Please ensure all contributions follow security best practices and include appropriate testing.

---

**⚠️ Important**: This tool is designed for security analysis and threat detection. Always use responsibly and in accordance with your organization's security policies. 