#!/usr/bin/env python3
"""
Test script to check advanced metrics values
"""

import requests
import json

def test_advanced_metrics():
    """Test the advanced metrics endpoint"""
    try:
        # Test the command center metrics endpoint
        response = requests.get('http://localhost:5000/api/command-center/metrics')
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Command center metrics response:")
            print(json.dumps(data, indent=2))
            
            # Check logic_bomb_metrics specifically
            if 'logic_bomb_metrics' in data:
                lb_metrics = data['logic_bomb_metrics']
                print("\n🔍 Logic Bomb Metrics:")
                print(f"  - trigger_complexity_score: {lb_metrics.get('trigger_complexity_score', 'NOT FOUND')}")
                print(f"  - payload_severity_score: {lb_metrics.get('payload_severity_score', 'NOT FOUND')}")
                print(f"  - detection_confidence_avg: {lb_metrics.get('detection_confidence_avg', 'NOT FOUND')}")
                print(f"  - threat_density: {lb_metrics.get('threat_density', 'NOT FOUND')}")
                print(f"  - neutralization_urgency_hours: {lb_metrics.get('neutralization_urgency_hours', 'NOT FOUND')}")
            else:
                print("❌ No logic_bomb_metrics found in response")
        else:
            print(f"❌ Error: {response.status_code}")
            print(response.text)
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_advanced_metrics() 