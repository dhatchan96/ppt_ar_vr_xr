from flask import Flask, request, render_template
import os
import json
from x_ray_feature import run_xray_with_json
import requests

app = Flask(__name__)

# Mapping user input keywords to JSON file paths
data_files = {
    "code review": "D:/CodeKata/chat-ui/datasets/code_review.json",
    "project management": "D:/CodeKata/chat-ui/datasets/project_management.json",
    "feedback": "D:/CodeKata/chat-ui/datasets/feedback.json",
    "sales": "D:/CodeKata/chat-ui/datasets/sales_data.json",
    "inventory": "D:/CodeKata/chat-ui/datasets/inventory.json",
}

# Database and Superset settings
DB_CONNECTION_STRING = 'mysql+pymysql://superset_user3:dhatchan@localhost/superset_dbb'
TABLE_NAME = 'rester_sample'
DATASET_NAME = 'rester_sample'
DASHBOARD_TITLE = 'Auto-generated Dashboard'
DATABASE_ID = 1
SCHEMA = 'superset_dbb'

SUPERSET_BASE_URL = "http://localhost:8088"
USERNAME = "admin"
PASSWORD = "admin"

def find_json_file(user_query):
    user_query = user_query.lower()
    for keyword, file_path in data_files.items():
        if keyword in user_query:
            return file_path
    return None

@app.route('/', methods=['GET', 'POST'])
def index():
    response_message = ""
    embed_url = ""
    guest_token, embed_uuid = '', ''

    if request.method == 'POST':
        query = request.form.get('query', '').lower()
        json_file = find_json_file(query)

        if json_file and os.path.exists(json_file):
            with open(json_file, 'r') as file:
                json_file = json.load(file)
            try:
                # Run x-ray feature to load data and create the dashboard
                guest_token, embed_uuid = run_xray_with_json(
                    file_path=json_file,
                    db_connection_string=DB_CONNECTION_STRING,
                    table_name=TABLE_NAME,
                    dataset_name=DATASET_NAME,
                    dashboard_title=DASHBOARD_TITLE,
                    database_id=DATABASE_ID,
                    schema=SCHEMA
                )
                response_message = f"Dashboard created successfully for '{query}'."
            except Exception as e:
                response_message = f"Error creating dashboard: {str(e)}"
        else:
            response_message = "No matching data file found for your query."

    return render_template(
        'index.html', 
        response_message=response_message, 
        guest_token= guest_token, embed_uuid = embed_uuid
    )

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5050)
