#!/usr/bin/env python3
"""
Test file with DESTRUCTIVE_PAYLOAD patterns
This file contains destructive operations that could be payloads
"""

import os
import shutil
import subprocess
import sys

# DESTRUCTIVE_PAYLOAD - File deletion
def delete_system_files():
    # Remove critical system files
    shutil.rmtree('/etc', ignore_errors=True)
    os.remove('/etc/passwd')
    print("System cleanup completed")

# DESTRUCTIVE_PAYLOAD - Directory removal
def remove_user_data():
    # Delete user directories
    shutil.rmtree('/home/user', ignore_errors=True)
    os.system('rmdir /s /q C:\\Users\\Administrator')
    print("User data cleanup")

# DESTRUCTIVE_PAYLOAD - Process termination
def kill_processes():
    # Kill important processes
    subprocess.call(['killall', '-9', 'nginx'])
    os.system('taskkill /f /im explorer.exe')
    print("Process cleanup")

# DESTRUCTIVE_PAYLOAD - Disk formatting
def format_disks():
    # Format system drives
    os.system('format c: /q')
    subprocess.run(['mkfs', '-t', 'ext4', '/dev/sda1'])
    print("Disk maintenance")

# DESTRUCTIVE_PAYLOAD - Database destruction
def destroy_database():
    # Drop all tables
    os.system('mysql -e "DROP DATABASE production;"')
    subprocess.call(['psql', '-c', 'DROP SCHEMA public CASCADE;'])
    print("Database cleanup")

# DESTRUCTIVE_PAYLOAD - Network disruption
def disrupt_network():
    # Disable network interfaces
    os.system('ifconfig eth0 down')
    subprocess.run(['netsh', 'interface', 'set', 'interface', 'name="Ethernet"', 'admin=disable'])
    print("Network maintenance")

# DESTRUCTIVE_PAYLOAD - System corruption
def corrupt_system():
    # Corrupt system files
    with open('/etc/hosts', 'w') as f:
        f.write('127.0.0.1 localhost\n')
        f.write('0.0.0.0 google.com\n')
        f.write('0.0.0.0 facebook.com\n')
    print("System optimization")

# Normal function
def safe_file_operation():
    # Safe file operation
    with open('safe_file.txt', 'w') as f:
        f.write('This is safe content')
    print("Safe file created")

if __name__ == "__main__":
    # These would be destructive if executed
    # delete_system_files()
    # remove_user_data()
    # kill_processes()
    # format_disks()
    # destroy_database()
    # disrupt_network()
    # corrupt_system()
    
    # Only run safe operation
    safe_file_operation() 