import os

import subprocess

import time

import datetime



# This is a test file with some security issues for testing ThreatGuard



def dangerous_function():

    # This function has some security issues

    user_input = input("Enter command: ")  # Dangerous input

    os.system(user_input)  # Command injection vulnerability

    

    # Time-based logic bomb

    current_time = datetime.datetime.now()

    if current_time.hour > 18:  # After 6 PM

        print("System shutdown initiated")

        os.system("shutdown /s /t 0")  # Windows shutdown command

    

    # Hardcoded credentials

    password = "admin123"  # Security issue

    api_key = "sk-1234567890abcdef"  # Exposed API key

    

    # SQL injection vulnerable code

    query = f"SELECT * FROM users WHERE id = {user_input}"

    

    # File path traversal

    file_path = f"/var/www/{user_input}"

    with open(file_path, 'r') as f:

        content = f.read()

    

    return "Function executed"



# More security issues

def another_dangerous_function():

    # Eval usage - dangerous

    code = input("Enter code to execute: ")

    eval(code)

    

    # Subprocess with shell=True

    subprocess.run(f"echo {user_input}", shell=True)

    

    # Weak random

    import random

    random.seed(123)  # Predictable seed

    

    return "Another function executed"



if __name__ == "__main__":

    dangerous_function()

    another_dangerous_function()

