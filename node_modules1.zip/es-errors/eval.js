'use strict';

/** @type {import('./eval')} */
module.exports = EvalError;
