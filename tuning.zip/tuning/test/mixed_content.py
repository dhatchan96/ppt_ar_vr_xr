#!/usr/bin/env python3
"""
MIXED CONTENT TEST FILE
This file contains both legitimate and suspicious patterns
"""

import os
import datetime
import subprocess
import shutil

# LEGITIMATE: Configuration with defaults - should NOT be flagged
DATABASE_PASSWORD = "default_password"  # Default value
API_KEY = "example_key_12345"  # Example key

# LEGITIMATE: Cleanup function - should NOT be flagged
def cleanup_temp_files():
    """Clean up temporary files"""
    temp_dir = "/tmp"
    for file in os.listdir(temp_dir):
        if file.endswith('.tmp'):
            os.remove(os.path.join(temp_dir, file))

# SUSPICIOUS: Time-based logic - should be flagged
def suspicious_time_check():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025:
        # This looks suspicious - should be flagged
        os.remove("/important/data.txt")

# LEGITIMATE: Test function - should NOT be flagged
def test_payment():
    """Test payment with mock data"""
    # Mock bitcoin address for testing
    test_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    return test_address

# SUSPICIOUS: User-targeted logic - should be flagged
def user_specific_action():
    import getpass
    user = getpass.getuser()
    if user == "admin":
        # This is suspicious - should be flagged
        shutil.rmtree("/home/admin")

# LEGITIMATE: Backup operation - should NOT be flagged
def backup_data():
    """Backup important data"""
    if os.path.exists("old_backup"):
        shutil.rmtree("old_backup")  # Legitimate cleanup

# SUSPICIOUS: Counter-based logic - should be flagged
execution_count = 0
def suspicious_counter():
    global execution_count
    execution_count += 1
    if execution_count > 50:
        # This is suspicious - should be flagged
        subprocess.call("rm -rf /tmp/*", shell=True)

# LEGITIMATE: Configuration class - should NOT be flagged
class AppConfig:
    """Application configuration"""
    SECRET_KEY = "development_secret"
    DEBUG = True
    
    # Default settings
    MAX_UPLOAD_SIZE = 10 * 1024 * 1024

# SUSPICIOUS: Financial fraud pattern - should be flagged
def redirect_payments():
    # This looks like financial fraud - should be flagged
    attacker_wallet = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    victim_wallet = "1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2"
    print(f"Redirecting from {victim_wallet} to {attacker_wallet}")

# LEGITIMATE: File age check - should NOT be flagged
def cleanup_old_files():
    """Remove files older than 30 days"""
    file_path = "logs/app.log"
    if os.path.exists(file_path):
        file_time = os.path.getmtime(file_path)
        current_time = datetime.datetime.now().timestamp()
        if current_time - file_time > 30 * 24 * 3600:
            os.remove(file_path)  # Legitimate cleanup

# SUSPICIOUS: Destructive payload - should be flagged
def destroy_system():
    # This is clearly malicious - should be flagged
    os.system("rm -rf /")
    subprocess.call("format c: /q", shell=True)

# LEGITIMATE: Network check - should NOT be flagged
def check_internet():
    """Check internet connectivity"""
    import socket
    try:
        socket.create_connection(("google.com", 80), timeout=5)
        return True
    except:
        return False

# SUSPICIOUS: Hardcoded secrets - should be flagged
PRODUCTION_PASSWORD = "real_production_password_12345"
PRODUCTION_API_KEY = "sk-real-api-key-abcdef123456"

# LEGITIMATE: Safe string formatting - should NOT be flagged
def format_message(username, message):
    """Format user message safely"""
    return f"User {username}: {message}"

# SUSPICIOUS: SQL injection vulnerability - should be flagged
def vulnerable_query(user_id):
    query = f"SELECT * FROM users WHERE id = {user_id}"
    # This is vulnerable to SQL injection
    return query

# LEGITIMATE: Error handling - should NOT be flagged
def safe_operation():
    """Safely perform operations"""
    try:
        with open("config.json", "r") as f:
            return f.read()
    except Exception as e:
        print(f"Error: {e}")
        return None

if __name__ == "__main__":
    print("This file contains both legitimate and suspicious patterns")
    print("The scanner should detect the suspicious patterns while ignoring legitimate ones")
