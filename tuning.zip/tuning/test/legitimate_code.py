#!/usr/bin/env python3
"""
LEGITIMATE CODE TEST FILE
This file contains legitimate code that should NOT trigger false positives
"""

import os
import datetime
import subprocess
import shutil
import tempfile

# Legitimate cleanup function - should NOT be flagged
def cleanup_temp_files():
    """Clean up temporary files"""
    temp_dir = tempfile.gettempdir()
    for file in os.listdir(temp_dir):
        if file.endswith('.tmp'):
            try:
                os.remove(os.path.join(temp_dir, file))
            except:
                pass

# Legitimate backup function - should NOT be flagged
def backup_old_data():
    """Backup old data files"""
    if os.path.exists("old_data"):
        shutil.rmtree("old_data")  # Legitimate cleanup
    print("Backup completed")

# Configuration with default values - should NOT be flagged
DATABASE_PASSWORD = "default_password"  # This is a default value
API_KEY = "example_key_12345"  # This is an example
JWT_SECRET = "development_secret"  # This is for development

# Test function with mock data - should NOT be flagged
def test_payment_processing():
    """Test payment processing with mock data"""
    # Mock bitcoin address for testing
    test_bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    
    # Mock payment data
    payment_data = {
        "amount": 100.00,
        "currency": "USD",
        "wallet": test_bitcoin_address
    }
    return payment_data

# Legitimate file operations - should NOT be flagged
def process_files():
    """Process files safely"""
    if os.path.exists("temp_file.txt"):
        os.remove("temp_file.txt")  # Legitimate file removal
    
    # Create backup directory
    if not os.path.exists("backup"):
        os.makedirs("backup")

# Configuration settings - should NOT be flagged
class Config:
    """Application configuration"""
    DATABASE_URL = "sqlite:///app.db"
    SECRET_KEY = "development_secret_key"
    DEBUG = True
    
    # Default settings
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    UPLOAD_FOLDER = "uploads"

# Legitimate date handling - should NOT be flagged
def check_file_age():
    """Check if file is older than 30 days"""
    file_path = "data.txt"
    if os.path.exists(file_path):
        file_time = os.path.getmtime(file_path)
        current_time = datetime.datetime.now().timestamp()
        if current_time - file_time > 30 * 24 * 3600:  # 30 days
            os.remove(file_path)  # Clean up old files

# Legitimate user handling - should NOT be flagged
def get_user_info():
    """Get current user information"""
    import getpass
    current_user = getpass.getuser()
    return {
        "username": current_user,
        "home_dir": os.path.expanduser("~")
    }

# Legitimate network operations - should NOT be flagged
def check_network_connectivity():
    """Check if network is available"""
    import socket
    try:
        socket.create_connection(("google.com", 80), timeout=5)
        return True
    except:
        return False

# Legitimate counter for statistics - should NOT be flagged
request_count = 0
def handle_request():
    """Handle incoming requests"""
    global request_count
    request_count += 1
    print(f"Request #{request_count} processed")

# Safe string formatting - should NOT be flagged
def format_user_message(username, message):
    """Format user message safely"""
    return f"User {username}: {message}"

# Legitimate error handling - should NOT be flagged
def safe_file_operation():
    """Safely perform file operations"""
    try:
        with open("config.json", "r") as f:
            config = f.read()
        return config
    except FileNotFoundError:
        return "{}"  # Return empty config
    except Exception as e:
        print(f"Error: {e}")
        return None

if __name__ == "__main__":
    print("This is legitimate code that should not trigger false positives")
    print("All operations are safe and intended for normal application use")
