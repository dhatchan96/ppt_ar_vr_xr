#!/usr/bin/env python3
"""
Cleanup Malicious Threats Script
================================

This script removes only malicious threats (threat detection issues) from the system
while preserving application and infrastructure vulnerabilities.

Usage:
    python cleanup_malicious_threats.py [--dry-run] [--confirm]

Options:
    --dry-run    Show what would be deleted without actually deleting
    --confirm    Skip confirmation prompt and proceed with deletion
"""

import os
import sys
import json
import sqlite3
import argparse
from datetime import datetime
from pathlib import Path

# Add the current directory to Python path to import modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def load_json_file(file_path):
    """Load JSON data from file"""
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    except Exception as e:
        print(f"❌ Error loading {file_path}: {e}")
        return []

def save_json_file(file_path, data):
    """Save JSON data to file"""
    try:
        # Create backup
        if os.path.exists(file_path):
            backup_path = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(file_path, backup_path)
            print(f"📁 Created backup: {backup_path}")
        
        # Save new data
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"✅ Saved updated data to: {file_path}")
        return True
    except Exception as e:
        print(f"❌ Error saving {file_path}: {e}")
        return False

def cleanup_threat_issues_json(dry_run=False):
    """Clean up malicious threats from threat_issues.json"""
    file_path = "threatguard_data/threat_issues.json"
    
    if not os.path.exists(file_path):
        print(f"⚠️  File not found: {file_path}")
        return 0
    
    print(f"🔍 Processing: {file_path}")
    threats = load_json_file(file_path)
    
    if not threats:
        print("📝 No threats found in file")
        return 0
    
    # Filter out malicious threats (keep only application and infrastructure vulnerabilities)
    original_count = len(threats)
    filtered_threats = []
    malicious_count = 0
    
    for threat in threats:
        # Keep application and infrastructure vulnerabilities
        if (threat.get('source') == 'vulnerability-scan' or 
            threat.get('type') in ['application', 'infrastructure']):
            filtered_threats.append(threat)
        else:
            # This is a malicious threat - remove it
            malicious_count += 1
            if dry_run:
                print(f"🗑️  Would remove malicious threat: {threat.get('id', 'unknown')} - {threat.get('title', 'No title')}")
    
    if dry_run:
        print(f"📊 Dry run results for {file_path}:")
        print(f"   Original threats: {original_count}")
        print(f"   Malicious threats to remove: {malicious_count}")
        print(f"   Remaining threats: {len(filtered_threats)}")
        return malicious_count
    
    if malicious_count > 0:
        if save_json_file(file_path, filtered_threats):
            print(f"✅ Removed {malicious_count} malicious threats from {file_path}")
            return malicious_count
        else:
            print(f"❌ Failed to save {file_path}")
            return 0
    else:
        print(f"📝 No malicious threats found in {file_path}")
        return 0

def cleanup_enhanced_vulnerabilities_db(dry_run=False):
    """Clean up malicious threats from enhanced_vulnerabilities database"""
    db_path = "threatguard_data/vulnerabilities.db"
    
    if not os.path.exists(db_path):
        print(f"⚠️  Database not found: {db_path}")
        return 0
    
    print(f"🔍 Processing database: {db_path}")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='enhanced_vulnerabilities'")
        if not cursor.fetchone():
            print("⚠️  Table 'enhanced_vulnerabilities' not found")
            conn.close()
            return 0
        
        # Count malicious threats
        cursor.execute("""
            SELECT COUNT(*) FROM enhanced_vulnerabilities 
            WHERE source = 'threat-detection' 
            OR (source != 'vulnerability-scan' AND type NOT IN ('application', 'infrastructure'))
        """)
        malicious_count = cursor.fetchone()[0]
        
        if dry_run:
            # Show what would be deleted
            cursor.execute("""
                SELECT id, title, source, type FROM enhanced_vulnerabilities 
                WHERE source = 'threat-detection' 
                OR (source != 'vulnerability-scan' AND type NOT IN ('application', 'infrastructure'))
            """)
            malicious_threats = cursor.fetchall()
            
            print(f"📊 Dry run results for database:")
            print(f"   Malicious threats to remove: {malicious_count}")
            
            for threat in malicious_threats:
                print(f"🗑️  Would remove: {threat[0]} - {threat[1]} (source: {threat[2]}, type: {threat[3]})")
            
            conn.close()
            return malicious_count
        
        if malicious_count > 0:
            # Create backup
            backup_path = f"{db_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            import shutil
            shutil.copy2(db_path, backup_path)
            print(f"📁 Created database backup: {backup_path}")
            
            # Delete malicious threats
            cursor.execute("""
                DELETE FROM enhanced_vulnerabilities 
                WHERE source = 'threat-detection' 
                OR (source != 'vulnerability-scan' AND type NOT IN ('application', 'infrastructure'))
            """)
            
            conn.commit()
            conn.close()
            
            print(f"✅ Removed {malicious_count} malicious threats from database")
            return malicious_count
        else:
            print("📝 No malicious threats found in database")
            conn.close()
            return 0
            
    except Exception as e:
        print(f"❌ Error processing database: {e}")
        if 'conn' in locals():
            conn.close()
        return 0

def cleanup_scan_history(dry_run=False):
    """Clean up malicious threats from scan history"""
    file_path = "threatguard_data/scan_history.json"
    
    if not os.path.exists(file_path):
        print(f"⚠️  File not found: {file_path}")
        return 0
    
    print(f"🔍 Processing: {file_path}")
    scan_history = load_json_file(file_path)
    
    if not scan_history:
        print("📝 No scan history found")
        return 0
    
    malicious_count = 0
    updated_scans = []
    
    for scan in scan_history:
        if 'issues' in scan and scan['issues']:
            original_issues = scan['issues']
            filtered_issues = []
            
            for issue in original_issues:
                # Keep application and infrastructure vulnerabilities
                if (issue.get('source') == 'vulnerability-scan' or 
                    issue.get('type') in ['application', 'infrastructure']):
                    filtered_issues.append(issue)
                else:
                    malicious_count += 1
                    if dry_run:
                        print(f"🗑️  Would remove malicious threat from scan {scan.get('scan_id', 'unknown')}: {issue.get('id', 'unknown')}")
            
            # Update scan with filtered issues
            scan['issues'] = filtered_issues
            scan['issues_count'] = len(filtered_issues)
        
        updated_scans.append(scan)
    
    if dry_run:
        print(f"📊 Dry run results for scan history:")
        print(f"   Malicious threats to remove: {malicious_count}")
        return malicious_count
    
    if malicious_count > 0:
        if save_json_file(file_path, updated_scans):
            print(f"✅ Removed {malicious_count} malicious threats from scan history")
            return malicious_count
        else:
            print(f"❌ Failed to save scan history")
            return 0
    else:
        print("📝 No malicious threats found in scan history")
        return 0

def main():
    parser = argparse.ArgumentParser(description='Clean up malicious threats while preserving application and infrastructure vulnerabilities')
    parser.add_argument('--dry-run', action='store_true', help='Show what would be deleted without actually deleting')
    parser.add_argument('--confirm', action='store_true', help='Skip confirmation prompt and proceed with deletion')
    
    args = parser.parse_args()
    
    print("🧹 Malicious Threats Cleanup Script")
    print("=" * 50)
    print("This script will remove ONLY malicious threats (threat detection issues)")
    print("while preserving application and infrastructure vulnerabilities.")
    print()
    
    if args.dry_run:
        print("🔍 DRY RUN MODE - No actual changes will be made")
        print()
    
    # Count total malicious threats
    total_malicious = 0
    total_malicious += cleanup_threat_issues_json(dry_run=True)
    total_malicious += cleanup_enhanced_vulnerabilities_db(dry_run=True)
    total_malicious += cleanup_scan_history(dry_run=True)
    
    if total_malicious == 0:
        print("✅ No malicious threats found. Nothing to clean up.")
        return
    
    print(f"\n📊 Summary: {total_malicious} malicious threats found")
    
    if args.dry_run:
        print("\n🔍 Dry run completed. Use without --dry-run to perform actual cleanup.")
        return
    
    # Confirmation prompt
    if not args.confirm:
        print(f"\n⚠️  This will permanently delete {total_malicious} malicious threats.")
        print("Application and infrastructure vulnerabilities will be preserved.")
        response = input("Do you want to proceed? (yes/no): ").lower().strip()
        
        if response not in ['yes', 'y']:
            print("❌ Cleanup cancelled.")
            return
    
    print(f"\n🧹 Starting cleanup of {total_malicious} malicious threats...")
    
    # Perform actual cleanup
    total_removed = 0
    total_removed += cleanup_threat_issues_json(dry_run=False)
    total_removed += cleanup_enhanced_vulnerabilities_db(dry_run=False)
    total_removed += cleanup_scan_history(dry_run=False)
    
    print(f"\n✅ Cleanup completed!")
    print(f"📊 Total malicious threats removed: {total_removed}")
    print("📝 Application and infrastructure vulnerabilities preserved")
    print("\n🔄 You may need to restart the API server to see the changes.")

if __name__ == "__main__":
    main()
