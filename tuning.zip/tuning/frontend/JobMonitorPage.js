import React, { useState, useEffect } from 'react';
import { FaSpinner, FaCheck, FaTimes, FaEye, FaTrash, FaPlay, FaPause, FaFilter, FaDownload, FaArrowLeft, FaTrashAlt, FaCheckSquare, FaSquare } from 'react-icons/fa';
import API from '../api';

const JobMonitorPage = ({ onJobComplete, onBack }) => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [cleanupInProgress, setCleanupInProgress] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);
  const [showErrorDetails, setShowErrorDetails] = useState(false);
  const [selectedError, setSelectedError] = useState(null);
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Unique values for dropdowns
  const [uniqueAITs, setUniqueAITs] = useState([]);
  const [uniqueSPKs, setUniqueSPKs] = useState([]);
  const [uniqueRepos, setUniqueRepos] = useState([]);
  const [uniqueStatuses, setUniqueStatuses] = useState([]);

  useEffect(() => {
    loadJobs();
    // Poll for job updates every 5 seconds
    const interval = setInterval(loadJobs, 5000);
    setPollingInterval(interval);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [jobs, filterAIT, filterSPK, filterRepo, filterStatus]);

  const loadJobs = async () => {
    try {
      setLoading(true);
      console.log('🔄 Loading jobs...');
      
      // Add cache-busting parameter to ensure fresh data
      const timestamp = Date.now();
      const response = await API.get(`/api/jobs?limit=50&_t=${timestamp}`);
      const jobsData = response.data.jobs || [];
      console.log(`📋 Loaded ${jobsData.length} jobs:`, jobsData.map(job => ({ id: job.job_id, status: job.status })));
      setJobs(jobsData);
      
      // Extract unique values for filters
      const aits = Array.from(new Set(jobsData.map(job => job.ait_tag).filter(Boolean)));
      const spks = Array.from(new Set(jobsData.map(job => job.spk_tag).filter(Boolean)));
      const repos = Array.from(new Set(jobsData.map(job => job.repo_name).filter(Boolean)));
      const statuses = Array.from(new Set(jobsData.map(job => job.status).filter(Boolean)));
      
      setUniqueAITs(aits);
      setUniqueSPKs(spks);
      setUniqueRepos(repos);
      setUniqueStatuses(statuses);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...jobs];
    
    if (filterAIT) {
      filtered = filtered.filter(job => job.ait_tag === filterAIT);
    }
    
    if (filterSPK) {
      filtered = filtered.filter(job => job.spk_tag === filterSPK);
    }
    
    if (filterRepo) {
      filtered = filtered.filter(job => job.repo_name === filterRepo);
    }
    
    if (filterStatus) {
      filtered = filtered.filter(job => job.status === filterStatus);
    }
    
    setFilteredJobs(filtered);
  };

  const clearFilters = () => {
    setFilterAIT('');
    setFilterSPK('');
    setFilterRepo('');
    setFilterStatus('');
  };

  const getDisplayName = (value, type) => {
    if (!value) return 'Unknown';
    
    switch (type) {
      case 'ait':
        return value === 'AIT' ? 'Default AIT' : value;
      case 'spk':
        return value === 'SPK-DEFAULT' ? 'Default SPK' : value;
      case 'repo':
        return value === 'unknown-repo' ? 'Unknown Repository' : value;
      default:
        return value;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <FaPause className="text-warning" />;
      case 'running':
        return <FaSpinner className="text-primary fa-spin" />;
      case 'completed':
        return <FaCheck className="text-success" />;
      case 'failed':
        return <FaTimes className="text-danger" />;
      case 'cancelled':
        return <FaTimes className="text-secondary" />;
      default:
        return <FaEye className="text-muted" />;
    }
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'badge bg-warning text-dark',
      running: 'badge bg-primary',
      completed: 'badge bg-success',
      failed: 'badge bg-danger',
      cancelled: 'badge bg-secondary'
    };
    return statusClasses[status] || 'badge bg-secondary';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  const getDuration = (startedAt, completedAt) => {
    if (!startedAt) return 'N/A';
    const start = new Date(startedAt);
    const end = completedAt ? new Date(completedAt) : new Date();
    const duration = Math.round((end - start) / 1000);
    return `${duration}s`;
  };

  const truncateError = (errorMessage, maxLength = 3) => {
    if (!errorMessage) return '';
    if (errorMessage.length <= maxLength) return errorMessage;
    return errorMessage.substring(0, maxLength) + '...';
  };

  const cancelJob = async (jobId) => {
    try {
      await API.post(`/api/jobs/${jobId}/cancel`);
      showToast('Job cancelled successfully', 'success');
      loadJobs();
    } catch (error) {
      showToast('Failed to cancel job', 'error');
    }
  };

  const showJobDetails = (job) => {
    setSelectedJob(job);
    setShowDetails(true);
  };

  const handleShowErrorDetails = (errorMessage, job) => {
    setSelectedError({ errorMessage, job });
    setShowErrorDetails(true);
  };

  const showToast = (message, type = 'info') => {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  const cleanupOldJobs = async (days = 7) => {
    let cleanupMessage = '';
    let cleanupType = '';
    const counts = getJobCountsByStatus();
    
    if (days === 0) {
      cleanupType = 'all_completed';
      const jobsToClean = getJobsToBeCleanedUp(0);
      cleanupMessage = `Are you sure you want to clean up ALL completed/failed/cancelled jobs?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs with status:\n` +
                      `• COMPLETED\n` +
                      `• FAILED\n` +
                      `• CANCELLED\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    } else if (days === 1) {
      cleanupType = 'time_based_24h';
      const jobsToClean = getJobsToBeCleanedUp(1);
      cleanupMessage = `Are you sure you want to clean up completed/failed/cancelled jobs from the last 24 hours?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs that are completed, failed, or cancelled.\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    } else {
      cleanupType = 'time_based';
      const jobsToClean = getJobsToBeCleanedUp(days);
      cleanupMessage = `Are you sure you want to clean up completed/failed/cancelled jobs older than ${days} days?\n\n` +
                      `Current job counts:\n` +
                      `• COMPLETED: ${counts.completed} jobs\n` +
                      `• FAILED: ${counts.failed} jobs\n` +
                      `• CANCELLED: ${counts.cancelled} jobs\n` +
                      `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                      `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                      `Jobs that will be cleaned up: ${jobsToClean.length}\n` +
                      `This will permanently delete jobs that are completed, failed, or cancelled.\n\n` +
                      `⚠️  This will NOT affect:\n` +
                      `• RUNNING jobs\n` +
                      `• PENDING jobs\n` +
                      `• Any other active jobs\n\n` +
                      `This action cannot be undone.`;
    }
    
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Cleanup cancelled by user');
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cleanup');
      }
      
      console.log(`🧹 Starting cleanup - Type: ${cleanupType}, Days: ${days}`);
      const response = await API.post(`/api/jobs/cleanup?days=${days}`);
      const data = response.data;
      
      console.log('✅ Cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} old jobs`, 'success');
        console.log(`🧹 Cleanup completed: ${data.deleted_count} jobs removed`);
      } else {
        showToast('No old jobs found to clean up', 'info');
        console.log('🧹 Cleanup completed: No jobs to remove');
      }
      
      await loadJobs();
      
      setTimeout(async () => {
        console.log('🔄 Second reload after cleanup...');
        await loadJobs();
      }, 1000);
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cleanup');
      
    } catch (error) {
      console.error('Cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup jobs';
      showToast(errorMessage, 'error');
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  const getJobCountsByStatus = () => {
    const counts = {
      completed: 0,
      failed: 0,
      cancelled: 0,
      running: 0,
      pending: 0,
      other: 0
    };
    
    jobs.forEach(job => {
      const status = job.status?.toLowerCase();
      if (status === 'completed') counts.completed++;
      else if (status === 'failed') counts.failed++;
      else if (status === 'cancelled') counts.cancelled++;
      else if (status === 'running') counts.running++;
      else if (status === 'pending') counts.pending++;
      else counts.other++;
    });
    
    return counts;
  };

  const getJobsToBeCleanedUp = (days) => {
    const now = new Date();
    const jobsToClean = [];
    
    jobs.forEach(job => {
      const status = job.status?.toLowerCase();
      if (status === 'completed' || status === 'failed' || status === 'cancelled') {
        if (days === 0) {
          // All completed/failed/cancelled jobs
          jobsToClean.push(job);
        } else {
          // Time-based cleanup
          const jobDate = new Date(job.created_at);
          const diffTime = Math.abs(now - jobDate);
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          
          if (diffDays > days) {
            jobsToClean.push(job);
          }
        }
      }
    });
    
    return jobsToClean;
  };

  const cleanupCancelledJobsOnly = async () => {
    const counts = getJobCountsByStatus();
    const cleanupMessage = `Are you sure you want to clean up ONLY cancelled jobs?\n\n` +
                          `Current job counts:\n` +
                          `• CANCELLED: ${counts.cancelled} jobs (will be cleaned up)\n` +
                          `• COMPLETED: ${counts.completed} jobs (will NOT be affected)\n` +
                          `• FAILED: ${counts.failed} jobs (will NOT be affected)\n` +
                          `• RUNNING: ${counts.running} jobs (will NOT be affected)\n` +
                          `• PENDING: ${counts.pending} jobs (will NOT be affected)\n\n` +
                          `This will permanently delete jobs with status:\n` +
                          `• CANCELLED\n\n` +
                          `⚠️  This will NOT affect:\n` +
                          `• COMPLETED jobs\n` +
                          `• FAILED jobs\n` +
                          `• RUNNING jobs\n` +
                          `• PENDING jobs\n` +
                          `• Any other active jobs\n\n` +
                          `This action cannot be undone.`;
    
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Cancelled jobs cleanup cancelled by user');
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cancelled jobs cleanup');
      }
      
      console.log('🧹 Starting cancelled jobs cleanup');
      const response = await API.post('/api/jobs/cleanup?status=cancelled');
      const data = response.data;
      
      console.log('✅ Cancelled jobs cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} cancelled jobs`, 'success');
        console.log(`🧹 Cancelled jobs cleanup completed: ${data.deleted_count} jobs removed`);
      } else {
        showToast('No cancelled jobs found to clean up', 'info');
        console.log('🧹 Cancelled jobs cleanup completed: No jobs to remove');
      }
      
      await loadJobs();
      
      setTimeout(async () => {
        console.log('🔄 Second reload after cancelled jobs cleanup...');
        await loadJobs();
      }, 1000);
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cancelled jobs cleanup');
      
    } catch (error) {
      console.error('Cancelled jobs cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup cancelled jobs';
      showToast(errorMessage, 'error');
      
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  return (
    <div className="container-fluid mt-4 px-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div className="d-flex align-items-center">
          {onBack && (
            <button 
              className="btn btn-outline-secondary me-3"
              onClick={onBack}
            >
              <FaArrowLeft className="me-1" />
              Back
            </button>
          )}
          <h2>🔍 Job Monitor</h2>
        </div>
        <div className="d-flex gap-2">
          <button 
            className={`btn btn-outline-primary btn-sm ${showFilters ? 'active' : ''}`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <FaFilter className="me-1" />
            Filters
          </button>
          <button 
            className="btn btn-outline-secondary btn-sm"
            onClick={clearFilters}
            disabled={!filterAIT && !filterSPK && !filterRepo && !filterStatus}
          >
            Clear
          </button>
          <button 
            className="btn btn-outline-info btn-sm" 
            onClick={loadJobs}
            disabled={loading}
          >
            {loading ? <FaSpinner className="fa-spin" /> : 'Refresh'}
          </button>
        </div>
      </div>

             {/* Filter Section */}
       {showFilters && !showDetails && (
         <div className="card mb-4">
           <div className="card-header">
             <h6 className="mb-0">
               <FaFilter className="me-2" />
               Filter Jobs
             </h6>
           </div>
           <div className="card-body">
             <div className="row g-3">
               <div className="col-md-3">
                 <label className="form-label">AIT (Application Integration Team)</label>
                 <select
                   className="form-select"
                   value={filterAIT}
                   onChange={(e) => setFilterAIT(e.target.value)}
                 >
                   <option value="">All AITs</option>
                   {uniqueAITs.map(ait => (
                     <option key={ait} value={ait}>
                       {getDisplayName(ait, 'ait')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">SPK (Specific Product/Workstream Key)</label>
                 <select
                   className="form-select"
                   value={filterSPK}
                   onChange={(e) => setFilterSPK(e.target.value)}
                 >
                   <option value="">All SPKs</option>
                   {uniqueSPKs.map(spk => (
                     <option key={spk} value={spk}>
                       {getDisplayName(spk, 'spk')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">Repository Name</label>
                 <select
                   className="form-select"
                   value={filterRepo}
                   onChange={(e) => setFilterRepo(e.target.value)}
                 >
                   <option value="">All Repositories</option>
                   {uniqueRepos.map(repo => (
                     <option key={repo} value={repo}>
                       {getDisplayName(repo, 'repo')}
                     </option>
                   ))}
                 </select>
               </div>
               
               <div className="col-md-3">
                 <label className="form-label">Job Status</label>
                 <select
                   className="form-select"
                   value={filterStatus}
                   onChange={(e) => setFilterStatus(e.target.value)}
                 >
                   <option value="">All Statuses</option>
                   {uniqueStatuses.map(status => (
                     <option key={status} value={status}>
                       {status.charAt(0).toUpperCase() + status.slice(1)}
                     </option>
                   ))}
                 </select>
               </div>
             </div>
             
             {/* Active Filters Display */}
             {(filterAIT || filterSPK || filterRepo || filterStatus) && (
               <div className="mt-3">
                 <small className="text-muted">Active filters:</small>
                 <div className="d-flex flex-wrap gap-2 mt-1">
                   {filterAIT && (
                     <span className="badge bg-primary">
                       AIT: {getDisplayName(filterAIT, 'ait')}
                     </span>
                   )}
                   {filterSPK && (
                     <span className="badge bg-info">
                       SPK: {getDisplayName(filterSPK, 'spk')}
                     </span>
                   )}
                   {filterRepo && (
                     <span className="badge bg-success">
                       Repo: {getDisplayName(filterRepo, 'repo')}
                     </span>
                   )}
                   {filterStatus && (
                     <span className="badge bg-warning">
                       Status: {filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1)}
                     </span>
                   )}
                 </div>
               </div>
             )}
           </div>
         </div>
       )}

       {/* Statistics Summary */}
       {!showDetails && (
         <div className="row mb-4">
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-primary">{filteredJobs.length}</h4>
                 <small className="text-muted">Filtered Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-success">{jobs.length}</h4>
                 <small className="text-muted">Total Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-warning">
                   {filteredJobs.filter(job => job.status === 'running').length}
                 </h4>
                 <small className="text-muted">Running Jobs</small>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center">
               <div className="card-body">
                 <h4 className="text-info">
                   {filteredJobs.filter(job => job.status === 'completed').length}
                 </h4>
                 <small className="text-muted">Completed Jobs</small>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Cleanup Controls */}
       {!showDetails && (
         <div className="card mb-4">
           <div className="card-header">
             <h6 className="mb-0">
               <FaTrash className="me-2" />
               Job Management
             </h6>
           </div>
           <div className="card-body">
             <div className="alert alert-info mb-3">
               <strong>⚠️  Important:</strong> Cleanup operations only affect jobs with status COMPLETED, FAILED, or CANCELLED. 
               Running, pending, and other active jobs are never affected by cleanup operations.
             </div>
             
             {/* Job Counts Summary */}
             <div className="row mb-3">
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-success fw-bold">{getJobCountsByStatus().completed}</div>
                   <small className="text-muted">Completed</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-danger fw-bold">{getJobCountsByStatus().failed}</div>
                   <small className="text-muted">Failed</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-warning fw-bold">{getJobCountsByStatus().cancelled}</div>
                   <small className="text-muted">Cancelled</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-primary fw-bold">{getJobCountsByStatus().running}</div>
                   <small className="text-muted">Running</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-info fw-bold">{getJobCountsByStatus().pending}</div>
                   <small className="text-muted">Pending</small>
                 </div>
               </div>
               <div className="col-md-2">
                 <div className="text-center p-2 border rounded">
                   <div className="text-secondary fw-bold">{getJobCountsByStatus().other}</div>
                   <small className="text-muted">Other</small>
                 </div>
               </div>
             </div>
             <div className="d-flex gap-2">
               <div className="btn-group">
                 <button 
                   className="btn btn-outline-warning dropdown-toggle" 
                   data-bs-toggle="dropdown"
                   aria-expanded="false"
                   disabled={cleanupInProgress}
                 >
                   {cleanupInProgress ? (
                     <>
                       <FaSpinner className="fa-spin me-1" />
                       Cleaning...
                     </>
                   ) : (
                     <>
                       <FaTrash className="me-1" />
                       Cleanup Jobs
                     </>
                   )}
                 </button>
                 <ul className="dropdown-menu">
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(0.04)} disabled={cleanupInProgress}>Last 1 hour</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(1)} disabled={cleanupInProgress}>Last 24 hours</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(3)} disabled={cleanupInProgress}>Last 3 days</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(7)} disabled={cleanupInProgress}>Last 7 days</button></li>
                   <li><button className="dropdown-item" onClick={() => cleanupOldJobs(30)} disabled={cleanupInProgress}>Last 30 days</button></li>
                   <li><hr className="dropdown-divider" /></li>
                   <li><button className="dropdown-item text-warning" onClick={() => cleanupCancelledJobsOnly()} disabled={cleanupInProgress}>Only Cancelled Jobs</button></li>
                   <li><button className="dropdown-item text-danger" onClick={() => cleanupOldJobs(0)} disabled={cleanupInProgress}>All Completed/Failed/Cancelled Jobs</button></li>
                 </ul>
               </div>
               
               {/* Cleanup Options Explanation */}
               <div className="mt-3">
                 <small className="text-muted">
                   <strong>Cleanup Options:</strong><br/>
                   • <strong>Time-based:</strong> Removes completed/failed/cancelled jobs older than specified time<br/>
                   • <strong>Only Cancelled:</strong> Removes only cancelled jobs (keeps completed/failed jobs)<br/>
                   • <strong>All Completed/Failed/Cancelled:</strong> Removes all jobs with these statuses regardless of age
                 </small>
               </div>
             </div>
           </div>
         </div>
       )}

       {/* Jobs Table */}
       {!showDetails && (
         <div className="card">
           <div className="card-header">
             <h6 className="mb-0">
               <FaEye className="me-2" />
               Job Results ({filteredJobs.length} of {jobs.length} jobs)
             </h6>
           </div>
           <div className="card-body p-0">
             {cleanupInProgress && (
               <div className="alert alert-info text-center m-3">
                 <FaSpinner className="fa-spin me-2" />
                 Cleaning up old jobs... Please wait.
               </div>
             )}
             
             {filteredJobs.length === 0 ? (
               <div className="text-center text-muted py-5">
                 <FaEye className="mb-3" style={{ fontSize: '3rem' }} />
                 <p>{jobs.length === 0 ? 'No scan jobs found' : 'No jobs match the current filters'}</p>
                 <small>Repository scans will appear here</small>
               </div>
             ) : (
                               <div className="table-responsive">
                  <table className="table table-hover mb-0 job-monitor-table">
                   <thead className="table-light">
                     <tr>
                       <th>Status</th>
                       <th>Repository</th>
                       <th>AIT</th>
                       <th>SPK</th>
                       <th>Progress</th>
                       <th>Created</th>
                       <th>Duration</th>
                       <th>Actions</th>
                     </tr>
                   </thead>
                   <tbody>
                     {filteredJobs.map((job) => (
                       <tr key={job.job_id}>
                         <td>
                           <div className="d-flex align-items-center">
                             {getStatusIcon(job.status)}
                             <span className={`ms-2 ${getStatusBadge(job.status)}`}>
                               {job.status}
                             </span>
                           </div>
                         </td>
                         <td>
                           <div>
                             <strong>{job.repo_url?.split('/').pop() || job.repo_name || 'Unknown'}</strong>
                             <br />
                             <small className="text-muted">{job.repo_url}</small>
                           </div>
                         </td>
                         <td>
                           <span className="badge bg-primary">
                             {getDisplayName(job.ait_tag, 'ait')}
                           </span>
                         </td>
                         <td>
                           <span className="badge bg-info">
                             {getDisplayName(job.spk_tag, 'spk')}
                           </span>
                         </td>
                                                   <td>
                            <div className="progress-container">
                              <div className="progress" style={{ height: '8px', borderRadius: '4px' }}>
                                <div 
                                  className={`progress-bar ${
                                    job.status === 'completed' ? 'bg-success' :
                                    job.status === 'failed' ? 'bg-danger' :
                                    job.status === 'running' ? 'bg-primary' :
                                    'bg-secondary'
                                  }`}
                                  style={{ 
                                    width: job.status === 'completed' ? '100%' :
                                           job.status === 'failed' ? '100%' :
                                           job.status === 'running' ? '50%' : '0%',
                                    borderRadius: '4px',
                                    transition: 'width 0.3s ease'
                                  }}
                                >
                                </div>
                              </div>
                              <small className="job-progress-text">
                                {job.progress}
                              </small>
                                                           {job.error_message && (
                               <div className="error-container" style={{ maxWidth: '160px', width: '160px', overflow: 'hidden', justifyContent: 'center' }}>
                                 <button 
                                   className="error-info-btn"
                                   onClick={() => handleShowErrorDetails(job.error_message, job)}
                                   title="View Error Details"
                                   style={{ flexShrink: 0, width: '16px', height: '16px' }}
                                 >
                                   i
                                 </button>
                               </div>
                             )}
                            </div>
                          </td>
                         <td>
                           <small>
                             {new Date(job.created_at).toLocaleDateString()}<br/>
                             {new Date(job.created_at).toLocaleTimeString()}
                           </small>
                         </td>
                         <td>
                           <small>{getDuration(job.started_at, job.completed_at)}</small>
                         </td>
                         <td>
                           <div className="btn-group btn-group-sm">
                             <button
                               className="btn btn-outline-primary"
                               onClick={() => showJobDetails(job)}
                               title="View Details"
                             >
                               <FaEye />
                             </button>
                             {job.status === 'running' && (
                               <button
                                 className="btn btn-outline-warning"
                                 onClick={() => cancelJob(job.job_id)}
                                 title="Cancel Job"
                               >
                                 <FaTimes />
                               </button>
                             )}
                             {job.status === 'completed' && job.result_data && (
                               <button
                                 className="btn btn-outline-success"
                                 onClick={() => {
                                   console.log('🔍 View Results clicked for job:', job.job_id);
                                   onJobComplete(job.result_data);
                                 }}
                                 title="View Results"
                               >
                                 <FaDownload />
                               </button>
                             )}
                           </div>
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
             )}
           </div>
         </div>
       )}

      {/* Job Details Modal */}
      {showDetails && selectedJob && (
        <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
          <div className="modal-dialog modal-xl modal-dialog-scrollable" style={{ zIndex: 1055, maxWidth: '90vw' }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Job Details</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowDetails(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row g-3 g-md-4">
                  <div className="col-12 col-lg-6">
                    <div className="card h-100">
                      <div className="card-header">
                        <h6 className="mb-0">Job Information</h6>
                      </div>
                      <div className="card-body">
                        <div className="table-responsive">
                          <table className="table table-sm mb-0">
                            <tbody>
                              <tr>
                                <td className="text-nowrap" style={{ width: '25%' }}><strong>Job ID:</strong></td>
                                <td style={{ wordBreak: 'break-all' }}>
                                  <code style={{ fontSize: '0.8rem' }} className="d-block">{selectedJob.job_id}</code>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Status:</strong></td>
                                <td>
                                  <span className={getStatusBadge(selectedJob.status)}>
                                    {selectedJob.status}
                                  </span>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Repository:</strong></td>
                                <td style={{ wordBreak: 'break-all' }}>
                                  <small className="text-muted d-block">{selectedJob.repo_url}</small>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Type:</strong></td>
                                <td>{selectedJob.repo_type}</td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>AIT:</strong></td>
                                <td>{getDisplayName(selectedJob.ait_tag, 'ait')}</td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>SPK:</strong></td>
                                <td>{getDisplayName(selectedJob.spk_tag, 'spk')}</td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Created:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.created_at)}</small>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Started:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.started_at)}</small>
                                </td>
                              </tr>
                              <tr>
                                <td className="text-nowrap"><strong>Completed:</strong></td>
                                <td>
                                  <small className="d-block">{formatDate(selectedJob.completed_at)}</small>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-lg-6">
                    <div className="card h-100">
                      <div className="card-header">
                        <h6 className="mb-0">Progress & Results</h6>
                      </div>
                      <div className="card-body">
                        <div className="mb-3">
                          <strong>Progress:</strong>
                          <p className="text-muted mt-1 mb-2">{selectedJob.progress}</p>
                        </div>
                        {selectedJob.error_message && (
                          <div className="mb-3">
                            <strong>Error:</strong>
                            <div className="alert alert-danger mt-1">
                              <small>{selectedJob.error_message}</small>
                            </div>
                          </div>
                        )}
                        {selectedJob.result_data && (
                          <div className="mb-3">
                            <strong>Results:</strong>
                                <div className="alert alert-success mt-1">
                                  <div className="row g-3">
                                    <div className="col-4">
                                      <div className="text-center p-2">
                                        <div className="fw-bold text-success fs-4">{selectedJob.result_data.files_scanned || 'N/A'}</div>
                                        <small className="text-muted">Files Scanned</small>
                                      </div>
                                    </div>
                                    <div className="col-4">
                                      <div className="text-center p-2">
                                        <div className="fw-bold text-warning fs-4">{selectedJob.result_data.summary?.total_issues || 0}</div>
                                        <small className="text-muted">Threats Found</small>
                                      </div>
                                    </div>
                                    <div className="col-4">
                                      <div className="text-center p-2">
                                        <div className="fw-bold text-info fs-4">{selectedJob.result_data.summary?.logic_bomb_risk_score || 0}/100</div>
                                        <small className="text-muted">Risk Score</small>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowDetails(false)}
                >
                  Close
                </button>
                {selectedJob.status === 'completed' && selectedJob.result_data && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => {
                      console.log('🔍 View Results clicked for job:', selectedJob.job_id);
                      onJobComplete(selectedJob.result_data);
                      setShowDetails(false);
                    }}
                  >
                    View Results
                  </button>
                )}
              </div>
            </div>
          </div>
                     <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
         </div>
       )}

       {/* Error Details Modal */}
       {showErrorDetails && selectedError && (
         <div className="modal fade show error-details-modal" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
           <div className="modal-dialog" style={{ zIndex: 1055 }}>
             <div className="modal-content">
               <div className="modal-header">
                 <h5 className="modal-title">
                   <span className="text-danger">⚠️</span> Error Details
                 </h5>
                 <button
                   type="button"
                   className="btn-close"
                   onClick={() => setShowErrorDetails(false)}
                 ></button>
               </div>
               <div className="modal-body">
                 <table className="table table-bordered error-details-table">
                   <tbody>
                     <tr>
                       <th>Job ID</th>
                       <td><code>{selectedError.job.job_id}</code></td>
                     </tr>
                     <tr>
                       <th>Repository</th>
                       <td>{selectedError.job.repo_url}</td>
                     </tr>
                     <tr>
                       <th>Status</th>
                       <td>
                         <span className={getStatusBadge(selectedError.job.status)}>
                           {selectedError.job.status}
                         </span>
                       </td>
                     </tr>
                     <tr>
                       <th>Created</th>
                       <td>{formatDate(selectedError.job.created_at)}</td>
                     </tr>
                     <tr>
                       <th>Error Message</th>
                       <td className="error-message-cell">{selectedError.errorMessage}</td>
                     </tr>
                   </tbody>
                 </table>
               </div>
               <div className="modal-footer">
                 <button
                   type="button"
                   className="btn btn-secondary"
                   onClick={() => setShowErrorDetails(false)}
                 >
                   Close
                 </button>
               </div>
             </div>
           </div>
           <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
         </div>
       )}
     </div>
   );
 };

export default JobMonitorPage;
