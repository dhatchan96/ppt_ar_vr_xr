import React, { useEffect, useState } from "react";
import API from "../api";
import { copilotAPI } from "../api";
import "../style.css";
import { Toast } from "bootstrap";
import JSZip from "jszip";
import { 
  aitData, 
  spkData, 
  repoData, 
  getAITName, 
  getSPKName, 
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
} from '../config/dropdownData';

const Dashboard = ({ jobResults, setJobResults }) => {
  const [metrics, setMetrics] = useState(null);
  const [recentIssues, setRecentIssues] = useState([]);
  const [health, setHealth] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [malwareStats, setMalwareStats] = useState(null);
  const [activeTab, setActiveTab] = useState("malware");
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');

  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
  };

  // Use jobResults if available, otherwise use local state
  const malwareIssues = (jobResults?.recent_threats || recentIssues).filter((i) =>
    i.rule_id?.startsWith("MALWARE_")
  );
  const otherIssues = (jobResults?.recent_threats || recentIssues).filter((i) =>
    !i.rule_id?.startsWith("MALWARE_")
  );

  useEffect(() => {
    fetchMetrics();
    fetchHealth();
  }, []);

  // Update metrics when jobResults change
  useEffect(() => {
    if (jobResults) {
      console.log("🔄 Dashboard: Updating with new job results", jobResults);
      setMetrics(jobResults);
      setRecentIssues(jobResults.recent_threats || []);
      
      // Update malware stats from job results
      if (jobResults.recent_threats) {
        const malwareCount = jobResults.recent_threats.filter(i => i.rule_id?.startsWith("MALWARE_")).length;
        setMalwareStats({
          count: malwareCount,
          details: jobResults.recent_threats
            .filter(i => i.rule_id?.startsWith("MALWARE_"))
            .map(issue => `${issue.type}: 1`)
        });
      }
    }
  }, [jobResults]);

  const fetchMetrics = async () => {
    try {
      const res = await API.get("/api/dashboard/metrics");
      if (res.data && !res.data.error) {
        setMetrics(res.data);
        setRecentIssues(res.data.recent_issues || []);
        if (res.data.malware_patterns_found || res.data.malware_analysis) {
          setMalwareStats({
            count: res.data.malware_patterns_found || 0,
            details: Object.entries(
              res.data.malware_analysis.by_type || {}
            ).map(([type, count]) => `${type}: ${count}`),
          });
        }
      }
    } catch (error) {
      console.error("Failed to fetch metrics:", error);
    }
  };

  const fetchHealth = async () => {
    try {
      const res = await API.get("/api/health");
      setHealth(res.data);
    } catch (err) {
      console.error("Failed to fetch health info:", err);
    }
  };

  const resolveIssue = async (id) => {
    try {
      await API.put(`/api/issues/${id}/status`, { status: "RESOLVED" });
      fetchMetrics();
    } catch (error) {
      console.error("Failed to resolve issue:", error);
    }
  };

  const handleFileDrop = async (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = e.dataTransfer.items;
    const files = await extractFilesFromItems(items);
    handleUpload(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    handleUpload(files);
  };

  const extractFilesFromItems = async (items) => {
    const files = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.kind === "file") {
        const file = item.getAsFile();
        if (file) {
          files.push(file);
        }
      }
    }
    return files;
  };

  const handleUpload = async (files) => {
    if (!selectedAIT || !selectedSPK || !selectedRepo) {
      alert('Please select AIT, SPK, and Repository before uploading files.');
      return;
    }

    if (files.length === 0) return;

    setUploading(true);
    try {
      const fileContents = [];
      for (const file of files) {
        const content = await readFileContent(file);
        fileContents.push({
          name: file.name,
          content: content,
          language: getFileLanguage(file.name),
          size: file.size,
        });
      }

      const payload = {
        project_id: generateId(),
        project_name: `File Upload - ${files[0].name}`,
        timestamp: new Date().toISOString(),
        files: fileContents,
        ait_tag: selectedAIT,
        spk_tag: selectedSPK,
        repo_name: selectedRepo,
        scan_type: 'file_upload'
      };

      console.log("📤 Uploading files with payload:", payload);
      const response = await API.post("/api/scan/files", payload);
      console.log("📥 Upload response:", response.data);

      // Update job results with new scan data
      if (response.data) {
        const scanData = response.data;
        const updatedJobResults = {
          ...scanData,
          recent_threats: scanData.recent_threats || [],
          scan_info: {
            project_id: scanData.project_id || payload.project_id,
            scan_date: scanData.timestamp || payload.timestamp,
            files_scanned: scanData.files_scanned || fileContents.length,
            lines_of_code: scanData.lines_of_code || 0,
            duration_ms: scanData.duration_ms || 0,
            ait_tag: payload.ait_tag,
            spk_tag: payload.spk_tag,
            repo_name: payload.repo_name
          }
        };
        
        console.log("🔄 Setting new job results:", updatedJobResults);
        setJobResults(updatedJobResults);
        
        // Show success message
        const toast = new Toast(document.getElementById('uploadToast'));
        toast.show();
      }
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Upload failed: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => "id_" + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const map = {
      py: "python",
      js: "javascript",
      ts: "typescript",
      java: "java",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      cpp: "cpp",
      cs: "csharp",
      rb: "ruby",
      php: "php",
      zip: "zip",
    };
    return map[ext] || "unknown";
  };

  const timeAgo = (isoTime) => {
    const diffMs = Date.now() - new Date(isoTime).getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "just now";
    if (diffMin === 1) return "1 minute ago";
    return `${diffMin} minutes ago`;
  };

  const downloadCopilotPrompts = async () => {
    try {
      const res = await copilotAPI.downloadPrompts();

      const blob = new Blob([res.data], { type: "application/zip" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "copilot_prompts.zip";
      link.click();
    } catch (err) {
      console.error("Failed to download prompts:", err);
      alert("❌ Failed to download Copilot prompts.");
    }
  };

  const availableSPKs = getAvailableSPKs(selectedAIT);
  const availableRepos = getAvailableRepos(selectedSPK);

  // Use jobResults if available, otherwise use local metrics
  const displayMetrics = jobResults || metrics;
  
  if (!displayMetrics) return <p className="text-center mt-5">Loading metrics...</p>;

  const {
    ratings,
    scan_info,
    quality_gate,
    issues,
    metrics: metricData,
  } = displayMetrics;

  return (
    <div className="container-fluid mt-4 px-5">
      {health && (
        <div
          className={`alert ${
            health.status === "healthy" ? "alert-success" : "alert-danger"
          } mb-4`}
        >
          <strong>System Status:</strong> {health.status} - {health.message}
        </div>
      )}

      {/* Project Selection Dropdowns */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">Project Configuration</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4">
              <label className="form-label">AIT (Application Integration Team)</label>
              <select 
                className="form-select" 
                value={selectedAIT} 
                onChange={(e) => handleAITChange(e.target.value)}
              >
                <option value="">Select AIT</option>
                {Object.keys(aitData).map(ait => (
                  <option key={ait} value={ait}>{getAITName(ait)}</option>
                ))}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">SPK (Specific Product Key)</label>
              <select 
                className="form-select" 
                value={selectedSPK} 
                onChange={(e) => handleSPKChange(e.target.value)}
                disabled={!selectedAIT}
              >
                <option value="">Select SPK</option>
                {availableSPKs.map(spk => (
                  <option key={spk} value={spk}>{getSPKName(spk)}</option>
                ))}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Repository</label>
              <select 
                className="form-select" 
                value={selectedRepo} 
                onChange={(e) => handleRepoChange(e.target.value)}
                disabled={!selectedSPK}
              >
                <option value="">Select Repository</option>
                {availableRepos.map(repo => (
                  <option key={repo} value={repo}>{getRepoName(repo)}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* File Upload Area */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">File Upload & Scan</h5>
        </div>
        <div className="card-body">
          <div
            className={`upload-area ${dragOver ? "drag-over" : ""} ${uploading ? "uploading" : ""}`}
            onDrop={handleFileDrop}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onClick={() => document.getElementById("fileInput").click()}
            style={{
              border: "2px dashed #ccc",
              borderRadius: "8px",
              padding: "40px",
              textAlign: "center",
              cursor: "pointer",
              backgroundColor: dragOver ? "#f8f9fa" : "white",
            }}
          >
            {uploading ? (
              <div>
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Uploading...</span>
                </div>
                <p className="mt-2">Uploading and scanning files...</p>
              </div>
            ) : (
              <div>
                <i className="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                <p className="mb-2">Click to upload files or drag and drop</p>
                <p className="text-muted small">
                  Supported formats: .py, .js, .ts, .java, .html, .css, .json, .xml, .sql, .cpp, .cs, .rb, .php
                </p>
              </div>
            )}
          </div>
          <input
            id="fileInput"
            type="file"
            multiple
            style={{ display: "none" }}
            onChange={handleFileSelect}
            accept=".py,.js,.ts,.java,.html,.css,.json,.xml,.sql,.cpp,.cs,.rb,.php"
          />
        </div>
      </div>

      {/* Success Toast */}
      <div className="toast-container position-fixed top-0 end-0 p-3">
        <div id="uploadToast" className="toast" role="alert" aria-live="assertive" aria-atomic="true">
          <div className="toast-header">
            <i className="fas fa-check-circle text-success me-2"></i>
            <strong className="me-auto">Upload Successful</strong>
            <button type="button" className="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
          </div>
          <div className="toast-body">
            Files uploaded and scanned successfully!
          </div>
        </div>
      </div>

      {/* Metrics Overview */}
      <div className="row mb-4">
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h5 className="card-title text-primary">
                <i className="fas fa-shield-alt me-2"></i>
                Security Rating
              </h5>
              <h2 className={`text-${ratings?.security === "A" ? "success" : ratings?.security === "B" ? "warning" : "danger"}`}>
                {ratings?.security || "A"}
              </h2>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h5 className="card-title text-info">
                <i className="fas fa-bug me-2"></i>
                Threats Found
              </h5>
              <h2 className="text-danger">
                {displayMetrics?.summary?.total_issues || displayMetrics?.threat_intelligence?.total_threats || 0}
              </h2>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h5 className="card-title text-success">
                <i className="fas fa-file-code me-2"></i>
                Files Scanned
              </h5>
              <h2 className="text-primary">
                {scan_info?.files_scanned || 0}
              </h2>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h5 className="card-title text-warning">
                <i className="fas fa-clock me-2"></i>
                Scan Time
              </h5>
              <h2 className="text-info">
                {scan_info?.duration_ms ? `${(scan_info.duration_ms / 1000).toFixed(1)}s` : "N/A"}
              </h2>
            </div>
          </div>
        </div>
      </div>

      {/* Threat Analysis Tabs */}
      <div className="card">
        <div className="card-header">
          <ul className="nav nav-tabs card-header-tabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === "malware" ? "active" : ""}`}
                onClick={() => setActiveTab("malware")}
                type="button"
              >
                <i className="fas fa-virus me-2"></i>
                Malicious Code ({malwareIssues.length})
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === "techdebt" ? "active" : ""}`}
                onClick={() => setActiveTab("techdebt")}
                type="button"
              >
                <i className="fas fa-code me-2"></i>
                Tech Debt ({otherIssues.length})
              </button>
            </li>
          </ul>
        </div>
        <div className="card-body">
          {activeTab === "malware" && (
            <div>
              <h5>Malicious Code Detection</h5>
              {malwareIssues.length === 0 ? (
                <p className="text-muted">No malicious code patterns detected.</p>
              ) : (
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>File</th>
                        <th>Line</th>
                        <th>Threat Type</th>
                        <th>Severity</th>
                        <th>Description</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {malwareIssues.map((issue, index) => (
                        <tr key={index}>
                          <td>
                            <code>{issue.file_path || issue.file_name || "Unknown"}</code>
                          </td>
                          <td>{issue.line_number || "N/A"}</td>
                          <td>
                            <span className={`badge bg-${issue.severity === "CRITICAL_BOMB" ? "danger" : issue.severity === "HIGH_RISK" ? "warning" : "info"}`}>
                              {issue.type || "Unknown"}
                            </span>
                          </td>
                          <td>
                            <span className={`badge bg-${issue.severity === "CRITICAL_BOMB" ? "danger" : issue.severity === "HIGH_RISK" ? "warning" : "secondary"}`}>
                              {issue.severity || "Unknown"}
                            </span>
                          </td>
                          <td>{issue.message || "No description"}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-success"
                              onClick={() => resolveIssue(issue.id)}
                            >
                              <i className="fas fa-check me-1"></i>
                              Resolve
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {activeTab === "techdebt" && (
            <div>
              <h5>Technical Debt Analysis</h5>
              {otherIssues.length === 0 ? (
                <p className="text-muted">No technical debt issues found.</p>
              ) : (
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>File</th>
                        <th>Line</th>
                        <th>Issue Type</th>
                        <th>Severity</th>
                        <th>Description</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {otherIssues.map((issue, index) => (
                        <tr key={index}>
                          <td>
                            <code>{issue.file_path || issue.file_name || "Unknown"}</code>
                          </td>
                          <td>{issue.line_number || "N/A"}</td>
                          <td>
                            <span className={`badge bg-${issue.severity === "CRITICAL" ? "danger" : issue.severity === "MAJOR" ? "warning" : "info"}`}>
                              {issue.type || "Unknown"}
                            </span>
                          </td>
                          <td>
                            <span className={`badge bg-${issue.severity === "CRITICAL" ? "danger" : issue.severity === "MAJOR" ? "warning" : "secondary"}`}>
                              {issue.severity || "Unknown"}
                            </span>
                          </td>
                          <td>{issue.message || "No description"}</td>
                          <td>
                            <button
                              className="btn btn-sm btn-outline-success"
                              onClick={() => resolveIssue(issue.id)}
                            >
                              <i className="fas fa-check me-1"></i>
                              Resolve
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;