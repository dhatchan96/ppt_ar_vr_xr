#!/usr/bin/env python3
"""
Test script to debug command center metrics
"""

import requests
import json

def test_debug_endpoints():
    """Test the debug endpoints to see what's happening"""
    base_url = "http://localhost:5000"
    
    print("🔍 Testing Debug Endpoints...")
    print("=" * 50)
    
    # Test 1: Debug issues endpoint
    print("\n1. Testing /api/debug/issues")
    try:
        response = requests.get(f"{base_url}/api/debug/issues")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Total issues: {data.get('total_issues', 0)}")
            print(f"✅ Type counts: {data.get('type_counts', {})}")
            print(f"✅ Sample issues: {json.dumps(data.get('sample_issues', []), indent=2)}")
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 2: Command center metrics endpoint
    print("\n2. Testing /api/command-center/metrics")
    try:
        response = requests.get(f"{base_url}/api/command-center/metrics")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Command center metrics returned")
            
            # Print the full response structure to debug
            print(f"📊 Full response structure:")
            print(f"   Keys in response: {list(data.keys())}")
            
            # Check scan_info if it exists
            if 'scan_info' in data:
                print(f"   📁 Scan info keys: {list(data['scan_info'].keys())}")
                print(f"   📁 Files scanned: {data['scan_info'].get('files_scanned', 'NOT FOUND')}")
                print(f"   📁 Lines of code: {data['scan_info'].get('lines_of_code', 'NOT FOUND')}")
                print(f"   📁 Security rating: {data['scan_info'].get('security_rating', 'NOT FOUND')}")
                print(f"   📁 Reliability rating: {data['scan_info'].get('reliability_rating', 'NOT FOUND')}")
                print(f"   📁 Maintainability rating: {data['scan_info'].get('maintainability_rating', 'NOT FOUND')}")
                print(f"   📁 Technical debt: {data['scan_info'].get('technical_debt_hours', 'NOT FOUND')}")
            else:
                print(f"   ❌ No scan_info found in response")
            
            # Check metrics if it exists
            if 'metrics' in data:
                print(f"   📊 Metrics keys: {list(data['metrics'].keys())}")
                print(f"   📊 Coverage: {data['metrics'].get('coverage', 'NOT FOUND')}")
                print(f"   📊 Duplications: {data['metrics'].get('duplications', 'NOT FOUND')}")
                print(f"   📊 Security rating: {data['metrics'].get('security_rating', 'NOT FOUND')}")
                print(f"   📊 Reliability rating: {data['metrics'].get('reliability_rating', 'NOT FOUND')}")
                print(f"   📊 Maintainability rating: {data['metrics'].get('maintainability_rating', 'NOT FOUND')}")
                print(f"   📊 Technical debt: {data['metrics'].get('technical_debt_hours', 'NOT FOUND')}")
            else:
                print(f"   ❌ No metrics found in response")
            
            # Check specific threat counts
            threats = data.get('threats', {})
            by_type = threats.get('by_type', {})
            
            print(f"✅ SCHEDULED_THREAT: {by_type.get('SCHEDULED_THREAT', 0)}")
            print(f"✅ TARGETED_ATTACK: {by_type.get('TARGETED_ATTACK', 0)}")
            print(f"✅ EXECUTION_TRIGGER: {by_type.get('EXECUTION_TRIGGER', 0)}")
            print(f"✅ DESTRUCTIVE_PAYLOAD: {by_type.get('DESTRUCTIVE_PAYLOAD', 0)}")
            print(f"✅ FINANCIAL_FRAUD: {by_type.get('FINANCIAL_FRAUD', 0)}")
            
            # Check total issues
            print(f"✅ Total issues: {threats.get('total', 0)}")
            
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Exception: {e}")
    
    # Test 3: Health endpoint
    print("\n3. Testing /api/health")
    try:
        response = requests.get(f"{base_url}/api/health")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health check passed")
            print(f"✅ Total issues: {data.get('total_issues', 0)}")
            print(f"✅ Active threats: {data.get('active_threats', 0)}")
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Exception: {e}")

def test_with_sample_data():
    """Test with a sample file upload to see if issues are created"""
    print("\n" + "=" * 50)
    print("🧪 Testing with sample data...")
    
    # Create a simple test file content
    test_content = '''
import datetime
import os
import time

# SCHEDULED_THREAT - Time-based trigger
def scheduled_threat_example():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025:
        os.remove('/etc/passwd')
        print("Scheduled threat triggered!")

# EXECUTION_TRIGGER - Counter-based trigger  
def execution_trigger_example():
    counter = 0
    for i in range(100):
        counter += 1
        if counter == 50:  # Execution counter trigger
            os.system('rm -rf /home/user')
            print("Execution trigger activated!")

# TARGETED_ATTACK - User-specific trigger
def targeted_attack_example():
    import getpass
    current_user = getpass.getuser()
    if current_user == "admin":
        os.system('rm -rf /home/admin')
        print("Targeted attack executed!")

# DESTRUCTIVE_PAYLOAD - Direct destructive action
def destructive_payload_example():
    import shutil
    shutil.rmtree('/var/log')
    print("Destructive payload executed!")

# FINANCIAL_FRAUD - Financial redirection
def financial_fraud_example():
    bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    print(f"Payment redirected to: {bitcoin_address}")

# Main function to test all patterns
def main():
    print("Testing threat patterns...")
    
    # Test scheduled threat
    scheduled_threat_example()
    
    # Test execution trigger
    execution_trigger_example()
    
    # Test targeted attack
    targeted_attack_example()
    
    # Test destructive payload
    destructive_payload_example()
    
    # Test financial fraud
    financial_fraud_example()
    
    print("All tests completed!")

if __name__ == "__main__":
    main()
'''
    
    # Test file upload
    base_url = "http://localhost:5000"
    
    try:
        upload_data = {
            "scan_id": "test_debug_scan",
            "scan_type": "quick",
            "file_contents": [
                {
                    "id": "test_file_1",
                    "name": "test_debug_file.py",
                    "content": test_content,
                    "type": "python"
                }
            ],
            "project_id": "test_project",
            "project_name": "Test Debug Project"
        }
        
        print("📤 Uploading test file...")
        response = requests.post(f"{base_url}/api/scan/files", json=upload_data)
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Upload successful")
            print(f"✅ Files scanned: {data.get('files_scanned', 0)}")
            print(f"✅ Total issues: {data.get('summary', {}).get('total_issues', 0)}")
            
            # Wait a moment and check metrics again
            import time
            time.sleep(2)
            
            print("\n🔄 Checking metrics after upload...")
            test_debug_endpoints()
            
        else:
            print(f"❌ Upload failed: {response.status_code} - {response.text}")
            
    except Exception as e:
        print(f"❌ Exception during upload: {e}")

if __name__ == "__main__":
    print("🚀 Starting Debug Test...")
    test_debug_endpoints()
    test_with_sample_data()
    print("\n✅ Debug test completed!") 