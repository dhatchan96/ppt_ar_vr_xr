import React, { useState, useEffect } from 'react';
import './WaveManagement.css';

const WaveManagement = () => {
    const [waves, setWaves] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showCreateWave, setShowCreateWave] = useState(false);
    const [newWave, setNewWave] = useState({
        name: '',
        description: '',
        target_start_date: '',
        target_completion_date: '',
        priority: 'MEDIUM',
        business_impact: 'MEDIUM',
        team_owner: '',
        budget_allocation: 0,
        fte_requirement: 1.0
    });

    useEffect(() => {
        fetchWaves();
    }, []);

    const fetchWaves = async () => {
        try {
            setLoading(true);
            const response = await fetch('/api/v1/waves');
            const data = await response.json();

            if (data.success) {
                setWaves(data.waves);
            }
        } catch (error) {
            console.error('Error fetching waves:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateWave = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/v1/waves', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newWave),
            });

            const data = await response.json();

            if (data.success) {
                setShowCreateWave(false);
                setNewWave({
                    name: '',
                    description: '',
                    target_start_date: '',
                    target_completion_date: '',
                    priority: 'MEDIUM',
                    business_impact: 'MEDIUM',
                    team_owner: '',
                    budget_allocation: 0,
                    fte_requirement: 1.0
                });
                fetchWaves();
            } else {
                alert('Error creating wave: ' + data.error);
            }
        } catch (error) {
            console.error('Error creating wave:', error);
            alert('Error creating wave');
        }
    };

    const handleUpdateWaveStatus = async (waveId, newStatus) => {
        try {
            const response = await fetch(`/api/v1/waves/${waveId}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus }),
            });

            const data = await response.json();

            if (data.success) {
                fetchWaves();
            } else {
                alert('Error updating wave status: ' + data.error);
            }
        } catch (error) {
            console.error('Error updating wave status:', error);
            alert('Error updating wave status');
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            'PLANNING': '#6c757d',
            'IN_PROGRESS': '#007bff',
            'COMPLETED': '#28a745',
            'ON_HOLD': '#ffc107'
        };
        return colors[status] || '#6c757d';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'CRITICAL': '#dc3545',
            'HIGH': '#fd7e14',
            'MEDIUM': '#ffc107',
            'LOW': '#28a745'
        };
        return colors[priority] || '#6c757d';
    };

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    };

    const calculateProgress = (wave) => {
        if (wave.total_vulnerabilities === 0) return 0;
        return Math.round((wave.completed_vulnerabilities / wave.total_vulnerabilities) * 100);
    };

    return (
        <div className="wave-management">
            <div className="header">
                <h2>Wave Management</h2>
                <p>Organize and track vulnerability remediation waves</p>
                <button 
                    className="btn-create-wave"
                    onClick={() => setShowCreateWave(true)}
                >
                    Create New Wave
                </button>
            </div>

            {/* Statistics */}
            <div className="statistics-section">
                <div className="stat-card">
                    <h3>Total Waves</h3>
                    <p className="stat-number">{waves.length}</p>
                </div>
                <div className="stat-card">
                    <h3>In Progress</h3>
                    <p className="stat-number in-progress">
                        {waves.filter(w => w.status === 'IN_PROGRESS').length}
                    </p>
                </div>
                <div className="stat-card">
                    <h3>Completed</h3>
                    <p className="stat-number completed">
                        {waves.filter(w => w.status === 'COMPLETED').length}
                    </p>
                </div>
                <div className="stat-card">
                    <h3>Total Budget</h3>
                    <p className="stat-number">
                        {formatCurrency(waves.reduce((sum, w) => sum + (w.budget_allocation || 0), 0))}
                    </p>
                </div>
            </div>

            {/* Waves List */}
            <div className="waves-container">
                {loading ? (
                    <div className="loading">Loading waves...</div>
                ) : (
                    <div className="waves-grid">
                        {waves.map((wave) => (
                            <div key={wave.id} className="wave-card">
                                <div className="wave-header">
                                    <h3 className="wave-name">{wave.name}</h3>
                                    <div className="wave-badges">
                                        <span 
                                            className="status-badge"
                                            style={{ backgroundColor: getStatusColor(wave.status) }}
                                        >
                                            {wave.status}
                                        </span>
                                        <span 
                                            className="priority-badge"
                                            style={{ backgroundColor: getPriorityColor(wave.priority) }}
                                        >
                                            {wave.priority}
                                        </span>
                                    </div>
                                </div>

                                <p className="wave-description">{wave.description}</p>

                                <div className="wave-progress">
                                    <div className="progress-header">
                                        <span>Progress</span>
                                        <span>{calculateProgress(wave)}%</span>
                                    </div>
                                    <div className="progress-bar">
                                        <div 
                                            className="progress-fill"
                                            style={{ width: `${calculateProgress(wave)}%` }}
                                        ></div>
                                    </div>
                                    <div className="progress-stats">
                                        <span>{wave.completed_vulnerabilities} / {wave.total_vulnerabilities} completed</span>
                                    </div>
                                </div>

                                <div className="wave-details">
                                    <div className="detail-row">
                                        <span className="label">Team Owner:</span>
                                        <span className="value">{wave.team_owner}</span>
                                    </div>
                                    <div className="detail-row">
                                        <span className="label">Budget:</span>
                                        <span className="value">{formatCurrency(wave.budget_allocation)}</span>
                                    </div>
                                    <div className="detail-row">
                                        <span className="label">FTE Required:</span>
                                        <span className="value">{wave.fte_requirement} FTE</span>
                                    </div>
                                </div>

                                <div className="wave-actions">
                                    {wave.status === 'PLANNING' && (
                                        <button 
                                            className="btn-start"
                                            onClick={() => handleUpdateWaveStatus(wave.id, 'IN_PROGRESS')}
                                        >
                                            Start Wave
                                        </button>
                                    )}
                                    
                                    {wave.status === 'IN_PROGRESS' && (
                                        <button 
                                            className="btn-complete"
                                            onClick={() => handleUpdateWaveStatus(wave.id, 'COMPLETED')}
                                        >
                                            Complete Wave
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* Create Wave Modal */}
            {showCreateWave && (
                <div className="modal-overlay" onClick={() => setShowCreateWave(false)}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3>Create New Wave</h3>
                            <button 
                                className="btn-close"
                                onClick={() => setShowCreateWave(false)}
                            >
                                ×
                            </button>
                        </div>
                        
                        <form onSubmit={handleCreateWave} className="modal-body">
                            <div className="form-group">
                                <label>Wave Name *</label>
                                <input
                                    type="text"
                                    value={newWave.name}
                                    onChange={(e) => setNewWave({...newWave, name: e.target.value})}
                                    required
                                    placeholder="Enter wave name"
                                />
                            </div>

                            <div className="form-group">
                                <label>Description *</label>
                                <textarea
                                    value={newWave.description}
                                    onChange={(e) => setNewWave({...newWave, description: e.target.value})}
                                    required
                                    placeholder="Enter wave description"
                                    rows="3"
                                />
                            </div>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Start Date *</label>
                                    <input
                                        type="date"
                                        value={newWave.target_start_date}
                                        onChange={(e) => setNewWave({...newWave, target_start_date: e.target.value})}
                                        required
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Completion Date *</label>
                                    <input
                                        type="date"
                                        value={newWave.target_completion_date}
                                        onChange={(e) => setNewWave({...newWave, target_completion_date: e.target.value})}
                                        required
                                    />
                                </div>
                            </div>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Priority *</label>
                                    <select
                                        value={newWave.priority}
                                        onChange={(e) => setNewWave({...newWave, priority: e.target.value})}
                                        required
                                    >
                                        <option value="CRITICAL">Critical</option>
                                        <option value="HIGH">High</option>
                                        <option value="MEDIUM">Medium</option>
                                        <option value="LOW">Low</option>
                                    </select>
                                </div>

                                <div className="form-group">
                                    <label>Business Impact *</label>
                                    <select
                                        value={newWave.business_impact}
                                        onChange={(e) => setNewWave({...newWave, business_impact: e.target.value})}
                                        required
                                    >
                                        <option value="CRITICAL">Critical</option>
                                        <option value="HIGH">High</option>
                                        <option value="MEDIUM">Medium</option>
                                        <option value="LOW">Low</option>
                                    </select>
                                </div>
                            </div>

                            <div className="form-group">
                                <label>Team Owner *</label>
                                <input
                                    type="text"
                                    value={newWave.team_owner}
                                    onChange={(e) => setNewWave({...newWave, team_owner: e.target.value})}
                                    required
                                    placeholder="Enter team owner"
                                />
                            </div>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Budget Allocation ($)</label>
                                    <input
                                        type="number"
                                        value={newWave.budget_allocation}
                                        onChange={(e) => setNewWave({...newWave, budget_allocation: parseFloat(e.target.value) || 0})}
                                        placeholder="0"
                                        min="0"
                                    />
                                </div>

                                <div className="form-group">
                                    <label>FTE Requirement</label>
                                    <input
                                        type="number"
                                        value={newWave.fte_requirement}
                                        onChange={(e) => setNewWave({...newWave, fte_requirement: parseFloat(e.target.value) || 0})}
                                        placeholder="1.0"
                                        min="0"
                                        step="0.1"
                                    />
                                </div>
                            </div>

                            <div className="form-actions">
                                <button type="button" className="btn-cancel" onClick={() => setShowCreateWave(false)}>
                                    Cancel
                                </button>
                                <button type="submit" className="btn-create">
                                    Create Wave
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WaveManagement;
