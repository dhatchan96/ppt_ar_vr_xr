import React, { useState, useEffect } from "react";
import API from "../api";
import "../style.css";
import { getAITName, getSPKName, getRepoName } from '../config/dropdownData';
import * as XLSX from 'xlsx';
import {
  FaShieldAlt,
  FaBug,
  FaExclamationTriangle,
  FaTools,
  FaFilter,
  FaTimesCircle,
  FaEye,
  FaCheck,
  FaBan,
  FaInfoCircle,
  FaUndo
} from "react-icons/fa";

const ActiveThreatsManagement = () => {
  const [activeTab, setActiveTab] = useState("issue");
  const [activeSubTab, setActiveSubTab] = useState("malicious");
  const [threats, setThreats] = useState([]);
  const [vulnerabilities, setVulnerabilities] = useState([]);
  
  // Hierarchical filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  
  // Vulnerability filter states
  const [vulnFilterSeverity, setVulnFilterSeverity] = useState('ALL');
  const [vulnFilterPriority, setVulnFilterPriority] = useState('ALL');
  const [vulnFilterStatus, setVulnFilterStatus] = useState('ALL');

  // Add pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Details popup state
  const [showDetailsPopup, setShowDetailsPopup] = useState(false);
  const [selectedThreat, setSelectedThreat] = useState(null);
  const [showVulnerabilityDetailsPopup, setShowVulnerabilityDetailsPopup] = useState(false);
  const [selectedVulnerability, setSelectedVulnerability] = useState(null);
  const [importingExcel, setImportingExcel] = useState(false);
  const [excelData, setExcelData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch threats from the same endpoint as ThreatIssues
      const threatsRes = await API.get("/api/threats");
      console.log("Threats API response:", threatsRes);
      const threatsData = threatsRes.data?.threats || threatsRes.data || [];
      console.log("Processed threats data:", threatsData);
      setThreats(threatsData);
      
      // Try to fetch enhanced vulnerabilities
      try {
        const params = new URLSearchParams({
          severity: 'ALL',
          priority: 'ALL',
          wave_assignment: 'ALL',
          page: 1,
          per_page: 1000 // Get all vulnerabilities for now
        });
        const vulnerabilitiesRes = await API.get(`/api/v1/vulnerabilities/enhanced?${params}`);
        let apiVulnerabilities = [];
        if (vulnerabilitiesRes.data?.success) {
          apiVulnerabilities = vulnerabilitiesRes.data.vulnerabilities || [];
        }
        
        // Load any persisted Excel data from localStorage and merge with API data
        const persistedExcelData = localStorage.getItem('excel_vulnerabilities');
        if (persistedExcelData) {
          try {
            const parsedExcelData = JSON.parse(persistedExcelData);
            setExcelData(parsedExcelData);
            
            // Merge API data with Excel data, avoiding duplicates
            const existingIds = new Set(apiVulnerabilities.map(v => v.id));
            const newExcelVulns = parsedExcelData.filter(v => !existingIds.has(v.id));
            const mergedVulnerabilities = [...apiVulnerabilities, ...newExcelVulns];
            
            setVulnerabilities(mergedVulnerabilities);
            console.log(`Loaded ${apiVulnerabilities.length} API vulnerabilities and ${parsedExcelData.length} Excel vulnerabilities (${newExcelVulns.length} new)`);
          } catch (error) {
            console.error('Error loading persisted Excel data:', error);
            localStorage.removeItem('excel_vulnerabilities');
            setVulnerabilities(apiVulnerabilities);
          }
        } else {
          setVulnerabilities(apiVulnerabilities);
        }
      } catch (vulnError) {
        console.log("Enhanced vulnerabilities endpoint not available, using empty array");
        
        // Even if API fails, try to load persisted Excel data
        const persistedExcelData = localStorage.getItem('excel_vulnerabilities');
        if (persistedExcelData) {
          try {
            const parsedExcelData = JSON.parse(persistedExcelData);
            setExcelData(parsedExcelData);
            setVulnerabilities(parsedExcelData);
            console.log(`Loaded ${parsedExcelData.length} persisted Excel vulnerabilities`);
          } catch (error) {
            console.error('Error loading persisted Excel data:', error);
            localStorage.removeItem('excel_vulnerabilities');
            setVulnerabilities([]);
          }
        } else {
          setVulnerabilities([]);
        }
      }
    } catch (err) {
      console.error("Failed to fetch data:", err);
      
      // If all API calls fail, try to load persisted Excel data
      const persistedExcelData = localStorage.getItem('excel_vulnerabilities');
      if (persistedExcelData) {
        try {
          const parsedExcelData = JSON.parse(persistedExcelData);
          setExcelData(parsedExcelData);
          setVulnerabilities(parsedExcelData);
          console.log(`Loaded ${parsedExcelData.length} persisted Excel vulnerabilities as fallback`);
        } catch (error) {
          console.error('Error loading persisted Excel data:', error);
          localStorage.removeItem('excel_vulnerabilities');
        }
      }
    }
  };

  const handleStatusToggle = async (id) => {
    const threat = threats.find((t) => t.id === id);
    const newStatus =
      threat.status === "ACTIVE_THREAT" ? "NEUTRALIZED" : "ACTIVE_THREAT";
    try {
      await API.put(`/api/threats/${id}/status`, { status: newStatus });
      fetchData();
    } catch (err) {
      console.error("Failed to update threat status:", err);
    }
  };

  const neutralizeThreat = async (id) => {
    if (!window.confirm("Are you sure you want to neutralize this threat?"))
      return;
    try {
      await API.post(`/api/threats/${id}/neutralize`);
      fetchData();
    } catch (err) {
      console.error("Failed to neutralize threat:", err);
    }
  };

  const revertThreat = async (id) => {
    if (!window.confirm("Are you sure you want to revert this threat to active status?"))
      return;
    try {
      // Use the same endpoint as neutralize but with different method or use status update
      await API.put(`/api/threats/${id}/status`, { status: "ACTIVE_THREAT" });
      fetchData();
    } catch (err) {
      console.error("Failed to revert threat:", err);
    }
  };

  const showDetails = (threat) => {
    setSelectedThreat(threat);
    setShowDetailsPopup(true);
  };

  const closeDetails = () => {
    setShowDetailsPopup(false);
    setSelectedThreat(null);
  };

  const showVulnerabilityDetails = (vulnerability) => {
    setSelectedVulnerability(vulnerability);
    setShowVulnerabilityDetailsPopup(true);
  };

  const closeVulnerabilityDetails = () => {
    setShowVulnerabilityDetailsPopup(false);
    setSelectedVulnerability(null);
  };

  const neutralizeVulnerability = async (id) => {
    if (!window.confirm("Are you sure you want to neutralize this vulnerability?"))
      return;
    try {
      // Update vulnerability status to NEUTRALIZED
      await API.put(`/api/v1/vulnerabilities/enhanced/${id}/status`, { status: "NEUTRALIZED" });
      fetchData();
    } catch (err) {
      console.error("Failed to neutralize vulnerability:", err);
    }
  };

  const revertVulnerability = async (id) => {
    if (!window.confirm("Are you sure you want to revert this vulnerability to active status?"))
      return;
    try {
      // Update vulnerability status back to ACTIVE
      await API.put(`/api/vulnerabilities/${id}/status`, { status: "ACTIVE" });
      fetchData();
    } catch (err) {
      console.error("Failed to revert vulnerability:", err);
    }
  };

  const handleExcelUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setImportingExcel(true);
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        // Skip header row and process data
        const processedData = jsonData.slice(1).map((row, index) => {
          return {
            id: `excel-${Date.now()}-${index}`,
            ait_tag: row[0] || 'AIT-Unknown',
            title: row[1] || 'Unknown Vulnerability',
            description: row[1] || 'No description available',
            severity: row[2] || 'MEDIUM_RISK',
            risk_score: parseInt(row[3]) || Math.floor(Math.random() * 10) + 1,
            remediation_action: row[4] || 'Update to latest version',
            status: row[5] || 'ACTIVE_THREAT',
            priority: 'MEDIUM', // Default priority
            wave_assignment: 'UNASSIGNED', // Default wave assignment
            cost_impact: 0, // Default cost impact
            created_date: new Date().toISOString(),
            source: 'excel_import'
          };
        });

        // Save to backend API to persist the data
        try {
          // Try to save each vulnerability to the backend
          for (const vuln of processedData) {
            await API.post('/api/v1/vulnerabilities/enhanced', vuln);
          }
          
          // Update local state with the new data
          setExcelData(processedData);
          setVulnerabilities(prevVulns => [...prevVulns, ...processedData]);
          
          // Save to localStorage as backup
          const existingExcelData = localStorage.getItem('excel_vulnerabilities');
          const existingData = existingExcelData ? JSON.parse(existingExcelData) : [];
          const updatedData = [...existingData, ...processedData];
          localStorage.setItem('excel_vulnerabilities', JSON.stringify(updatedData));
          
          alert(`Successfully imported and persisted ${processedData.length} vulnerabilities from Excel file!`);
        } catch (apiError) {
          console.error('Error saving to backend:', apiError);
          
          // If backend save fails, still update local state and save to localStorage
          setExcelData(processedData);
          setVulnerabilities(prevVulns => [...prevVulns, ...processedData]);
          
          // Save to localStorage as backup
          const existingExcelData = localStorage.getItem('excel_vulnerabilities');
          const existingData = existingExcelData ? JSON.parse(existingExcelData) : [];
          const updatedData = [...existingData, ...processedData];
          localStorage.setItem('excel_vulnerabilities', JSON.stringify(updatedData));
          
          alert(`Imported ${processedData.length} vulnerabilities to local state. Backend save failed - data saved to browser storage as backup.`);
        }
      } catch (error) {
        console.error('Error processing Excel file:', error);
        alert('Error processing Excel file. Please check the file format.');
      } finally {
        setImportingExcel(false);
      }
    };

    reader.onerror = () => {
      alert('Error reading Excel file.');
      setImportingExcel(false);
    };

    reader.readAsArrayBuffer(file);
    event.target.value = ''; // Reset file input
  };

  const downloadSampleExcel = () => {
    const sampleData = [
      ['AIT', 'Vulnerability', 'Severity', 'Risk Score', 'Remediation Action', 'Status'],
      ['AIT-001', 'SQL Injection Vulnerability', 'CRITICAL_BOMB', 9, 'Use parameterized queries and input validation', 'ACTIVE_THREAT'],
      ['AIT-002', 'XSS Vulnerability', 'HIGH_RISK', 7, 'Implement input validation and output encoding', 'ACTIVE_THREAT'],
      ['AIT-003', 'Hardcoded Credentials', 'MEDIUM_RISK', 5, 'Move credentials to environment variables', 'ACTIVE_THREAT'],
      ['AIT-004', 'Outdated Dependencies', 'LOW_RISK', 3, 'Update to latest secure version', 'ACTIVE_THREAT'],
      ['AIT-005', 'Missing Input Validation', 'HIGH_RISK', 6, 'Add comprehensive input validation', 'ACTIVE_THREAT'],
      ['AIT-006', 'Insecure File Upload', 'CRITICAL_BOMB', 8, 'Implement file type validation and scanning', 'ACTIVE_THREAT'],
      ['AIT-007', 'Weak Password Policy', 'MEDIUM_RISK', 4, 'Enforce strong password policy', 'ACTIVE_THREAT'],
      ['AIT-008', 'Missing HTTPS', 'HIGH_RISK', 7, 'Enable HTTPS and redirect HTTP traffic', 'ACTIVE_THREAT'],
      ['AIT-009', 'Insecure Session Management', 'MEDIUM_RISK', 5, 'Implement proper session management', 'ACTIVE_THREAT'],
      ['AIT-010', 'Directory Traversal', 'CRITICAL_BOMB', 9, 'Implement proper path validation', 'ACTIVE_THREAT']
    ];

    const ws = XLSX.utils.aoa_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Vulnerabilities');
    
    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // AIT
      { wch: 35 }, // Vulnerability
      { wch: 15 }, // Severity
      { wch: 12 }, // Risk Score
      { wch: 40 }, // Remediation Action
      { wch: 18 }  // Status
    ];
    ws['!cols'] = colWidths;

    // Add some styling to the header row
    for (let col = 0; col < sampleData[0].length; col++) {
      const cellRef = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellRef]) continue;
      ws[cellRef].s = {
        font: { bold: true, color: { rgb: "FFFFFF" } },
        fill: { fgColor: { rgb: "4472C4" } },
        alignment: { horizontal: "center" }
      };
    }

    XLSX.writeFile(wb, 'vulnerability_template.xlsx');
  };

  const resetToApiData = () => {
    setExcelData([]);
    localStorage.removeItem('excel_vulnerabilities'); // Clear localStorage backup
    fetchData(); // This will fetch fresh data from the backend and properly handle the merge
    alert('Refreshed data from API and cleared local backup. Any persisted Excel data will be included.');
  };

  // Filter threats based on type - including security debt in tech debt
  const maliciousThreats = threats.filter((threat) => {
    // Exclude tech debt, vulnerability, and security debt types
    const threatType = threat.type?.toLowerCase() || '';
    const threatRuleId = threat.rule_id?.toLowerCase() || '';
    const threatMessage = threat.message?.toLowerCase() || '';
    
    const isTechDebt = threatType.includes('tech debt') || 
                      threatType.includes('vulnerability') ||
                      threatType.includes('security debt') ||
                      threatType.includes('security tech debt') ||
                      threatType.includes('security_tech_debt') ||
                      threatRuleId.includes('tech_debt') ||
                      threatRuleId.includes('vulnerability') ||
                      threatRuleId.includes('security_debt') ||
                      threatRuleId.includes('security_tech_debt') ||
                      threatMessage.includes('tech debt') ||
                      threatMessage.includes('vulnerability') ||
                      threatMessage.includes('security debt') ||
                      threatMessage.includes('security tech debt');
    
    // Apply hierarchical filters
    if (filterAIT && threat.ait_tag !== filterAIT) return false;
    if (filterSPK && threat.spk_tag !== filterSPK) return false;
    if (filterRepo && threat.repo_name !== filterRepo) return false;
    
    const result = !isTechDebt;
    if (threat.type) {
      console.log(`Threat ${threat.id}: type="${threat.type}", isTechDebt=${isTechDebt}, result=${result}`);
    }
    return result;
  });

  const techDebtThreats = threats.filter((threat) => {
    // Include tech debt, vulnerability, and security debt types
    const threatType = threat.type?.toLowerCase() || '';
    const threatRuleId = threat.rule_id?.toLowerCase() || '';
    const threatMessage = threat.message?.toLowerCase() || '';
    
    const isTechDebt = threatType.includes('tech debt') || 
                      threatType.includes('vulnerability') ||
                      threatType.includes('security debt') ||
                      threatType.includes('security tech debt') ||
                      threatType.includes('security_tech_debt') ||
                      threatRuleId.includes('tech_debt') ||
                      threatRuleId.includes('vulnerability') ||
                      threatRuleId.includes('security_debt') ||
                      threatRuleId.includes('security_tech_debt') ||
                      threatMessage.includes('tech debt') ||
                      threatMessage.includes('vulnerability') ||
                      threatMessage.includes('security debt') ||
                      threatMessage.includes('security tech debt');
    
    // Apply hierarchical filters
    if (filterAIT && threat.ait_tag !== filterAIT) return false;
    if (filterSPK && threat.spk_tag !== filterSPK) return false;
    if (filterRepo && threat.repo_name !== filterRepo) return false;
    
    return isTechDebt;
  });

  // Additional statistics for tech debt categories
  const hardcodedCredentials = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('hardcoded') || 
    threat.rule_id?.toLowerCase().includes('credentials') ||
    threat.debt_category === 'HARDCODED_CREDENTIALS'
  );

  const hardcodedUrls = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('url') || 
    threat.rule_id?.toLowerCase().includes('endpoint') ||
    threat.debt_category === 'HARDCODED_URLS'
  );

  const inputValidation = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('input') || 
    threat.rule_id?.toLowerCase().includes('validation') ||
    threat.debt_category === 'INPUT_VALIDATION'
  );

  const vulnerableLibraries = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('library') || 
    threat.rule_id?.toLowerCase().includes('dependency') ||
    threat.debt_category === 'VULNERABLE_LIBRARIES'
  );

  const accessControl = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('access') || 
    threat.rule_id?.toLowerCase().includes('control') ||
    threat.debt_category === 'ACCESS_CONTROL'
  );

  // Calculate total hours (assuming each threat has an effort field)
  const totalHours = techDebtThreats.reduce((total, threat) => {
    return total + (threat.effort || 0);
  }, 0);

  // Filter vulnerabilities based on selected filters
  const filteredVulnerabilities = vulnerabilities.filter((vuln) => {
    // Apply severity filter
    if (vulnFilterSeverity !== 'ALL' && vuln.severity !== vulnFilterSeverity) return false;
    
    // Apply priority filter
    if (vulnFilterPriority !== 'ALL' && vuln.priority !== vulnFilterPriority) return false;
    
    // Apply status filter
    if (vulnFilterStatus !== 'ALL') {
      const vulnStatus = vuln.status || 'ACTIVE';
      if (vulnFilterStatus === 'ACTIVE' && vulnStatus !== 'ACTIVE') return false;
      if (vulnFilterStatus === 'NEUTRALIZED' && vulnStatus !== 'NEUTRALIZED') return false;
      if (vulnFilterStatus === 'RESOLVED' && vulnStatus !== 'RESOLVED') return false;
    }
    
    return true;
  });

  // Vulnerability statistics
  const criticalVulnerabilities = filteredVulnerabilities.filter(v => v.severity === 'CRITICAL_BOMB');
  const highRiskVulnerabilities = filteredVulnerabilities.filter(v => v.severity === 'HIGH_RISK');
  const mediumRiskVulnerabilities = filteredVulnerabilities.filter(v => v.severity === 'MEDIUM_RISK');
  const lowRiskVulnerabilities = filteredVulnerabilities.filter(v => v.severity === 'LOW_RISK');
  const activeVulnerabilities = filteredVulnerabilities.filter(v => (v.status || 'ACTIVE') === 'ACTIVE');
  const neutralizedVulnerabilities = filteredVulnerabilities.filter(v => v.status === 'NEUTRALIZED');
  const resolvedVulnerabilities = filteredVulnerabilities.filter(v => v.status === 'RESOLVED');
  
  // Calculate total cost impact
  const totalCostImpact = filteredVulnerabilities.reduce((sum, v) => sum + (v.cost_impact || 0), 0);
  
  // Calculate average risk score
  const avgRiskScore = filteredVulnerabilities.length > 0 
    ? (filteredVulnerabilities.reduce((sum, v) => sum + (v.risk_score || 0), 0) / filteredVulnerabilities.length).toFixed(1)
    : 0;

  // Get current data based on active tabs
  const getCurrentData = () => {
    if (activeTab === "issue") {
      if (activeSubTab === "malicious") {
        // If no malicious threats found, show all threats
        return maliciousThreats.length > 0 ? maliciousThreats : threats;
      } else {
        // If no tech debt threats found, show all threats
        return techDebtThreats.length > 0 ? techDebtThreats : threats;
      }
    } else {
      return filteredVulnerabilities;
    }
  };

  const currentData = getCurrentData();

  // Calculate paginated data
  const totalPages = Math.ceil(currentData.length / pageSize) || 1;
  const paginatedData = currentData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Reset to page 1 if filters change
  useEffect(() => { setCurrentPage(1); }, [activeTab, activeSubTab, filterAIT, filterSPK, filterRepo, vulnFilterSeverity, vulnFilterPriority, vulnFilterStatus, pageSize, currentData.length]);

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3;
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  const renderThreatTable = (data) => (
    <div className="table-responsive">
      <table className="table table-bordered table-hover align-middle">
        <thead className="table-light">
          <tr className="text-center">
            <th>Threat Level</th>
            <th>Type</th>
            <th>AIT</th>
            <th>SPK</th>
            <th>Repository</th>
            <th style={{minWidth: "150px"}}>File Name</th>
            <th>Line #</th>
            <th>Code Snippet</th>
            <th>Status</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.length > 0 ? (
            data.map((threat) => (
              <tr key={threat.id}>
                <td>
                  {(() => {
                    let badgeClass = "border-secondary text-secondary bg-secondary-subtle";
                    if (threat.severity === "CRITICAL_BOMB") {
                      badgeClass = "border-danger text-danger bg-danger-subtle";
                    } else if (threat.severity === "HIGH_RISK") {
                      badgeClass = "border-warning text-warning bg-warning-subtle";
                    } else if (threat.severity === "MEDIUM_RISK") {
                      badgeClass = "border-info text-info bg-info-subtle";
                    }
                    return (
                      <span className={`badge border ${badgeClass}`}>
                        {threat.severity}
                      </span>
                    );
                  })()}
                </td>
                <td>
                  <span className="badge bg-primary">{threat.type}</span>
                </td>
                <td>
                  <small>{getAITName(threat.ait_tag) || threat.ait_tag || "AIT"}</small>
                </td>
                <td>
                  <small>{getSPKName(threat.spk_tag) || threat.spk_tag || "SPK"}</small>
                </td>
                <td>
                  <small>{getRepoName(threat.repo_name) || threat.repo_name || "Repo"}</small>
                </td>
                <td>
                  <code className="small">{threat.file_path}</code>
                </td>
                <td className="text-center">{threat.line_number}</td>
                <td>
                  <code className="small" style={{ maxWidth: "200px", overflow: "hidden", textOverflow: "ellipsis", display: "block" }}>
                    {threat.code_snippet}
                  </code>
                </td>
                <td>
                  <span className={`badge ${threat.status === "ACTIVE_THREAT" ? "bg-danger" : "bg-success"}`}>
                    {threat.status}
                  </span>
                </td>
                <td className="text-center">
                  <div className="btn-group btn-group-sm" role="group">
                    <button
                      className="btn btn-outline-info"
                      onClick={() => showDetails(threat)}
                      title="View Details"
                    >
                      <FaInfoCircle />
                    </button>
                    {threat.status === "ACTIVE_THREAT" ? (
                      <button
                        className="btn btn-outline-success"
                        onClick={() => neutralizeThreat(threat.id)}
                        title="Neutralize Threat"
                      >
                        <FaCheck />
                      </button>
                    ) : (
                      <button
                        className="btn btn-outline-warning"
                        onClick={() => revertThreat(threat.id)}
                        title="Revert Threat"
                      >
                        <FaUndo />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="10" className="text-center text-muted">
                No {activeSubTab === "malicious" ? "malicious threats" : "tech debt issues"} found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  const renderVulnerabilityTable = (data) => (
    <div className="table-responsive">
      <table className="table table-bordered table-hover align-middle">
        <thead className="table-light">
          <tr className="text-center">
            <th>ID</th>
            <th>AIT</th>
            <th>Vulnerability</th>
            <th>Severity</th>
            <th>Risk Score</th>
            <th>Remediation Action</th>
            <th>Status</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.length > 0 ? (
            data.map((vuln) => (
              <tr key={vuln.id}>
                <td>
                  <code className="small">{vuln.id?.substring(0, 8)}...</code>
                </td>
                <td>
                  <span className="badge bg-secondary">{vuln.ait_tag || 'AIT-Unknown'}</span>
                </td>
                <td>
                  <div>
                    <strong>{vuln.title || vuln.description}</strong>
                    {vuln.priority && (
                      <div>
                        <small className="text-muted">Priority: {vuln.priority}</small>
                      </div>
                    )}
                  </div>
                </td>
                <td>
                  <span className={`badge ${
                    vuln.severity === 'CRITICAL_BOMB' ? 'bg-danger' :
                    vuln.severity === 'HIGH_RISK' ? 'bg-warning' :
                    vuln.severity === 'MEDIUM_RISK' ? 'bg-info' :
                    vuln.severity === 'LOW_RISK' ? 'bg-success' : 'bg-secondary'
                  }`}>
                    {vuln.severity}
                  </span>
                </td>
                <td>
                  <span className={`badge ${
                    vuln.risk_score >= 8 ? 'bg-danger' :
                    vuln.risk_score >= 6 ? 'bg-warning' :
                    vuln.risk_score >= 4 ? 'bg-info' : 'bg-success'
                  }`}>
                    {vuln.risk_score}/10
                  </span>
                </td>
                <td>
                  <small>{vuln.remediation_action || 'Update to latest version'}</small>
                </td>
                                 <td>
                   <span className={`badge ${(vuln.status || 'ACTIVE') === 'ACTIVE' ? 'bg-danger' : 'bg-success'}`}>
                     {vuln.status || 'ACTIVE'}
                   </span>
                 </td>
                 <td className="text-center">
                   <div className="btn-group btn-group-sm" role="group">
                     <button
                       className="btn btn-outline-info"
                       onClick={() => showVulnerabilityDetails(vuln)}
                       title="View Details"
                     >
                       <FaInfoCircle />
                     </button>
                     {(vuln.status || 'ACTIVE') === 'ACTIVE' ? (
                       <button
                         className="btn btn-outline-success"
                         onClick={() => neutralizeVulnerability(vuln.id)}
                         title="Neutralize Vulnerability"
                       >
                         <FaCheck />
                       </button>
                     ) : (
                       <button
                         className="btn btn-outline-warning"
                         onClick={() => revertVulnerability(vuln.id)}
                         title="Revert Vulnerability"
                       >
                         <FaUndo />
                       </button>
                     )}
                   </div>
                 </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="8" className="text-center text-muted">
                No vulnerabilities found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  // Details Popup Component
  const DetailsPopup = () => {
    if (!selectedThreat) return null;

    return (
      <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
        <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Threat Details</h5>
              <button type="button" className="btn-close" onClick={closeDetails}></button>
            </div>
            <div className="modal-body">
              <div className="row">
                <div className="col-md-6">
                  <h6>Basic Information</h6>
                  <table className="table table-sm">
                    <tbody>
                      <tr><td><strong>ID:</strong></td><td>{selectedThreat.id}</td></tr>
                      <tr><td><strong>Type:</strong></td><td><span className="badge bg-primary">{selectedThreat.type}</span></td></tr>
                      <tr><td><strong>Severity:</strong></td><td>
                        <span className={`badge ${
                          selectedThreat.severity === "CRITICAL_BOMB" ? "bg-danger" :
                          selectedThreat.severity === "HIGH_RISK" ? "bg-warning" :
                          selectedThreat.severity === "MEDIUM_RISK" ? "bg-info" : "bg-secondary"
                        }`}>
                          {selectedThreat.severity}
                        </span>
                      </td></tr>
                      <tr><td><strong>Status:</strong></td><td>
                        <span className={`badge ${selectedThreat.status === "ACTIVE_THREAT" ? "bg-danger" : "bg-success"}`}>
                          {selectedThreat.status}
                        </span>
                      </td></tr>
                      <tr><td><strong>Rule ID:</strong></td><td>{selectedThreat.rule_id || 'N/A'}</td></tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-6">
                  <h6>Project Information</h6>
                  <table className="table table-sm">
                    <tbody>
                      <tr><td><strong>AIT:</strong></td><td>{getAITName(selectedThreat.ait_tag) || selectedThreat.ait_tag || 'N/A'}</td></tr>
                      <tr><td><strong>SPK:</strong></td><td>{getSPKName(selectedThreat.spk_tag) || selectedThreat.spk_tag || 'N/A'}</td></tr>
                      <tr><td><strong>Repository:</strong></td><td>{getRepoName(selectedThreat.repo_name) || selectedThreat.repo_name || 'N/A'}</td></tr>
                      <tr><td><strong>File Path:</strong></td><td><code>{selectedThreat.file_path}</code></td></tr>
                      <tr><td><strong>Line Number:</strong></td><td>{selectedThreat.line_number}</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="row mt-3">
                <div className="col-12">
                  <h6>Code Snippet</h6>
                  <pre className="bg-light p-3 rounded" style={{ fontSize: '0.9em' }}>
                    <code>{selectedThreat.code_snippet}</code>
                  </pre>
                </div>
              </div>
              {selectedThreat.message && (
                <div className="row mt-3">
                  <div className="col-12">
                    <h6>Message</h6>
                    <p className="text-muted">{selectedThreat.message}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeDetails}>Close</button>
            </div>
          </div>
        </div>
        <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
      </div>
         );
   };

   // Vulnerability Details Popup Component
   const VulnerabilityDetailsPopup = () => {
     if (!selectedVulnerability) return null;

     const formatCurrency = (amount) => {
       return new Intl.NumberFormat('en-US', {
         style: 'currency',
         currency: 'USD'
       }).format(amount || 0);
     };

     const getRiskScoreColor = (score) => {
       if (score >= 8) return '#dc3545';
       if (score >= 6) return '#fd7e14';
       if (score >= 4) return '#ffc107';
       return '#28a745';
     };

     const getSeverityColor = (severity) => {
       const colors = {
         'CRITICAL_BOMB': '#dc3545',
         'HIGH_RISK': '#fd7e14',
         'MEDIUM_RISK': '#ffc107',
         'LOW_RISK': '#28a745',
         'SUSPICIOUS': '#6c757d'
       };
       return colors[severity] || '#6c757d';
     };

     const getPriorityColor = (priority) => {
       const colors = {
         'CRITICAL': '#dc3545',
         'HIGH': '#fd7e14',
         'MEDIUM': '#ffc107',
         'LOW': '#28a745'
       };
       return colors[priority] || '#6c757d';
     };

     return (
       <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
         <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
           <div className="modal-content">
             <div className="modal-header">
               <h5 className="modal-title">Vulnerability Details</h5>
               <button type="button" className="btn-close" onClick={closeVulnerabilityDetails}></button>
             </div>
             <div className="modal-body">
               <div className="row">
                 <div className="col-md-6">
                   <h6>Basic Information</h6>
                   <table className="table table-sm">
                     <tbody>
                       <tr><td><strong>ID:</strong></td><td>{selectedVulnerability.id}</td></tr>
                       <tr><td><strong>Title:</strong></td><td>{selectedVulnerability.title || selectedVulnerability.description}</td></tr>
                       <tr><td><strong>Severity:</strong></td><td>
                         <span className="badge" style={{ backgroundColor: getSeverityColor(selectedVulnerability.severity) }}>
                           {selectedVulnerability.severity}
                         </span>
                       </td></tr>
                       <tr><td><strong>Priority:</strong></td><td>
                         <span className="badge" style={{ backgroundColor: getPriorityColor(selectedVulnerability.priority) }}>
                           {selectedVulnerability.priority}
                         </span>
                       </td></tr>
                       <tr><td><strong>Status:</strong></td><td>
                         <span className={`badge ${selectedVulnerability.status === "ACTIVE" ? "bg-danger" : "bg-success"}`}>
                           {selectedVulnerability.status || 'ACTIVE'}
                         </span>
                       </td></tr>
                       <tr><td><strong>AIT Tag:</strong></td><td>{selectedVulnerability.ait_tag || 'AIT-Unknown'}</td></tr>
                     </tbody>
                   </table>
                 </div>
                 <div className="col-md-6">
                   <h6>Risk Assessment</h6>
                   <table className="table table-sm">
                     <tbody>
                       <tr><td><strong>Risk Score:</strong></td><td>
                         <span style={{ color: getRiskScoreColor(selectedVulnerability.risk_score) }}>
                           {selectedVulnerability.risk_score}/10
                         </span>
                       </td></tr>
                       <tr><td><strong>Remediation Priority:</strong></td><td>{selectedVulnerability.remediation_priority || 'N/A'}</td></tr>
                       <tr><td><strong>Cost Impact:</strong></td><td>{formatCurrency(selectedVulnerability.cost_impact)}</td></tr>
                       <tr><td><strong>FTE Requirement:</strong></td><td>{selectedVulnerability.fte_requirement || 0} FTE</td></tr>
                       <tr><td><strong>Remediation Action:</strong></td><td>{selectedVulnerability.remediation_action || 'Update to latest version'}</td></tr>
                     </tbody>
                   </table>
                 </div>
               </div>
               
               {selectedVulnerability.wave_assignment && (
                 <div className="row mt-3">
                   <div className="col-12">
                     <h6>Wave Assignment</h6>
                     <table className="table table-sm">
                       <tbody>
                         <tr><td><strong>Wave ID:</strong></td><td>{selectedVulnerability.wave_assignment.wave_id}</td></tr>
                         <tr><td><strong>Status:</strong></td><td>{selectedVulnerability.wave_assignment.status}</td></tr>
                         <tr><td><strong>Assigned Date:</strong></td><td>{new Date(selectedVulnerability.wave_assignment.assigned_date).toLocaleDateString()}</td></tr>
                         <tr><td><strong>Estimated Effort:</strong></td><td>{selectedVulnerability.wave_assignment.estimated_effort_hours} hours</td></tr>
                       </tbody>
                     </table>
                   </div>
                 </div>
               )}
             </div>
             <div className="modal-footer">
               <button type="button" className="btn btn-secondary" onClick={closeVulnerabilityDetails}>Close</button>
             </div>
           </div>
         </div>
         <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
       </div>
     );
   };

   return (
    <div style={{ background: "#fff", color: "#222", minHeight: "100vh" }}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: "#0d6efd" }}>🚨 Active Threats Management</h2>
        <button className="btn btn-outline-primary" onClick={fetchData}>
          <FaEye className="me-1" />
          Refresh
        </button>
      </div>

      {/* Main Tab Navigation */}
      <div className="row mb-4">
        <div className="col-12">
          <ul className="nav nav-tabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'issue' ? 'active' : ''}`}
                onClick={() => setActiveTab('issue')}
                type="button"
                role="tab"
              >
                <FaShieldAlt className="me-2" />
                Issue Management
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'vulnerability' ? 'active' : ''}`}
                onClick={() => setActiveTab('vulnerability')}
                type="button"
                role="tab"
              >
                <FaBug className="me-2" />
                Vulnerability Management
              </button>
            </li>
          </ul>
        </div>
      </div>

             {/* Filter Controls */}
       {activeTab === 'issue' ? (
         <div className="mb-4 p-3 bg-light rounded">
           <h6 className="mb-2" style={{ color: "#222" }}>
             <FaFilter className="me-2" /> Filter by Project Hierarchy
           </h6>
           <div className="row g-2">
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterAIT}
                 onChange={(e) => setFilterAIT(e.target.value)}
               >
                 <option value="">All AITs</option>
                 {Array.from(new Set(threats.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                   <option key={ait} value={ait}>{getAITName(ait)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterSPK}
                 onChange={(e) => setFilterSPK(e.target.value)}
               >
                 <option value="">All SPKs</option>
                 {Array.from(new Set(threats.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                   <option key={spk} value={spk}>{getSPKName(spk)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterRepo}
                 onChange={(e) => setFilterRepo(e.target.value)}
               >
                 <option value="">All Repositories</option>
                 {Array.from(new Set(threats.map(t => t.repo_name).filter(Boolean))).map(repo => (
                   <option key={repo} value={repo}>{getRepoName(repo)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <button
                 className="btn btn-outline-secondary btn-sm w-100"
                 onClick={() => {
                   setFilterAIT('');
                   setFilterSPK('');
                   setFilterRepo('');
                 }}
               >
                 <FaTimesCircle className="me-1" /> Clear Filters
               </button>
             </div>
           </div>
           {(filterAIT || filterSPK || filterRepo) && (
             <div className="mt-2">
               <small className="text-muted">
                 Showing {currentData.length} of {threats.length} items
               </small>
             </div>
           )}
         </div>
       ) : (
         <div className="mb-4 p-3 bg-light rounded">
           <h6 className="mb-2" style={{ color: "#222" }}>
             <FaFilter className="me-2" /> Filter Vulnerabilities
           </h6>
           <div className="row g-2 mb-3">
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={vulnFilterSeverity}
                 onChange={(e) => setVulnFilterSeverity(e.target.value)}
               >
                 <option value="ALL">All Severities</option>
                 <option value="CRITICAL_BOMB">Critical Bomb</option>
                 <option value="HIGH_RISK">High Risk</option>
                 <option value="MEDIUM_RISK">Medium Risk</option>
                 <option value="LOW_RISK">Low Risk</option>
                 <option value="SUSPICIOUS">Suspicious</option>
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={vulnFilterPriority}
                 onChange={(e) => setVulnFilterPriority(e.target.value)}
               >
                 <option value="ALL">All Priorities</option>
                 <option value="CRITICAL">Critical</option>
                 <option value="HIGH">High</option>
                 <option value="MEDIUM">Medium</option>
                 <option value="LOW">Low</option>
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={vulnFilterStatus}
                 onChange={(e) => setVulnFilterStatus(e.target.value)}
               >
                 <option value="ALL">All Statuses</option>
                 <option value="ACTIVE">Active</option>
                 <option value="NEUTRALIZED">Neutralized</option>
                 <option value="RESOLVED">Resolved</option>
               </select>
             </div>
             <div className="col-md-3">
               <button
                 className="btn btn-outline-secondary btn-sm w-100"
                 onClick={() => {
                   setVulnFilterSeverity('ALL');
                   setVulnFilterPriority('ALL');
                   setVulnFilterStatus('ALL');
                 }}
               >
                 <FaTimesCircle className="me-1" /> Clear Filters
               </button>
             </div>
           </div>
           
           {/* Excel Import Section */}
           <div className="row g-2 mb-3">
             <div className="col-md-12">
               <div className="d-flex gap-2 align-items-center">
                 <span className="text-muted small">📊 Excel Import:</span>
                 {excelData.length > 0 && (
                   <span className="badge bg-success">
                     {excelData.length} Excel records loaded
                   </span>
                 )}
                 {localStorage.getItem('excel_vulnerabilities') && (
                   <span className="badge bg-info">
                     📁 Persisted
                   </span>
                 )}
                 <button 
                   className="btn btn-outline-primary btn-sm"
                   onClick={downloadSampleExcel}
                   title="Download sample Excel template"
                 >
                   📥 Download Template
                 </button>
                 <div className="excel-upload-container">
                   <input
                     type="file"
                     id="excel-upload"
                     accept=".xlsx,.xls"
                     onChange={handleExcelUpload}
                     style={{ display: 'none' }}
                   />
                   <label 
                     htmlFor="excel-upload" 
                     className="btn btn-success btn-sm"
                     title="Upload Excel file to populate vulnerability table"
                   >
                     {importingExcel ? '📊 Importing...' : '📊 Fetch from Excel'}
                   </label>
                 </div>
               </div>
             </div>
           </div>
         </div>
       )}

             {/* Statistics Cards - First Row */}
       {activeTab === 'issue' ? (
         <div className="row g-4 mb-4">
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-danger">{maliciousThreats.length}</h3>
                 <p className="card-text">Malicious Threats</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-warning">{techDebtThreats.length}</h3>
                 <p className="card-text">Tech Debt Issues</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-info">{vulnerabilities.length}</h3>
                 <p className="card-text">Vulnerabilities</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{threats.filter(t => t.status === 'NEUTRALIZED').length}</h3>
                 <p className="card-text">Resolved</p>
               </div>
             </div>
           </div>
         </div>
       ) : (
         <div className="row g-4 mb-4">
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-danger">{criticalVulnerabilities.length}</h3>
                 <p className="card-text">Critical</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-warning">{highRiskVulnerabilities.length}</h3>
                 <p className="card-text">High Risk</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-info">{mediumRiskVulnerabilities.length}</h3>
                 <p className="card-text">Medium Risk</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{lowRiskVulnerabilities.length}</h3>
                 <p className="card-text">Low Risk</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-primary">{activeVulnerabilities.length}</h3>
                 <p className="card-text">Active</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-secondary">{neutralizedVulnerabilities.length}</h3>
                 <p className="card-text">Neutralized</p>
               </div>
             </div>
           </div>
         </div>
       )}

             {/* Statistics Cards - Second Row */}
       {activeTab === 'issue' ? (
         <div className="row g-4 mb-4">
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-primary">{hardcodedCredentials.length}</h3>
                 <p className="card-text">Hardcoded Credentials</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-secondary">{hardcodedUrls.length}</h3>
                 <p className="card-text">Hardcoded URLs</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-dark">{inputValidation.length}</h3>
                 <p className="card-text">Input Validation</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-muted">{vulnerableLibraries.length}</h3>
                 <p className="card-text">Vulnerable Libraries</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-body">{accessControl.length}</h3>
                 <p className="card-text">Access Control</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{totalHours}</h3>
                 <p className="card-text">Total Hours</p>
               </div>
             </div>
           </div>
         </div>
               ) : (
          <div className="row g-4 mb-4">
            <div className="col-md-4">
              <div className="card text-center shadow-sm">
                <div className="card-body">
                  <h3 className="text-warning">{avgRiskScore}/10</h3>
                  <p className="card-text">Avg Risk Score</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card text-center shadow-sm">
                <div className="card-body">
                  <h3 className="text-info">{filteredVulnerabilities.length}</h3>
                  <p className="card-text">Total Vulnerabilities</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card text-center shadow-sm">
                <div className="card-body">
                  <h3 className="text-success">{filteredVulnerabilities.filter(v => v.wave_assignment).length}</h3>
                  <p className="card-text">Wave Assigned</p>
                </div>
              </div>
            </div>
          </div>
        )}

      {/* Table Content */}
      <div className="card shadow-sm">
        <div className="card-header">
          <h5 className="mb-0">
            {activeTab === 'issue' ? 
              (activeSubTab === 'malicious' ? '🚨 Malicious Threats' : '📄 Tech Debt & Vulnerabilities') :
              '🐛 Vulnerability Management'
            }
          </h5>
        </div>
        
        {/* Sub-tab Navigation for Issue Management - Now immediately above table */}
        {activeTab === 'issue' && (
          <div className="card-body border-bottom">
            <ul className="nav nav-pills" role="tablist">
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeSubTab === 'malicious' ? 'active' : ''}`}
                  onClick={() => setActiveSubTab('malicious')}
                  type="button"
                  role="tab"
                >
                  <FaExclamationTriangle className="me-2" />
                  🚨 Malicious Threats ({maliciousThreats.length})
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeSubTab === 'techdebt' ? 'active' : ''}`}
                  onClick={() => setActiveSubTab('techdebt')}
                  type="button"
                  role="tab"
                >
                  <FaTools className="me-2" />
                  📄 Tech Debt & Vulnerabilities ({techDebtThreats.length})
                </button>
              </li>
            </ul>
          </div>
        )}
        
        <div className="card-body">
          {activeTab === 'issue' ? renderThreatTable(paginatedData) : renderVulnerabilityTable(paginatedData)}
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button
                  className="page-link"
                  onClick={() => setCurrentPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              
              {getPaginationWindow(currentPage, totalPages).map((page, index) => (
                <li key={index} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                  {page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                    <span className="page-link">...</span>
                  ) : (
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </button>
                  )}
                </li>
              ))}
              
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button
                  className="page-link"
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

             {/* Details Popup */}
       {showDetailsPopup && <DetailsPopup />}
       
       {/* Vulnerability Details Popup */}
       {showVulnerabilityDetailsPopup && <VulnerabilityDetailsPopup />}
    </div>
  );
};

export default ActiveThreatsManagement;
