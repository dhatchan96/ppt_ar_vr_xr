import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Create axios instance with enhanced configuration
const API = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000, // 30 seconds for large file scans
  headers: {
    'Content-Type': 'application/json'
    // Temporarily removed custom headers to test CORS
    // 'X-ThreatGuard-Client': 'ThreatGuard-Pro-UI',
    // 'X-Client-Version': '2.0.0'
  }
});

// Enhanced request interceptor for threat scanning
API.interceptors.request.use(
  (config) => {
    // Temporarily removed custom headers to test CORS
    // Add scan timestamp for tracking
    // if (config.url.includes('/scan')) {
    //   config.headers['X-Scan-Timestamp'] = new Date().toISOString();
    // }
    
    // Add threat detection headers
    // if (config.url.includes('/threat')) {
    //   config.headers['X-Threat-Detection'] = 'enhanced';
    // }
    
    console.log(`🔍 ThreatGuard API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('❌ ThreatGuard API Request Error:', error);
    return Promise.reject(error);
  }
);

// Enhanced response interceptor with threat intelligence
API.interceptors.response.use(
  (response) => {
    // Log successful threat detection responses
    if (response.config.url.includes('/scan') || response.config.url.includes('/threat')) {
      const threatCount = response.data?.summary?.total_issues || 
                         response.data?.threats?.total || 
                         (Array.isArray(response.data) ? response.data.length : 0);
      console.log(`✅ ThreatGuard Response: ${threatCount} threats detected`);
    }
    
    return response;
  },
  (error) => {
    console.error('❌ ThreatGuard API Response Error:', error.response?.data || error.message);
    
    // Enhanced error handling for threat detection
    if (error.response?.status === 429) {
      console.warn('⚠️ Rate limit exceeded for threat scanning');
    } else if (error.response?.status >= 500) {
      console.error('🚨 ThreatGuard server error - threat detection may be affected');
    }
    
    return Promise.reject(error);
  }
);

export default API;

// Copilot Remediation API functions
export const copilotAPI = {
  // Get all Copilot projects
  getProjects: async () => {
    try {
      console.log('🔍 Calling /api/copilot/projects...');
      const response = await API.get('/api/copilot/projects');
      console.log('✅ /api/copilot/projects response:', response);
      console.log('✅ Response data:', response.data);
      return response;
    } catch (error) {
      console.error('❌ /api/copilot/projects error:', error);
      console.error('❌ Error response:', error.response);
      throw error;
    }
  },
  
  // Get Copilot agent status
  getAgentStatus: () => API.get('/api/copilot/agent/status'),
  
  // Start Copilot agent
  startAgent: () => API.post('/api/copilot/agent/start'),
  
  // Stop Copilot agent
  stopAgent: () => API.post('/api/copilot/agent/stop'),
  
  // Process Copilot task for a specific scan
  processTask: (scanId) => API.post(`/api/copilot/process/${scanId}`),
  
  // Get file contents for comparison
  getFileContents: (scanId, fileName) => API.get(`/api/copilot/files/${scanId}/${fileName}`),
  
  // Get available files for a scan
  getAvailableFiles: (scanId) => API.get(`/api/copilot/files/${scanId}`),
  
  // Get Copilot task details
  getTaskDetails: (scanId) => API.get(`/api/copilot/task/${scanId}`),
  
  // Download Copilot prompts
  downloadPrompts: () => API.get('/api/copilot/prompts/download', {
    responseType: 'blob'
  })
};

// VS Code Copilot API functions
const vscodeCopilotAPI = {
  // Get VS Code instructions
  getInstructions: async (scanId) => {
    try {
      const response = await API.get(`/api/copilot/vscode/instructions/${scanId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching VS Code instructions:', error);
      throw error;
    }
  },

  // Get VS Code prompts
  getPrompts: async (scanId) => {
    try {
      const response = await API.get(`/api/copilot/vscode/prompts/${scanId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching VS Code prompts:', error);
      throw error;
    }
  },

  // Get VS Code workspace
  getWorkspace: async (scanId) => {
    try {
      const response = await API.get(`/api/copilot/vscode/workspace/${scanId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching VS Code workspace:', error);
      throw error;
    }
  },

  // Download VS Code files
  downloadFiles: async (scanId) => {
    try {
      const response = await API.get(`/api/copilot/vscode/download/${scanId}`, {
        responseType: 'blob'
      });
      
      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `vscode_copilot_remediation_${scanId}.zip`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      return { success: true };
    } catch (error) {
      console.error('Error downloading VS Code files:', error);
      throw error;
    }
  }
};

// VS Code Agent API functions
const vscodeAgentAPI = {
  // Process VS Code agent for a specific scan
  processAgent: async (scanId) => {
    try {
      console.log('🔍 Calling /api/vscode-agent/process/', scanId);
      const response = await API.post(`/api/vscode-agent/process/${scanId}`);
      console.log('✅ /api/vscode-agent/process response:', response);
      console.log('✅ Response data:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ /api/vscode-agent/process error:', error);
      console.error('❌ Error response:', error.response);
      throw error;
    }
  },

  // Get VS Code prompts for a scan
  getPrompts: async (scanId) => {
    try {
      console.log('🔍 Calling /api/vscode-agent/prompts/', scanId);
      const response = await API.get(`/api/vscode-agent/prompts/${scanId}`);
      console.log('✅ /api/vscode-agent/prompts response:', response);
      console.log('✅ Response data:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ /api/vscode-agent/prompts error:', error);
      console.error('❌ Error response:', error.response);
      throw error;
    }
  },

  // Get VS Code agent files
  getFile: async (scanId, fileName) => {
    try {
      const response = await API.get(`/api/vscode-agent/files/${scanId}/${encodeURIComponent(fileName)}`);
      return response.data;
    } catch (error) {
      console.error('Error getting VS Code agent file:', error);
      throw error;
    }
  },

  // Get diff between original and remediated files
  getDiff: async (scanId, fileName) => {
    try {
      const response = await API.get(`/api/vscode-agent/diff/${scanId}/${encodeURIComponent(fileName)}`);
      return response.data;
    } catch (error) {
      console.error('Error getting VS Code agent diff:', error);
      throw error;
    }
  },

  // Get VS Code agent status
  getStatus: async () => {
    try {
      const response = await API.get('/api/vscode-agent/status');
      return response.data;
    } catch (error) {
      console.error('Error getting VS Code agent status:', error);
      throw error;
    }
  }
};

// Export all API functions
export {
  vscodeAgentAPI,
  vscodeCopilotAPI
};
