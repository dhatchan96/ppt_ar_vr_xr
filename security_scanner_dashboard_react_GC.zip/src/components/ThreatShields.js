import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';

const ThreatShields = () => {
  const [shields, setShields] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formMode, setFormMode] = useState('create');
  const [shieldData, setShieldData] = useState({ 
    id: '', 
    name: '', 
    protection_rules: '', 
    threat_categories: '',
    risk_threshold: 'MEDIUM_RISK'
  });

  useEffect(() => {
    fetchShields();
  }, []);

  const fetchShields = async () => {
    try {
      const res = await API.get('/api/threat-shields');
      const shieldsData = Object.values(res.data || {});
      
      console.log('🔍 Raw shields data:', shieldsData);
      
      // Validate and normalize shield data
      const normalizedShields = shieldsData.map(shield => {
        console.log('🔍 Processing shield:', shield);
        console.log('🔍 threat_categories type:', typeof shield.threat_categories, 'value:', shield.threat_categories);
        console.log('🔍 protection_rules type:', typeof shield.protection_rules, 'value:', shield.protection_rules);
        
        return {
          ...shield,
          threat_categories: Array.isArray(shield.threat_categories) 
            ? shield.threat_categories 
            : (typeof shield.threat_categories === 'string' 
                ? shield.threat_categories.split(',').map(cat => cat.trim()).filter(cat => cat)
                : []),
          protection_rules: Array.isArray(shield.protection_rules) 
            ? shield.protection_rules 
            : []
        };
      });
      
      console.log('🔍 Normalized shields:', normalizedShields);
      setShields(normalizedShields);
    } catch (err) {
      console.error('Failed to fetch threat shields:', err);
    }
  };

  const openCreateModal = () => {
    setFormMode('create');
    setShieldData({ 
      id: '', 
      name: '', 
      protection_rules: '', 
      threat_categories: '',
      risk_threshold: 'MEDIUM_RISK'
    });
    setShowModal(true);
  };

  const openEditModal = (shield) => {
    setFormMode('edit');
    setShieldData({
      id: shield.id,
      name: shield.name,
      protection_rules: Array.isArray(shield.protection_rules) 
        ? JSON.stringify(shield.protection_rules, null, 2) 
        : JSON.stringify([], null, 2),
      threat_categories: Array.isArray(shield.threat_categories) 
        ? shield.threat_categories.join(', ') 
        : '',
      risk_threshold: shield.risk_threshold || 'MEDIUM_RISK'
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let protection_rules = [];
    try {
      if (shieldData.protection_rules) {
        protection_rules = JSON.parse(shieldData.protection_rules);
      }
    } catch (e) {
      alert('Invalid JSON format in protection rules');
      return;
    }

    const payload = {
      name: shieldData.name,
      protection_rules: protection_rules,
      threat_categories: shieldData.threat_categories.split(',').map(cat => cat.trim()).filter(cat => cat),
      risk_threshold: shieldData.risk_threshold
    };

    try {
      if (formMode === 'create') {
        const response = await API.post('/api/threat-shields', payload);
        if (response.data.success) {
          alert('✅ Threat shield created successfully!');
        }
      } else {
        const response = await API.put(`/api/threat-shields/${shieldData.id}`, payload);
        if (response.data.success) {
          alert('✅ Threat shield updated successfully!');
        }
      }
      fetchShields();
      setShowModal(false);
    } catch (err) {
      console.error('Failed to submit threat shield:', err);
      const errorMessage = err.response?.data?.error || 'Failed to save threat shield';
      alert(`❌ ${errorMessage}`);
    }
  };

  const deleteShield = async (id) => {
    if (!window.confirm('Are you sure you want to delete this threat shield?')) return;
    try {
      const response = await API.delete(`/api/threat-shields/${id}`);
      if (response.data.success) {
        alert('✅ Threat shield deleted successfully!');
      }
      fetchShields();
    } catch (err) {
      console.error('Failed to delete threat shield:', err);
      const errorMessage = err.response?.data?.error || 'Failed to delete threat shield';
      alert(`❌ ${errorMessage}`);
    }
  };

  // Enhanced preset shield templates
  const createPresetShield = async (preset) => {
    const presets = {
      logicBombShield: {
        name: 'Logic Bomb Protection Shield',
        risk_threshold: 'MEDIUM_RISK',
        threat_categories: 'SCHEDULED_THREAT,TARGETED_ATTACK,EXECUTION_TRIGGER,DESTRUCTIVE_PAYLOAD',
        protection_rules: [
          {
            "threat_type": "SCHEDULED_THREAT",
            "risk_threshold": "HIGH_RISK",
            "block": true,
            "alert": true
          },
          {
            "threat_type": "TARGETED_ATTACK",
            "risk_threshold": "CRITICAL_BOMB",
            "block": true,
            "alert": true
          },
          {
            "threat_type": "EXECUTION_TRIGGER",
            "risk_threshold": "HIGH_RISK",
            "block": true,
            "alert": true
          },
          {
            "threat_type": "DESTRUCTIVE_PAYLOAD",
            "risk_threshold": "CRITICAL_BOMB",
            "block": true,
            "alert": true
          }
        ]
      },
      productionShield: {
        name: 'Production Environment Shield',
        risk_threshold: 'HIGH_RISK',
        threat_categories: 'DESTRUCTIVE_PAYLOAD,FINANCIAL_FRAUD,SYSTEM_SPECIFIC_THREAT',
        protection_rules: [
          {
            "threat_type": "DESTRUCTIVE_PAYLOAD",
            "risk_threshold": "CRITICAL_BOMB",
            "block": true,
            "alert": true
          },
          {
            "threat_type": "FINANCIAL_FRAUD",
            "risk_threshold": "CRITICAL_BOMB",
            "block": true,
            "alert": true
          },
          {
            "threat_type": "SYSTEM_SPECIFIC_THREAT",
            "risk_threshold": "MEDIUM_RISK",
            "block": false,
            "alert": true
          }
        ]
      },
      developmentShield: {
        name: 'Development Environment Shield',
        risk_threshold: 'LOW_RISK',
        threat_categories: 'SCHEDULED_THREAT,TARGETED_ATTACK,EXECUTION_TRIGGER',
        protection_rules: [
          {
            "threat_type": "SCHEDULED_THREAT",
            "risk_threshold": "MEDIUM_RISK",
            "block": false,
            "alert": true
          },
          {
            "threat_type": "TARGETED_ATTACK",
            "risk_threshold": "HIGH_RISK",
            "block": false,
            "alert": true
          },
          {
            "threat_type": "EXECUTION_TRIGGER",
            "risk_threshold": "MEDIUM_RISK",
            "block": false,
            "alert": true
          }
        ]
      }
    };

    try {
      const presetData = presets[preset];
      
      // Ensure threat_categories is properly formatted
      const formattedData = {
        ...presetData,
        threat_categories: presetData.threat_categories.split(',').map(cat => cat.trim()).filter(cat => cat)
      };
      
      const response = await API.post('/api/threat-shields', formattedData);
      if (response.data.success) {
        alert(`✅ ${presetData.name} created successfully!`);
        fetchShields();
      }
    } catch (err) {
      console.error('Failed to create preset shield:', err);
      const errorMessage = err.response?.data?.error || 'Failed to create preset shield';
      alert(`❌ ${errorMessage}`);
    }
  };

  return (
    <div className="container-fluid mt-4 px-5" style={{ background: '#fff', color: '#222', minHeight: '100vh' }}>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2 style={{ color: '#0d6efd' }}>🛡️ Threat Shield Management</h2>
        <button className="btn btn-primary" onClick={openCreateModal}>
          Create New Shield
        </button>
      </div>

      {/* Enhanced Preset Shield Templates */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🚀 Quick Setup - Preset Threat Shields</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4 mb-2">
              <button 
                className="btn btn-outline-danger w-100" 
                onClick={() => createPresetShield('logicBombShield')}
              >
                🚨 Logic Bomb Protection
              </button>
            </div>
            <div className="col-md-4 mb-2">
              <button 
                className="btn btn-outline-warning w-100" 
                onClick={() => createPresetShield('productionShield')}
              >
                🏭 Production Environment
              </button>
            </div>
            <div className="col-md-4 mb-2">
              <button 
                className="btn btn-outline-info w-100" 
                onClick={() => createPresetShield('developmentShield')}
              >
                💻 Development Environment
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        {shields.map(shield => (
          <div key={shield.id} className="col-md-6 mb-3">
            <div className="card" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb', color: '#222' }}>
              <div className="card-header" style={{ background: '#e9f3ff', borderBottom: '1px solid #e5e7eb' }}>
                <h5 style={{ color: '#0d6efd' }}>
                  {shield.name} {shield.is_default && <span className="badge bg-secondary">Default</span>}
                </h5>
              </div>
              <div className="card-body">
                <p><strong style={{ color: '#0d6efd' }}>Risk Threshold:</strong> 
                  <span className={`badge ms-2 ${
                    shield.risk_threshold === 'CRITICAL_BOMB' ? 'bg-danger' :
                    shield.risk_threshold === 'HIGH_RISK' ? 'bg-warning' :
                    shield.risk_threshold === 'MEDIUM_RISK' ? 'bg-info' :
                    'bg-secondary'
                  }`}>
                    {shield.risk_threshold}
                  </span>
                </p>
                
                <p><strong style={{ color: '#0d6efd' }}>Threat Categories:</strong></p>
                <div className="mb-2">
                  {Array.isArray(shield.threat_categories) && shield.threat_categories.length > 0 ? (
                    shield.threat_categories.map((category, idx) => (
                    <span key={idx} className="badge bg-light text-dark border border-primary me-1 mb-1">
                      {category}
                    </span>
                    ))
                  ) : (
                    <span style={{ color: '#b0b0b0' }}>No categories specified</span>
                  )}
                </div>
                
                <p><strong style={{ color: '#0d6efd' }}>Protection Rules:</strong></p>
                <div style={{ maxHeight: '150px', overflow: 'auto', background: '#fff', padding: '0.5rem', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
                  {Array.isArray(shield.protection_rules) && shield.protection_rules.length > 0 ? (
                    <ul className="mb-0" style={{ color: '#444', fontSize: '0.95rem' }}>
                      {shield.protection_rules.map((rule, idx) => (
                        <li key={idx}>
                          <strong>{rule.threat_type}:</strong> {rule.risk_threshold}
                          {rule.block && <span className="badge bg-danger ms-1">BLOCK</span>}
                          {rule.alert && <span className="badge bg-warning ms-1">ALERT</span>}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <span style={{ color: '#b0b0b0' }}>No protection rules defined</span>
                  )}
                </div>
                
                <div className="mt-3 d-flex gap-2">
                  <button className="btn btn-sm btn-primary" onClick={() => openEditModal(shield)}>
                    Edit Shield
                  </button>
                  <button className="btn btn-sm btn-danger" onClick={() => deleteShield(shield.id)}>
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {shields.length === 0 && (
          <div className="col-12">
            <div className="text-center" style={{ color: '#888', padding: '2rem' }}>
              <h4>No threat shields configured</h4>
              <p>Create your first threat shield to protect against logic bomb attacks</p>
            </div>
          </div>
        )}
      </div>

      {showModal && (
        <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }}>
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div className="modal-content" style={{ background: '#fff', color: '#222', border: '1px solid #e5e7eb' }}>
              <form onSubmit={handleSubmit}>
                <div className="modal-header" style={{ borderBottom: '1px solid #e5e7eb' }}>
                  <h5 className="modal-title" style={{ color: '#0d6efd' }}>
                    {formMode === 'create' ? 'Create Threat Shield' : 'Edit Threat Shield'}
                  </h5>
                  <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>
                <div className="modal-body">
                  <div className="form-group mb-3">
                    <label style={{ color: '#0d6efd' }}>Shield Name</label>
                    <input
                      type="text"
                      className="form-control"
                      style={{ background: '#f8f9fa', color: '#222', border: '1px solid #e5e7eb' }}
                      required
                      value={shieldData.name}
                      onChange={(e) => setShieldData({ ...shieldData, name: e.target.value })}
                      placeholder="e.g., Production Logic Bomb Shield"
                    />
                  </div>
                  
                  <div className="form-group mb-3">
                    <label style={{ color: '#0d6efd' }}>Risk Threshold</label>
                    <select
                      className="form-select"
                      style={{ background: '#f8f9fa', color: '#222', border: '1px solid #e5e7eb' }}
                      value={shieldData.risk_threshold}
                      onChange={(e) => setShieldData({ ...shieldData, risk_threshold: e.target.value })}
                    >
                      <option value="CRITICAL_BOMB">Critical Bomb</option>
                      <option value="HIGH_RISK">High Risk</option>
                      <option value="MEDIUM_RISK">Medium Risk</option>
                      <option value="LOW_RISK">Low Risk</option>
                    </select>
                    <small style={{ color: '#888' }}>Minimum threat level to trigger this shield</small>
                  </div>
                  
                  <div className="form-group mb-3">
                    <label style={{ color: '#0d6efd' }}>Threat Categories (comma-separated)</label>
                    <input
                      type="text"
                      className="form-control"
                      style={{ background: '#f8f9fa', color: '#222', border: '1px solid #e5e7eb' }}
                      value={shieldData.threat_categories}
                      onChange={(e) => setShieldData({ ...shieldData, threat_categories: e.target.value })}
                      placeholder="TIME_BOMB, USER_BOMB, COUNTER_BOMB, DESTRUCTIVE_PAYLOAD"
                    />
                    <small style={{ color: '#888' }}>Types of threats this shield should protect against</small>
                  </div>
                  
                  <div className="form-group mb-3">
                    <label style={{ color: '#0d6efd' }}>Protection Rules (JSON format)</label>
                    <textarea
                      className="form-control"
                      style={{ background: '#f8f9fa', color: '#222', border: '1px solid #e5e7eb', minHeight: '200px' }}
                      value={shieldData.protection_rules}
                      onChange={(e) => setShieldData({ ...shieldData, protection_rules: e.target.value })}
                      placeholder={JSON.stringify([
                        {
                          "threat_type": "TIME_BOMB",
                          "risk_threshold": "HIGH_RISK",
                          "block": true,
                          "alert": true
                        },
                        {
                          "threat_type": "DESTRUCTIVE_PAYLOAD",
                          "risk_threshold": "CRITICAL_BOMB",
                          "block": true,
                          "alert": true
                        }
                      ], null, 2)}
                    />
                    <small style={{ color: '#888' }}>Define specific protection rules in JSON format</small>
                  </div>
                </div>
                <div className="modal-footer" style={{ borderTop: '1px solid #e5e7eb' }}>
                  <button type="submit" className="btn btn-primary">
                    {formMode === 'create' ? 'Create Shield' : 'Update Shield'}
                  </button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ThreatShields;