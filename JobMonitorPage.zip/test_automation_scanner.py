#!/usr/bin/env python3
"""
Test Automation Scanner Worker
Scans repositories for test automation files based on test case Excel and locators path
"""

import threading
import time
import tempfile
import subprocess
import shutil
import os
import re
from pathlib import Path
from typing import Dict, List, Optional
import logging
import pandas as pd
import openpyxl
from job_manager import job_manager, JobStatus
from config import settings
from excel_to_markdown_converter import extract_steps_to_markdown
from excel_to_markdown_converter import extract_steps_to_markdown

logger = logging.getLogger(__name__)

class TestAutomationScanner:
    """Test automation scanner worker"""
    
    def __init__(self):
        self.active_jobs = {}
        self.worker_threads = {}
    
    def start_scan_job(self, job_id: str, scan_data: Dict):
        """Start a test automation scan job in a background thread"""
        if job_id in self.active_jobs:
            logger.warning(f"Job {job_id} is already running")
            return
        
        # Mark job as active
        self.active_jobs[job_id] = scan_data
        
        # Start worker thread
        worker_thread = threading.Thread(
            target=self._scan_test_automation_worker,
            args=(job_id, scan_data),
            daemon=True
        )
        worker_thread.start()
        
        self.worker_threads[job_id] = worker_thread
        logger.info(f"Started async test automation scan job {job_id}")
    
    def _scan_test_automation_worker(self, job_id: str, scan_data: Dict):
        """Worker function that performs the actual test automation scanning"""
        try:
            # Update status to running
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Starting test automation scan...")
            
            clone_url = scan_data.get('clone_url')
            repo_token = scan_data.get('repo_token')
            test_locators_path = scan_data.get('test_locators_path')
            test_case_file_path = scan_data.get('test_case_file_path')
            scan_id = scan_data.get('scan_id')
            ait_tag = scan_data.get('ait_tag')
            spk_tag = scan_data.get('spk_tag')
            repo_name = scan_data.get('repo_name')
            
            # Parse repository URL
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Analyzing repository URL...")
            repo_type, owner, repo, server_url = self._parse_repo_url(clone_url)
            logger.info(f"Parsed repository URL: type={repo_type}, owner={owner}, repo={repo}, server={server_url}")
            
            if not repo_type:
                raise ValueError("Invalid repository URL format")
            
            # Clone repository
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Cloning repository...")
            
            # Use job_id in temp directory name to avoid conflicts
            temp_dir = tempfile.mkdtemp(prefix=f"test_automation_{job_id}_")
            repo_path = os.path.join(temp_dir, repo)
            
            try:
                # Clone the repository
                clone_cmd = self._get_clone_command(repo_type, owner, repo, repo_token, server_url)
                
                # Change to temp directory and clone there
                original_cwd = os.getcwd()
                os.chdir(temp_dir)
                
                result = subprocess.run(clone_cmd, capture_output=True, text=True, timeout=settings.GIT_CLONE_TIMEOUT)
                
                # Change back to original directory
                os.chdir(original_cwd)
                
                if result.returncode != 0:
                    error_msg = result.stderr.strip()
                    raise Exception(f"Failed to clone repository: {error_msg}")
                
                # Process test case Excel file
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Processing test case Excel file...")
                test_cases = self._process_test_case_file(test_case_file_path)
                
                # Convert Excel to Markdown
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Converting Excel to Markdown...")
                markdown_content = extract_steps_to_markdown(test_case_file_path)
                
                # Find files in test locators path
                job_manager.update_job_status(job_id, JobStatus.RUNNING, f"Scanning test locators path: {test_locators_path}...")
                locator_files = self._find_locator_files(repo_path, test_locators_path)
                
                # Compile results
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Compiling results...")
                
                result_data = {
                    'scan_id': scan_id,
                    'scan_type': 'test_automation',
                    'project_id': scan_data.get('project_id', f'test-automation-{scan_id}'),
                    'project_name': scan_data.get('project_name', 'Test Automation Scan'),
                    'repo_url': clone_url,
                    'repo_name': repo_name,
                    'ait_tag': ait_tag,
                    'spk_tag': spk_tag,
                    'test_locators_path': test_locators_path,
                    'test_cases': test_cases,
                    'locator_files': locator_files,
                    'markdown_content': markdown_content,  # Add markdown content
                    'total_test_cases': len(test_cases),
                    'total_locator_files': len(locator_files),
                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Update job status to completed
                job_manager.update_job_status(
                    job_id, 
                    JobStatus.COMPLETED, 
                    f"Scan completed: Found {len(test_cases)} test cases and {len(locator_files)} locator files",
                    result_data=result_data
                )
                
                logger.info(f"Test automation scan job {job_id} completed successfully")
                
            except Exception as e:
                logger.error(f"Error in test automation scan job {job_id}: {e}", exc_info=True)
                job_manager.update_job_status(
                    job_id, 
                    JobStatus.FAILED, 
                    f"Scan failed: {str(e)}",
                    error_message=str(e)
                )
            finally:
                # Cleanup temp directory
                try:
                    if os.path.exists(temp_dir):
                        shutil.rmtree(temp_dir, ignore_errors=True)
                        logger.info(f"Cleaned up temp directory: {temp_dir}")
                except Exception as e:
                    logger.warning(f"Failed to cleanup temp directory {temp_dir}: {e}")
                
                # Remove from active jobs
                if job_id in self.active_jobs:
                    del self.active_jobs[job_id]
        
        except Exception as e:
            logger.error(f"Fatal error in test automation scan job {job_id}: {e}", exc_info=True)
            job_manager.update_job_status(
                job_id, 
                JobStatus.FAILED, 
                f"Fatal error: {str(e)}",
                error_message=str(e)
            )
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
    
    def _parse_repo_url(self, repo_url: str) -> tuple:
        """Parse repository URL and return (repo_type, owner, repo, server_url)"""
        if not repo_url:
            return (None, None, None, None)
        
        # GitHub patterns
        github_pattern = r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'
        github_match = re.match(github_pattern, repo_url.strip())
        
        # Bitbucket patterns
        bitbucket_cloud_pattern = r'https://bitbucket\.org/([^/]+)/([^/]+?)(?:\.git)?/?$'
        bitbucket_server_pattern = r'https://([^/]+)/scm/([^/]+)/([^/]+?)(?:\.git)?/?$'
        
        bitbucket_cloud_match = re.match(bitbucket_cloud_pattern, repo_url.strip())
        bitbucket_server_match = re.match(bitbucket_server_pattern, repo_url.strip())
        
        if github_match:
            return ('github', github_match.group(1), github_match.group(2), 'github.com')
        elif bitbucket_cloud_match:
            return ('bitbucket_cloud', bitbucket_cloud_match.group(1), bitbucket_cloud_match.group(2), 'bitbucket.org')
        elif bitbucket_server_match:
            return ('bitbucket_server', bitbucket_server_match.group(2), bitbucket_server_match.group(3), bitbucket_server_match.group(1))
        else:
            return (None, None, None, None)
    
    def _get_clone_command(self, repo_type: str, owner: str, repo: str, token: Optional[str], server_url: str) -> List[str]:
        """Get git clone command based on repository type"""
        if repo_type == 'github':
            if token:
                clone_url = f"https://{token}@github.com/{owner}/{repo}.git"
            else:
                clone_url = f"https://github.com/{owner}/{repo}.git"
        elif repo_type == 'bitbucket_cloud':
            if token:
                clone_url = f"https://x-token-auth:{token}@bitbucket.org/{owner}/{repo}.git"
            else:
                clone_url = f"https://bitbucket.org/{owner}/{repo}.git"
        elif repo_type == 'bitbucket_server':
            if token:
                clone_url = f"https://{token}@{server_url}/scm/{owner}/{repo}.git"
            else:
                clone_url = f"https://{server_url}/scm/{owner}/{repo}.git"
        else:
            raise ValueError(f"Unsupported repository type: {repo_type}")
        
        return ['git', 'clone', clone_url, repo]
    
    def _process_test_case_file(self, excel_file_path: str) -> List[Dict]:
        """Process test case Excel file and extract test cases"""
        test_cases = []
        
        try:
            # Validate file exists
            if not os.path.exists(excel_file_path):
                raise FileNotFoundError(f"Excel file not found: {excel_file_path}")
            
            # Validate file size (should be > 0)
            file_size = os.path.getsize(excel_file_path)
            if file_size == 0:
                raise ValueError("Uploaded Excel file is empty (0 bytes)")
            
            logger.info(f"Processing Excel file: {excel_file_path}, size: {file_size} bytes")
            
            # Validate file is a valid Excel file by checking magic bytes
            # Excel files (.xlsx) start with PK (ZIP file signature)
            with open(excel_file_path, 'rb') as f:
                magic_bytes = f.read(4)
                if magic_bytes[:2] != b'PK':
                    raise ValueError(f"Invalid Excel file format. Expected .xlsx file (ZIP format), but got invalid file signature: {magic_bytes.hex()}")
            
            # Read Excel file
            df = pd.read_excel(excel_file_path, engine='openpyxl')
            
            if df.empty:
                logger.warning("Excel file is empty (no data rows)")
                return []
            
            # Convert to list of dictionaries, replacing NaN with None (which becomes null in JSON)
            for index, row in df.iterrows():
                row_dict = row.to_dict()
                # Replace NaN values with None (pandas NaN becomes None, which serializes to null in JSON)
                cleaned_dict = {k: (None if pd.isna(v) else v) for k, v in row_dict.items()}
                test_case = {
                    'id': index + 1,
                    'data': cleaned_dict
                }
                test_cases.append(test_case)
            
            logger.info(f"Processed {len(test_cases)} test cases from Excel file")
            
        except FileNotFoundError as e:
            logger.error(f"File not found: {e}", exc_info=True)
            raise Exception(f"Excel file not found: {str(e)}")
        except ValueError as e:
            logger.error(f"Invalid file format: {e}", exc_info=True)
            raise Exception(f"Invalid Excel file: {str(e)}. Please ensure you uploaded a valid .xlsx file.")
        except pd.errors.EmptyDataError:
            logger.error("Excel file is empty")
            raise Exception("Excel file is empty. Please upload a file with data.")
        except Exception as e:
            error_msg = str(e)
            if "Bad magic number" in error_msg or "BadZipFile" in error_msg:
                logger.error(f"Corrupted Excel file: {e}", exc_info=True)
                raise Exception(f"Corrupted or invalid Excel file. Please ensure the file is a valid .xlsx file and try uploading again. Error: {str(e)}")
            else:
                logger.error(f"Error processing test case file: {e}", exc_info=True)
                raise Exception(f"Failed to process test case Excel file: {str(e)}")
        
        return test_cases
    
    def _find_locator_files(self, repo_path: str, locators_path: str) -> List[Dict]:
        """Find all files in the test locators path"""
        locator_files = []
        
        try:
            # Construct full path to locators directory
            full_locators_path = os.path.join(repo_path, locators_path)
            
            if not os.path.exists(full_locators_path):
                logger.warning(f"Locators path does not exist: {full_locators_path}")
                return locator_files
            
            if not os.path.isdir(full_locators_path):
                logger.warning(f"Locators path is not a directory: {full_locators_path}")
                return locator_files
            
            # Walk through the locators directory
            for root, dirs, files in os.walk(full_locators_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, repo_path)
                    
                    # Get file info
                    try:
                        file_size = os.path.getsize(file_path)
                        file_ext = os.path.splitext(file)[1].lower()
                        
                        # Try to read file content if it's a text file
                        # Use a reasonable max size (50KB) to prevent issues with very large files
                        # This ensures full content is included in prompts while preventing memory issues
                        MAX_FILE_CONTENT_SIZE = 50 * 1024  # 50KB limit
                        file_content = None
                        is_truncated = False
                        
                        if file_ext in ['.json', '.yaml', '.yml', '.xml', '.properties', '.txt', '.py', '.js', '.ts', '.java', '.jsx', '.tsx', '.css', '.html', '.md']:
                            try:
                                # Only read if file is within reasonable size limit
                                if file_size <= MAX_FILE_CONTENT_SIZE:
                                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                        file_content = f.read()
                                else:
                                    # For larger files, read up to the limit and mark as truncated
                                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                        file_content = f.read(MAX_FILE_CONTENT_SIZE)
                                    is_truncated = True
                                    logger.info(f"File {file_path} is large ({file_size} bytes), truncated to {MAX_FILE_CONTENT_SIZE} bytes for prompt generation")
                            except Exception as e:
                                logger.warning(f"Error reading file content for {file_path}: {e}")
                                pass
                        
                        locator_file = {
                            'file_name': file,
                            'file_path': relative_path,
                            'full_path': file_path,
                            'file_size': file_size,
                            'file_extension': file_ext,
                            'file_content': file_content,  # Include full content (up to 50KB limit)
                            'is_truncated': is_truncated  # Flag to indicate if content was truncated
                        }
                        
                        locator_files.append(locator_file)
                        
                    except Exception as e:
                        logger.warning(f"Error processing file {file_path}: {e}")
                        continue
            
            logger.info(f"Found {len(locator_files)} files in locators path: {locators_path}")
            
        except Exception as e:
            logger.error(f"Error finding locator files: {e}", exc_info=True)
            raise Exception(f"Failed to find locator files: {str(e)}")
        
        return locator_files

# Global instance
test_automation_scanner = TestAutomationScanner()

