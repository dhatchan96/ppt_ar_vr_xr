"""
ThreatGuard Pro - Database Management
Enhanced database operations with SQLite support for vulnerability management
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Enhanced database manager with SQLite support for vulnerabilities"""
    
    def __init__(self):
        self.data_dir = Path("threatguard_data")
        self.data_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "vulnerabilities.db"
        self.init_sqlite_database()
    
    def init_sqlite_database(self):
        """Initialize SQLite database for vulnerabilities"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create enhanced_vulnerabilities table (matching API expectations)
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS enhanced_vulnerabilities (
                        id TEXT PRIMARY KEY,
                        gis_id TEXT,
                        ait_tag TEXT,
                        title TEXT,
                        description TEXT,
                        remediation_action TEXT,
                        status TEXT,
                        severity TEXT,
                        risk_score INTEGER,
                        wave_assignment TEXT,
                        cost_impact REAL,
                        created_date TEXT,
                        source TEXT,
                        vulnerability_type TEXT,
                        import_date TEXT
                    )
                ''')
                
                # Create vulnerabilities table (for backward compatibility)
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS vulnerabilities (
                        id TEXT PRIMARY KEY,
                        gis_id TEXT,
                        ait_tag TEXT,
                        title TEXT,
                        description TEXT,
                        remediation_action TEXT,
                        status TEXT,
                        severity TEXT,
                        risk_score INTEGER,
                        wave_assignment TEXT,
                        cost_impact REAL,
                        created_date TEXT,
                        source TEXT,
                        vulnerability_type TEXT,
                        import_date TEXT
                    )
                ''')
                
                # Create scan_history table for VSCode extension scans
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS scan_history (
                        scan_id TEXT PRIMARY KEY,
                        project_id TEXT,
                        file_name TEXT,
                        file_path TEXT,
                        timestamp TEXT,
                        duration_ms INTEGER,
                        files_scanned INTEGER,
                        lines_of_code INTEGER,
                        coverage TEXT,
                        issues_found INTEGER,
                        total_threats INTEGER,
                        quality_gate_status TEXT,
                        threat_shield_status TEXT,
                        source TEXT,
                        ait_tag TEXT,
                        spk_tag TEXT,
                        repo_name TEXT,
                        username TEXT,
                        threats_json TEXT,
                        scan_metrics_json TEXT,
                        severity_breakdown_json TEXT,
                        threat_types_json TEXT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Add username column if it doesn't exist (for existing databases)
                try:
                    cursor.execute("ALTER TABLE scan_history ADD COLUMN username TEXT")
                except sqlite3.OperationalError:
                    # Column already exists, ignore
                    pass
                
                # Create index for faster queries
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_scan_history_source 
                    ON scan_history(source)
                ''')
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_scan_history_timestamp 
                    ON scan_history(timestamp DESC)
                ''')
                
                # Create prompt_usage_tracking table for knowledge base prompt usage
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS prompt_usage_tracking (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        template_id TEXT NOT NULL,
                        template_title TEXT,
                        username TEXT NOT NULL,
                        usage_type TEXT,
                        timestamp TEXT NOT NULL,
                        source TEXT DEFAULT 'vscode_extension',
                        metadata TEXT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (template_id) REFERENCES knowledge_base_templates(id)
                    )
                ''')
                
                # Create indexes for prompt usage tracking
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_prompt_usage_template_id 
                    ON prompt_usage_tracking(template_id)
                ''')
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_prompt_usage_username 
                    ON prompt_usage_tracking(username)
                ''')
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_prompt_usage_timestamp 
                    ON prompt_usage_tracking(timestamp DESC)
                ''')
                
                conn.commit()
                logger.info("SQLite database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize SQLite database: {e}")
    
    def get_vulnerabilities(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get vulnerabilities from SQLite with optional filtering"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                query = "SELECT * FROM enhanced_vulnerabilities"
                params = []
                
                if filters:
                    conditions = []
                    for key, value in filters.items():
                        conditions.append(f"{key} = ?")
                        params.append(value)
                    
                    if conditions:
                        query += " WHERE " + " AND ".join(conditions)
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"Error getting vulnerabilities from SQLite: {e}")
            return []
    
    def save_vulnerability(self, vulnerability: Dict[str, Any]) -> bool:
        """Save a vulnerability to SQLite"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO enhanced_vulnerabilities 
                    (id, gis_id, ait_tag, title, description, remediation_action, 
                     status, severity, risk_score, wave_assignment, cost_impact, 
                     created_date, source, vulnerability_type, import_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    vulnerability.get('id'),
                    vulnerability.get('gis_id'),
                    vulnerability.get('ait_tag'),
                    vulnerability.get('title'),
                    vulnerability.get('description'),
                    vulnerability.get('remediation_action'),
                    vulnerability.get('status'),
                    vulnerability.get('severity'),
                    vulnerability.get('risk_score'),
                    vulnerability.get('wave_assignment'),
                    vulnerability.get('cost_impact'),
                    vulnerability.get('created_date'),
                    vulnerability.get('source'),
                    vulnerability.get('vulnerability_type'),
                    vulnerability.get('import_date')
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving vulnerability to SQLite: {e}")
            return False
    
    def save_enhanced_vulnerability(self, vulnerability: Dict[str, Any]) -> bool:
        """Save a vulnerability to enhanced_vulnerabilities table"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO enhanced_vulnerabilities 
                    (id, gis_id, ait_tag, title, description, remediation_action, 
                     status, severity, risk_score, wave_assignment, cost_impact, 
                     created_date, source, vulnerability_type, import_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    vulnerability.get('id'),
                    vulnerability.get('gis_id'),
                    vulnerability.get('ait_tag'),
                    vulnerability.get('title'),
                    vulnerability.get('description'),
                    vulnerability.get('remediation_action'),
                    vulnerability.get('status'),
                    vulnerability.get('severity'),
                    vulnerability.get('risk_score'),
                    vulnerability.get('wave_assignment'),
                    vulnerability.get('cost_impact'),
                    vulnerability.get('created_date'),
                    vulnerability.get('source'),
                    vulnerability.get('vulnerability_type'),
                    vulnerability.get('import_date')
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving enhanced vulnerability to SQLite: {e}")
            return False
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get database health status"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM enhanced_vulnerabilities")
                count = cursor.fetchone()[0]
                
                return {
                    "status": "healthy",
                    "total_vulnerabilities": count,
                    "last_updated": datetime.now().isoformat(),
                    "database_type": "SQLite"
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "database_type": "SQLite"
            }
    
    def save_scan_history(self, scan_data: Dict[str, Any]) -> bool:
        """Save scan history to SQLite database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Extract data
                scan_id = scan_data.get('scan_id')
                project_id = scan_data.get('project_id', scan_data.get('file_path', '').split('/')[-1] if scan_data.get('file_path') else 'vscode-workspace')
                file_name = scan_data.get('file_name', '')
                file_path = scan_data.get('file_path', '')
                timestamp = scan_data.get('timestamp', datetime.now().isoformat())
                
                # Extract scan metrics
                scan_metrics = scan_data.get('scan_metrics', {})
                duration_ms = scan_metrics.get('duration_ms', 0)
                files_scanned = scan_metrics.get('files_scanned', 1)
                lines_of_code = scan_metrics.get('lines_of_code', 0)
                coverage = scan_metrics.get('coverage', 'N/A')
                quality_gate_status = scan_metrics.get('quality_gate_status', 'UNKNOWN')
                threat_shield_status = scan_metrics.get('threat_shield_status', 'UNKNOWN')
                
                # Extract threats
                threats = scan_data.get('threats', [])
                issues_found = len(threats)
                total_threats = len(threats)
                
                # Extract tags
                ait_tag = scan_data.get('ait_tag', 'AIT')
                spk_tag = scan_data.get('spk_tag', 'SPK-DEFAULT')
                repo_name = scan_data.get('repo_name', 'unknown-repo')
                
                # Serialize complex data to JSON
                threats_json = json.dumps(threats, default=str)
                scan_metrics_json = json.dumps(scan_metrics, default=str)
                
                # Calculate severity breakdown
                severity_breakdown = {
                    'CRITICAL': len([t for t in threats if t.get('severity') in ['CRITICAL', 'CRITICAL_BOMB']]),
                    'HIGH': len([t for t in threats if t.get('severity') in ['HIGH', 'HIGH_RISK']]),
                    'MEDIUM': len([t for t in threats if t.get('severity') in ['MEDIUM', 'MEDIUM_RISK']]),
                    'LOW': len([t for t in threats if t.get('severity') in ['LOW', 'LOW_RISK']])
                }
                severity_breakdown_json = json.dumps(severity_breakdown)
                
                # Calculate threat types breakdown
                threat_types = {
                    'LOGIC_BOMB': len([t for t in threats if t.get('type') == 'LOGIC_BOMB']),
                    'DESTRUCTIVE_PAYLOAD': len([t for t in threats if t.get('type') == 'DESTRUCTIVE_PAYLOAD']),
                    'VULNERABILITY': len([t for t in threats if t.get('type') == 'VULNERABILITY']),
                    'SECURITY_ISSUE': len([t for t in threats if t.get('type') == 'SECURITY_ISSUE'])
                }
                threat_types_json = json.dumps(threat_types)
                
                source = scan_data.get('source', 'vscode_extension')
                
                username = scan_data.get('username', 'unknown')
                
                cursor.execute('''
                    INSERT OR REPLACE INTO scan_history 
                    (scan_id, project_id, file_name, file_path, timestamp, duration_ms, 
                     files_scanned, lines_of_code, coverage, issues_found, total_threats,
                     quality_gate_status, threat_shield_status, source, ait_tag, spk_tag, 
                     repo_name, username, threats_json, scan_metrics_json, severity_breakdown_json, 
                     threat_types_json, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    scan_id, project_id, file_name, file_path, timestamp, duration_ms,
                    files_scanned, lines_of_code, coverage, issues_found, total_threats,
                    quality_gate_status, threat_shield_status, source, ait_tag, spk_tag,
                    repo_name, username, threats_json, scan_metrics_json, severity_breakdown_json,
                    threat_types_json, datetime.now().isoformat()
                ))
                
                conn.commit()
                logger.info(f"Scan history saved to SQLite: {scan_id}")
                return True
        except Exception as e:
            logger.error(f"Error saving scan history to SQLite: {e}")
            return False
    
    def get_scan_history(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get scan history from SQLite with optional filtering"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                query = "SELECT * FROM scan_history WHERE 1=1"
                params = []
                
                if filters:
                    if filters.get('source'):
                        query += " AND source = ?"
                        params.append(filters['source'])
                    if filters.get('ait_tag'):
                        query += " AND ait_tag = ?"
                        params.append(filters['ait_tag'])
                    if filters.get('spk_tag'):
                        query += " AND spk_tag = ?"
                        params.append(filters['spk_tag'])
                    if filters.get('repo_name'):
                        query += " AND repo_name = ?"
                        params.append(filters['repo_name'])
                
                query += " ORDER BY timestamp DESC"
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                # Convert rows to dictionaries and deserialize JSON fields
                scan_history = []
                for row in rows:
                    scan_dict = dict(row)
                    # Deserialize JSON fields
                    if scan_dict.get('threats_json'):
                        scan_dict['issues'] = json.loads(scan_dict['threats_json'])
                    if scan_dict.get('scan_metrics_json'):
                        scan_dict['scan_metrics'] = json.loads(scan_dict['scan_metrics_json'])
                    if scan_dict.get('severity_breakdown_json'):
                        scan_dict['severity_breakdown'] = json.loads(scan_dict['severity_breakdown_json'])
                    if scan_dict.get('threat_types_json'):
                        scan_dict['threat_types'] = json.loads(scan_dict['threat_types_json'])
                    
                    # Rename issues_found to match expected format
                    if 'issues_found' not in scan_dict and 'total_threats' in scan_dict:
                        scan_dict['issues_found'] = scan_dict['total_threats']
                    
                    scan_history.append(scan_dict)
                
                return scan_history
        except Exception as e:
            logger.error(f"Error getting scan history from SQLite: {e}")
            return []
    
    def track_prompt_usage(self, template_id: str, username: str, template_title: str = None, usage_type: str = 'used', metadata: Dict[str, Any] = None, source: str = 'vscode_extension') -> bool:
        """Track knowledge base prompt usage"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                metadata_json = json.dumps(metadata or {})
                timestamp = datetime.now().isoformat()
                
                cursor.execute('''
                    INSERT INTO prompt_usage_tracking 
                    (template_id, template_title, username, usage_type, timestamp, source, metadata, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    template_id,
                    template_title,
                    username,
                    usage_type,
                    timestamp,
                    source,
                    metadata_json,
                    timestamp
                ))
                
                conn.commit()
                logger.info(f"Prompt usage tracked: template_id={template_id}, username={username}, usage_type={usage_type}")
                return True
        except Exception as e:
            logger.error(f"Error tracking prompt usage: {e}")
            return False
    
    def get_prompt_usage_stats(self, template_id: str = None, username: str = None) -> Dict[str, Any]:
        """Get prompt usage statistics"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                query = "SELECT * FROM prompt_usage_tracking WHERE 1=1"
                params = []
                
                if template_id:
                    query += " AND template_id = ?"
                    params.append(template_id)
                
                if username:
                    query += " AND username = ?"
                    params.append(username)
                
                query += " ORDER BY timestamp DESC"
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                # Get column names
                columns = [description[0] for description in cursor.description]
                
                usage_records = []
                for row in rows:
                    record = dict(zip(columns, row))
                    if record.get('metadata'):
                        record['metadata'] = json.loads(record['metadata'])
                    usage_records.append(record)
                
                return {
                    'total_usage': len(usage_records),
                    'usage_records': usage_records
                }
        except Exception as e:
            logger.error(f"Error getting prompt usage stats: {e}")
            return {'total_usage': 0, 'usage_records': []}

# Global database manager instance
db_manager = DatabaseManager()

