#!/usr/bin/env python3
"""
Complete Logic Bomb Detection Tool with Enhanced Multi-Language Support
A static analysis tool to detect potential logic bombs in multiple programming languages.
"""

import ast
import re
import os
import tempfile
import zipfile
import string
import json
from datetime import datetime
from typing import List, Dict, Set, Any
from dataclasses import dataclass
from flask import Flask, request, jsonify
from flask_cors import CORS
import traceback

@dataclass
class SuspiciousPattern:
    """Represents a suspicious code pattern that might indicate a logic bomb."""
    pattern_type: str
    description: str
    severity: str  # LOW, MEDIUM, HIGH
    line_number: int
    code_snippet: str
    confidence: float
    language: str = "python"  # Added language field

class Secure_Guard:
    """Main detector class for identifying potential logic bombs and financial fraud with multi-language support."""
    
    def __init__(self):
        self.suspicious_patterns = []
        
        # Language detection support
        self.supported_languages = {
            '.py': 'python',
            '.java': 'java', 
            '.js': 'javascript',
            '.ts': 'typescript',
            '.cs': 'csharp',
            '.vb': 'vbnet',
            '.jsx': 'react',
            '.tsx': 'react_typescript',
            '.json': 'config',
            '.html': 'html',
            '.php': 'php',
            '.rb': 'ruby',
            '.go': 'golang',
            '.cpp': 'cpp',
            '.c': 'c'
        }
        
        self.time_related_imports = {
            'datetime', 'time', 'calendar', 'dateutil', 'arrow', 'pendulum'
        }
        self.file_system_operations = {
            'os.remove', 'os.unlink', 'os.rmdir', 'shutil.rmtree', 
            'os.system', 'subprocess.call', 'subprocess.run', 'subprocess.Popen'
        }
        self.destructive_operations = {
            'format', 'delete', 'drop', 'truncate', 'destroy', 'wipe', 
            'clear', 'erase', 'purge', 'kill', 'terminate'
        }
        
        # Financial fraud patterns
        self.financial_keywords = {
            'payment', 'transfer', 'transaction', 'amount', 'balance', 'account',
            'withdraw', 'deposit', 'send_money', 'pay', 'charge', 'billing',
            'invoice', 'refund', 'credit', 'debit', 'wallet', 'bank'
        }
        
        # Suspicious financial operations
        self.financial_operations = {
            'transfer_money', 'send_payment', 'process_payment', 'charge_card',
            'withdraw_funds', 'deposit_amount', 'update_balance', 'create_transaction',
            'send_to_account', 'redirect_payment', 'modify_amount', 'skim_amount'
        }
        
        # Developer/personal identifiers (suspicious in payment code)
        self.personal_identifiers = [
            r'developer', r'admin', r'personal', r'private', r'secret',
            r'my_account', r'dev_account', r'test_account', r'backup_account'
        ]
        
        # Suspicious account patterns
        self.suspicious_account_patterns = [
            r'\b\d{10,20}\b',  # Long account numbers
            r'[a-zA-Z0-9]{20,}',  # Long alphanumeric strings (crypto addresses)
            r'0x[a-fA-F0-9]{40}',  # Ethereum addresses
            r'[13][a-km-zA-HJ-NP-Z1-9]{25,34}',  # Bitcoin addresses
            r'paypal\.me\/[a-zA-Z0-9]+',  # PayPal.me links
        ]
        
        # Data exfiltration patterns
        self.data_exfiltration_keywords = {
            'requests', 'urllib', 'http', 'ftp', 'smtp', 'socket', 'paramiko',
            'ftplib', 'smtplib', 'email', 'zipfile', 'tarfile', 'pickle'
        }
        
        # Sensitive data patterns
        self.sensitive_data_patterns = [
            r'password', r'credit_card', r'ssn', r'social_security',
            r'api_key', r'secret', r'token', r'private_key', r'certificate'
        ]
        
        # Backdoor patterns
        self.backdoor_indicators = {
            'shell', 'cmd', 'powershell', 'bash', 'terminal', 'reverse_shell',
            'bind_shell', 'netcat', 'telnet', 'ssh', 'rdp'
        }
        
        # Privilege escalation patterns
        self.privilege_escalation_keywords = {
            'sudo', 'admin', 'root', 'administrator', 'privilege', 'escalate',
            'setuid', 'setgid', 'chmod', 'chown', 'runas'
        }
        
        # Anti-analysis patterns
        self.anti_analysis_patterns = [
            r'debugger', r'analyst', r'reverse', r'disassemble', r'decompile',
            r'sandbox', r'vm', r'virtual', r'monitor', r'trace'
        ]
        
        # Cryptocurrency mining patterns
        self.crypto_mining_keywords = {
            'mining', 'miner', 'hashrate', 'cryptocurrency', 'bitcoin',
            'ethereum', 'monero', 'mining_pool', 'gpu', 'cpu_mining'
        }
        
        # Ransomware indicators
        self.ransomware_patterns = [
            r'encrypt', r'decrypt', r'ransom', r'payment', r'bitcoin',
            r'\.locked', r'\.encrypted', r'README.*txt', r'HOW_TO_DECRYPT'
        ]

    def detect_language(self, filepath: str, content: str) -> str:
        """Detect programming language from file extension and content."""
        
        # Check file extension first
        _, ext = os.path.splitext(filepath.lower())
        if ext in self.supported_languages:
            detected = self.supported_languages[ext]
            
            # Special cases
            if ext in ['.js', '.jsx'] and 'angular' in content.lower():
                return 'angular'
            elif ext in ['.ts', '.tsx'] and 'angular' in content.lower():
                return 'angular_typescript'
            elif ext == '.json' and ('package.json' in filepath or 'dependencies' in content):
                return 'npm_config'
                
            return detected
        
        # Content-based detection fallback
        if 'public class' in content and 'static void main' in content:
            return 'java'
        elif 'using System' in content or 'namespace' in content:
            return 'csharp'
        elif 'function' in content and ('var ' in content or 'let ' in content):
            return 'javascript'
        elif 'interface' in content and ': ' in content and 'export' in content:
            return 'typescript'
        elif '@Component' in content or '@Injectable' in content:
            return 'angular'
        elif '<?php' in content:
            return 'php'
        elif 'def ' in content and 'import ' in content:
            return 'python'
        
        return 'python'  # Default to python for backward compatibility

    def _analyze_multi_language_patterns(self, content: str, language: str):
        """Analyze patterns specific to the detected language."""
        print(f"🔍 Running {language}-specific analysis...")
        
        if language == 'java':
            self._analyze_java_patterns(content)
        elif language in ['javascript', 'react']:
            self._analyze_javascript_patterns(content)
        elif language in ['typescript', 'react_typescript']:
            self._analyze_typescript_patterns(content)
        elif language in ['csharp', 'vbnet']:
            self._analyze_csharp_patterns(content)
        elif language in ['angular', 'angular_typescript']:
            self._analyze_angular_patterns(content)
        elif language == 'php':
            self._analyze_php_patterns(content)
        elif language == 'html':
            self._analyze_html_patterns(content)
        elif language == 'npm_config':
            self._analyze_npm_config_patterns(content)
        # Python is handled by existing methods

    def _analyze_java_patterns(self, content: str):
        """Analyze Java-specific suspicious patterns."""
        lines = content.split('\n')
        
        java_patterns = [
            (r'Runtime\.getRuntime\(\)\.exec\(', "Java runtime command execution", "HIGH"),
            (r'ProcessBuilder\s*\(', "Java process builder usage", "HIGH"),
            (r'Class\.forName\s*\(', "Java dynamic class loading", "MEDIUM"),
            (r'Method\.invoke\s*\(', "Java method reflection", "MEDIUM"),
            (r'new\s+Date\s*\(\s*\)', "Java date object creation", "MEDIUM"),
            (r'System\.currentTimeMillis\s*\(\)', "Java current time access", "MEDIUM"),
            (r'Calendar\.getInstance\s*\(\)', "Java calendar instance", "MEDIUM"),
            (r'File\s*\(.*\)\.delete\s*\(\)', "Java file deletion", "HIGH"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in java_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JAVA_SUSPICIOUS_PATTERN",
                            description=f"Java: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="java"
                        )
                    )

    def _analyze_javascript_patterns(self, content: str):
        """Analyze JavaScript-specific suspicious patterns."""
        lines = content.split('\n')
        
        js_patterns = [
            (r'eval\s*\(', "JavaScript code evaluation", "HIGH"),
            (r'Function\s*\(.*\)', "JavaScript dynamic function creation", "HIGH"),
            (r'document\.write\s*\(', "JavaScript DOM manipulation", "MEDIUM"),
            (r'innerHTML\s*=', "JavaScript HTML injection", "MEDIUM"),
            (r'require\s*\(\s*["\']child_process["\']\s*\)', "Node.js child process access", "HIGH"),
            (r'fs\.unlink\s*\(', "Node.js file deletion", "HIGH"),
            (r'fs\.rmdir\s*\(', "Node.js directory deletion", "HIGH"),
            (r'process\.exit\s*\(', "Node.js process termination", "MEDIUM"),
            (r'new\s+Date\s*\(\s*\)', "JavaScript date object creation", "MEDIUM"),
            (r'Date\.now\s*\(\)', "JavaScript current timestamp", "MEDIUM"),
            (r'setTimeout\s*\(', "JavaScript delayed execution", "MEDIUM"),
            (r'setInterval\s*\(', "JavaScript repeated execution", "MEDIUM"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in js_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JAVASCRIPT_SUSPICIOUS_PATTERN",
                            description=f"JavaScript: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="javascript"
                        )
                    )

    def _analyze_typescript_patterns(self, content: str):
        """Analyze TypeScript-specific suspicious patterns."""
        # First run JavaScript analysis
        self._analyze_javascript_patterns(content)
        
        lines = content.split('\n')
        
        ts_patterns = [
            (r'any\s*=.*eval', "TypeScript type-unsafe eval usage", "MEDIUM"),
            (r'<any>.*Function', "TypeScript type casting to bypass security", "MEDIUM"),
            (r'declare\s+var\s+require', "TypeScript ambient require declaration", "MEDIUM"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in ts_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="TYPESCRIPT_SUSPICIOUS_PATTERN",
                            description=f"TypeScript: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="typescript"
                        )
                    )

    def _analyze_csharp_patterns(self, content: str):
        """Analyze C#-specific suspicious patterns."""
        lines = content.split('\n')
        
        csharp_patterns = [
            (r'Process\.Start\s*\(', "C# process execution", "HIGH"),
            (r'Assembly\.Load\s*\(', "C# dynamic assembly loading", "MEDIUM"),
            (r'Registry\.SetValue\s*\(', "C# registry modification", "HIGH"),
            (r'File\.Delete\s*\(', "C# file deletion", "HIGH"),
            (r'Directory\.Delete\s*\(', "C# directory deletion", "HIGH"),
            (r'DateTime\.Now', "C# current date/time access", "MEDIUM"),
            (r'Environment\.Exit\s*\(', "C# application termination", "HIGH"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in csharp_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CSHARP_SUSPICIOUS_PATTERN",
                            description=f"C#: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="csharp"
                        )
                    )

    def _analyze_angular_patterns(self, content: str):
        """Analyze Angular-specific suspicious patterns."""
        lines = content.split('\n')
        
        angular_patterns = [
            (r'innerHTML\s*=.*\+', "Angular dynamic HTML injection", "HIGH"),
            (r'bypassSecurityTrust', "Angular security bypass", "HIGH"),
            (r'dangerouslySetInnerHTML', "Angular dangerous HTML setting", "HIGH"),
            (r'eval\s*\(.*params', "Angular parameter evaluation", "HIGH"),
            (r'HttpClient.*\.get\s*\(.*\+', "Angular dynamic URL construction", "MEDIUM"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in angular_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="ANGULAR_SUSPICIOUS_PATTERN",
                            description=f"Angular: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="angular"
                        )
                    )

    def _analyze_php_patterns(self, content: str):
        """Analyze PHP-specific suspicious patterns."""
        lines = content.split('\n')
        
        php_patterns = [
            (r'eval\s*\(', "PHP code evaluation", "HIGH"),
            (r'exec\s*\(', "PHP command execution", "HIGH"),
            (r'system\s*\(', "PHP system command", "HIGH"),
            (r'shell_exec\s*\(', "PHP shell execution", "HIGH"),
            (r'passthru\s*\(', "PHP pass through execution", "HIGH"),
            (r'file_get_contents\s*\(.*http', "PHP remote file inclusion", "MEDIUM"),
            (r'include\s*\(.*\$', "PHP dynamic include", "MEDIUM"),
            (r'require\s*\(.*\$', "PHP dynamic require", "MEDIUM"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in php_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PHP_SUSPICIOUS_PATTERN",
                            description=f"PHP: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="php"
                        )
                    )

    def _analyze_html_patterns(self, content: str):
        """Analyze HTML-specific suspicious patterns."""
        lines = content.split('\n')
        
        html_patterns = [
            (r'<script.*src.*http', "HTML external script inclusion", "MEDIUM"),
            (r'javascript:.*eval', "HTML JavaScript eval", "HIGH"),
            (r'onclick.*eval', "HTML eval in event handler", "HIGH"),
            (r'onerror.*location', "HTML error handler redirect", "MEDIUM"),
            (r'<iframe.*src.*javascript', "HTML JavaScript iframe", "HIGH"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in html_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="HTML_SUSPICIOUS_PATTERN",
                            description=f"HTML: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="html"
                        )
                    )

    def _analyze_npm_config_patterns(self, content: str):
        """Analyze npm config suspicious patterns."""
        try:
            config = json.loads(content)
            
            # Check for suspicious dependencies
            suspicious_deps = ['remote-exec', 'node-shell', 'exec-async', 'malicious-package']
            
            deps_to_check = {}
            if 'dependencies' in config:
                deps_to_check.update(config['dependencies'])
            if 'devDependencies' in config:
                deps_to_check.update(config['devDependencies'])
            
            for dep_name, version in deps_to_check.items():
                if any(sus in dep_name.lower() for sus in suspicious_deps):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="NPM_SUSPICIOUS_DEPENDENCY",
                            description=f"Suspicious npm dependency: {dep_name}",
                            severity="HIGH",
                            line_number=1,
                            code_snippet=f'"{dep_name}": "{version}"',
                            confidence=0.8,
                            language="npm_config"
                        )
                    )
            
            # Check for suspicious scripts
            if 'scripts' in config:
                for script_name, script_cmd in config['scripts'].items():
                    if any(cmd in script_cmd.lower() for cmd in ['rm -rf', 'del /s', 'curl', 'wget']):
                        self.suspicious_patterns.append(
                            SuspiciousPattern(
                                pattern_type="NPM_SUSPICIOUS_SCRIPT",
                                description=f"Suspicious npm script: {script_name}",
                                severity="MEDIUM",
                                line_number=1,
                                code_snippet=f'"{script_name}": "{script_cmd}"',
                                confidence=0.7,
                                language="npm_config"
                            )
                        )
        except json.JSONDecodeError:
            pass

    def _check_universal_patterns(self, content: str, language: str):
        """Check for universal suspicious patterns across all languages."""
        lines = content.split('\n')
        
        # Universal patterns that work across languages
        universal_patterns = [
            (r'bitcoin.*address.*[13][a-km-zA-HJ-NP-Z1-9]{25,34}', "Bitcoin address found", "HIGH"),
            (r'ethereum.*address.*0x[a-fA-F0-9]{40}', "Ethereum address found", "HIGH"),
            (r'paypal\.me/[a-zA-Z0-9]+', "PayPal.me link found", "HIGH"),
            (r'backdoor|reverse.*shell', "Backdoor indicators", "HIGH"),
            (r'keylog|password.*steal', "Credential theft indicators", "HIGH"),
            (r'mining|miner|hashrate', "Crypto mining indicators", "MEDIUM"),
            (r'encrypt.*files|ransom', "Ransomware indicators", "HIGH"),
            (r'amount\s*[-+*/]\s*0\.\d+', "Financial amount manipulation", "HIGH"),
            (r'payment.*redirect|developer.*wallet', "Payment redirection", "HIGH"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity in universal_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="UNIVERSAL_SUSPICIOUS_PATTERN",
                            description=f"Universal: {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language=language
                        )
                    )
        
    def analyze_file(self, filepath: str) -> List[SuspiciousPattern]:
        """Analyze a single file for logic bomb patterns with multi-language support."""
        print(f"\n=== ANALYZING FILE: {filepath} ===")
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            print(f"File content ({len(content)} chars):")
            print("-" * 50)
            print(content)
            print("-" * 50)
            
            if not content.strip():
                print("WARNING: File is empty!")
                return []
            
            # Detect language
            language = self.detect_language(filepath, content)
            print(f"🔍 Detected language: {language}")
            
            # Reset patterns for new file
            self.suspicious_patterns = []
            
            # Run language-specific analysis
            self._analyze_multi_language_patterns(content, language)
            self._check_universal_patterns(content, language)
            
            # Only run Python AST analysis for Python files
            if language == 'python':
                try:
                    tree = ast.parse(content)
                    print("✅ AST parsing successful")
                    
                    # Perform various checks
                    print("\n🔍 Running detection checks...")
                    
                    self._check_time_based_conditions(tree, content)
                    print(f"Time-based conditions: {len([p for p in self.suspicious_patterns if p.pattern_type == 'TIME_BASED_CONDITION'])}")
                    
                    self._check_suspicious_imports(tree)
                    print(f"Suspicious imports: {len([p for p in self.suspicious_patterns if p.pattern_type == 'SUSPICIOUS_IMPORT_COMBINATION'])}")
                    
                    self._check_conditional_destructive_operations(tree, content)
                    print(f"Destructive operations: {len([p for p in self.suspicious_patterns if p.pattern_type == 'CONDITIONAL_DESTRUCTIVE_OPERATION'])}")
                    
                    self._check_system_date_manipulation(tree, content)
                    print(f"System date manipulation: {len([p for p in self.suspicious_patterns if p.pattern_type == 'SYSTEM_DATE_MANIPULATION'])}")
                    
                except SyntaxError as e:
                    print(f"❌ Syntax error in Python file: {e}")
                    # Continue with regex-based analysis for Python
                
                # Continue with all your existing Python checks
                self._check_hardcoded_dates(content)
                print(f"Hardcoded dates: {len([p for p in self.suspicious_patterns if p.pattern_type == 'HARDCODED_DATE'])}")
                
                self._check_obfuscated_code(content)
                print(f"Obfuscated code: {len([p for p in self.suspicious_patterns if p.pattern_type == 'CODE_OBFUSCATION'])}")
                
                # Financial fraud detection
                self._check_financial_fraud_patterns(content)
                print(f"Financial fraud patterns: {len([p for p in self.suspicious_patterns if p.pattern_type == 'FINANCIAL_FRAUD'])}")
                
                self._check_payment_manipulation(content)
                print(f"Payment manipulation: {len([p for p in self.suspicious_patterns if p.pattern_type == 'PAYMENT_MANIPULATION'])}")
                
                self._check_suspicious_accounts(content)
                print(f"Suspicious accounts: {len([p for p in self.suspicious_patterns if p.pattern_type == 'SUSPICIOUS_ACCOUNT'])}")
                
                self._check_amount_skimming(content)
                print(f"Amount skimming: {len([p for p in self.suspicious_patterns if p.pattern_type == 'AMOUNT_SKIMMING'])}")
                
                # Additional security threats
                self._check_data_exfiltration(content)
                print(f"Data exfiltration: {len([p for p in self.suspicious_patterns if p.pattern_type == 'DATA_EXFILTRATION'])}")
                
                self._check_backdoor_creation(content)
                print(f"Backdoor creation: {len([p for p in self.suspicious_patterns if p.pattern_type == 'BACKDOOR_CREATION'])}")
                
                self._check_privilege_escalation(content)
                print(f"Privilege escalation: {len([p for p in self.suspicious_patterns if p.pattern_type == 'PRIVILEGE_ESCALATION'])}")
                
                self._check_anti_analysis_techniques(content)
                print(f"Anti-analysis techniques: {len([p for p in self.suspicious_patterns if p.pattern_type == 'ANTI_ANALYSIS'])}")
                
                self._check_crypto_mining(content)
                print(f"Crypto mining: {len([p for p in self.suspicious_patterns if p.pattern_type == 'CRYPTO_MINING'])}")
                
                self._check_ransomware_patterns(content)
                print(f"Ransomware patterns: {len([p for p in self.suspicious_patterns if p.pattern_type == 'RANSOMWARE'])}")
                
                self._check_credential_harvesting(content)
                print(f"Credential harvesting: {len([p for p in self.suspicious_patterns if p.pattern_type == 'CREDENTIAL_HARVESTING'])}")
                
                self._check_network_reconnaissance(content)
                print(f"Network reconnaissance: {len([p for p in self.suspicious_patterns if p.pattern_type == 'NETWORK_RECONNAISSANCE'])}")
                
                self._check_steganography_hiding(content)
                print(f"Steganography/hiding: {len([p for p in self.suspicious_patterns if p.pattern_type == 'STEGANOGRAPHY'])}")
                
                self._check_supply_chain_attacks(content)
                print(f"Supply chain attacks: {len([p for p in self.suspicious_patterns if p.pattern_type == 'SUPPLY_CHAIN_ATTACK'])}")
            
            print(f"\n📊 Total patterns found: {len(self.suspicious_patterns)}")
            for i, pattern in enumerate(self.suspicious_patterns, 1):
                print(f"  {i}. {pattern.pattern_type} (Line {pattern.line_number}) - {pattern.severity} - {pattern.language}")
                print(f"     Code: {pattern.code_snippet}")
            
            return self.suspicious_patterns
            
        except Exception as e:
            print(f"❌ Error analyzing {filepath}: {str(e)}")
            print(f"Exception details: {traceback.format_exc()}")
            return []
    
    def _check_time_based_conditions(self, tree: ast.AST, content: str):
        """Check for time-based conditional statements."""
        print("🕐 Checking time-based conditions...")
        lines = content.split('\n')
        
        class TimeConditionVisitor(ast.NodeVisitor):
            def __init__(self, detector):
                self.detector = detector
                
            def visit_If(self, node):
                print(f"   Found IF statement at line {node.lineno}")
                # Check if condition involves time/date comparisons
                try:
                    if hasattr(ast, 'unparse'):
                        condition_code = ast.unparse(node.test)
                    else:
                        # Fallback for older Python versions
                        condition_code = ast.dump(node.test)
                    
                    print(f"   Condition: {condition_code}")
                    
                    # Look for date/time comparisons
                    time_patterns = [
                        r'datetime\.',
                        r'time\.',
                        r'date\.',
                        r'now\(\)',
                        r'today\(\)',
                        r'strftime',
                        r'strptime'
                    ]
                    
                    for pattern in time_patterns:
                        if re.search(pattern, condition_code):
                            line_num = node.lineno
                            snippet = lines[line_num - 1] if line_num <= len(lines) else condition_code
                            
                            print(f"   ✅ Found time-based condition with pattern: {pattern}")
                            
                            self.detector.suspicious_patterns.append(
                                SuspiciousPattern(
                                    pattern_type="TIME_BASED_CONDITION",
                                    description="Conditional statement based on date/time",
                                    severity="MEDIUM",
                                    line_number=line_num,
                                    code_snippet=snippet.strip(),
                                    confidence=0.6,
                                    language="python"
                                )
                            )
                            break
                except Exception as e:
                    print(f"   ❌ Error processing IF statement: {e}")
                
                self.generic_visit(node)
        
        visitor = TimeConditionVisitor(self)
        visitor.visit(tree)
    
    def _check_suspicious_imports(self, tree: ast.AST):
        """Check for suspicious import combinations."""
        print("📦 Checking suspicious imports...")
        imports = set()
        
        class ImportVisitor(ast.NodeVisitor):
            def visit_Import(self, node):
                for alias in node.names:
                    imports.add(alias.name)
                    print(f"   Import: {alias.name}")
            
            def visit_ImportFrom(self, node):
                if node.module:
                    imports.add(node.module)
                    print(f"   From import: {node.module}")
                    for alias in node.names:
                        imports.add(f"{node.module}.{alias.name}")
        
        visitor = ImportVisitor()
        visitor.visit(tree)
        
        print(f"   All imports: {imports}")
        
        # Check for suspicious combinations
        has_time_import = any(imp in imports for imp in self.time_related_imports)
        has_system_import = any(imp in ['os', 'subprocess', 'shutil'] for imp in imports)
        
        print(f"   Has time import: {has_time_import}")
        print(f"   Has system import: {has_system_import}")
        
        if has_time_import and has_system_import:
            print("   ✅ Found suspicious import combination")
            self.suspicious_patterns.append(
                SuspiciousPattern(
                    pattern_type="SUSPICIOUS_IMPORT_COMBINATION",
                    description="Combination of time-related and system operation imports",
                    severity="MEDIUM",
                    line_number=1,
                    code_snippet=f"Imports: {', '.join(sorted(imports))}",
                    confidence=0.5,
                    language="python"
                )
            )
    
    def _check_hardcoded_dates(self, content: str):
        """Check for hardcoded dates that might trigger logic bombs."""
        print("📅 Checking hardcoded dates...")
        lines = content.split('\n')
        
        # Date patterns
        date_patterns = [
            (r'\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b', 'YYYY-MM-DD format'),
            (r'\b\d{1,2}[-/]\d{1,2}[-/]\d{4}\b', 'MM-DD-YYYY format'),
            (r'\b\d{4}\d{2}\d{2}\b', 'YYYYMMDD format'),
            (r'datetime\(\d{4},\s*\d{1,2},\s*\d{1,2}', 'datetime() constructor'),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in date_patterns:
                matches = re.finditer(pattern, line)
                for match in matches:
                    print(f"   ✅ Found hardcoded date on line {i}: {match.group()} ({desc})")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="HARDCODED_DATE",
                            description=f"Hardcoded date found - {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_data_exfiltration(self, content: str):
        """Check for data exfiltration patterns."""
        print("📤 Checking data exfiltration patterns...")
        lines = content.split('\n')
        
        exfiltration_patterns = [
            # Network-based exfiltration
            (r'requests\.post.*data.*=', "HTTP POST data exfiltration"),
            (r'urllib.*urlopen.*data', "URL-based data transmission"),
            (r'socket\.send.*data', "Socket-based data transmission"),
            (r'smtplib.*send.*data', "Email-based data exfiltration"),
            (r'ftplib.*stor.*data', "FTP-based data upload"),
            
            # File compression before exfiltration
            (r'zipfile.*write.*password', "Password-protected ZIP creation"),
            (r'tarfile.*add.*sensitive', "Archive creation with sensitive data"),
            
            # Base64 encoding of sensitive data
            (r'base64.*encode.*(?:password|secret|key)', "Base64 encoding of secrets"),
            
            # DNS exfiltration
            (r'dns.*query.*data', "DNS-based data exfiltration"),
            (r'nslookup.*[a-fA-F0-9]{32,}', "DNS query with encoded data"),
            
            # Steganography
            (r'PIL.*Image.*save.*data', "Image steganography"),
            (r'LSB.*hide.*data', "Least Significant Bit hiding"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in exfiltration_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found data exfiltration pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="DATA_EXFILTRATION",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_backdoor_creation(self, content: str):
        """Check for backdoor creation patterns."""
        print("🚪 Checking backdoor creation patterns...")
        lines = content.split('\n')
        
        backdoor_patterns = [
            # Reverse shells
            (r'socket.*connect.*shell', "Reverse shell creation"),
            (r'subprocess.*shell.*netcat', "Netcat-based backdoor"),
            (r'/bin/bash.*>&.*socket', "Bash reverse shell"),
            
            # Bind shells
            (r'socket.*bind.*listen', "Bind shell creation"),
            (r'serve_forever.*shell', "Persistent shell server"),
            
            # SSH backdoors
            (r'paramiko.*exec_command', "SSH-based backdoor"),
            (r'authorized_keys.*append', "SSH key injection"),
            
            # Web backdoors
            (r'@app\.route.*exec', "Web shell endpoint"),
            (r'flask.*request.*eval', "Web-based code execution"),
            
            # Scheduled backdoors
            (r'crontab.*backdoor', "Cron-based persistence"),
            (r'schedule.*every.*shell', "Scheduled backdoor execution"),
            
            # Service backdoors
            (r'systemd.*service.*backdoor', "System service backdoor"),
            (r'windows.*service.*shell', "Windows service backdoor"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in backdoor_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found backdoor pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="BACKDOOR_CREATION",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.9,
                            language="python"
                        )
                    )
    
    def _check_privilege_escalation(self, content: str):
        """Check for privilege escalation attempts."""
        print("⬆️ Checking privilege escalation patterns...")
        lines = content.split('\n')
        
        privilege_patterns = [
            # UNIX privilege escalation
            (r'sudo.*passwd', "Password change via sudo"),
            (r'chmod.*4755', "SUID bit setting"),
            (r'chown.*root', "Ownership change to root"),
            (r'setuid.*0', "Set UID to root"),
            
            # Windows privilege escalation
            (r'runas.*administrator', "Run as administrator"),
            (r'UAC.*bypass', "UAC bypass attempt"),
            (r'SeDebugPrivilege', "Windows debug privilege"),
            
            # Kernel exploits
            (r'kernel.*exploit', "Kernel exploitation"),
            (r'/proc/.*mem', "Process memory manipulation"),
            
            # Service exploitation
            (r'service.*replace.*binary', "Service binary replacement"),
            (r'dll.*hijacking', "DLL hijacking"),
            
            # Token manipulation
            (r'token.*impersonate', "Token impersonation"),
            (r'access.*token.*duplicate', "Access token duplication"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in privilege_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found privilege escalation pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PRIVILEGE_ESCALATION",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_anti_analysis_techniques(self, content: str):
        """Check for anti-analysis and evasion techniques."""
        print("🕵️ Checking anti-analysis techniques...")
        lines = content.split('\n')
        
        anti_analysis_patterns = [
            # Debugger detection
            (r'debugger.*detect', "Debugger detection"),
            (r'ptrace.*deny', "Anti-debugging via ptrace"),
            (r'IsDebuggerPresent', "Windows debugger detection"),
            
            # VM detection
            (r'virtual.*machine.*detect', "Virtual machine detection"),
            (r'vmware.*detect', "VMware detection"),
            (r'vbox.*detect', "VirtualBox detection"),
            
            # Sandbox evasion
            (r'sandbox.*detect', "Sandbox detection"),
            (r'sleep.*\d{4,}', "Long sleep for sandbox evasion"),
            (r'time.*check.*analysis', "Time-based analysis evasion"),
            
            # Process monitoring evasion
            (r'process.*monitor.*evade', "Process monitoring evasion"),
            (r'wireshark.*detect', "Network monitoring detection"),
            (r'procmon.*detect', "Process Monitor detection"),
            
            # Code obfuscation
            (r'obfuscat.*code', "Code obfuscation"),
            (r'encrypt.*string', "String encryption"),
            (r'decode.*runtime', "Runtime decoding"),
            
            # Anti-forensics
            (r'clear.*logs', "Log clearing"),
            (r'delete.*history', "History deletion"),
            (r'wipe.*metadata', "Metadata wiping"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in anti_analysis_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found anti-analysis technique on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="ANTI_ANALYSIS",
                            description=description,
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )
    
    def _check_crypto_mining(self, content: str):
        """Check for cryptocurrency mining patterns."""
        print("⛏️ Checking crypto mining patterns...")
        lines = content.split('\n')
        
        mining_patterns = [
            # Mining software references
            (r'xmrig|ethminer|cgminer', "Cryptocurrency miner reference"),
            (r'mining.*pool.*connect', "Mining pool connection"),
            (r'hashrate.*calculate', "Hash rate calculation"),
            (r'gpu.*mining', "GPU mining"),
            (r'cpu.*mining', "CPU mining"),
            
            # Mining configuration
            (r'stratum.*tcp.*mining', "Stratum mining protocol"),
            (r'wallet.*address.*mining', "Mining wallet configuration"),
            (r'difficulty.*target', "Mining difficulty target"),
            
            # Resource consumption
            (r'cpu.*usage.*100', "High CPU usage"),
            (r'gpu.*max.*usage', "Maximum GPU usage"),
            (r'multiprocessing.*pool.*mining', "Multi-process mining"),
            
            # Hidden mining
            (r'silent.*mining', "Silent mining"),
            (r'background.*mining', "Background mining"),
            (r'stealth.*mining', "Stealth mining"),
            
            # Mining pools
            (r'minergate|nicehash|f2pool', "Known mining pool"),
            (r'pool.*worker.*mining', "Mining pool worker"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in mining_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found crypto mining pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CRYPTO_MINING",
                            description=description,
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )
    
    def _check_ransomware_patterns(self, content: str):
        """Check for ransomware-related patterns."""
        print("🔒 Checking ransomware patterns...")
        lines = content.split('\n')
        
        ransomware_patterns = [
            # File encryption
            (r'encrypt.*files.*\.', "File encryption"),
            (r'cryptography.*fernet.*encrypt', "Cryptographic file encryption"),
            (r'AES.*encrypt.*files', "AES file encryption"),
            
            # File extension changes
            (r'rename.*\.locked', "File locking via rename"),
            (r'\.encrypted.*extension', "Encrypted file extension"),
            (r'\.ransom.*extension', "Ransom file extension"),
            
            # Ransom notes
            (r'README.*decrypt', "Ransom note creation"),
            (r'HOW_TO_DECRYPT', "Decryption instructions"),
            (r'ransom.*payment.*bitcoin', "Bitcoin ransom demand"),
            
            # Key management
            (r'encryption.*key.*server', "Key server communication"),
            (r'private.*key.*delete', "Private key deletion"),
            (r'master.*key.*generate', "Master key generation"),
            
            # System modification
            (r'wallpaper.*change.*ransom', "Wallpaper change to ransom message"),
            (r'startup.*ransom.*message', "Startup ransom message"),
            (r'disable.*recovery', "System recovery disabling"),
            
            # Payment mechanisms
            (r'bitcoin.*address.*payment', "Bitcoin payment address"),
            (r'tor.*onion.*payment', "Tor payment site"),
            (r'countdown.*timer.*payment', "Payment countdown timer"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in ransomware_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found ransomware pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="RANSOMWARE",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.9,
                            language="python"
                        )
                    )
    
    def _check_credential_harvesting(self, content: str):
        """Check for credential harvesting and password stealing."""
        print("🔑 Checking credential harvesting patterns...")
        lines = content.split('\n')
        
        credential_patterns = [
            # Browser credential theft
            (r'chrome.*password.*sqlite', "Chrome password extraction"),
            (r'firefox.*logins.*json', "Firefox password extraction"),
            (r'safari.*keychain', "Safari keychain access"),
            
            # System credential access
            (r'sam.*file.*password', "Windows SAM file access"),
            (r'/etc/shadow.*read', "Linux shadow file access"),
            (r'lsass.*dump.*password', "LSASS memory dump"),
            
            # Keylogging
            (r'keyboard.*hook.*log', "Keyboard hooking"),
            (r'keylogger.*capture', "Keylogger implementation"),
            (r'input.*capture.*password', "Input capture"),
            
            # Network credential sniffing
            (r'sniff.*password.*network', "Network password sniffing"),
            (r'mitm.*credentials', "Man-in-the-middle credential theft"),
            (r'packet.*capture.*login', "Packet capture for credentials"),
            
            # Token theft
            (r'discord.*token.*steal', "Discord token theft"),
            (r'steam.*token.*extract', "Steam token extraction"),
            (r'api.*key.*harvest', "API key harvesting"),
            
            # Phishing
            (r'fake.*login.*page', "Fake login page creation"),
            (r'phishing.*credentials', "Phishing for credentials"),
            (r'harvest.*password.*form', "Password form harvesting"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in credential_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found credential harvesting pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CREDENTIAL_HARVESTING",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_network_reconnaissance(self, content: str):
        """Check for network reconnaissance and scanning."""
        print("🌐 Checking network reconnaissance patterns...")
        lines = content.split('\n')
        
        recon_patterns = [
            # Port scanning
            (r'socket.*connect.*port.*scan', "Port scanning"),
            (r'nmap.*scan.*network', "Nmap network scanning"),
            (r'masscan.*port.*range', "Mass port scanning"),
            
            # Network discovery
            (r'ping.*sweep.*network', "Network ping sweep"),
            (r'arp.*scan.*discovery', "ARP network discovery"),
            (r'subnet.*enumeration', "Subnet enumeration"),
            
            # Service enumeration
            (r'banner.*grab.*service', "Service banner grabbing"),
            (r'version.*detect.*service', "Service version detection"),
            (r'vulnerability.*scan', "Vulnerability scanning"),
            
            # DNS reconnaissance
            (r'dns.*enumeration', "DNS enumeration"),
            (r'subdomain.*brute.*force', "Subdomain brute forcing"),
            (r'zone.*transfer.*dns', "DNS zone transfer"),
            
            # Web reconnaissance
            (r'directory.*brute.*force', "Directory brute forcing"),
            (r'web.*crawler.*reconnaissance', "Web reconnaissance"),
            (r'robots\.txt.*parse', "Robots.txt parsing"),
            
            # SNMP scanning
            (r'snmp.*community.*scan', "SNMP community scanning"),
            (r'snmp.*walk.*enumeration', "SNMP enumeration"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in recon_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found network reconnaissance pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="NETWORK_RECONNAISSANCE",
                            description=description,
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )
    
    def _check_steganography_hiding(self, content: str):
        """Check for steganography and data hiding techniques."""
        print("🖼️ Checking steganography and data hiding...")
        lines = content.split('\n')
        
        steganography_patterns = [
            # Image steganography
            (r'PIL.*Image.*LSB', "LSB image steganography"),
            (r'steghide.*embed', "Steghide data embedding"),
            (r'image.*pixel.*data.*hide', "Pixel-based data hiding"),
            
            # Audio steganography
            (r'wav.*file.*lsb.*hide', "Audio LSB hiding"),
            (r'spectogram.*hide.*data', "Spectrogram data hiding"),
            
            # Text steganography
            (r'whitespace.*steganography', "Whitespace steganography"),
            (r'unicode.*hide.*data', "Unicode steganography"),
            (r'zero.*width.*character', "Zero-width character hiding"),
            
            # File system hiding
            (r'alternate.*data.*stream', "NTFS ADS hiding"),
            (r'hidden.*partition', "Hidden partition creation"),
            (r'file.*slack.*space', "File slack space hiding"),
            
            # Network steganography
            (r'covert.*channel.*tcp', "TCP covert channel"),
            (r'dns.*tunneling.*data', "DNS tunneling"),
            (r'icmp.*tunnel.*data', "ICMP tunneling"),
            
            # Polyglot files
            (r'polyglot.*file.*create', "Polyglot file creation"),
            (r'dual.*format.*file', "Dual-format file"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in steganography_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found steganography pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="STEGANOGRAPHY",
                            description=description,
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language="python"
                        )
                    )
    
    def _check_supply_chain_attacks(self, content: str):
        """Check for supply chain attack patterns."""
        print("📦 Checking supply chain attack patterns...")
        lines = content.split('\n')
        
        supply_chain_patterns = [
            # Package manipulation
            (r'setup\.py.*backdoor', "Setup.py backdoor"),
            (r'__init__\.py.*malicious', "Init file manipulation"),
            (r'pip.*install.*typosquatting', "Typosquatting package"),
            
            # Dependency confusion
            (r'private.*package.*public', "Dependency confusion"),
            (r'internal.*package.*external', "Internal package exposure"),
            
            # Build process manipulation
            (r'makefile.*inject.*code', "Makefile code injection"),
            (r'cmake.*backdoor', "CMake backdoor"),
            (r'build.*script.*modify', "Build script modification"),
            
            # CI/CD pipeline attacks
            (r'github.*action.*malicious', "Malicious GitHub Action"),
            (r'jenkins.*pipeline.*inject', "Jenkins pipeline injection"),
            (r'docker.*image.*backdoor', "Docker image backdoor"),
            
            # Code signing bypass
            (r'certificate.*fake', "Fake code signing certificate"),
            (r'signature.*bypass', "Signature verification bypass"),
            
            # Version pinning attacks
            (r'requirements.*downgrade', "Dependency downgrade attack"),
            (r'version.*rollback.*vulnerable', "Vulnerable version rollback"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in supply_chain_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found supply chain attack pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="SUPPLY_CHAIN_ATTACK",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_financial_fraud_patterns(self, content: str):
        """Check for financial fraud and unauthorized payment patterns."""
        print("💰 Checking financial fraud patterns...")
        lines = content.split('\n')
        
        # Patterns that indicate potential financial fraud
        fraud_patterns = [
            # Developer accounts in payment code
            (r'(developer|admin|personal|private).*account', "Developer/personal account in payment code"),
            (r'my_account|dev_account|test_account', "Personal account references"),
            
            # Unauthorized transfers
            (r'transfer.*to.*developer', "Transfer to developer account"),
            (r'send.*money.*admin', "Send money to admin"),
            (r'redirect.*payment', "Payment redirection"),
            
            # Amount manipulation
            (r'amount\s*[-+*/]\s*\d+', "Amount calculation manipulation"),
            (r'fee\s*=\s*amount\s*\*', "Suspicious fee calculation"),
            (r'skim|siphon|divert', "Money skimming terminology"),
            
            # Hidden transactions
            (r'hidden.*transaction', "Hidden transaction"),
            (r'secret.*payment', "Secret payment"),
            (r'if.*amount.*>.*\d+.*send', "Conditional money transfer"),
            
            # Hardcoded recipient accounts
            (r'recipient.*=.*["\'].*developer', "Hardcoded developer recipient"),
            (r'payee.*=.*["\'].*admin', "Hardcoded admin payee"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in fraud_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found financial fraud pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="FINANCIAL_FRAUD",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_payment_manipulation(self, content: str):
        """Check for payment amount manipulation and skimming."""
        print("💳 Checking payment manipulation...")
        lines = content.split('\n')
        
        manipulation_patterns = [
            # Small amount skimming
            (r'amount\s*-\s*0\.\d+', "Small amount deduction (penny shaving)"),
            (r'round.*down.*amount', "Rounding down amounts"),
            (r'math\.floor.*amount', "Floor operation on amounts"),
            
            # Percentage skimming
            (r'amount\s*\*\s*0\.\d+', "Percentage-based skimming"),
            (r'fee\s*=\s*amount\s*\*\s*0\.0\d+', "Small percentage fee"),
            
            # Conditional skimming
            (r'if.*amount.*>.*\d+.*amount.*-=', "Conditional amount reduction"),
            (r'if.*transaction.*amount.*\*=', "Conditional amount multiplication"),
            
            # Random skimming
            (r'random.*amount', "Random amount manipulation"),
            (r'if.*random.*<.*amount', "Random-based amount changes"),
            
            # Account number manipulation
            (r'account.*=.*developer', "Account reassignment to developer"),
            (r'recipient.*replace', "Recipient replacement"),
            
            # Duplicate transactions
            (r'for.*in.*range.*send', "Multiple send operations"),
            (r'while.*amount.*transfer', "Loop-based transfers"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in manipulation_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found payment manipulation on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PAYMENT_MANIPULATION",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.9,
                            language="python"
                        )
                    )
    
    def _check_suspicious_accounts(self, content: str):
        """Check for hardcoded suspicious account numbers or addresses."""
        print("🏦 Checking suspicious account patterns...")
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            # Check for cryptocurrency addresses
            if re.search(r'0x[a-fA-F0-9]{40}', line):  # Ethereum address
                print(f"   ✅ Found Ethereum address on line {i}")
                self.suspicious_patterns.append(
                    SuspiciousPattern(
                        pattern_type="SUSPICIOUS_ACCOUNT",
                        description="Hardcoded Ethereum address",
                        severity="HIGH",
                        line_number=i,
                        code_snippet=line.strip(),
                        confidence=0.9,
                        language="python"
                    )
                )
            
            # Bitcoin addresses
            if re.search(r'[13][a-km-zA-HJ-NP-Z1-9]{25,34}', line):
                print(f"   ✅ Found Bitcoin address on line {i}")
                self.suspicious_patterns.append(
                    SuspiciousPattern(
                        pattern_type="SUSPICIOUS_ACCOUNT",
                        description="Hardcoded Bitcoin address",
                        severity="HIGH",
                        line_number=i,
                        code_snippet=line.strip(),
                        confidence=0.9,
                        language="python"
                    )
                )
            
            # PayPal.me links
            if re.search(r'paypal\.me\/[a-zA-Z0-9]+', line, re.IGNORECASE):
                print(f"   ✅ Found PayPal.me link on line {i}")
                self.suspicious_patterns.append(
                    SuspiciousPattern(
                        pattern_type="SUSPICIOUS_ACCOUNT",
                        description="Hardcoded PayPal.me link",
                        severity="HIGH",
                        line_number=i,
                        code_snippet=line.strip(),
                        confidence=0.8,
                        language="python"
                    )
                )
            
            # Long account numbers in payment context
            if any(keyword in line.lower() for keyword in self.financial_keywords):
                if re.search(r'\b\d{10,20}\b', line):
                    print(f"   ✅ Found long account number in payment context on line {i}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="SUSPICIOUS_ACCOUNT",
                            description="Hardcoded account number in payment code",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )
    
    def _check_amount_skimming(self, content: str):
        """Check for subtle amount skimming patterns."""
        print("🔍 Checking amount skimming patterns...")
        lines = content.split('\n')
        
        skimming_patterns = [
            # Penny shaving
            (r'amount\s*=\s*int\(.*amount.*\)', "Converting to int (penny shaving)"),
            (r'amount\s*=\s*math\.floor\(.*amount.*\)', "Floor operation (penny shaving)"),
            (r'cents\s*=\s*amount\s*%\s*1', "Extracting cents/fractional part"),
            
            # Small fixed deductions
            (r'amount\s*-=?\s*0\.0[1-9]', "Small fixed amount deduction"),
            (r'fee\s*=\s*0\.0[1-9]', "Small fixed fee"),
            
            # Rounding manipulation
            (r'round\(.*amount.*,\s*0\)', "Rounding to remove cents"),
            (r'truncate.*amount', "Amount truncation"),
            
            # Conditional micro-transactions
            (r'if.*amount.*>\s*\d+.*amount.*-=.*0\.\d+', "Conditional micro-deduction"),
            (r'if.*total.*>\s*\d+.*skim', "Conditional skimming"),
            
            # Developer fee patterns
            (r'dev_fee|developer_fee|admin_fee', "Developer/admin fee"),
            (r'maintenance_fee.*=.*amount', "Maintenance fee on amount"),
            
            # Suspicious calculations
            (r'extra.*=.*amount.*\*.*0\.00\d+', "Extra small percentage"),
            (r'tip.*=.*amount.*\*.*0\.0\d+', "Automatic tip calculation"),
        ]
        
        for i, line in enumerate(lines, 1):
            line_lower = line.lower()
            for pattern, description in skimming_patterns:
                if re.search(pattern, line_lower):
                    print(f"   ✅ Found amount skimming pattern on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="AMOUNT_SKIMMING",
                            description=description,
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )
    
    def _check_conditional_destructive_operations(self, tree: ast.AST, content: str):
        """Check for destructive operations inside conditional blocks."""
        print("💥 Checking destructive operations...")
        lines = content.split('\n')
        
        class DestructiveOpVisitor(ast.NodeVisitor):
            def __init__(self, detector):
                self.detector = detector
                self.in_conditional = False
                
            def visit_If(self, node):
                print(f"   Entering IF block at line {node.lineno}")
                old_conditional = self.in_conditional
                self.in_conditional = True
                
                # Check all statements in the if block
                for stmt in node.body:
                    self._check_statement_for_destruction(stmt)
                
                # Check else block
                for stmt in node.orelse:
                    self._check_statement_for_destruction(stmt)
                
                self.in_conditional = old_conditional
                self.generic_visit(node)
            
            def _check_statement_for_destruction(self, stmt):
                if isinstance(stmt, ast.Call):
                    try:
                        if hasattr(ast, 'unparse'):
                            call_str = ast.unparse(stmt)
                        else:
                            call_str = ast.dump(stmt)
                        
                        print(f"   Found call in conditional: {call_str}")
                        
                        # Check for destructive function calls
                        for destructive_op in self.detector.file_system_operations:
                            if destructive_op in call_str:
                                line_num = stmt.lineno
                                snippet = lines[line_num - 1] if line_num <= len(lines) else call_str
                                
                                print(f"   ✅ Found destructive operation: {destructive_op}")
                                
                                self.detector.suspicious_patterns.append(
                                    SuspiciousPattern(
                                        pattern_type="CONDITIONAL_DESTRUCTIVE_OPERATION",
                                        description="Destructive operation inside conditional block",
                                        severity="HIGH",
                                        line_number=line_num,
                                        code_snippet=snippet.strip(),
                                        confidence=0.9,
                                        language="python"
                                    )
                                )
                                break
                    except Exception as e:
                        print(f"   ❌ Error processing call: {e}")
        
        visitor = DestructiveOpVisitor(self)
        visitor.visit(tree)
    
    def _check_obfuscated_code(self, content: str):
        """Check for code obfuscation techniques."""
        print("🔒 Checking code obfuscation...")
        lines = content.split('\n')
        
        obfuscation_patterns = [
            (r'exec\s*\(', "Use of exec() function"),
            (r'eval\s*\(', "Use of eval() function"),
            (r'__import__\s*\(', "Dynamic import using __import__"),
            (r'getattr\s*\(.*,.*\)', "Dynamic attribute access"),
            (r'chr\s*\(\d+\)', "Character encoding obfuscation"),
            (r'base64\.', "Base64 encoding/decoding"),
            (r'codecs\.', "Codec operations"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, description in obfuscation_patterns:
                if re.search(pattern, line):
                    print(f"   ✅ Found obfuscation on line {i}: {description}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CODE_OBFUSCATION",
                            description=description,
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )
    
    def _check_system_date_manipulation(self, tree: ast.AST, content: str):
        """Check for system date/time manipulation attempts."""
        print("⏰ Checking system date manipulation...")
        lines = content.split('\n')
        
        manipulation_patterns = [
            r'os\.system.*date',
            r'subprocess.*date',
            r'SetSystemTime',
            r'settimeofday',
            r'clock_settime'
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern in manipulation_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    print(f"   ✅ Found system date manipulation on line {i}")
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="SYSTEM_DATE_MANIPULATION",
                            description="Potential system date/time manipulation",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )

# Flask API Setup
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = tempfile.gettempdir()
# Updated to support multiple languages
ALLOWED_EXTENSIONS = {'py', 'java', 'js', 'ts', 'jsx', 'tsx', 'cs', 'vb', 'json', 'html', 'php', 'rb', 'go', 'cpp', 'c', 'zip'}
MAX_FILE_SIZE = 16 * 1024 * 1024

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

def secure_filename(filename):
    """Create a secure filename by removing/replacing unsafe characters."""
    filename = os.path.basename(filename)
    safe_chars = string.ascii_letters + string.digits + '.-_'
    secure_name = ''.join(c if c in safe_chars else '_' for c in filename)
    secure_name = re.sub(r'_+', '_', secure_name)
    secure_name = secure_name.strip('._')
    
    if not secure_name or secure_name in ('.', '..'):
        secure_name = 'unnamed_file'
    
    if len(secure_name) > 100:
        name, ext = os.path.splitext(secure_name)
        secure_name = name[:95] + ext
    
    return secure_name

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def pattern_to_dict(pattern: SuspiciousPattern) -> Dict[str, Any]:
    """Convert SuspiciousPattern to dictionary."""
    return {
        'pattern_type': pattern.pattern_type,
        'description': pattern.description,
        'severity': pattern.severity,
        'line_number': pattern.line_number,
        'code_snippet': pattern.code_snippet,
        'confidence': pattern.confidence,
        'language': getattr(pattern, 'language', 'python')
    }

def analyze_file_safe(detector: Secure_Guard, filepath: str) -> tuple[List[SuspiciousPattern], str]:
    """Safely analyze a file and return patterns and any error."""
    try:
        patterns = detector.analyze_file(filepath)
        return patterns, None
    except Exception as e:
        error_msg = f"Error analyzing {os.path.basename(filepath)}: {str(e)}"
        print(error_msg)
        print(f"Exception details: {traceback.format_exc()}")
        return [], error_msg

def get_risk_level(patterns: List[SuspiciousPattern]) -> str:
    """Determine risk level based on patterns."""
    if not patterns:
        return "LOW"
    
    high_severity = any(p.severity == "HIGH" for p in patterns)
    medium_severity = any(p.severity == "MEDIUM" for p in patterns)
    
    if high_severity:
        return "HIGH"
    elif medium_severity:
        return "MEDIUM"
    else:
        return "LOW"

def extract_zip_file(zip_path: str, extract_dir: str) -> List[str]:
    """Extract ZIP file and return list of extracted files."""
    extracted_files = []
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            file_list = zip_ref.namelist()
            
            # Filter for allowed file types
            allowed_files = []
            for file_path in file_list:
                if not file_path.endswith('/'):  # Skip directories
                    filename = os.path.basename(file_path)
                    if allowed_file(filename):
                        allowed_files.append(file_path)
            
            # Extract allowed files (limit to 50 files)
            for file_path in allowed_files[:50]:
                try:
                    zip_ref.extract(file_path, extract_dir)
                    extracted_files.append(os.path.join(extract_dir, file_path))
                except Exception as e:
                    print(f"Error extracting {file_path}: {e}")
                    
    except zipfile.BadZipFile:
        print("Invalid ZIP file")
    except Exception as e:
        print(f"Error processing ZIP file: {e}")
    
    return extracted_files

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '2.0.0 - Multi-Language Support',
        'supported_languages': ['Python', 'Java', 'JavaScript', 'TypeScript', 'C#', 'Angular', 'PHP', 'HTML', 'JSON']
    })

@app.route('/api/analyze', methods=['POST'])
def analyze_files():
    """Analyze uploaded files for logic bombs and malware."""
    print("\n" + "="*80)
    print("NEW MULTI-LANGUAGE FILE UPLOAD REQUEST")
    print("="*80)
    
    try:
        # Debug: Print all form data and files
        print("Request content type:", request.content_type)
        print("Form data keys:", list(request.form.keys()))
        print("Files keys:", list(request.files.keys()))
        
        # Handle different ways files might be sent
        files = []
        
        # Method 1: Check for 'files' key
        if 'files' in request.files:
            files = request.files.getlist('files')
            print(f"Found {len(files)} files under 'files' key")
        
        # Method 2: Check all file keys if 'files' not found
        if not files:
            for key in request.files.keys():
                file_list = request.files.getlist(key)
                files.extend(file_list)
                print(f"Found {len(file_list)} files under '{key}' key")
        
        # Check if we have any files
        if not files:
            return jsonify({
                'error': 'No files provided',
                'debug_info': {
                    'content_type': request.content_type,
                    'form_keys': list(request.form.keys()),
                    'file_keys': list(request.files.keys()),
                    'expected': 'files key with file data'
                }
            }), 400
        
        # Filter out empty files
        valid_files = [f for f in files if f and f.filename and f.filename != '']
        
        if not valid_files:
            return jsonify({
                'error': 'No valid files selected',
                'debug_info': {
                    'total_files': len(files),
                    'files_info': [(f.filename if f else 'None', getattr(f, 'content_length', 0) if f else 0) for f in files]
                }
            }), 400
        
        detector = Secure_Guard()
        results = []
        temp_dirs = []
        
        try:
            for file in valid_files:
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    original_filename = file.filename
                    
                    print(f"\n📁 Processing file: {original_filename} -> {filename}")
                    
                    # Create temporary directory for this file
                    temp_dir = tempfile.mkdtemp()
                    temp_dirs.append(temp_dir)
                    
                    # Save uploaded file
                    file_path = os.path.join(temp_dir, filename)
                    file.save(file_path)
                    
                    # Verify file was saved
                    if not os.path.exists(file_path):
                        print(f"❌ ERROR: File not saved to {file_path}")
                        continue
                    
                    file_size = os.path.getsize(file_path)
                    print(f"✅ File saved to: {file_path}")
                    print(f"📊 File size: {file_size} bytes")
                    
                    files_to_analyze = []
                    
                    # Handle ZIP files
                    if filename.lower().endswith('.zip'):
                        print(f"📦 Extracting ZIP file: {filename}")
                        extracted_files = extract_zip_file(file_path, temp_dir)
                        files_to_analyze.extend(extracted_files)
                        if not extracted_files:
                            results.append({
                                'filename': original_filename,
                                'language': 'archive',
                                'risk_level': 'ERROR',
                                'total_patterns': 0,
                                'patterns': [],
                                'scan_date': datetime.now().isoformat(),
                                'error': 'No valid files found in ZIP archive'
                            })
                            continue
                    else:
                        files_to_analyze.append(file_path)
                    
                    # Analyze each file
                    all_patterns = []
                    detected_languages = set()
                    
                    for analyze_path in files_to_analyze:
                        patterns, error = analyze_file_safe(detector, analyze_path)
                        all_patterns.extend(patterns)
                        
                        # Get detected language
                        try:
                            with open(analyze_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                            language = detector.detect_language(analyze_path, content)
                            detected_languages.add(language)
                        except Exception:
                            detected_languages.add('unknown')
                    
                    # Combine results
                    primary_language = list(detected_languages)[0] if detected_languages else 'unknown'
                    if len(detected_languages) > 1:
                        primary_language = f"mixed ({', '.join(detected_languages)})"
                    
                    # Create result object
                    result = {
                        'filename': original_filename,
                        'language': primary_language,
                        'risk_level': get_risk_level(all_patterns),
                        'total_patterns': len(all_patterns),
                        'patterns': [pattern_to_dict(p) for p in all_patterns],
                        'scan_date': datetime.now().isoformat(),
                        'files_analyzed': len(files_to_analyze),
                        'error': None
                    }
                    
                    print(f"📊 Analysis complete:")
                    print(f"   Risk Level: {result['risk_level']}")
                    print(f"   Patterns Found: {result['total_patterns']}")
                    print(f"   Language: {primary_language}")
                    
                    results.append(result)
                
                else:
                    # Invalid file type
                    print(f"❌ Invalid file type: {file.filename}")
                    results.append({
                        'filename': file.filename,
                        'language': 'unknown',
                        'risk_level': 'ERROR',
                        'total_patterns': 0,
                        'patterns': [],
                        'scan_date': datetime.now().isoformat(),
                        'error': f'Invalid file type. Supported: {", ".join(sorted(ALLOWED_EXTENSIONS))}'
                    })
        
        finally:
            # Cleanup temporary directories
            for temp_dir in temp_dirs:
                try:
                    import shutil
                    shutil.rmtree(temp_dir)
                    print(f"🧹 Cleaned up temp directory: {temp_dir}")
                except Exception as e:
                    print(f"❌ Error cleaning up temp directory {temp_dir}: {str(e)}")
        
        print(f"\n📋 Returning {len(results)} results")
        return jsonify(results)
    
    except Exception as e:
        print(f"💥 Unexpected error in analyze_files: {str(e)}")
        print(f"Exception details: {traceback.format_exc()}")
        return jsonify({
            'error': f'Internal server error: {str(e)}'
        }), 500

@app.route('/api/analyze/text', methods=['POST'])
def analyze_text():
    """Analyze code provided as text with multi-language support."""
    print("\n" + "="*80)
    print("NEW MULTI-LANGUAGE TEXT ANALYSIS REQUEST")
    print("="*80)
    
    try:
        data = request.get_json()
        
        if not data or 'code' not in data:
            return jsonify({'error': 'No code provided'}), 400
        
        code = data['code']
        filename = data.get('filename', 'code.txt')
        
        print(f"📝 Analyzing code for file: {filename}")
        print(f"📊 Code length: {len(code)} characters")
        print(f"📄 Code preview:")
        print("-" * 50)
        print(code[:500] + ("..." if len(code) > 500 else ""))
        print("-" * 50)
        
        # Create temporary file
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, filename)
        
        try:
            # Write code to temporary file
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            print(f"✅ Code written to temp file: {temp_file}")
            
            # Analyze the code
            detector = Secure_Guard()
            patterns, error = analyze_file_safe(detector, temp_file)
            language = detector.detect_language(filename, code)
            
            result = {
                'filename': filename,
                'language': language,
                'risk_level': get_risk_level(patterns),
                'total_patterns': len(patterns),
                'patterns': [pattern_to_dict(p) for p in patterns],
                'scan_date': datetime.now().isoformat(),
                'code_length': len(code),
                'error': error
            }
            
            print(f"📊 Analysis complete:")
            print(f"   Language: {language}")
            print(f"   Risk Level: {result['risk_level']}")
            print(f"   Patterns Found: {result['total_patterns']}")
            for pattern in patterns:
                print(f"   - {pattern.pattern_type} (Line {pattern.line_number}): {pattern.description}")
            
            return jsonify(result)
        
        finally:
            # Cleanup
            try:
                import shutil
                shutil.rmtree(temp_dir)
                print(f"🧹 Cleaned up temp directory: {temp_dir}")
            except Exception as e:
                print(f"❌ Error cleaning up temp directory: {str(e)}")
    
    except Exception as e:
        print(f"💥 Unexpected error in analyze_text: {str(e)}")
        print(f"Exception details: {traceback.format_exc()}")
        return jsonify({
            'error': f'Internal server error: {str(e)}'
        }), 500

@app.route('/api/languages', methods=['GET'])
def get_supported_languages():
    """Get information about supported languages."""
    return jsonify({
        'supported_languages': {
            'python': {
                'extensions': ['.py'],
                'description': 'Python programming language',
                'patterns': ['Time bombs', 'System operations', 'Obfuscation', 'Financial fraud', 'Import analysis']
            },
            'java': {
                'extensions': ['.java'],
                'description': 'Java programming language',
                'patterns': ['Reflection abuse', 'System commands', 'Time conditions', 'File operations', 'Crypto operations']
            },
            'javascript': {
                'extensions': ['.js', '.jsx'],
                'description': 'JavaScript and React',
                'patterns': ['Code injection', 'DOM manipulation', 'Node.js operations', 'Browser security', 'Dynamic functions']
            },
            'typescript': {
                'extensions': ['.ts', '.tsx'],
                'description': 'TypeScript and React with TypeScript',
                'patterns': ['Type bypassing', 'Dynamic imports', 'JavaScript patterns', 'Type safety violations']
            },
            'csharp': {
                'extensions': ['.cs', '.vb'],
                'description': 'C# and VB.NET',
                'patterns': ['Reflection', 'Registry manipulation', 'Process execution', 'Assembly loading', 'Crypto operations']
            },
            'angular': {
                'extensions': ['.ts', '.js', '.html'],
                'description': 'Angular framework',
                'patterns': ['Security bypassing', 'HTTP security', 'Payment manipulation', 'Template injection', 'Dynamic HTML']
            },
            'php': {
                'extensions': ['.php'],
                'description': 'PHP server-side language',
                'patterns': ['Code injection', 'Remote file inclusion', 'Command execution', 'Parameter manipulation']
            },
            'html': {
                'extensions': ['.html', '.htm'],
                'description': 'HTML markup language',
                'patterns': ['Script injection', 'Event handler abuse', 'External resource loading', 'JavaScript execution']
            }
        },
        'detection_categories': [
            'Time-based logic bombs',
            'Financial fraud and payment manipulation',
            'Code obfuscation and injection',
            'System operations and file manipulation',
            'Network operations and data exfiltration',
            'Cryptographic operations',
            'Authentication and authorization bypass',
            'Cross-language malware indicators',
            'Backdoor and remote access',
            'Credential harvesting',
            'Privilege escalation',
            'Anti-analysis techniques'
        ]
    })

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    print("🚀 Starting Multi-Language Logic Bomb Detection API Server...")
    print(f"📁 Upload folder: {UPLOAD_FOLDER}")
    print(f"📏 Max file size: {MAX_FILE_SIZE / (1024*1024):.1f}MB")
    print("🌐 Supported Languages:")
    print("  • Python (.py)")
    print("  • Java (.java)")
    print("  • JavaScript/React (.js, .jsx)")
    print("  • TypeScript (.ts, .tsx)")
    print("  • C#/VB.NET (.cs, .vb)")
    print("  • Angular (TypeScript/JavaScript)")
    print("  • PHP (.php)")
    print("  • HTML (.html)")
    print("  • Configuration files (.json)")
    print("  • Archives (.zip)")
    print("\n🔗 API Endpoints:")
    print("  GET  /api/health - Health check and system info")
    print("  POST /api/analyze - Analyze uploaded files")
    print("  POST /api/analyze/text - Analyze code text")
    print("  GET  /api/languages - Get supported languages info")
    print("\n🎯 Server running on http://localhost:5000")
    print("📊 Enhanced multi-language detection enabled")
    print("🔍 Advanced pattern matching across all supported languages")
    print("="*80)
    
    # Run the app
    app.run(host='127.0.0.1', port=5000, debug=True)