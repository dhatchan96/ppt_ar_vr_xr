#!/usr/bin/env python3
"""
Integrated Multi-Language Malware Detection Flask API
Supports: Python, Java, JavaScript, TypeScript, C#/.NET, Angular, Node.js
"""

import ast
import re
import os
import tempfile
import zipfile
import string
import json
from datetime import datetime
from typing import List, Dict, Set, Any, Optional
from dataclasses import dataclass
from flask import Flask, request, jsonify
from flask_cors import CORS
import traceback

@dataclass
class SuspiciousPattern:
    """Represents a suspicious code pattern that might indicate malware."""
    pattern_type: str
    description: str
    severity: str  # LOW, MEDIUM, HIGH
    line_number: int
    code_snippet: str
    confidence: float
    language: str

class MultiLanguageDetector:
    """Multi-language malware detection system."""
    
    def __init__(self):
        self.suspicious_patterns = []
        self.supported_languages = {
            '.py': 'python',
            '.java': 'java', 
            '.js': 'javascript',
            '.ts': 'typescript',
            '.cs': 'csharp',
            '.vb': 'vbnet',
            '.jsx': 'react',
            '.tsx': 'react_typescript',
            '.json': 'config',
            '.html': 'html',
            '.php': 'php',
            '.rb': 'ruby',
            '.go': 'golang',
            '.cpp': 'cpp',
            '.c': 'c'
        }
        
        # Initialize language-specific patterns
        self.init_language_patterns()
        
    def init_language_patterns(self):
        """Initialize language-specific malicious patterns."""
        
        # Python patterns
        self.python_patterns = {
            'time_imports': {'datetime', 'time', 'calendar', 'dateutil', 'arrow', 'pendulum'},
            'system_ops': {'os.system', 'subprocess', 'shutil.rmtree', 'os.remove'},
            'obfuscation': [r'exec\s*\(', r'eval\s*\(', r'__import__\s*\('],
            'file_ops': {'os.remove', 'os.unlink', 'shutil.rmtree'},
            'network': {'requests', 'urllib', 'socket', 'http'}
        }
        
        # Java patterns
        self.java_patterns = {
            'time_imports': {'java.util.Date', 'java.time.LocalDateTime', 'java.util.Calendar'},
            'system_ops': {'Runtime.getRuntime().exec', 'ProcessBuilder', 'System.exit'},
            'obfuscation': [r'Class\.forName', r'Method\.invoke', r'Reflection'],
            'file_ops': {'File.delete', 'Files.delete', 'FileUtils.deleteDirectory'},
            'network': {'Socket', 'ServerSocket', 'HttpURLConnection'},
            'crypto': {'MessageDigest', 'Cipher', 'KeyGenerator'}
        }
        
        # JavaScript/TypeScript patterns
        self.javascript_patterns = {
            'time_funcs': {'Date.now', 'new Date', 'setTimeout', 'setInterval'},
            'system_ops': {'child_process.exec', 'fs.unlink', 'fs.rmdir', 'process.exit'},
            'obfuscation': [r'eval\s*\(', r'Function\s*\(', r'new Function'],
            'dom_manipulation': {'document.write', 'innerHTML', 'eval'},
            'network': {'fetch', 'XMLHttpRequest', 'WebSocket'},
            'storage': {'localStorage', 'sessionStorage', 'indexedDB'},
            'crypto': {'crypto.subtle', 'btoa', 'atob'}
        }
        
        # C#/.NET patterns
        self.csharp_patterns = {
            'time_types': {'DateTime', 'DateTimeOffset', 'TimeSpan'},
            'system_ops': {'Process.Start', 'File.Delete', 'Directory.Delete'},
            'obfuscation': [r'Assembly\.Load', r'Type\.GetType', r'Activator\.CreateInstance'],
            'file_ops': {'File.Delete', 'Directory.Delete', 'FileInfo.Delete'},
            'network': {'HttpClient', 'WebRequest', 'TcpClient'},
            'crypto': {'AesCryptoServiceProvider', 'RSACryptoServiceProvider'},
            'registry': {'Registry.SetValue', 'RegistryKey.SetValue'}
        }
        
        # Financial/payment patterns (language-agnostic)
        self.financial_patterns = [
            r'payment|transfer|transaction|amount|balance|account',
            r'bitcoin|ethereum|crypto|wallet|mining',
            r'paypal\.me|stripe|square|venmo',
            r'credit_card|debit|invoice|billing'
        ]
        
        # Common malware indicators (all languages)
        self.malware_indicators = {
            'backdoors': [r'shell|cmd|powershell|bash|reverse'],
            'exfiltration': [r'base64|encode|decode|compress'],
            'persistence': [r'startup|autorun|registry|cron'],
            'evasion': [r'debugger|vm|sandbox|analysis'],
            'crypto_mining': [r'mining|miner|hashrate|cryptocurrency'],
            'ransomware': [r'encrypt.*files|ransom|decrypt.*key'],
            'keylogger': [r'keylog|password.*steal|credential.*harvest']
        }

    def detect_language(self, filepath: str, content: str) -> str:
        """Detect programming language from file extension and content."""
        
        # Check file extension first
        _, ext = os.path.splitext(filepath.lower())
        if ext in self.supported_languages:
            detected = self.supported_languages[ext]
            
            # Special cases for JavaScript variants
            if ext in ['.js', '.jsx'] and 'angular' in content.lower():
                return 'angular'
            elif ext in ['.ts', '.tsx'] and 'angular' in content.lower():
                return 'angular_typescript'
            elif ext == '.json' and ('package.json' in filepath or 'dependencies' in content):
                return 'npm_config'
                
            return detected
        
        # Content-based detection fallback
        if 'public class' in content and 'static void main' in content:
            return 'java'
        elif 'using System' in content or 'namespace' in content:
            return 'csharp'
        elif 'function' in content and ('var ' in content or 'let ' in content):
            return 'javascript'
        elif 'interface' in content and ': ' in content and 'export' in content:
            return 'typescript'
        elif '@Component' in content or '@Injectable' in content:
            return 'angular'
        elif '<?php' in content:
            return 'php'
        elif 'def ' in content and 'import ' in content:
            return 'python'
        
        return 'unknown'

    def analyze_file(self, filepath: str) -> List[SuspiciousPattern]:
        """Analyze a file for malicious patterns based on its language."""
        
        print(f"\n=== ANALYZING FILE: {filepath} ===")
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            if not content.strip():
                print("WARNING: File is empty!")
                return []
            
            # Detect language
            language = self.detect_language(filepath, content)
            print(f"Detected language: {language}")
            
            # Reset patterns for new file
            self.suspicious_patterns = []
            
            # Analyze based on detected language
            if language == 'python':
                self._analyze_python(content)
            elif language == 'java':
                self._analyze_java(content)
            elif language in ['javascript', 'react']:
                self._analyze_javascript(content)
            elif language in ['typescript', 'react_typescript']:
                self._analyze_typescript(content)
            elif language in ['csharp', 'vbnet']:
                self._analyze_csharp(content)
            elif language in ['angular', 'angular_typescript']:
                self._analyze_angular(content)
            elif language == 'npm_config':
                self._analyze_npm_config(content)
            elif language == 'php':
                self._analyze_php(content)
            elif language == 'html':
                self._analyze_html(content)
            else:
                # Generic analysis for unknown languages
                self._analyze_generic(content, language)
            
            # Common cross-language checks
            self._check_financial_fraud_universal(content, language)
            self._check_malware_indicators_universal(content, language)
            self._check_time_bombs_universal(content, language)
            self._check_obfuscation_universal(content, language)
            
            print(f"\n📊 Total patterns found: {len(self.suspicious_patterns)}")
            return self.suspicious_patterns
            
        except Exception as e:
            print(f"❌ Error analyzing {filepath}: {str(e)}")
            return []

    def _analyze_python(self, content: str):
        """Analyze Python code for malicious patterns."""
        print("🐍 Analyzing Python code...")
        
        try:
            tree = ast.parse(content)
            lines = content.split('\n')
            
            # Python-specific checks
            self._check_python_time_bombs(tree, content)
            self._check_python_obfuscation(content)
            self._check_python_system_ops(content)
            self._check_python_imports(tree)
            self._check_python_financial_fraud(content)
            
        except SyntaxError as e:
            print(f"Python syntax error: {e}")
            # Fall back to regex-based analysis
            self._analyze_python_regex(content)

    def _analyze_java(self, content: str):
        """Analyze Java code for malicious patterns."""
        print("☕ Analyzing Java code...")
        
        lines = content.split('\n')
        
        # Java time-based logic bombs
        java_time_patterns = [
            (r'new\s+Date\s*\(\s*\)', "Date object creation"),
            (r'System\.currentTimeMillis\s*\(\)', "Current time access"),
            (r'Calendar\.getInstance\s*\(\)', "Calendar instance"),
            (r'LocalDateTime\.now\s*\(\)', "LocalDateTime access"),
            (r'if\s*\(.*Date.*\.after\(', "Date comparison"),
            (r'if\s*\(.*\.compareTo\(.*Date', "Date comparison"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in java_time_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JAVA_TIME_BASED_CONDITION",
                            description=f"Java {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language="java"
                        )
                    )
        
        # Java system operations
        java_system_patterns = [
            (r'Runtime\.getRuntime\(\)\.exec\(', "Runtime command execution"),
            (r'ProcessBuilder\s*\(', "Process builder usage"),
            (r'System\.exit\s*\(', "System exit call"),
            (r'File\s*\(.*\)\.delete\s*\(\)', "File deletion"),
            (r'Files\.delete\(', "NIO file deletion"),
            (r'FileUtils\.deleteDirectory\(', "Directory deletion"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in java_system_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JAVA_DESTRUCTIVE_OPERATION",
                            description=f"Java {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="java"
                        )
                    )

    def _analyze_javascript(self, content: str):
        """Analyze JavaScript code for malicious patterns."""
        print("🟨 Analyzing JavaScript code...")
        
        lines = content.split('\n')
        
        # JavaScript time-based patterns
        js_time_patterns = [
            (r'new\s+Date\s*\(\s*\)', "Date object creation"),
            (r'Date\.now\s*\(\)', "Current timestamp"),
            (r'setTimeout\s*\(', "Delayed execution"),
            (r'setInterval\s*\(', "Repeated execution"),
            (r'if\s*\(.*Date.*>\s*new\s+Date', "Date comparison"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in js_time_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JS_TIME_BASED_CONDITION",
                            description=f"JavaScript {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language="javascript"
                        )
                    )
        
        # JavaScript obfuscation and dangerous functions
        js_obfuscation_patterns = [
            (r'eval\s*\(', "Code evaluation"),
            (r'Function\s*\(.*\)', "Dynamic function creation"),
            (r'new\s+Function\s*\(', "Constructor function"),
            (r'document\.write\s*\(', "DOM manipulation"),
            (r'innerHTML\s*=', "HTML injection"),
            (r'outerHTML\s*=', "HTML replacement"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in js_obfuscation_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="JS_OBFUSCATION",
                            description=f"JavaScript {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="javascript"
                        )
                    )
        
        # Node.js specific patterns
        nodejs_patterns = [
            (r'require\s*\(\s*["\']child_process["\']\s*\)', "Child process access"),
            (r'require\s*\(\s*["\']fs["\']\s*\)', "File system access"),
            (r'fs\.unlink\s*\(', "File deletion"),
            (r'fs\.rmdir\s*\(', "Directory deletion"),
            (r'process\.exit\s*\(', "Process termination"),
            (r'child_process\.exec\s*\(', "Command execution"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in nodejs_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="NODEJS_SYSTEM_OPERATION",
                            description=f"Node.js {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.9,
                            language="javascript"
                        )
                    )

    def _analyze_typescript(self, content: str):
        """Analyze TypeScript code for malicious patterns."""
        print("🔷 Analyzing TypeScript code...")
        
        # TypeScript includes all JavaScript patterns plus type-specific ones
        self._analyze_javascript(content)
        
        lines = content.split('\n')
        
        # TypeScript-specific patterns
        ts_patterns = [
            (r'any\s*=.*eval', "Type-unsafe eval usage"),
            (r'<any>.*Function', "Type casting to bypass security"),
            (r'declare\s+var\s+require', "Ambient require declaration"),
            (r'import\s*\*\s*as.*=.*require', "Dynamic require import"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in ts_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="TYPESCRIPT_SECURITY_RISK",
                            description=f"TypeScript {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="typescript"
                        )
                    )

    def _analyze_csharp(self, content: str):
        """Analyze C#/.NET code for malicious patterns."""
        print("🔵 Analyzing C#/.NET code...")
        
        lines = content.split('\n')
        
        # C# time-based patterns
        csharp_time_patterns = [
            (r'DateTime\.Now', "Current date/time access"),
            (r'DateTime\.Today', "Current date access"),
            (r'DateTimeOffset\.Now', "Current offset time"),
            (r'if\s*\(.*DateTime.*>\s*new\s+DateTime', "Date comparison"),
            (r'Environment\.TickCount', "System uptime access"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in csharp_time_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CSHARP_TIME_BASED_CONDITION",
                            description=f"C# {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language="csharp"
                        )
                    )
        
        # C# system operations
        csharp_system_patterns = [
            (r'Process\.Start\s*\(', "Process execution"),
            (r'File\.Delete\s*\(', "File deletion"),
            (r'Directory\.Delete\s*\(', "Directory deletion"),
            (r'Environment\.Exit\s*\(', "Application termination"),
            (r'Registry\.SetValue\s*\(', "Registry modification"),
            (r'RegistryKey\.SetValue\s*\(', "Registry key modification"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in csharp_system_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="CSHARP_DESTRUCTIVE_OPERATION",
                            description=f"C# {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="csharp"
                        )
                    )

    def _analyze_angular(self, content: str):
        """Analyze Angular code for malicious patterns."""
        print("🅰️ Analyzing Angular code...")
        
        # First analyze as TypeScript/JavaScript
        if '.ts' in content or 'export' in content:
            self._analyze_typescript(content)
        else:
            self._analyze_javascript(content)
        
        lines = content.split('\n')
        
        # Angular-specific security risks
        angular_patterns = [
            (r'innerHTML\s*=.*\+', "Dynamic HTML injection"),
            (r'bypassSecurityTrust', "Security bypass"),
            (r'dangerouslySetInnerHTML', "Dangerous HTML setting"),
            (r'eval\s*\(.*params', "Parameter evaluation"),
            (r'new\s+Function\s*\(.*req', "Dynamic function from request"),
            (r'document\.write\s*\(.*input', "Input-based document write"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in angular_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="ANGULAR_SECURITY_RISK",
                            description=f"Angular {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="angular"
                        )
                    )

    def _analyze_php(self, content: str):
        """Analyze PHP code for malicious patterns."""
        print("🐘 Analyzing PHP code...")
        
        lines = content.split('\n')
        
        # PHP-specific malicious patterns
        php_patterns = [
            (r'eval\s*\(', "Code evaluation"),
            (r'exec\s*\(', "Command execution"),
            (r'system\s*\(', "System command"),
            (r'shell_exec\s*\(', "Shell execution"),
            (r'passthru\s*\(', "Pass through execution"),
            (r'file_get_contents\s*\(.*http', "Remote file inclusion"),
            (r'include\s*\(.*\$', "Dynamic include"),
            (r'require\s*\(.*\$', "Dynamic require"),
            (r'\$_GET\[.*\]\s*\)', "GET parameter usage"),
            (r'\$_POST\[.*\]\s*\)', "POST parameter usage"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in php_patterns:
                if re.search(pattern, line):
                    severity = "HIGH" if any(x in desc.lower() for x in ['execution', 'eval', 'system']) else "MEDIUM"
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PHP_SECURITY_RISK",
                            description=f"PHP {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="php"
                        )
                    )

    def _analyze_html(self, content: str):
        """Analyze HTML code for malicious patterns."""
        print("🌐 Analyzing HTML code...")
        
        lines = content.split('\n')
        
        # HTML-specific malicious patterns
        html_patterns = [
            (r'<script.*src.*http', "External script inclusion"),
            (r'javascript:.*eval', "JavaScript eval in HTML"),
            (r'onclick.*eval', "Eval in event handler"),
            (r'onerror.*location', "Error handler redirect"),
            (r'<iframe.*src.*javascript', "JavaScript iframe"),
            (r'document\.write.*\+', "Dynamic document write"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in html_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="HTML_SECURITY_RISK",
                            description=f"HTML {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="html"
                        )
                    )

    def _analyze_npm_config(self, content: str):
        """Analyze npm package.json and config files."""
        print("📦 Analyzing npm configuration...")
        
        try:
            config = json.loads(content)
            
            # Check for suspicious dependencies
            suspicious_deps = [
                'remote-exec', 'node-shell', 'exec-async', 'malicious-package',
                'bitcoin-miner', 'crypto-miner', 'backdoor-js'
            ]
            
            deps_to_check = {}
            if 'dependencies' in config:
                deps_to_check.update(config['dependencies'])
            if 'devDependencies' in config:
                deps_to_check.update(config['devDependencies'])
            
            for dep_name, version in deps_to_check.items():
                if any(sus in dep_name.lower() for sus in suspicious_deps):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="NPM_SUSPICIOUS_DEPENDENCY",
                            description=f"Suspicious npm dependency: {dep_name}",
                            severity="HIGH",
                            line_number=1,
                            code_snippet=f'"{dep_name}": "{version}"',
                            confidence=0.8,
                            language="npm_config"
                        )
                    )
            
            # Check for suspicious scripts
            if 'scripts' in config:
                for script_name, script_cmd in config['scripts'].items():
                    if any(cmd in script_cmd.lower() for cmd in ['rm -rf', 'del /s', 'curl', 'wget']):
                        self.suspicious_patterns.append(
                            SuspiciousPattern(
                                pattern_type="NPM_SUSPICIOUS_SCRIPT",
                                description=f"Suspicious npm script: {script_name}",
                                severity="MEDIUM",
                                line_number=1,
                                code_snippet=f'"{script_name}": "{script_cmd}"',
                                confidence=0.7,
                                language="npm_config"
                            )
                        )
                        
        except json.JSONDecodeError:
            # Fallback to text analysis
            lines = content.split('\n')
            for i, line in enumerate(lines, 1):
                if 'postinstall' in line and ('curl' in line or 'wget' in line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="NPM_POSTINSTALL_DOWNLOAD",
                            description="Postinstall script downloads content",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.9,
                            language="npm_config"
                        )
                    )

    def _analyze_generic(self, content: str, language: str):
        """Generic analysis for unknown file types."""
        print(f"🔍 Analyzing generic {language} code...")
        
        lines = content.split('\n')
        
        # Generic suspicious patterns
        generic_patterns = [
            (r'eval\s*\(', "Code evaluation"),
            (r'exec\s*\(', "Code execution"),
            (r'system\s*\(', "System command"),
            (r'shell\s*\(', "Shell execution"),
            (r'delete.*file', "File deletion"),
            (r'remove.*directory', "Directory removal"),
            (r'password|secret|key', "Sensitive data reference"),
            (r'bitcoin|crypto|mining', "Cryptocurrency reference"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in generic_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    severity = "HIGH" if any(x in desc.lower() for x in ['execution', 'deletion']) else "MEDIUM"
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="GENERIC_SUSPICIOUS_PATTERN",
                            description=f"Generic {desc}",
                            severity=severity,
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.5,
                            language=language
                        )
                    )

    # Python-specific methods
    def _check_python_time_bombs(self, tree, content):
        """Python-specific time bomb detection."""
        lines = content.split('\n')
        
        class TimeConditionVisitor(ast.NodeVisitor):
            def __init__(self, detector):
                self.detector = detector
                
            def visit_If(self, node):
                try:
                    if hasattr(ast, 'unparse'):
                        condition_code = ast.unparse(node.test)
                    else:
                        condition_code = ast.dump(node.test)
                    
                    time_patterns = [
                        r'datetime\.',
                        r'time\.',
                        r'date\.',
                        r'now\(\)',
                        r'today\(\)',
                    ]
                    
                    for pattern in time_patterns:
                        if re.search(pattern, condition_code):
                            line_num = node.lineno
                            snippet = lines[line_num - 1] if line_num <= len(lines) else condition_code
                            
                            self.detector.suspicious_patterns.append(
                                SuspiciousPattern(
                                    pattern_type="PYTHON_TIME_BASED_CONDITION",
                                    description="Python time-based conditional statement",
                                    severity="MEDIUM",
                                    line_number=line_num,
                                    code_snippet=snippet.strip(),
                                    confidence=0.6,
                                    language="python"
                                )
                            )
                            break
                except Exception:
                    pass
                
                self.generic_visit(node)
        
        visitor = TimeConditionVisitor(self)
        visitor.visit(tree)

    def _check_python_obfuscation(self, content):
        """Python obfuscation detection."""
        lines = content.split('\n')
        
        obfuscation_patterns = [
            (r'exec\s*\(', "exec() function usage"),
            (r'eval\s*\(', "eval() function usage"),
            (r'__import__\s*\(', "Dynamic import"),
            (r'base64\.decode', "Base64 decoding"),
            (r'codecs\.decode', "Codec decoding"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in obfuscation_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PYTHON_OBFUSCATION",
                            description=f"Python {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language="python"
                        )
                    )

    def _check_python_system_ops(self, content):
        """Python system operations detection."""
        lines = content.split('\n')
        
        system_patterns = [
            (r'os\.system\s*\(', "OS system command"),
            (r'subprocess\.call\s*\(', "Subprocess call"),
            (r'subprocess\.run\s*\(', "Subprocess run"),
            (r'shutil\.rmtree\s*\(', "Directory removal"),
            (r'os\.remove\s*\(', "File removal"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in system_patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PYTHON_SYSTEM_OPERATION",
                            description=f"Python {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )

    def _check_python_imports(self, tree):
        """Python import analysis."""
        imports = set()
        
        class ImportVisitor(ast.NodeVisitor):
            def visit_Import(self, node):
                for alias in node.names:
                    imports.add(alias.name)
            
            def visit_ImportFrom(self, node):
                if node.module:
                    imports.add(node.module)
        
        visitor = ImportVisitor()
        visitor.visit(tree)
        
        # Check for suspicious import combinations
        time_imports = {'datetime', 'time', 'calendar'}
        system_imports = {'os', 'subprocess', 'shutil'}
        
        has_time = any(imp in imports for imp in time_imports)
        has_system = any(imp in imports for imp in system_imports)
        
        if has_time and has_system:
            self.suspicious_patterns.append(
                SuspiciousPattern(
                    pattern_type="PYTHON_SUSPICIOUS_IMPORT_COMBINATION",
                    description="Suspicious combination of time and system imports",
                    severity="MEDIUM",
                    line_number=1,
                    code_snippet=f"Imports: {', '.join(sorted(imports))}",
                    confidence=0.5,
                    language="python"
                )
            )

    def _check_python_financial_fraud(self, content):
        """Python financial fraud detection."""
        lines = content.split('\n')
        
        fraud_patterns = [
            (r'amount\s*[-+*/]\s*0\.\d+', "Amount manipulation"),
            (r'payment.*redirect', "Payment redirection"),
            (r'developer.*account', "Developer account reference"),
            (r'skim|siphon.*amount', "Amount skimming"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in fraud_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PYTHON_FINANCIAL_FRAUD",
                            description=f"Python {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language="python"
                        )
                    )

    def _analyze_python_regex(self, content):
        """Fallback regex-based Python analysis."""
        lines = content.split('\n')
        
        patterns = [
            (r'if.*datetime.*>', "Time-based condition"),
            (r'exec\s*\(', "Code execution"),
            (r'eval\s*\(', "Code evaluation"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in patterns:
                if re.search(pattern, line):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="PYTHON_REGEX_DETECTION",
                            description=f"Python {desc} (regex)",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language="python"
                        )
                    )

    # Universal cross-language checks
    def _check_financial_fraud_universal(self, content: str, language: str):
        """Check for financial fraud patterns across all languages."""
        print("💰 Checking universal financial fraud patterns...")
        
        lines = content.split('\n')
        
        # Universal financial fraud patterns
        fraud_patterns = [
            (r'amount\s*[-+*/]\s*0\.\d+', "Amount manipulation"),
            (r'payment.*redirect.*developer', "Payment redirection"),
            (r'bitcoin.*address.*[13][a-km-zA-HJ-NP-Z1-9]{25,34}', "Bitcoin address"),
            (r'ethereum.*address.*0x[a-fA-F0-9]{40}', "Ethereum address"),
            (r'paypal\.me/[a-zA-Z0-9]+', "PayPal.me link"),
            (r'fee\s*=\s*amount\s*\*\s*0\.\d+', "Percentage fee calculation"),
            (r'skim|siphon|divert.*amount', "Amount skimming"),
            (r'personal.*account.*transfer', "Personal account transfer"),
            (r'developer.*wallet|admin.*wallet', "Developer/admin wallet"),
            (r'hidden.*transaction|secret.*payment', "Hidden financial operation"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in fraud_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="UNIVERSAL_FINANCIAL_FRAUD",
                            description=f"Universal {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language=language
                        )
                    )

    def _check_malware_indicators_universal(self, content: str, language: str):
        """Check for universal malware indicators across all languages."""
        print("🦠 Checking universal malware indicators...")
        
        lines = content.split('\n')
        
        # Universal malware patterns
        malware_patterns = [
            (r'backdoor|reverse.*shell|bind.*shell', "Backdoor indicators"),
            (r'keylog|password.*steal|credential.*harvest', "Credential theft"),
            (r'encrypt.*files|ransom|decrypt.*key', "Ransomware indicators"),
            (r'mining|miner|hashrate|cryptocurrency', "Crypto mining"),
            (r'botnet|c2|command.*control', "Botnet communication"),
            (r'rootkit|stealth|hide.*process', "Stealth techniques"),
            (r'exploit|vulnerability|buffer.*overflow', "Exploitation"),
            (r'persistence|autostart|registry.*run', "Persistence mechanisms"),
            (r'data.*exfiltration|steal.*data', "Data theft"),
            (r'privilege.*escalation|admin.*rights', "Privilege escalation"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in malware_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="UNIVERSAL_MALWARE_INDICATOR",
                            description=f"Universal {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.7,
                            language=language
                        )
                    )

    def _check_time_bombs_universal(self, content: str, language: str):
        """Check for time-based logic bombs across all languages."""
        print("⏰ Checking universal time bomb patterns...")
        
        lines = content.split('\n')
        
        # Universal time bomb patterns
        time_patterns = [
            (r'if.*date.*>.*\d{4}', "Date comparison condition"),
            (r'if.*time.*>.*\d{10}', "Timestamp comparison"),
            (r'trigger.*date|activation.*date', "Trigger date reference"),
            (r'delay.*until|wait.*until.*date', "Delayed execution"),
            (r'schedule.*destroy|timed.*delete', "Scheduled destruction"),
            (r'countdown|timer.*expire', "Countdown mechanism"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in time_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="UNIVERSAL_TIME_BOMB",
                            description=f"Universal {desc}",
                            severity="HIGH",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.8,
                            language=language
                        )
                    )

    def _check_obfuscation_universal(self, content: str, language: str):
        """Check for code obfuscation across all languages."""
        print("🔒 Checking universal obfuscation patterns...")
        
        lines = content.split('\n')
        
        # Universal obfuscation patterns
        obfuscation_patterns = [
            (r'base64|b64encode|b64decode', "Base64 encoding/decoding"),
            (r'encrypt|decrypt|cipher', "Encryption/decryption"),
            (r'encode|decode|compress', "Data encoding"),
            (r'dynamic.*load|reflection', "Dynamic code loading"),
            (r'string.*replace.*obfuscat', "String obfuscation"),
            (r'hex.*decode|hex.*encode', "Hexadecimal encoding"),
        ]
        
        for i, line in enumerate(lines, 1):
            for pattern, desc in obfuscation_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    self.suspicious_patterns.append(
                        SuspiciousPattern(
                            pattern_type="UNIVERSAL_OBFUSCATION",
                            description=f"Universal {desc}",
                            severity="MEDIUM",
                            line_number=i,
                            code_snippet=line.strip(),
                            confidence=0.6,
                            language=language
                        )
                    )


# Flask API Setup
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = tempfile.gettempdir()
# Updated to support multiple languages
ALLOWED_EXTENSIONS = {
    'py', 'java', 'js', 'ts', 'jsx', 'tsx', 'cs', 'vb', 'json', 
    'txt', 'html', 'php', 'rb', 'go', 'cpp', 'c', 'zip'
}
MAX_FILE_SIZE = 16 * 1024 * 1024

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

def secure_filename(filename):
    """Create a secure filename."""
    filename = os.path.basename(filename)
    safe_chars = string.ascii_letters + string.digits + '.-_'
    secure_name = ''.join(c if c in safe_chars else '_' for c in filename)
    secure_name = re.sub(r'_+', '_', secure_name)
    secure_name = secure_name.strip('._')
    
    if not secure_name or secure_name in ('.', '..'):
        secure_name = 'unnamed_file'
    
    if len(secure_name) > 100:
        name, ext = os.path.splitext(secure_name)
        secure_name = name[:95] + ext
    
    return secure_name

def allowed_file(filename):
    """Check if file extension is allowed."""
    if '.' not in filename:
        return True  # Allow files without extensions
    ext = filename.rsplit('.', 1)[1].lower()
    return ext in ALLOWED_EXTENSIONS

def pattern_to_dict(pattern: SuspiciousPattern) -> Dict[str, Any]:
    """Convert SuspiciousPattern to dictionary."""
    return {
        'pattern_type': pattern.pattern_type,
        'description': pattern.description,
        'severity': pattern.severity,
        'line_number': pattern.line_number,
        'code_snippet': pattern.code_snippet,
        'confidence': pattern.confidence,
        'language': pattern.language
    }

def get_risk_level(patterns: List[SuspiciousPattern]) -> str:
    """Determine risk level based on patterns."""
    if not patterns:
        return "LOW"
    
    high_severity = any(p.severity == "HIGH" for p in patterns)
    medium_severity = any(p.severity == "MEDIUM" for p in patterns)
    
    if high_severity:
        return "HIGH"
    elif medium_severity:
        return "MEDIUM"
    else:
        return "LOW"

def analyze_file_safe(detector: MultiLanguageDetector, filepath: str) -> tuple[List[SuspiciousPattern], Optional[str]]:
    """Safely analyze a file and return patterns and any error."""
    try:
        patterns = detector.analyze_file(filepath)
        return patterns, None
    except Exception as e:
        error_msg = f"Error analyzing {os.path.basename(filepath)}: {str(e)}"
        print(error_msg)
        print(f"Exception details: {traceback.format_exc()}")
        return [], error_msg

def extract_zip_file(zip_path: str, extract_dir: str) -> List[str]:
    """Extract ZIP file and return list of extracted files."""
    extracted_files = []
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Get list of files in ZIP
            file_list = zip_ref.namelist()
            
            # Filter for allowed file types
            allowed_files = []
            for file_path in file_list:
                if not file_path.endswith('/'):  # Skip directories
                    filename = os.path.basename(file_path)
                    if allowed_file(filename):
                        allowed_files.append(file_path)
            
            # Extract allowed files
            for file_path in allowed_files[:50]:  # Limit to 50 files
                try:
                    zip_ref.extract(file_path, extract_dir)
                    extracted_files.append(os.path.join(extract_dir, file_path))
                except Exception as e:
                    print(f"Error extracting {file_path}: {e}")
                    
    except zipfile.BadZipFile:
        print("Invalid ZIP file")
    except Exception as e:
        print(f"Error processing ZIP file: {e}")
    
    return extracted_files

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '3.0.0 - Integrated Multi-Language Support',
        'supported_languages': [
            'Python', 'Java', 'JavaScript', 'TypeScript', 'C#', 'VB.NET',
            'Angular', 'Node.js', 'PHP', 'HTML', 'JSON', 'Generic'
        ]
    })

@app.route('/api/analyze', methods=['POST'])
def analyze_files():
    """Analyze uploaded files for malicious patterns."""
    print("\n" + "="*80)
    print("NEW MULTI-LANGUAGE FILE ANALYSIS REQUEST")
    print("="*80)
    
    try:
        # Handle file uploads
        files = []
        if 'files' in request.files:
            files = request.files.getlist('files')
        
        if not files:
            for key in request.files.keys():
                files.extend(request.files.getlist(key))
        
        if not files:
            return jsonify({
                'error': 'No files provided',
                'supported_extensions': list(ALLOWED_EXTENSIONS)
            }), 400
        
        valid_files = [f for f in files if f and f.filename and f.filename != '']
        
        if not valid_files:
            return jsonify({'error': 'No valid files selected'}), 400
        
        detector = MultiLanguageDetector()
        results = []
        temp_dirs = []
        
        try:
            for file in valid_files:
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    original_filename = file.filename
                    
                    print(f"\n📁 Processing file: {original_filename}")
                    
                    # Create temporary directory
                    temp_dir = tempfile.mkdtemp()
                    temp_dirs.append(temp_dir)
                    
                    # Save file
                    file_path = os.path.join(temp_dir, filename)
                    file.save(file_path)
                    
                    if not os.path.exists(file_path):
                        continue
                    
                    files_to_analyze = []
                    
                    # Handle ZIP files
                    if filename.lower().endswith('.zip'):
                        print(f"📦 Extracting ZIP file: {filename}")
                        extracted_files = extract_zip_file(file_path, temp_dir)
                        files_to_analyze.extend(extracted_files)
                        if not extracted_files:
                            results.append({
                                'filename': original_filename,
                                'language': 'archive',
                                'risk_level': 'ERROR',
                                'total_patterns': 0,
                                'patterns': [],
                                'scan_date': datetime.now().isoformat(),
                                'error': 'No valid files found in ZIP archive'
                            })
                            continue
                    else:
                        files_to_analyze.append(file_path)
                    
                    # Analyze each file
                    all_patterns = []
                    detected_languages = set()
                    
                    for analyze_path in files_to_analyze:
                        patterns, error = analyze_file_safe(detector, analyze_path)
                        all_patterns.extend(patterns)
                        
                        # Get detected language
                        try:
                            with open(analyze_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                            language = detector.detect_language(analyze_path, content)
                            detected_languages.add(language)
                        except Exception:
                            detected_languages.add('unknown')
                    
                    # Combine results
                    primary_language = list(detected_languages)[0] if detected_languages else 'unknown'
                    if len(detected_languages) > 1:
                        primary_language = f"mixed ({', '.join(detected_languages)})"
                    
                    result = {
                        'filename': original_filename,
                        'language': primary_language,
                        'risk_level': get_risk_level(all_patterns),
                        'total_patterns': len(all_patterns),
                        'patterns': [pattern_to_dict(p) for p in all_patterns],
                        'scan_date': datetime.now().isoformat(),
                        'files_analyzed': len(files_to_analyze),
                        'error': None
                    }
                    
                    print(f"📊 Analysis complete for {original_filename}:")
                    print(f"   Language: {primary_language}")
                    print(f"   Risk Level: {result['risk_level']}")
                    print(f"   Patterns Found: {result['total_patterns']}")
                    print(f"   Files Analyzed: {result['files_analyzed']}")
                    
                    results.append(result)
                
                else:
                    results.append({
                        'filename': file.filename,
                        'language': 'unknown',
                        'risk_level': 'ERROR',
                        'total_patterns': 0,
                        'patterns': [],
                        'scan_date': datetime.now().isoformat(),
                        'error': f'Unsupported file type. Supported: {", ".join(sorted(ALLOWED_EXTENSIONS))}'
                    })
        
        finally:
            # Cleanup
            for temp_dir in temp_dirs:
                try:
                    import shutil
                    shutil.rmtree(temp_dir)
                    print(f"🧹 Cleaned up temp directory: {temp_dir}")
                except Exception as e:
                    print(f"Cleanup error: {e}")
        
        return jsonify(results)
    
    except Exception as e:
        print(f"Analysis error: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

@app.route('/api/analyze/text', methods=['POST'])
def analyze_text():
    """Analyze code text for malicious patterns."""
    print("\n" + "="*80)
    print("NEW MULTI-LANGUAGE TEXT ANALYSIS REQUEST")
    print("="*80)
    
    try:
        data = request.get_json()
        
        if not data or 'code' not in data:
            return jsonify({'error': 'No code provided'}), 400
        
        code = data['code']
        filename = data.get('filename', 'code.txt')
        
        print(f"📝 Analyzing code for: {filename}")
        
        # Create temporary file
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, filename)
        
        try:
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(code)
            
            # Analyze
            detector = MultiLanguageDetector()
            patterns, error = analyze_file_safe(detector, temp_file)
            language = detector.detect_language(filename, code)
            
            result = {
                'filename': filename,
                'language': language,
                'risk_level': get_risk_level(patterns),
                'total_patterns': len(patterns),
                'patterns': [pattern_to_dict(p) for p in patterns],
                'scan_date': datetime.now().isoformat(),
                'code_length': len(code),
                'error': error
            }
            
            print(f"📊 Text analysis complete:")
            print(f"   Language: {language}")
            print(f"   Risk Level: {result['risk_level']}")
            print(f"   Patterns Found: {result['total_patterns']}")
            
            return jsonify(result)
        
        finally:
            try:
                import shutil
                shutil.rmtree(temp_dir)
            except Exception:
                pass
    
    except Exception as e:
        print(f"Text analysis error: {str(e)}")
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

@app.route('/api/languages', methods=['GET'])
def get_supported_languages():
    """Get information about supported languages."""
    return jsonify({
        'supported_languages': {
            'python': {
                'extensions': ['.py'],
                'description': 'Python programming language',
                'patterns': ['Time bombs', 'System operations', 'Obfuscation', 'Financial fraud', 'Import analysis']
            },
            'java': {
                'extensions': ['.java'],
                'description': 'Java programming language',
                'patterns': ['Reflection abuse', 'System commands', 'Time conditions', 'File operations', 'Crypto operations']
            },
            'javascript': {
                'extensions': ['.js', '.jsx'],
                'description': 'JavaScript and React',
                'patterns': ['Code injection', 'DOM manipulation', 'Node.js operations', 'Browser security', 'Dynamic functions']
            },
            'typescript': {
                'extensions': ['.ts', '.tsx'],
                'description': 'TypeScript and React with TypeScript',
                'patterns': ['Type bypassing', 'Dynamic imports', 'JavaScript patterns', 'Type safety violations']
            },
            'csharp': {
                'extensions': ['.cs', '.vb'],
                'description': 'C# and VB.NET',
                'patterns': ['Reflection', 'Registry manipulation', 'Process execution', 'Assembly loading', 'Crypto operations']
            },
            'angular': {
                'extensions': ['.ts', '.js', '.html'],
                'description': 'Angular framework',
                'patterns': ['Security bypassing', 'HTTP security', 'Payment manipulation', 'Template injection', 'Dynamic HTML']
            },
            'php': {
                'extensions': ['.php'],
                'description': 'PHP server-side language',
                'patterns': ['Code injection', 'Remote file inclusion', 'Command execution', 'Parameter manipulation']
            },
            'html': {
                'extensions': ['.html', '.htm'],
                'description': 'HTML markup language',
                'patterns': ['Script injection', 'Event handler abuse', 'External resource loading', 'JavaScript execution']
            },
            'config': {
                'extensions': ['.json', '.config'],
                'description': 'Configuration files',
                'patterns': ['Suspicious dependencies', 'Malicious scripts', 'Security bypasses', 'Package manipulation']
            }
        },
        'detection_categories': [
            'Time-based logic bombs',
            'Financial fraud and payment manipulation',
            'Code obfuscation and injection',
            'System operations and file manipulation',
            'Network operations and data exfiltration',
            'Cryptographic operations',
            'Authentication and authorization bypass',
            'Cross-language malware indicators',
            'Backdoor and remote access',
            'Credential harvesting',
            'Privilege escalation',
            'Anti-analysis techniques'
        ],
        'severity_levels': {
            'HIGH': 'Immediate security risk - requires urgent attention',
            'MEDIUM': 'Potential security risk - review recommended',
            'LOW': 'Minor concern - monitor for patterns'
        }
    })

@app.route('/api/patterns', methods=['GET'])
def get_pattern_types():
    """Get information about different pattern types detected."""
    return jsonify({
        'pattern_types': {
            'time_based': {
                'description': 'Logic bombs triggered by date/time conditions',
                'examples': ['Hardcoded trigger dates', 'Time comparisons', 'Scheduled destruction'],
                'risk': 'HIGH'
            },
            'financial_fraud': {
                'description': 'Payment manipulation and financial fraud',
                'examples': ['Amount skimming', 'Payment redirection', 'Cryptocurrency addresses'],
                'risk': 'HIGH'
            },
            'system_operations': {
                'description': 'Dangerous system-level operations',
                'examples': ['File deletion', 'Process execution', 'Registry modification'],
                'risk': 'HIGH'
            },
            'obfuscation': {
                'description': 'Code hiding and obfuscation techniques',
                'examples': ['Dynamic code execution', 'Base64 encoding', 'Reflection'],
                'risk': 'MEDIUM'
            },
            'network_operations': {
                'description': 'Suspicious network activities',
                'examples': ['Data exfiltration', 'Remote connections', 'External downloads'],
                'risk': 'MEDIUM'
            },
            'malware_indicators': {
                'description': 'Common malware behavior patterns',
                'examples': ['Backdoors', 'Keyloggers', 'Crypto miners', 'Ransomware'],
                'risk': 'HIGH'
            }
        }
    })

@app.route('/api/stats', methods=['GET'])
def get_detection_stats():
    """Get statistics about the detection system."""
    return jsonify({
        'system_info': {
            'version': '3.0.0',
            'supported_languages': len(ALLOWED_EXTENSIONS),
            'max_file_size_mb': MAX_FILE_SIZE // (1024 * 1024),
            'detection_methods': ['AST Analysis', 'Regex Patterns', 'Behavioral Analysis', 'Cross-reference Checks']
        },
        'capabilities': {
            'file_upload': True,
            'text_analysis': True,
            'zip_extraction': True,
            'multi_language': True,
            'real_time_detection': True,
            'detailed_reporting': True
        },
        'supported_file_types': sorted(list(ALLOWED_EXTENSIONS))
    })

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    print("🚀 Starting Integrated Multi-Language Malware Detection API Server...")
    print(f"📁 Upload folder: {UPLOAD_FOLDER}")
    print(f"📏 Max file size: {MAX_FILE_SIZE / (1024*1024):.1f}MB")
    print("🌐 Supported Languages:")
    print("  • Python (.py)")
    print("  • Java (.java)")
    print("  • JavaScript/React (.js, .jsx)")
    print("  • TypeScript (.ts, .tsx)")
    print("  • C#/VB.NET (.cs, .vb)")
    print("  • Angular (TypeScript/JavaScript)")
    print("  • PHP (.php)")
    print("  • HTML (.html)")
    print("  • Configuration files (.json)")
    print("  • Archives (.zip)")
    print("\n🔗 API Endpoints:")
    print("  GET  /api/health - Health check and system info")
    print("  POST /api/analyze - Analyze uploaded files")
    print("  POST /api/analyze/text - Analyze code text")
    print("  GET  /api/languages - Get supported languages info")
    print("  GET  /api/patterns - Get pattern types info")
    print("  GET  /api/stats - Get detection statistics")
    print("\n🎯 Server running on http://localhost:5000")
    print("📊 Enhanced multi-language detection enabled")
    print("🔍 Advanced pattern matching across all supported languages")
    print("="*80)
    
    # Run the app
    app.run(host='127.0.0.1', port=5000, debug=True)