"""
Benign Python code for legitimate functionality
"""
import datetime
import json

def calculate_interest(principal, rate, time):
    """Calculate compound interest"""
    return principal * (1 + rate) ** time

def get_current_time():
    """Get current timestamp"""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def process_user_data(data):
    """Process user data safely"""
    cleaned_data = {
        'name': data.get('name', '').strip(),
        'email': data.get('email', '').lower(),
        'timestamp': get_current_time()
    }
    return cleaned_data

def main():
    print("Hello, World!")
    result = calculate_interest(1000, 0.05, 2)
    print(f"Interest calculation result: {result}")

if __name__ == "__main__":
    main()