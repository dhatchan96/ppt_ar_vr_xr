// Benign JavaScript for legitimate functionality

function calculateTotal(items) {
    return items.reduce((sum, item) => sum + item.price, 0);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function getCurrentDate() {
    return new Date().toLocaleDateString();
}

// Simple calculator
class Calculator {
    add(a, b) {
        return a + b;
    }
    
    subtract(a, b) {
        return a - b;
    }
    
    multiply(a, b) {
        return a * b;
    }
    
    divide(a, b) {
        if (b === 0) {
            throw new Error("Division by zero");
        }
        return a / b;
    }
}

// Event handling
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded successfully');
    const calc = new Calculator();
    console.log('2 + 3 =', calc.add(2, 3));
});