<?php
// Benign PHP code

class UserManager {
    private $db;
    
    public function __construct($database) {
        $this->db = $database;
    }
    
    public function createUser($name, $email) {
        $name = htmlspecialchars(trim($name));
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        
        $stmt = $this->db->prepare("INSERT INTO users (name, email) VALUES (?, ?)");
        return $stmt->execute([$name, $email]);
    }
    
    public function getUser($id) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}

function calculate_discount($price, $discount_percent) {
    if ($discount_percent < 0 || $discount_percent > 100) {
        return $price;
    }
    return $price * (1 - $discount_percent / 100);
}

echo "Welcome to our website!";
echo "Current time: " . date('Y-m-d H:i:s');
?>