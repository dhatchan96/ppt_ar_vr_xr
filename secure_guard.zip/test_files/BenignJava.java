import java.util.Date;
import java.util.Scanner;

public class BenignJava {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Welcome to the Calculator!");
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();
        
        double result = num1 + num2;
        System.out.println("Result: " + result);
        
        System.out.println("Current time: " + new Date());
        scanner.close();
    }
}
