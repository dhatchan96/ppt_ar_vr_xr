# Containerization Detection Testing Guide

## Test Files Created

I've created 3 comprehensive test files for you:

### 1. **containerization_test.cs** (C#/.NET)
- 🔴 **11 BLOCKER patterns**
- 🟡 **3 ENHANCEMENT patterns**
- Tests: Windows Forms, Registry, Services, File I/O, etc.

### 2. **containerization_test.java** (Java)
- 🔴 **7 BLOCKER patterns**
- 🟡 **4 ENHANCEMENT patterns**
- Tests: Swing/AWT, EJB, JBoss, File I/O, Process execution

### 3. **containerization_test.py** (Python)
- 🔴 **4 BLOCKER patterns**
- 🟡 **2 ENHANCEMENT patterns**
- Tests: Tkinter, subprocess, file operations, logging

---

## Expected Detection Results

### From C# File (`containerization_test.cs`):

| Pattern | Docker Class | Tool Detection | Solution |
|---------|-------------|----------------|----------|
| `File.Open`, `FileStream` | 🔴 BLOCKER | RMEngine Only | Persistent volumes & object storage |
| `Form`, `MessageBox`, `System.Windows.Forms` | 🔴 BLOCKER | SonarQube + RMEngine | Web-based UI modernization |
| `ServiceBase`, `ServiceController` | 🔴 BLOCKER | RMEngine Only | Container orchestration services |
| `Registry.LocalMachine`, `RegistryKey` | 🔴 BLOCKER | RMEngine Only | Configuration management modernization |
| `WindowsIdentity`, `WindowsPrincipal` | 🔴 BLOCKER | RMEngine Only | Identity and access management |
| `IsolatedStorageFile`, `ProtectedData` | 🔴 BLOCKER | Checkmarx + RMEngine | Kubernetes-native secrets management |
| `StreamWriter` to file path | 🔴 BLOCKER | RMEngine Only | Centralized logging infrastructure |
| `Process.Start`, `ProcessStartInfo` | 🔴 BLOCKER | SonarQube + RMEngine | Container orchestration |
| `MemoryCache`, `HttpRuntime.Cache` | 🔴 BLOCKER | RMEngine Only | Distributed caching solutions |
| `Integrated Security`, `Trusted_Connection` | 🔴 BLOCKER | RMEngine Only | Identity provider integration |
| `Console.WriteLine`, `Debug.WriteLine` | 🟡 ENHANCEMENT | SonarQube + Checkmarx + RMEngine | Structured logging and monitoring |
| `AppDomain.CreateDomain` | 🟡 ENHANCEMENT | RMEngine Only | Windows containers or Linux migration |

### From Java File (`containerization_test.java`):

| Pattern | Docker Class | Tool Detection | Solution |
|---------|-------------|----------------|----------|
| `FileInputStream`, `FileOutputStream` | 🔴 BLOCKER | RMEngine Only | Persistent volumes & object storage |
| `JFrame`, `JPanel`, `javax.swing` | 🔴 BLOCKER | RMEngine Only | Web-based UI modernization |
| `Runtime.getRuntime().exec()` | 🔴 BLOCKER | SonarQube + RMEngine | Container orchestration |
| `KeyStore.getInstance("JKS")` | 🔴 BLOCKER | Checkmarx + RMEngine | Kubernetes-native secrets management |
| `FileHandler` (logging to file) | 🔴 BLOCKER | RMEngine Only | Centralized logging infrastructure |
| `@Stateless`, `@Stateful`, `javax.ejb` | 🟡 ENHANCEMENT | RMEngine Only | Cloud-native application platforms |
| `System.out.println` | 🟡 ENHANCEMENT | SonarQube + Checkmarx + RMEngine | Structured logging and monitoring |
| `BufferedReader` with intensive loops | 🟡 ENHANCEMENT | RMEngine Only | Optimized container networking |

### From Python File (`containerization_test.py`):

| Pattern | Docker Class | Tool Detection | Solution |
|---------|-------------|----------------|----------|
| `open('/path/to/file')` | 🔴 BLOCKER | RMEngine Only | Persistent volumes & object storage |
| `subprocess.Popen`, `os.system` | 🔴 BLOCKER | SonarQube + RMEngine | Container orchestration |
| `logging.FileHandler` | 🔴 BLOCKER | RMEngine Only | Centralized logging infrastructure |
| `tkinter.Tk`, `messagebox` | 🔴 BLOCKER | RMEngine Only | Web-based UI modernization |
| `print()` statements | 🟡 ENHANCEMENT | SonarQube + Checkmarx + RMEngine | Structured logging and monitoring |

---

## How to Test

### Step 1: Restart Backend Server
```bash
# Make sure the updated code is running
cd D:\CodeKata\dashboard_api_enhanced
python dashboard_api_enhanced.py
```

### Step 2: Navigate to Code Magic Page
```
http://localhost:3000/threats
```

### Step 3: Upload Test Files

**Option A: Upload Single File**
1. Click "Upload Files" or drag & drop
2. Select one of the test files:
   - `containerization_test.cs`
   - `containerization_test.java`
   - `containerization_test.py`
3. Choose AIT/SPK/Repo tags
4. Click "Scan Files"

**Option B: Upload All Files**
1. Select all three test files at once
2. Upload and scan together
3. See results from multiple languages

### Step 4: Check Results

Look for these columns in the table:

#### **Docker Class Column:**
- Should show 🔴 **BLOCKER** (red badge) for serious issues
- Should show 🟡 **ENHANCEMENT** (yellow badge) for improvements
- Should show **-** or be empty for non-containerization issues

#### **Tool Detection Column:**
- Should show 🔵 **RMEngine Only** (blue badge) for unique detections
- Should show multiple badges like:
  - 🔵 **SonarQube** 🔵 **RMEngine Only**
  - 🟢 **Checkmarx** 🔵 **RMEngine Only**
  - 🔵 **SonarQube** 🟢 **Checkmarx** 🔵 **RMEngine Only**

### Step 5: View Details

1. Click on any issue to open the modal
2. Scroll to "Additional Details" section
3. Verify you see:
   - **Docker Class:** Badge with classification
   - **Detectable By:** List of tool badges
   - **Containerization Solution:** (appears if applicable)

---

## Expected Issue Counts

### C# File (containerization_test.cs)
- **Approximate:** 30-50 issues
- **BLOCKERS:** 20-35 issues
- **ENHANCEMENTS:** 5-10 issues
- **High concentration of:** File operations, Windows-specific APIs

### Java File (containerization_test.java)
- **Approximate:** 25-40 issues
- **BLOCKERS:** 15-25 issues
- **ENHANCEMENTS:** 5-10 issues
- **High concentration of:** File operations, Swing/AWT, Process execution

### Python File (containerization_test.py)
- **Approximate:** 20-35 issues
- **BLOCKERS:** 10-20 issues
- **ENHANCEMENTS:** 5-10 issues
- **High concentration of:** File operations, subprocess calls

---

## Filtering and Sorting

### Filter by Docker Classification:
1. Use the filter dropdowns at the top
2. Select "Type" → "CONTAINERIZATION_BLOCKER"
3. See only containerization-related issues

### Sort by Docker Class:
1. Click the "Docker Class" column header
2. Sorts by: BLOCKER → ENHANCEMENT → NONE
3. Helps prioritize critical issues first

### Filter by Tool Detection:
*Currently not filterable, but visible in table*

---

## Troubleshooting

### If columns are still empty:

1. **Check backend logs:**
   ```
   Look for: "Creating issue for rule ... docker=BLOCKER"
   ```

2. **Verify API response:**
   ```bash
   curl http://localhost:5000/api/threats | grep docker_classification
   ```

3. **Check browser console:**
   ```
   F12 → Console tab → Look for errors
   ```

4. **Try the nuclear option:**
   ```bash
   # Delete old data and regenerate
   cd threatguard_data
   del logic_bomb_rules.json threat_issues.json
   cd ..
   python dashboard_api_enhanced.py
   ```

### If detection seems incorrect:

1. **Check rule patterns** in `logic_bomb_rules.json`
2. **Review false positives** - test files are in test directories
3. **Adjust confidence thresholds** if needed

---

## Sample Screenshots (What You Should See)

### Table View:
```
Title                       | Docker Class | Tool Detection           | Status
----------------------------|--------------|--------------------------|-------------
File Operations Detected    | 🔴 BLOCKER   | 🔵 RMEngine Only         | ACTIVE_THREAT
Windows Forms UI Detected   | 🔴 BLOCKER   | 🔵 SonarQube 🔵 RMEngine | ACTIVE_THREAT
Console Logging Detected    | 🟡 ENHANCEMENT | 🔵 SQ 🟢 CM 🔵 RME     | ACTIVE_THREAT
Time-Based Logic Bomb       | -            | 🔵 RMEngine Only         | ACTIVE_THREAT
```

### Details Modal:
```
Additional Details
------------------
Docker Class: 🔴 BLOCKER

Detectable By: 🔵 RMEngine Only

📋 Containerization Solution
Use persistent volumes & object storage instead of local file system operations.
This allows your application to run in stateless containers.
```

---

## Next Steps After Testing

1. ✅ **Verify columns populate** with data
2. ✅ **Check tool detection badges** display correctly
3. ✅ **Test sorting and filtering** by Docker Class
4. ✅ **View details modal** shows containerization info
5. 📊 **Scan real code** from your projects
6. 📈 **Export to Excel** for reporting
7. 🎯 **Assign to waves** for remediation planning

---

## Questions?

If anything doesn't work as expected:
1. Check `QUICK_FIX.md` for common issues
2. Review backend console for errors
3. Verify file paths in test files match your OS (Windows vs Linux)

**Happy Testing!** 🚀

