"""
Containerization Test File - Python
This file contains various containerization blockers and enhancements
Scan this file to test Docker Class and Tool Detection columns
"""

import os
import subprocess
import logging
from logging.handlers import RotatingFileHandler
import tkinter as tk
from tkinter import messagebox

# ==================== FILE DEPENDENCY BLOCKERS ====================

def test_file_operations():
    """BLOCKER: File Operations - Should show 'Persistent volumes & object storage'"""
    
    # File reading
    with open('/data/config.ini', 'r') as f:
        config = f.read()
    
    # File writing
    with open('/logs/application.log', 'w') as f:
        f.write('Log entry\n')
    
    # File operations
    file = open('/tmp/temp.txt', 'w')
    file.write('Temporary data')
    file.close()
    
    # More file operations
    os.remove('/tmp/old_file.txt')
    os.rename('/tmp/source.txt', '/tmp/dest.txt')
    os.makedirs('/data/new_directory', exist_ok=True)
    
    # Path operations
    if os.path.exists('/config/settings.json'):
        with open('/config/settings.json', 'r') as config_file:
            settings = config_file.read()


# ==================== DESKTOP UI BLOCKER ====================

def test_desktop_ui():
    """BLOCKER: Desktop UI - Should show 'Web-based UI modernization'"""
    
    # Tkinter GUI
    root = tk.Tk()
    root.title("Desktop Application")
    
    label = tk.Label(root, text="This is a desktop application")
    label.pack()
    
    button = tk.Button(root, text="Click Me", command=lambda: print("Clicked"))
    button.pack()
    
    # Message box
    messagebox.showinfo("Info", "This is a desktop dialog")
    
    # Entry widget
    entry = tk.Entry(root)
    entry.pack()
    
    # Text widget
    text = tk.Text(root, height=10, width=40)
    text.pack()


# ==================== PROCESS LAUNCHING BLOCKER ====================

def test_process_launching():
    """BLOCKER: Process Execution - Should show 'Container orchestration'"""
    
    # subprocess.Popen
    process = subprocess.Popen(['ls', '-la'], stdout=subprocess.PIPE)
    output, error = process.communicate()
    
    # subprocess.run
    result = subprocess.run(['echo', 'hello'], capture_output=True)
    
    # subprocess.call
    return_code = subprocess.call(['python', '--version'])
    
    # os.system
    os.system('ls -l /tmp')
    os.system('ps aux | grep python')
    
    # More subprocess
    subprocess.Popen(['bash', '-c', 'echo $PATH'])


# ==================== FILE LOGGING BLOCKER ====================

def test_file_logging():
    """BLOCKER: File-based Logging - Should show 'Centralized logging infrastructure'"""
    
    # File handler for logging
    file_handler = logging.FileHandler('/var/log/application.log')
    logger = logging.getLogger('myapp')
    logger.addHandler(file_handler)
    
    # Rotating file handler
    rotating_handler = RotatingFileHandler(
        '/logs/app.log',
        maxBytes=10485760,
        backupCount=5
    )
    logger.addHandler(rotating_handler)
    
    # Stream handler to file
    log_file = open('/tmp/debug.log', 'a')
    stream_handler = logging.StreamHandler(log_file)
    logger.addHandler(stream_handler)
    
    # Direct file writing for logs
    with open('/var/log/custom.log', 'a') as log:
        log.write(f'Log entry at {os.getpid()}\n')


# ==================== ENHANCEMENTS (Not Blockers) ====================

def test_console_logging():
    """ENHANCEMENT: Console Logging - Should show 'Structured logging and monitoring'"""
    
    # Print statements
    print("Application started")
    print(f"Debug info: Process ID is {os.getpid()}")
    print("Warning: Configuration file not found")
    
    # More console output
    import sys
    sys.stdout.write("Writing to stdout\n")
    sys.stderr.write("Writing to stderr\n")
    
    # Console debugging
    import pdb
    # pdb.set_trace()  # Debugger breakpoint


def test_intensive_io():
    """ENHANCEMENT: IO Operations - Should show 'Optimized container networking'"""
    
    # Reading large files
    with open('/data/large_dataset.csv', 'r') as input_file:
        for line in input_file:
            # Process each line
            data = line.strip().split(',')
    
    # Writing large files
    with open('/output/results.txt', 'w') as output_file:
        for i in range(1000000):
            output_file.write(f"Line {i}\n")
    
    # Buffered operations
    import io
    buffered_reader = io.BufferedReader(open('/data/binary.dat', 'rb'))
    buffered_writer = io.BufferedWriter(open('/output/binary.out', 'wb'))


# ==================== MORE FILE PATTERNS ====================

def more_file_operations():
    """More file operations to trigger detection"""
    
    # Different file open modes
    f1 = open('/etc/config.conf', 'r')
    f2 = open('/var/data/database.db', 'rb')
    f3 = open('/tmp/output.txt', 'w')
    f4 = open('/logs/debug.log', 'a')
    
    # Path manipulation
    import pathlib
    path = pathlib.Path('/data/files')
    path.mkdir(parents=True, exist_ok=True)
    
    # File info
    stat_info = os.stat('/etc/passwd')
    file_size = os.path.getsize('/data/file.txt')
    
    # Directory operations
    for root, dirs, files in os.walk('/data'):
        for file in files:
            full_path = os.path.join(root, file)
            with open(full_path, 'r') as f:
                content = f.read()


def more_subprocess_operations():
    """More subprocess patterns"""
    
    # Shell execution
    subprocess.run('ls -la /tmp', shell=True)
    subprocess.call('grep pattern file.txt', shell=True)
    
    # Command with arguments
    subprocess.Popen(['python3', 'script.py', '--verbose'])
    subprocess.run(['curl', 'http://api.example.com/data'])
    
    # Getting output
    result = subprocess.check_output(['date'])
    output = subprocess.getoutput('uname -a')


# ==================== EXECUTION PATTERNS ====================

def test_eval_exec():
    """Dynamic code execution patterns"""
    
    # eval() - can execute code
    result = eval("2 + 2")
    
    # exec() - can execute statements
    exec("x = 10; print(x)")
    
    # compile() - compiles code
    code = compile("print('hello')", '<string>', 'exec')
    exec(code)


# ==================== MAIN EXECUTION ====================

if __name__ == '__main__':
    print("Starting containerization test...")
    
    # Run various tests
    test_file_operations()
    test_process_launching()
    test_file_logging()
    test_console_logging()
    test_intensive_io()
    
    print("Containerization test completed!")
    
    # More file operations at module level
    config_file = open('/etc/app/config.yaml', 'r')
    log_file = open('/var/log/app.log', 'a')
    data_file = open('/data/records.json', 'w')

