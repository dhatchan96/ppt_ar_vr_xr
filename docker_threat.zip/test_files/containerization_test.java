/*
 * Containerization Test File - Java
 * This file contains various containerization blockers and enhancements
 * Scan this file to test Docker Class and Tool Detection columns
 */

import java.io.*;
import javax.swing.*;
import java.awt.*;
import javax.ejb.Stateless;
import javax.ejb.Stateful;

public class ContainerizationTest {
    
    // ==================== FILE DEPENDENCY BLOCKERS ====================
    
    // BLOCKER: File Operations - Should show "Persistent volumes & object storage"
    public void testFileOperations() throws IOException {
        // File reading and writing
        FileInputStream fis = new FileInputStream("/data/config.properties");
        FileOutputStream fos = new FileOutputStream("/logs/application.log");
        FileReader reader = new FileReader("/config/settings.xml");
        FileWriter writer = new FileWriter("/output/results.txt");
        
        // Buffered operations
        BufferedReader br = new BufferedReader(new FileReader("/data/input.txt"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("/data/output.txt"));
        
        // Random access
        RandomAccessFile raf = new RandomAccessFile("/data/database.dat", "rw");
        
        // File object operations
        File file = new File("/temp/temporary.txt");
        file.createNewFile();
        file.delete();
        file.renameTo(new File("/temp/renamed.txt"));
    }
    
    // ==================== DESKTOP UI BLOCKER ====================
    
    // BLOCKER: Java Swing/AWT - Should show "Web-based UI modernization"
    public class DesktopApplication extends JFrame {
        public DesktopApplication() {
            // Swing components
            JPanel panel = new JPanel();
            JButton button = new JButton("Click Me");
            JLabel label = new JLabel("Desktop Application");
            
            // AWT components
            Frame frame = new Frame("AWT Application");
            Button awtButton = new Button("AWT Button");
            
            // Layout
            setLayout(new BorderLayout());
            add(panel, BorderLayout.CENTER);
            
            // Show dialog
            JOptionPane.showMessageDialog(this, "This is a desktop dialog");
        }
    }
    
    // ==================== APP SERVER LOCK-IN ====================
    
    // ENHANCEMENT: JBoss/EJB Dependency - Should show "Cloud-native application platforms"
    @Stateless
    public class MyStatelessBean {
        public String doSomething() {
            // EJB business logic
            return "Result";
        }
    }
    
    @Stateful
    public class MyStatefulBean {
        private int counter;
        
        public void increment() {
            counter++;
        }
    }
    
    // ENHANCEMENT: WebLogic specific code
    public void testWebLogic() {
        // weblogic.jndi.WLInitialContextFactory
        // weblogic.ejb.container.interfaces.BeanInfo
        String jndiFactory = "weblogic.jndi.WLInitialContextFactory";
    }
    
    // ENHANCEMENT: WebSphere specific code
    public void testWebSphere() {
        // com.ibm.websphere.models.config
        String wsClass = "com.ibm.websphere.runtime.ServerName";
    }
    
    // ENHANCEMENT: GlassFish specific code
    public void testGlassFish() {
        // org.glassfish.api.deployment.DeployCommandParameters
        String gfClass = "org.glassfish.internal.api.Globals";
    }
    
    // ==================== PROCESS LAUNCHING BLOCKER ====================
    
    // BLOCKER: Process Execution - Should show "Container orchestration"
    public void testProcessLaunching() throws IOException {
        // Runtime.exec
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec("ls -la");
        Process process2 = runtime.exec(new String[]{"bash", "-c", "echo hello"});
        
        // ProcessBuilder
        ProcessBuilder pb = new ProcessBuilder("python", "script.py");
        pb.start();
    }
    
    // ==================== SECRET STORAGE BLOCKER ====================
    
    // BLOCKER: KeyStore/Secret Storage - Should show "Kubernetes-native secrets management"
    public void testSecretStorage() throws Exception {
        // Java KeyStore
        java.security.KeyStore keyStore = java.security.KeyStore.getInstance("JKS");
        FileInputStream fis = new FileInputStream("/config/keystore.jks");
        keyStore.load(fis, "password".toCharArray());
        
        // Properties with secrets
        java.util.Properties props = new java.util.Properties();
        props.load(new FileInputStream("/config/secrets.properties"));
    }
    
    // ==================== FILE LOGGING BLOCKER ====================
    
    // BLOCKER: File-based Logging - Should show "Centralized logging infrastructure"
    public void testFileLogging() {
        // Log4j file appender configuration
        // log4j.appender.file=org.apache.log4j.FileAppender
        // log4j.appender.file.File=/var/log/application.log
        
        // Logback file appender
        // <appender name="FILE" class="ch.qos.logback.core.FileAppender">
        //   <file>/logs/application.log</file>
        // </appender>
        
        // Java Util Logging to file
        try {
            java.util.logging.FileHandler fileHandler = 
                new java.util.logging.FileHandler("/logs/app.log");
            java.util.logging.Logger.getLogger("MyApp").addHandler(fileHandler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // ==================== ENHANCEMENTS (Not Blockers) ====================
    
    // ENHANCEMENT: Console Logging - Should show "Structured logging and monitoring"
    public void testConsoleLogging() {
        System.out.println("Application started");
        System.err.println("Error occurred");
        System.out.println("Debug: User logged in at " + new java.util.Date());
        
        // Standard output
        System.out.print("Processing...");
        System.out.println("Done!");
    }
    
    // ENHANCEMENT: Intensive IO Operations - Should show "Optimized container networking"
    public void testIntensiveIO() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("/data/largefile.txt"));
        BufferedWriter writer = new BufferedWriter(new FileWriter("/data/output.txt"));
        
        String line;
        while ((line = reader.readLine()) != null) {
            writer.write(line);
            writer.newLine();
        }
        
        reader.close();
        writer.close();
    }
    
    // ==================== MORE PATTERNS ====================
    
    public void moreFileOperations() throws IOException {
        // More file operations to trigger detection
        File config = new File("/etc/app/config.xml");
        File data = new File("/var/data/database.db");
        File logs = new File("/var/log/app.log");
        
        if (config.exists()) {
            FileInputStream stream = new FileInputStream(config);
            stream.read();
            stream.close();
        }
        
        // Creating directories
        File dir = new File("/tmp/app_temp");
        dir.mkdir();
        dir.delete();
    }
    
    public void moreSwingComponents() {
        // More Swing/AWT to trigger detection
        JFrame frame = new JFrame("My App");
        JPanel panel = new JPanel();
        JButton button = new JButton("Submit");
        JTextField textField = new JTextField(20);
        JTextArea textArea = new JTextArea(10, 30);
        JComboBox<String> combo = new JComboBox<>();
        JCheckBox checkbox = new JCheckBox("Accept");
        JRadioButton radio = new JRadioButton("Option 1");
        
        frame.add(panel);
        panel.add(button);
    }
    
    public void moreProcessExecution() throws IOException, InterruptedException {
        // More process execution patterns
        Runtime.getRuntime().exec("grep pattern file.txt");
        Runtime.getRuntime().exec("find /data -name '*.xml'");
        
        ProcessBuilder builder = new ProcessBuilder();
        builder.command("sh", "-c", "echo $PATH");
        builder.start();
    }
}

