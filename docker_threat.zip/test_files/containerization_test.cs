/*
 * Containerization Test File - C#/.NET
 * This file contains various containerization blockers and enhancements
 * Scan this file to test Docker Class and Tool Detection columns
 */

using System;
using System.IO;
using System.Windows.Forms;
using System.Runtime.Caching;
using Microsoft.Win32;
using System.Security.Principal;
using System.ServiceProcess;
using System.Diagnostics;

namespace ContainerizationTest
{
    public class ContainerizationBlockers
    {
        // ==================== FILE DEPENDENCY BLOCKERS ====================
        
        // BLOCKER: Read/Write Local Files - Should show "Persistent volumes & object storage"
        public void TestFileOperations()
        {
            // File read/write operations
            FileStream fs = File.Open("C:\\data\\config.dat", FileMode.Open);
            StreamWriter writer = new StreamWriter("C:\\logs\\application.log");
            StreamReader reader = new StreamReader("C:\\config\\settings.ini");
            
            // File operations
            File.Create("C:\\temp\\output.txt");
            File.Delete("C:\\temp\\old_file.txt");
            File.Move("C:\\source.txt", "C:\\destination.txt");
            File.Copy("C:\\original.txt", "C:\\backup.txt");
        }

        // ==================== DESKTOP UI BLOCKERS ====================
        
        // BLOCKER: Windows Forms UI - Should show "Web-based UI modernization"
        public class MyDesktopForm : Form
        {
            public MyDesktopForm()
            {
                InitializeComponent();
                this.Controls.Add(new Button());
                MessageBox.Show("This is a desktop UI component");
            }
            
            private void InitializeComponent()
            {
                // Windows Forms initialization
                this.Text = "Desktop Application";
                this.Size = new System.Drawing.Size(800, 600);
            }
        }

        // ==================== WINDOWS SERVICES BLOCKER ====================
        
        // BLOCKER: Windows Service - Should show "Container orchestration services"
        public class MyWindowsService : ServiceBase
        {
            protected override void OnStart(string[] args)
            {
                // Service startup logic
                ServiceController sc = new ServiceController("MyService");
                sc.Start();
            }
            
            protected override void OnStop()
            {
                // Service stop logic
            }
        }

        // ==================== REGISTRY DEPENDENCY BLOCKER ====================
        
        // BLOCKER: Windows Registry - Should show "Configuration management modernization"
        public void TestRegistryOperations()
        {
            // Reading from registry
            RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\MyApp");
            string value = (string)Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MyApp", "Config", "");
            
            // Writing to registry
            Registry.SetValue("HKEY_CURRENT_USER\\Software\\MyApp", "Setting", "Value");
        }

        // ==================== WINDOWS AUTH BLOCKER ====================
        
        // BLOCKER: Windows Authentication - Should show "Identity and access management"
        public void TestWindowsAuth()
        {
            WindowsIdentity currentUser = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(currentUser);
            
            if (principal.IsInRole(WindowsBuiltInRole.Administrator))
            {
                Console.WriteLine("User is admin");
            }
        }

        // ==================== SECRET STORAGE BLOCKER ====================
        
        // BLOCKER: Local Secret Storage - Should show "Kubernetes-native secrets management"
        public void TestSecretStorage()
        {
            // Using isolated storage for secrets
            var store = System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForAssembly();
            
            // Protected data (Windows Data Protection API)
            byte[] protectedData = System.Security.Cryptography.ProtectedData.Protect(
                new byte[] { 1, 2, 3 }, 
                null, 
                System.Security.Cryptography.DataProtectionScope.CurrentUser
            );
        }

        // ==================== FILE LOGGING BLOCKER ====================
        
        // BLOCKER: File-based Logging - Should show "Centralized logging infrastructure"
        public void TestFileLogging()
        {
            // Log4Net file appender example
            // log4j.appender.file=org.apache.log4j.FileAppender
            // log4j.appender.file.File=C:\\logs\\application.log
            
            StreamWriter logWriter = new StreamWriter("C:\\logs\\app.log", true);
            logWriter.WriteLine($"{DateTime.Now}: Application started");
            logWriter.Close();
        }

        // ==================== PROCESS LAUNCHING BLOCKER ====================
        
        // BLOCKER: Process Launching - Should show "Container orchestration"
        public void TestProcessLaunching()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/c dir";
            
            Process process = Process.Start(startInfo);
            process.WaitForExit();
        }

        // ==================== MEMORY CACHING BLOCKER ====================
        
        // BLOCKER: In-Memory Caching - Should show "Distributed caching solutions"
        public void TestMemoryCaching()
        {
            MemoryCache cache = MemoryCache.Default;
            CacheItemPolicy policy = new CacheItemPolicy();
            policy.AbsoluteExpiration = DateTimeOffset.Now.AddHours(1);
            
            cache.Add("key", "value", policy);
            
            // HttpRuntime cache (ASP.NET)
            // HttpRuntime.Cache.Insert("key", "value", null);
        }

        // ==================== OS AUTHENTICATION BLOCKER ====================
        
        // BLOCKER: OS Integrated Authentication - Should show "Identity provider integration"
        public void TestOSAuth()
        {
            // Integrated Security connection string
            string connectionString = "Server=myServer;Database=myDB;Integrated Security=true;";
            
            // Trusted connection
            string trustedConnection = "Data Source=myServer;Initial Catalog=myDB;Trusted_Connection=True;";
            
            // Windows Authentication
            // Authentication Mode: Windows
            // NTLM or Kerberos authentication
        }

        // ==================== ENHANCEMENTS (Not Blockers) ====================
        
        // ENHANCEMENT: Console Logging - Should show "Structured logging and monitoring"
        public void TestConsoleLogging()
        {
            Console.WriteLine("Application started");
            Console.WriteLine($"Debug info: User logged in at {DateTime.Now}");
            System.Diagnostics.Debug.WriteLine("Debug message");
        }

        // ENHANCEMENT: IIS Module Dependency - Should show "Modern web server alternatives"
        // Note: This would be in a web.config file typically
        // <system.webServer>
        //   <modules>
        //     <add name="MyModule" type="MyApp.MyHttpModule" />
        //   </modules>
        // </system.webServer>

        // ENHANCEMENT: Windows App Domain - Should show "Windows containers or Linux migration"
        public void TestAppDomain()
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            AppDomain newDomain = AppDomain.CreateDomain("NewDomain");
            
            System.Reflection.Assembly assembly = System.Reflection.Assembly.Load("MyAssembly");
        }
    }
    
    // ==================== ADDITIONAL PATTERNS ====================
    
    public class MoreContainerizationIssues
    {
        // BLOCKER: More file operations
        public void MoreFileOps()
        {
            FileStream stream1 = new FileStream("C:\\data\\file.dat", FileMode.Open);
            FileStream stream2 = File.OpenRead("C:\\config\\app.config");
            FileStream stream3 = File.OpenWrite("C:\\output\\result.txt");
        }
        
        // BLOCKER: More registry operations
        public void MoreRegistryOps()
        {
            RegistryKey key1 = Registry.CurrentUser.CreateSubKey("Software\\MyApp");
            RegistryKey key2 = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet");
        }
        
        // ENHANCEMENT: IO operations that may bottleneck
        public void IntensiveIO()
        {
            using (FileStream fs = new FileStream("C:\\largefile.dat", FileMode.Open))
            using (BufferedReader br = new BufferedReader(new StreamReader(fs)))
            {
                string line;
                while ((line = br.ReadLine()) != null)
                {
                    // Process each line
                }
            }
        }
    }
}

