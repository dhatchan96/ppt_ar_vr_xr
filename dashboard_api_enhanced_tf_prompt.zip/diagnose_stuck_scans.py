#!/usr/bin/env python3
"""
Diagnostic script for stuck scans
Helps identify and troubleshoot issues with repository scanning
"""

import os
import time
import psutil
import sqlite3
import json
import logging
from pathlib import Path
from typing import Dict, List, Any
from job_manager import job_manager, JobStatus

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ScanDiagnostic:
    """Diagnostic tool for stuck scans"""
    
    def __init__(self):
        self.jobs_db_path = "threatguard_data/jobs.db"
        self.scan_history_path = "threatguard_data/scan_history.json"
        self.upload_dir = "uploaded_projects"
        
    def check_active_jobs(self) -> List[Dict]:
        """Check for active/running jobs"""
        try:
            conn = sqlite3.connect(self.jobs_db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT job_id, status, created_at, started_at, progress, result_data
                FROM scan_jobs 
                WHERE status IN ('running', 'pending')
                ORDER BY created_at DESC
            """)
            
            active_jobs = []
            for row in cursor.fetchall():
                job_id, status, created_at, started_at, progress, result_data = row
                
                # Calculate job duration
                try:
                    # Try ISO format first
                    created_time = time.mktime(time.strptime(created_at.split('.')[0], "%Y-%m-%dT%H:%M:%S"))
                    if started_at:
                        started_time = time.mktime(time.strptime(started_at.split('.')[0], "%Y-%m-%dT%H:%M:%S"))
                        duration = started_time - created_time
                    else:
                        duration = time.time() - created_time
                except:
                    try:
                        # Try standard format
                        created_time = time.mktime(time.strptime(created_at, "%Y-%m-%d %H:%M:%S"))
                        if started_at:
                            started_time = time.mktime(time.strptime(started_at, "%Y-%m-%d %H:%M:%S"))
                            duration = started_time - created_time
                        else:
                            duration = time.time() - created_time
                    except:
                        duration = 0
                
                active_jobs.append({
                    'job_id': job_id,
                    'status': status,
                    'created_at': created_at,
                    'started_at': started_at,
                    'duration_seconds': duration,
                    'message': progress,
                    'result_data': json.loads(result_data) if result_data else None
                })
            
            conn.close()
            return active_jobs
            
        except Exception as e:
            logger.error(f"Error checking active jobs: {e}")
            return []
    
    def check_system_resources(self) -> Dict[str, Any]:
        """Check current system resource usage"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            
            # Disk usage
            disk = psutil.disk_usage('/')
            
            # Process count
            process_count = len(psutil.pids())
            
            return {
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'memory_available_gb': memory.available / (1024**3),
                'disk_percent': disk.percent,
                'disk_free_gb': disk.free / (1024**3),
                'process_count': process_count,
                'timestamp': time.time()
            }
        except Exception as e:
            logger.error(f"Error checking system resources: {e}")
            return {}
    
    def check_upload_directory(self) -> Dict[str, Any]:
        """Check uploaded_projects directory status"""
        try:
            upload_path = Path(self.upload_dir)
            if not upload_path.exists():
                return {'exists': False, 'error': 'Directory does not exist'}
            
            # Count scan directories
            scan_dirs = [d for d in upload_path.iterdir() if d.is_dir()]
            
            # Check for large directories
            large_dirs = []
            total_size = 0
            
            for scan_dir in scan_dirs:
                try:
                    dir_size = sum(f.stat().st_size for f in scan_dir.rglob('*') if f.is_file())
                    total_size += dir_size
                    
                    if dir_size > 100 * 1024 * 1024:  # 100MB
                        large_dirs.append({
                            'name': scan_dir.name,
                            'size_mb': dir_size / (1024 * 1024)
                        })
                except Exception as e:
                    logger.warning(f"Error checking directory {scan_dir}: {e}")
            
            return {
                'exists': True,
                'scan_directories': len(scan_dirs),
                'total_size_gb': total_size / (1024**3),
                'large_directories': large_dirs
            }
            
        except Exception as e:
            logger.error(f"Error checking upload directory: {e}")
            return {'error': str(e)}
    
    def check_recent_failures(self, hours: int = 24) -> List[Dict]:
        """Check for recent failed jobs"""
        try:
            conn = sqlite3.connect(self.jobs_db_path)
            cursor = conn.cursor()
            
            # Get jobs from last N hours
            cutoff_time = time.time() - (hours * 3600)
            cutoff_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(cutoff_time))
            
            cursor.execute("""
                SELECT job_id, status, created_at, started_at, progress, error_message
                FROM scan_jobs 
                WHERE created_at > ? AND status = 'failed'
                ORDER BY created_at DESC
            """, (cutoff_str,))
            
            failures = []
            for row in cursor.fetchall():
                job_id, status, created_at, updated_at, message, error_message = row
                failures.append({
                    'job_id': job_id,
                    'created_at': created_at,
                    'message': progress,
                    'error_message': error_message
                })
            
            conn.close()
            return failures
            
        except Exception as e:
            logger.error(f"Error checking recent failures: {e}")
            return []
    
    def identify_potential_issues(self, active_jobs: List[Dict], system_resources: Dict) -> List[str]:
        """Identify potential issues based on current state"""
        issues = []
        
        # Check for long-running jobs
        for job in active_jobs:
            duration = job['duration_seconds']
            if duration > 1800:  # 30 minutes
                issues.append(f"Job {job['job_id']} has been running for {duration/60:.1f} minutes")
            elif duration > 600:  # 10 minutes
                issues.append(f"Job {job['job_id']} has been running for {duration/60:.1f} minutes (monitor)")
        
        # Check system resources
        if system_resources.get('cpu_percent', 0) > 90:
            issues.append("High CPU usage detected (>90%)")
        
        if system_resources.get('memory_percent', 0) > 90:
            issues.append("High memory usage detected (>90%)")
        
        if system_resources.get('disk_percent', 0) > 95:
            issues.append("Low disk space detected (<5% free)")
        
        # Check for many active jobs
        if len(active_jobs) > 5:
            issues.append(f"Many active jobs ({len(active_jobs)}) - consider limiting concurrent scans")
        
        return issues
    
    def generate_recommendations(self, issues: List[str]) -> List[str]:
        """Generate recommendations based on identified issues"""
        recommendations = []
        
        for issue in issues:
            if "long-running" in issue.lower():
                recommendations.append("Consider increasing timeouts in config.py for large repositories")
                recommendations.append("Check if repository has many large files or complex dependencies")
            
            if "high cpu" in issue.lower():
                recommendations.append("Reduce MAX_WORKERS_FOR_PARALLEL in config.py")
                recommendations.append("Consider running scans during off-peak hours")
            
            if "high memory" in issue.lower():
                recommendations.append("Reduce MAX_FILES_PER_SCAN in config.py")
                recommendations.append("Consider processing files in smaller batches")
            
            if "low disk space" in issue.lower():
                recommendations.append("Clean up uploaded_projects directory")
                recommendations.append("Increase disk space or move to larger storage")
            
            if "many active jobs" in issue.lower():
                recommendations.append("Implement job queue limits")
                recommendations.append("Consider using a job scheduler with concurrency limits")
        
        if not recommendations:
            recommendations.append("No immediate issues detected. Monitor system performance during scans.")
        
        return list(set(recommendations))  # Remove duplicates
    
    def run_diagnostic(self) -> Dict[str, Any]:
        """Run complete diagnostic"""
        logger.info("Starting scan diagnostic...")
        
        # Gather information
        active_jobs = self.check_active_jobs()
        system_resources = self.check_system_resources()
        upload_status = self.check_upload_directory()
        recent_failures = self.check_recent_failures()
        
        # Analyze issues
        issues = self.identify_potential_issues(active_jobs, system_resources)
        recommendations = self.generate_recommendations(issues)
        
        diagnostic_report = {
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'active_jobs': active_jobs,
            'system_resources': system_resources,
            'upload_directory_status': upload_status,
            'recent_failures': recent_failures,
            'identified_issues': issues,
            'recommendations': recommendations,
            'summary': {
                'active_jobs_count': len(active_jobs),
                'recent_failures_count': len(recent_failures),
                'issues_count': len(issues)
            }
        }
        
        return diagnostic_report
    
    def print_report(self, report: Dict[str, Any]):
        """Print formatted diagnostic report"""
        print("\n" + "="*60)
        print("SCAN DIAGNOSTIC REPORT")
        print("="*60)
        print(f"Generated: {report['timestamp']}")
        
        # Summary
        print(f"\nSUMMARY:")
        print(f"  Active Jobs: {report['summary']['active_jobs_count']}")
        print(f"  Recent Failures: {report['summary']['recent_failures_count']}")
        print(f"  Issues Found: {report['summary']['issues_count']}")
        
        # Active Jobs
        if report['active_jobs']:
            print(f"\nACTIVE JOBS:")
            for job in report['active_jobs']:
                duration_min = job['duration_seconds'] / 60
                print(f"  {job['job_id']}: {job['status']} ({duration_min:.1f} min) - {job['message']}")
        else:
            print(f"\nACTIVE JOBS: None")
        
        # System Resources
        if report['system_resources']:
            resources = report['system_resources']
            print(f"\nSYSTEM RESOURCES:")
            print(f"  CPU: {resources.get('cpu_percent', 'N/A')}%")
            print(f"  Memory: {resources.get('memory_percent', 'N/A')}% ({resources.get('memory_available_gb', 'N/A'):.1f} GB available)")
            print(f"  Disk: {resources.get('disk_percent', 'N/A')}% ({resources.get('disk_free_gb', 'N/A'):.1f} GB free)")
            print(f"  Processes: {resources.get('process_count', 'N/A')}")
        
        # Issues
        if report['identified_issues']:
            print(f"\nIDENTIFIED ISSUES:")
            for issue in report['identified_issues']:
                print(f"  ⚠️  {issue}")
        else:
            print(f"\nIDENTIFIED ISSUES: None")
        
        # Recommendations
        if report['recommendations']:
            print(f"\nRECOMMENDATIONS:")
            for rec in report['recommendations']:
                print(f"  💡 {rec}")
        
        # Recent Failures
        if report['recent_failures']:
            print(f"\nRECENT FAILURES (last 24h):")
            for failure in report['recent_failures'][:5]:  # Show last 5
                print(f"  ❌ {failure['job_id']}: {failure['error_message']}")
        
        print("\n" + "="*60)

def main():
    """Main diagnostic function"""
    diagnostic = ScanDiagnostic()
    report = diagnostic.run_diagnostic()
    diagnostic.print_report(report)
    
    # Save report to file
    report_file = f"scan_diagnostic_{int(time.time())}.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\nDetailed report saved to: {report_file}")

if __name__ == "__main__":
    main()

