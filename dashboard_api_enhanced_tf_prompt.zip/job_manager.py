#!/usr/bin/env python3
"""
Job Manager for asynchronous repository scanning
"""

import json
import uuid
import threading
import time
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import logging
import os

logger = logging.getLogger(__name__)

class JobStatus:
    """Job status constants"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobManager:
    """Manages asynchronous repository scanning jobs"""
    
    def __init__(self, db_path: str = "threatguard_data/jobs.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(exist_ok=True)
        self.jobs: Dict[str, Dict] = {}
        self.init_database()
        
    def init_database(self):
        """Initialize the jobs database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS scan_jobs (
                        job_id TEXT PRIMARY KEY,
                        scan_id TEXT,
                        repo_url TEXT,
                        repo_type TEXT,
                        status TEXT,
                        progress TEXT,
                        created_at TEXT,
                        started_at TEXT,
                        completed_at TEXT,
                        result_data TEXT,
                        error_message TEXT,
                        ait_tag TEXT,
                        spk_tag TEXT,
                        repo_name TEXT
                    )
                ''')
                conn.commit()
                logger.info("Jobs database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize jobs database: {e}")
    
    def create_job(self, scan_data: Dict) -> str:
        """Create a new repository scan job"""
        job_id = str(uuid.uuid4())
        
        job = {
            'job_id': job_id,
            'scan_id': scan_data.get('scan_id'),
            'repo_url': scan_data.get('repo_url'),
            'repo_type': scan_data.get('repo_type', 'unknown'),
            'status': JobStatus.PENDING,
            'progress': 'Job created',
            'created_at': datetime.now().isoformat(),
            'started_at': None,
            'completed_at': None,
            'result_data': None,
            'error_message': None,
            'ait_tag': scan_data.get('ait_tag'),
            'spk_tag': scan_data.get('spk_tag'),
            'repo_name': scan_data.get('repo_name')
        }
        
        # Store in memory
        self.jobs[job_id] = job
        
        # Store in database
        self.save_job_to_db(job)
        
        logger.info(f"Created job {job_id} for repository {scan_data.get('repo_url')}")
        return job_id
    
    def save_job_to_db(self, job: Dict):
        """Save job to database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO scan_jobs 
                    (job_id, scan_id, repo_url, repo_type, status, progress, created_at, 
                     started_at, completed_at, result_data, error_message, ait_tag, spk_tag, repo_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    job['job_id'], job['scan_id'], job['repo_url'], job['repo_type'],
                    job['status'], job['progress'], job['created_at'], job['started_at'],
                    job['completed_at'], job.get('result_data'), job.get('error_message'),
                    job['ait_tag'], job['spk_tag'], job['repo_name']
                ))
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to save job to database: {e}")
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get job status by ID"""
        # Try memory first
        if job_id in self.jobs:
            return self.jobs[job_id]
        
        # Try database
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM scan_jobs WHERE job_id = ?', (job_id,))
                row = cursor.fetchone()
                
                if row:
                    columns = [desc[0] for desc in cursor.description]
                    job = dict(zip(columns, row))
                    # Cache in memory
                    self.jobs[job_id] = job
                    return job
        except Exception as e:
            logger.error(f"Failed to get job status: {e}")
        
        return None
    
    def update_job_status(self, job_id: str, status: str, progress: str = None, 
                         result_data: Dict = None, error_message: str = None):
        """Update job status"""
        if job_id not in self.jobs:
            logger.warning(f"Job {job_id} not found in memory")
            return
        
        job = self.jobs[job_id]
        job['status'] = status
        job['progress'] = progress or job.get('progress', '')
        
        if status == JobStatus.RUNNING and not job.get('started_at'):
            job['started_at'] = datetime.now().isoformat()
        elif status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            job['completed_at'] = datetime.now().isoformat()
        
        if result_data:
            job['result_data'] = json.dumps(result_data)
        if error_message:
            job['error_message'] = error_message
        
        # Update database
        self.save_job_to_db(job)
        
        logger.info(f"Updated job {job_id} status to {status}: {progress}")
    
    def get_all_jobs(self, limit: int = 50) -> List[Dict]:
        """Get all jobs with optional limit"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM scan_jobs 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ''', (limit,))
                
                columns = [desc[0] for desc in cursor.description]
                jobs = []
                for row in cursor.fetchall():
                    job = dict(zip(columns, row))
                    jobs.append(job)
                    # Cache in memory
                    self.jobs[job['job_id']] = job
                
                return jobs
        except Exception as e:
            logger.error(f"Failed to get all jobs: {e}")
            return []
    
    def cleanup_old_jobs(self, days: int = 7):
        """Clean up old completed/failed jobs"""
        try:
            # Handle special case: days=0 means clean up all completed jobs
            if days == 0:
                logger.info("Cleaning up ALL completed/failed/cancelled jobs")
                
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # Get count of jobs to be deleted
                    cursor.execute('''
                        SELECT COUNT(*) FROM scan_jobs 
                        WHERE status IN (?, ?, ?)
                    ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED))
                    
                    count_to_delete = cursor.fetchone()[0]
                    logger.info(f"Found {count_to_delete} jobs to clean up")
                    
                    if count_to_delete > 0:
                        # Delete all completed/failed/cancelled jobs
                        cursor.execute('''
                            DELETE FROM scan_jobs 
                            WHERE status IN (?, ?, ?)
                        ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED))
                        
                        deleted_count = cursor.rowcount
                        conn.commit()
                        
                        # Also clean up from memory cache
                        jobs_to_remove = []
                        for job_id, job in self.jobs.items():
                            if job['status'] in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
                                jobs_to_remove.append(job_id)
                        
                        for job_id in jobs_to_remove:
                            del self.jobs[job_id]
                        
                        logger.info(f"Successfully cleaned up {deleted_count} jobs from database and {len(jobs_to_remove)} from memory")
                        return deleted_count
                    else:
                        logger.info("No completed/failed/cancelled jobs found to clean up")
                        return 0
            else:
                # Calculate cutoff date for time-based cleanup
                from datetime import timedelta
                cutoff_date = datetime.now() - timedelta(days=days)
                cutoff_date_str = cutoff_date.isoformat()
                
                logger.info(f"Cleaning up jobs older than {days} days (before {cutoff_date_str})")
                
                # First, get the jobs that will be deleted for logging
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # Get count of jobs to be deleted
                    cursor.execute('''
                        SELECT COUNT(*) FROM scan_jobs 
                        WHERE status IN (?, ?, ?) 
                        AND created_at < ?
                    ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, cutoff_date_str))
                    
                    count_to_delete = cursor.fetchone()[0]
                    logger.info(f"Found {count_to_delete} jobs to clean up")
                    
                    if count_to_delete > 0:
                        # Delete the old jobs
                        cursor.execute('''
                            DELETE FROM scan_jobs 
                            WHERE status IN (?, ?, ?) 
                            AND created_at < ?
                        ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, cutoff_date_str))
                        
                        deleted_count = cursor.rowcount
                        conn.commit()
                        
                        # Also clean up from memory cache
                        jobs_to_remove = []
                        for job_id, job in self.jobs.items():
                            if (job['status'] in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED] and 
                                job['created_at'] < cutoff_date_str):
                                jobs_to_remove.append(job_id)
                        
                        for job_id in jobs_to_remove:
                            del self.jobs[job_id]
                        
                        logger.info(f"Successfully cleaned up {deleted_count} old jobs from database and {len(jobs_to_remove)} from memory")
                        return deleted_count
                    else:
                        logger.info("No old jobs found to clean up")
                        return 0
                    
        except Exception as e:
            logger.error(f"Failed to cleanup old jobs: {e}")
            logger.error(f"Database path: {self.db_path}")
            logger.error(f"Database exists: {os.path.exists(self.db_path)}")
            raise

    def cleanup_jobs_by_status(self, status: str):
        """Clean up jobs by specific status"""
        try:
            logger.info(f"Cleaning up jobs with status: {status}")
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get count of jobs to be deleted
                cursor.execute('''
                    SELECT COUNT(*) FROM scan_jobs 
                    WHERE status = ?
                ''', (status,))
                
                count_to_delete = cursor.fetchone()[0]
                logger.info(f"Found {count_to_delete} {status} jobs to clean up")
                
                if count_to_delete > 0:
                    # Delete jobs with specific status
                    cursor.execute('''
                        DELETE FROM scan_jobs 
                        WHERE status = ?
                    ''', (status,))
                    
                    deleted_count = cursor.rowcount
                    conn.commit()
                    
                    # Also clean up from memory cache
                    jobs_to_remove = []
                    for job_id, job in self.jobs.items():
                        if job['status'] == status:
                            jobs_to_remove.append(job_id)
                    
                    for job_id in jobs_to_remove:
                        del self.jobs[job_id]
                    
                    logger.info(f"Successfully cleaned up {deleted_count} {status} jobs from database and {len(jobs_to_remove)} from memory")
                    return deleted_count
                else:
                    logger.info(f"No {status} jobs found to clean up")
                    return 0
                    
        except Exception as e:
            logger.error(f"Failed to cleanup {status} jobs: {e}")
            logger.error(f"Database path: {self.db_path}")
            logger.error(f"Database exists: {os.path.exists(self.db_path)}")
            raise

# Global job manager instance
job_manager = JobManager()
