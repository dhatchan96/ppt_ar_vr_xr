#!/usr/bin/env python3
"""
Admin Data Manager for AIT-SPK-Repo mappings
Handles Excel import and SQLite database operations for hierarchical project data
"""

import sqlite3
import json
import pandas as pd
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AdminDataManager:
    def __init__(self, db_path: str = "admin_data.db"):
        """Initialize the admin data manager with SQLite database"""
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database with required tables"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create AIT table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS ait_mappings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ait_tag TEXT UNIQUE NOT NULL,
                        ait_name TEXT NOT NULL,
                        ait_description TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Create SPK table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS spk_mappings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        spk_tag TEXT UNIQUE NOT NULL,
                        spk_name TEXT NOT NULL,
                        spk_description TEXT,
                        ait_tag TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (ait_tag) REFERENCES ait_mappings (ait_tag)
                    )
                ''')
                
                # Create Repository table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS repo_mappings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        repo_name TEXT NOT NULL,
                        repo_url TEXT,
                        repo_description TEXT,
                        spk_tag TEXT NOT NULL,
                        ait_tag TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (spk_tag) REFERENCES spk_mappings (spk_tag),
                        FOREIGN KEY (ait_tag) REFERENCES ait_mappings (ait_tag)
                    )
                ''')
                
                # Create indexes for better performance
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_ait_tag ON ait_mappings(ait_tag)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_spk_tag ON spk_mappings(spk_tag)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_spk_ait ON spk_mappings(ait_tag)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_repo_spk ON repo_mappings(spk_tag)')
                cursor.execute('CREATE INDEX IF NOT EXISTS idx_repo_ait ON repo_mappings(ait_tag)')
                
                conn.commit()
                logger.info("Database initialized successfully")
                
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            raise
    
    def import_excel_data(self, excel_file_path: str) -> Dict:
        """Import data from Excel file to SQLite database"""
        try:
            logger.info(f"Importing data from {excel_file_path}")
            
            # Read Excel file
            df = pd.read_excel(excel_file_path)
            
            # Validate required columns
            required_columns = ['AIT_ID', 'SPK', 'REPOSITORY_NAME']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                return {
                    'success': False,
                    'error': f"Missing required columns: {missing_columns}",
                    'expected_columns': required_columns
                }
            
            # Clean and prepare data
            df = df.fillna('')
            df = df.drop_duplicates()
            
            # Convert AIT_ID to string to handle both numeric and string values
            df['AIT_ID'] = df['AIT_ID'].astype(str)
            
            # Use AIT_ID as the AIT tag (numerical ID)
            # AIT_ID format: "100" -> AIT tag: "100", AIT name: "AAR" (from SPK column)
            df['AIT'] = df['AIT_ID'].astype(str)  # Use AIT_ID as AIT tag
            df['AIT_Name'] = df['SPK']  # Use SPK as AIT name
            
            # Create SPK name from SPK tag
            df['SPK_Name'] = df['SPK']  # Create SPK name without prefix
            
            # Import data to database
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Clear existing data (optional - you might want to append instead)
                cursor.execute("DELETE FROM repo_mappings")
                cursor.execute("DELETE FROM spk_mappings")
                cursor.execute("DELETE FROM ait_mappings")
                
                # Import AIT data
                ait_data = df[['AIT', 'AIT_Name']].drop_duplicates()
                for _, row in ait_data.iterrows():
                    cursor.execute('''
                        INSERT OR REPLACE INTO ait_mappings (ait_tag, ait_name)
                        VALUES (?, ?)
                    ''', (row['AIT'], row['AIT_Name']))
                
                # Import SPK data
                spk_data = df[['SPK', 'SPK_Name', 'AIT']].drop_duplicates()
                for _, row in spk_data.iterrows():
                    cursor.execute('''
                        INSERT OR REPLACE INTO spk_mappings (spk_tag, spk_name, ait_tag)
                        VALUES (?, ?, ?)
                    ''', (row['SPK'], row['SPK_Name'], row['AIT']))
                
                # Import Repository data
                repo_data = df[['REPOSITORY_NAME', 'SPK', 'AIT']].drop_duplicates()
                for _, row in repo_data.iterrows():
                    cursor.execute('''
                        INSERT OR REPLACE INTO repo_mappings (repo_name, spk_tag, ait_tag)
                        VALUES (?, ?, ?)
                    ''', (row['REPOSITORY_NAME'], row['SPK'], row['AIT']))
                
                conn.commit()
                
                # Get import statistics
                cursor.execute("SELECT COUNT(*) FROM ait_mappings")
                ait_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM spk_mappings")
                spk_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM repo_mappings")
                repo_count = cursor.fetchone()[0]
                
                logger.info(f"Import completed: {ait_count} AITs, {spk_count} SPKs, {repo_count} Repositories")
                
                return {
                    'success': True,
                    'message': f"Successfully imported {ait_count} AITs, {spk_count} SPKs, {repo_count} Repositories",
                    'statistics': {
                        'ait_count': ait_count,
                        'spk_count': spk_count,
                        'repo_count': repo_count
                    }
                }
                
        except Exception as e:
            logger.error(f"Error importing Excel data: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_ait_list(self) -> List[Dict]:
        """Get list of all AITs"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT ait_tag, ait_name, ait_description, 
                           (SELECT COUNT(*) FROM spk_mappings WHERE ait_tag = a.ait_tag) as spk_count,
                           (SELECT COUNT(*) FROM repo_mappings WHERE ait_tag = a.ait_tag) as repo_count
                    FROM ait_mappings a
                    ORDER BY ait_tag
                ''')
                
                results = cursor.fetchall()
                return [
                    {
                        'ait_tag': row[0],
                        'ait_name': row[1],
                        'ait_description': row[2],
                        'spk_count': row[3],
                        'repo_count': row[4]
                    }
                    for row in results
                ]
        except Exception as e:
            logger.error(f"Error getting AIT list: {e}")
            return []
    
    def get_spk_list(self, ait_tag: str) -> List[Dict]:
        """Get list of SPKs for a specific AIT"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT spk_tag, spk_name, spk_description,
                           (SELECT COUNT(*) FROM repo_mappings WHERE spk_tag = s.spk_tag) as repo_count
                    FROM spk_mappings s
                    WHERE ait_tag = ?
                    ORDER BY spk_tag
                ''', (ait_tag,))
                
                results = cursor.fetchall()
                return [
                    {
                        'spk_tag': row[0],
                        'spk_name': row[1],
                        'spk_description': row[2],
                        'repo_count': row[3]
                    }
                    for row in results
                ]
        except Exception as e:
            logger.error(f"Error getting SPK list: {e}")
            return []
    
    def get_repo_list(self, spk_tag: str) -> List[Dict]:
        """Get list of repositories for a specific SPK"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT repo_name, repo_url, repo_description
                    FROM repo_mappings
                    WHERE spk_tag = ?
                    ORDER BY repo_name
                ''', (spk_tag,))
                
                results = cursor.fetchall()
                return [
                    {
                        'repo_name': row[0],
                        'repo_url': row[1],
                        'repo_description': row[2]
                    }
                    for row in results
                ]
        except Exception as e:
            logger.error(f"Error getting repository list: {e}")
            return []
    
    def get_hierarchical_data(self) -> Dict:
        """Get complete hierarchical data for frontend"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get all data in hierarchical structure
                cursor.execute('''
                    SELECT 
                        a.ait_tag, a.ait_name,
                        s.spk_tag, s.spk_name,
                        r.repo_name, r.repo_url
                    FROM ait_mappings a
                    LEFT JOIN spk_mappings s ON a.ait_tag = s.ait_tag
                    LEFT JOIN repo_mappings r ON s.spk_tag = r.spk_tag
                    ORDER BY a.ait_tag, s.spk_tag, r.repo_name
                ''')
                
                results = cursor.fetchall()
                
                # Build hierarchical structure
                hierarchy = {}
                for row in results:
                    ait_tag, ait_name, spk_tag, spk_name, repo_name, repo_url = row
                    
                    if ait_tag not in hierarchy:
                        hierarchy[ait_tag] = {
                            'ait_name': ait_name,
                            'spks': {}
                        }
                    
                    if spk_tag and spk_tag not in hierarchy[ait_tag]['spks']:
                        hierarchy[ait_tag]['spks'][spk_tag] = {
                            'spk_name': spk_name,
                            'repos': []
                        }
                    
                    if repo_name:
                        hierarchy[ait_tag]['spks'][spk_tag]['repos'].append({
                            'repo_name': repo_name,
                            'repo_url': repo_url
                        })
                
                return hierarchy
                
        except Exception as e:
            logger.error(f"Error getting hierarchical data: {e}")
            return {}
    
    def export_to_json(self, output_path: str = "hierarchical_data.json") -> bool:
        """Export hierarchical data to JSON file for frontend use"""
        try:
            data = self.get_hierarchical_data()
            
            with open(output_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"Data exported to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting to JSON: {e}")
            return False
    
    def get_statistics(self) -> Dict:
        """Get database statistics"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                cursor.execute("SELECT COUNT(*) FROM ait_mappings")
                ait_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM spk_mappings")
                spk_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM repo_mappings")
                repo_count = cursor.fetchone()[0]
                
                return {
                    'ait_count': ait_count,
                    'spk_count': spk_count,
                    'repo_count': repo_count,
                    'total_records': ait_count + spk_count + repo_count
                }
                
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {}

    def clear_all_data(self) -> Dict:
        """Clear all data from the database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get counts before clearing for the message
                cursor.execute("SELECT COUNT(*) FROM ait_mappings")
                ait_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM spk_mappings")
                spk_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM repo_mappings")
                repo_count = cursor.fetchone()[0]
                
                # Clear all data
                cursor.execute("DELETE FROM repo_mappings")
                cursor.execute("DELETE FROM spk_mappings")
                cursor.execute("DELETE FROM ait_mappings")
                
                conn.commit()
                
                logger.info(f"Cleared all data: {ait_count} AITs, {spk_count} SPKs, {repo_count} Repositories")
                
                return {
                    'success': True,
                    'message': f"Successfully cleared all data: {ait_count} AITs, {spk_count} SPKs, {repo_count} Repositories"
                }
                
        except Exception as e:
            logger.error(f"Error clearing data: {e}")
            return {
                'success': False,
                'error': str(e)
            }

# Global instance
admin_data_manager = AdminDataManager()
