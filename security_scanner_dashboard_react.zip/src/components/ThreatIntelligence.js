import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';

const ThreatIntelligence = () => {
  const [intelligence, setIntelligence] = useState(null);
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');

  useEffect(() => {
    fetchThreatIntelligence();
  }, []);

  const fetchThreatIntelligence = async () => {
    try {
      const res = await API.get('/api/threat-intelligence');
      setIntelligence(res.data);
    } catch (error) {
      console.error('Error fetching threat intelligence:', error);
    }
  };

  // Display name helpers (copy from ThreatIssues.js)
  const getAITName = (aitId) => {
    if (!aitId) return '';
    const aitData = {
      'AIT001': 'AIT-Web-Development',
      'AIT002': 'AIT-Mobile-Apps',
      'AIT003': 'AIT-Cloud-Services',
      'AIT004': 'AIT-Data-Analytics',
      'AIT005': 'AIT-Security-Tools'
    };
    return aitData[aitId] || aitId;
  };
  const getSPKName = (spkId) => {
    if (!spkId) return '';
    const spkData = {
      'SPK001': 'SPK-Frontend-React',
      'SPK002': 'SPK-Backend-NodeJS',
      'SPK003': 'SPK-Database-MongoDB',
      'SPK004': 'SPK-Android-Native',
      'SPK005': 'SPK-iOS-Swift',
      'SPK006': 'SPK-React-Native'
    };
    return spkData[spkId] || spkId;
  };
  const getRepoName = (repoId) => {
    if (!repoId) return '';
    const repoData = {
      'REPO001': 'user-management-frontend',
      'REPO002': 'dashboard-ui-components',
      'REPO003': 'admin-panel-react',
      'REPO004': 'api-gateway-service',
      'REPO005': 'user-authentication-api',
      'REPO006': 'payment-processing-api',
      'REPO007': 'mobile-app-ios',
      'REPO008': 'mobile-app-android',
      'REPO009': 'cloud-automation',
      'REPO010': 'data-analytics-pipeline',
      'REPO014': 'special-repo'
    };
    return repoData[repoId] || repoId;
  };

  if (!intelligence) return <p className="text-center mt-5" style={{ color: '#b0b0b0' }}>Loading threat intelligence...</p>;

  // Unique AIT, SPK, Repo values for dropdowns
  const scanHistory = intelligence.scan_history;
  const uniqueAITs = Array.from(new Set(scanHistory.map(s => s.ait_tag).filter(Boolean)));
  const uniqueSPKs = Array.from(new Set(scanHistory.map(s => s.spk_tag).filter(Boolean)));
  const uniqueRepos = Array.from(new Set(scanHistory.map(s => s.repo_name).filter(Boolean)));

  // Filtered scan history
  const filteredHistory = scanHistory.filter(scan => {
    if (filterAIT && scan.ait_tag !== filterAIT) return false;
    if (filterSPK && scan.spk_tag !== filterSPK) return false;
    if (filterRepo && scan.repo_name !== filterRepo) return false;
    return true;
  });

  return (
    <div className="container-fluid mt-4 px-5" style={{ background: '#fff', color: '#222', minHeight: '100vh' }}>
      <h2 className="mb-4" style={{ color: '#0d6efd' }}>🧠 Threat Intelligence Center</h2>
      
      {/* Intelligence Stats */}
      <div className="row g-4 mb-5">
        <div className="col-md-3">
          <div className="card text-center" style={{ background: '#fff', border: '1px solid #e5e7eb' }}>
            <div className="card-body">
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#0d6efd' }}>{intelligence.total_scans}</div>
              <div style={{ color: '#888' }}>Total Scans</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center" style={{ background: '#fff', border: '1px solid #e5e7eb' }}>
            <div className="card-body">
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#198754' }}>{intelligence.threats_neutralized}</div>
              <div style={{ color: '#888' }}>Threats Neutralized</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center" style={{ background: '#fff', border: '1px solid #e5e7eb' }}>
            <div className="card-body">
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#fd7e14' }}>{intelligence.avg_risk_score}</div>
              <div style={{ color: '#888' }}>Avg Risk Score</div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center" style={{ background: '#fff', border: '1px solid #e5e7eb' }}>
            <div className="card-body">
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#0d6efd' }}>{intelligence.shield_effectiveness}%</div>
              <div style={{ color: '#888' }}>Shield Effectiveness</div>
            </div>
          </div>
        </div>
      </div>

      {/* Hierarchical Filter Controls */}
      <div className="mb-4 p-3 bg-light rounded">
        <h6 className="mb-2" style={{ color: '#222' }}>
          <i className="bi bi-funnel"></i> Filter by Project Hierarchy
        </h6>
        <div className="row g-2">
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterAIT}
              onChange={e => setFilterAIT(e.target.value)}
            >
              <option value="">All AITs</option>
              {uniqueAITs.map(ait => (
                <option key={ait} value={ait}>{getAITName(ait)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterSPK}
              onChange={e => setFilterSPK(e.target.value)}
            >
              <option value="">All SPKs</option>
              {uniqueSPKs.map(spk => (
                <option key={spk} value={spk}>{getSPKName(spk)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterRepo}
              onChange={e => setFilterRepo(e.target.value)}
            >
              <option value="">All Repositories</option>
              {uniqueRepos.map(repo => (
                <option key={repo} value={repo}>{getRepoName(repo)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <button
              className="btn btn-outline-secondary btn-sm w-100"
              onClick={() => {
                setFilterAIT('');
                setFilterSPK('');
                setFilterRepo('');
              }}
            >
              <i className="bi bi-x-circle"></i> Clear Filters
            </button>
          </div>
        </div>
        {(filterAIT || filterSPK || filterRepo) && (
          <div className="mt-2">
            <small className="text-muted">
              Showing {filteredHistory.length} of {scanHistory.length} scans
            </small>
          </div>
        )}
      </div>

      <div className="section" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb' }}>
        <h3 style={{ color: '#0d6efd' }} className="mb-3">📊 Threat Intelligence History</h3>
        <div className="table-responsive">
          <table className="table table-bordered table-hover align-middle" style={{ background: '#fff' }}>
            <thead className="table-light">
              <tr>
                <th style={{ color: '#0d6efd' }}>Scan Date</th>
                <th style={{ color: '#0d6efd' }}>Project</th>
                <th style={{ color: '#0d6efd' }}>Logic Bombs</th>
                <th style={{ color: '#0d6efd' }}>Risk Score</th>
                <th style={{ color: '#0d6efd' }}>Shield Status</th>
                <th style={{ color: '#0d6efd' }}>Threat Level</th>
              </tr>
            </thead>
            <tbody>
              {filteredHistory.map((scan) => {
                const scanDate = new Date(scan.timestamp).toLocaleString();
                return (
                  <tr key={scan.scan_id}>
                    <td style={{ color: '#222' }}>{scanDate}</td>
                    <td style={{ color: '#222' }}>
                      {scan.ait_tag && scan.spk_tag && scan.repo_name
                        ? `${getAITName(scan.ait_tag)} → ${getSPKName(scan.spk_tag)} → ${getRepoName(scan.repo_name)}`
                        : scan.project_id}
                    </td>
                    <td style={{ color: '#dc3545' }}>{scan.logic_bombs || 0}</td>
                    <td>
                      <span className={`badge ${
                        scan.logic_bomb_risk_score >= 70 ? 'bg-danger' : 
                        scan.logic_bomb_risk_score >= 40 ? 'bg-warning' : 
                        'bg-success'
                      }`}>
                        {scan.logic_bomb_risk_score || 0}/100
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${
                        scan.threat_shield_status === 'PROTECTED' ? 'bg-success' : 
                        scan.threat_shield_status === 'BLOCKED' ? 'bg-danger' : 
                        'bg-warning'
                      }`}>
                        {scan.threat_shield_status}
                      </span>
                    </td>
                    <td style={{ color: scan.threat_level === 'CRITICAL' ? '#dc3545' : scan.threat_level === 'HIGH' ? '#fd7e14' : '#198754' }}>
                      {scan.threat_level || 'UNKNOWN'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ThreatIntelligence;