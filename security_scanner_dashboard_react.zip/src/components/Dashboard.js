import React, { useEffect, useState } from "react";
import API from "../api";
import { copilotAPI } from "../api";
import "../style.css";
import { Toast } from "bootstrap";
import JSZip from "jszip";

const Dashboard = () => {
  const [metrics, setMetrics] = useState(null);
  const [recentIssues, setRecentIssues] = useState([]);
  const [health, setHealth] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [malwareStats, setMalwareStats] = useState(null);
  const [activeTab, setActiveTab] = useState("malware");
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');

  // Sample data - you can replace with actual data from your backend
  const aitData = {
    'AIT001': 'Application Integration Team 1',
    'AIT002': 'Application Integration Team 2',
    'AIT003': 'Application Integration Team 3'
  };

  const spkData = {
    'AIT001': {
      'SPK001': 'Security Product Key 1',
      'SPK002': 'Security Product Key 2'
    },
    'AIT002': {
      'SPK003': 'Security Product Key 3',
      'SPK004': 'Security Product Key 4',
      'SPK005': 'Security Product Key 5'
    },
    'AIT003': {
      'SPK006': 'Security Product Key 6'
    }
  };

  const repoData = {
    'SPK001': ['REPO001', 'REPO002'],
    'SPK002': ['REPO003'],
    'SPK003': ['REPO004', 'REPO005'],
    'SPK004': ['REPO006'],
    'SPK005': ['REPO007', 'REPO008', 'REPO014'],
    'SPK006': ['REPO009', 'REPO010']
  };

  const getAITName = (aitId) => aitData[aitId] || aitId;
  const getSPKName = (spkId) => {
    const spkMap = Object.values(spkData).flatMap(spks => Object.entries(spks));
    const spkEntry = spkMap.find(([id]) => id === spkId);
    return spkEntry ? spkEntry[1] : spkId;
  };
  const getRepoName = (repoId) => repoId;

  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
  };

  const malwareIssues = recentIssues.filter((i) =>
  i.rule_id?.startsWith("MALWARE_")
);
const otherIssues = recentIssues.filter((i) =>
  !i.rule_id?.startsWith("MALWARE_")
);

  useEffect(() => {
    fetchMetrics();
    fetchHealth();
  }, []);

  const fetchMetrics = async () => {
    try {
      const res = await API.get("/api/dashboard/metrics");
      if (res.data && !res.data.error) {
        setMetrics(res.data);
        setRecentIssues(res.data.recent_issues || []);
        if (res.data.malware_patterns_found || res.data.malware_analysis) {
          setMalwareStats({
            count: res.data.malware_patterns_found || 0,
            details: Object.entries(
              res.data.malware_analysis.by_type || {}
            ).map(([type, count]) => `${type}: ${count}`),
          });
        }
      }
    } catch (error) {
      console.error("Failed to fetch metrics:", error);
    }
  };

  const fetchHealth = async () => {
    try {
      const res = await API.get("/api/health");
      setHealth(res.data);
    } catch (err) {
      console.error("Failed to fetch health info:", err);
    }
  };

  const resolveIssue = async (id) => {
    try {
      await API.put(`/api/issues/${id}/status`, { status: "RESOLVED" });
      fetchMetrics();
    } catch (error) {
      console.error("Failed to resolve issue:", error);
    }
  };

  const handleFileDrop = async (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = e.dataTransfer.items;
    const files = await extractFilesFromItems(items);
    handleUpload(files);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    handleUpload(files);
  };

  const extractFilesFromItems = async (items) => {
    const traverseFileTree = (item, path = "") => {
      return new Promise((resolve) => {
        if (item.isFile) {
          item.file((file) => {
            file.fullPath = path + file.name;
            resolve([file]);
          });
        } else if (item.isDirectory) {
          const dirReader = item.createReader();
          dirReader.readEntries(async (entries) => {
            const results = await Promise.all(
              entries.map((entry) =>
                traverseFileTree(entry, path + item.name + "/")
              )
            );
            resolve(results.flat());
          });
        }
      });
    };

    const results = await Promise.all(
      Array.from(items).map((item) => traverseFileTree(item))
    );
    return results.flat();
  };

  const handleUpload = async (files) => {
    if (!files.length) return;
    if (!selectedAIT || !selectedSPK || !selectedRepo) {
      alert('Please select AIT, SPK, and Repository before uploading files.');
      return;
    }

    const fileContents = [];
    for (const file of files) {
      try {
        if (file.name.endsWith('.zip')) {
          const zip = new JSZip();
          const zipContent = await zip.loadAsync(file);
          for (const [filename, zipFile] of Object.entries(zipContent.files)) {
            if (!zipFile.dir) {
              const content = await zipFile.async('string');
              fileContents.push({
                id: generateId(),
                name: filename,
                type: getFileLanguage(filename),
                content: content,
              });
            }
          }
        } else {
          const content = await readFileContent(file);
          fileContents.push({
            id: generateId(),
            name: file.name,
            type: getFileLanguage(file.name),
            content: content,
          });
        }
      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
      }
    }

    const payload = {
      scan_id: generateId(),
      scan_type: "manual",
      project_id: `upload-scan-${Date.now()}`,
      project_name: "Quick Security Scan",
      timestamp: new Date().toISOString(),
      file_contents: fileContents,
      ait_tag: selectedAIT,
      spk_tag: selectedSPK,
      repo_name: selectedRepo
    };

    try {
      setUploading(true);
      await API.post("/api/scan/files", payload);
      fetchMetrics();
      fetchHealth();
      const toastEl = document.getElementById("uploadSuccessToast");
      if (toastEl) new Toast(toastEl).show();
    } catch (err) {
      console.error(err);
      const toastEl = document.getElementById("uploadErrorToast");
      if (toastEl) new Toast(toastEl).show();
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => "id_" + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const map = {
      py: "python",
      js: "javascript",
      ts: "typescript",
      java: "java",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      cpp: "cpp",
      cs: "csharp",
      rb: "ruby",
      php: "php",
      zip: "zip",
    };
    return map[ext] || "unknown";
  };

  const timeAgo = (isoTime) => {
    const diffMs = Date.now() - new Date(isoTime).getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "just now";
    if (diffMin === 1) return "1 minute ago";
    return `${diffMin} minutes ago`;
  };

  const downloadCopilotPrompts = async () => {
    try {
      const res = await copilotAPI.downloadPrompts();

      const blob = new Blob([res.data], { type: "application/zip" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "copilot_prompts.zip";
      link.click();
    } catch (err) {
      console.error("Failed to download prompts:", err);
      alert("❌ Failed to download Copilot prompts.");
    }
  };

  const availableSPKs = selectedAIT ? Object.keys(spkData[selectedAIT] || {}) : [];
  const availableRepos = selectedSPK ? (repoData[selectedSPK] || []) : [];

  if (!metrics) return <p className="text-center mt-5">Loading metrics...</p>;

  const {
    ratings,
    scan_info,
    quality_gate,
    issues,
    metrics: metricData,
  } = metrics;

  return (
    <div className="container-fluid mt-4 px-5">
      {health && (
        <div
          className={`alert ${
            health.status === "healthy" ? "alert-success" : "alert-danger"
          } mb-4`}
        >
          <strong>System Status:</strong> {health.status} - {health.message}
        </div>
      )}

      {/* Project Selection Dropdowns */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">Project Configuration</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4">
              <label className="form-label">AIT (Application Integration Team)</label>
              <select 
                className="form-select" 
                value={selectedAIT} 
                onChange={(e) => handleAITChange(e.target.value)}
              >
                <option value="">Select AIT</option>
                {Object.keys(aitData).map(ait => (
                  <option key={ait} value={ait}>{getAITName(ait)}</option>
                ))}
              </select>
            </div>
            
            <div className="col-md-4">
              <label className="form-label">SPK (Security Product Key)</label>
              <select 
                className="form-select" 
                value={selectedSPK} 
                onChange={(e) => handleSPKChange(e.target.value)}
                disabled={!selectedAIT}
                style={{ opacity: selectedAIT ? 1 : 0.6 }}
              >
                <option value="">Select SPK</option>
                {availableSPKs.map(spk => (
                  <option key={spk} value={spk}>{getSPKName(spk)}</option>
                ))}
              </select>
            </div>
            
            <div className="col-md-4">
              <label className="form-label">Repository</label>
              <select 
                className="form-select" 
                value={selectedRepo} 
                onChange={(e) => handleRepoChange(e.target.value)}
                disabled={!selectedSPK}
                style={{ opacity: selectedSPK ? 1 : 0.6 }}
              >
                <option value="">Select Repository</option>
                {availableRepos.map(repo => (
                  <option key={repo} value={repo}>{getRepoName(repo)}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Selected Project Summary */}
          {selectedAIT && selectedSPK && selectedRepo && (
            <div className="alert alert-info mt-3">
              <strong>Selected Project:</strong><br />
              <strong>AIT:</strong> {getAITName(selectedAIT)}<br />
              <strong>SPK:</strong> {getSPKName(selectedSPK)}<br />
              <strong>Repository:</strong> {getRepoName(selectedRepo)}
            </div>
          )}
        </div>
      </div>

      {/* File Upload Area */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">File Upload & Scan</h5>
        </div>
        <div className="card-body">
          <div
            className={`border-2 border-dashed rounded p-5 text-center ${
              dragOver ? "border-primary bg-primary bg-opacity-10" : "border-secondary"
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleFileDrop}
          >
            <input
              type="file"
              id="fileInput"
              hidden
              multiple
              onChange={handleFileSelect}
            />
            <i className="bi bi-cloud-upload display-1 text-muted"></i>
            <h5 className="mt-3">Drop files here or click to browse</h5>
            <p className="text-muted">Supports individual files, folders, and ZIP archives</p>
            <button
              className="btn btn-primary"
              onClick={() => document.getElementById("fileInput").click()}
              disabled={uploading || !selectedAIT || !selectedSPK || !selectedRepo}
            >
              {uploading ? "Scanning..." : "📁 Browse Files"}
            </button>
          </div>
        </div>
      </div>

      <div
        className="position-fixed bottom-0 end-0 p-3"
        style={{ zIndex: 1055 }}
      >
        <div
          id="uploadSuccessToast"
          className="toast align-items-center text-white bg-success border-0"
          role="alert"
        >
          <div className="d-flex">
            <div className="toast-body">
              ✅ File scan completed successfully!
            </div>
            <button
              type="button"
              className="btn-close btn-close-white me-2 m-auto"
              data-bs-dismiss="toast"
            ></button>
          </div>
        </div>
        <div
          id="uploadErrorToast"
          className="toast align-items-center text-white bg-danger border-0"
          role="alert"
        >
          <div className="d-flex">
            <div className="toast-body">
              ❌ File scan failed. Please try again.
            </div>
            <button
              type="button"
              className="btn-close btn-close-white me-2 m-auto"
              data-bs-dismiss="toast"
            ></button>
          </div>
        </div>
      </div>

      {malwareStats?.details?.length > 0 && (
        <div className="section mt-5">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h2 className="mb-0">🛡️ Detected Malware Patterns</h2>
          </div>
          <div className="table-responsive w-100">
            <table className="table table-bordered table-hover align-middle">
              <thead className="table-danger">
                <tr>
                  <th>Rule Type</th>
                  <th>Occurrences</th>
                </tr>
              </thead>
              <tbody>
                {malwareStats.details.map((entry, idx) => {
                  const [type, count] = entry.split(":");
                  return (
                    <tr key={idx}>
                      <td className="text-danger fw-bold">{type.trim()}</td>
                      <td>{count.trim()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <h2 className="mb-4">Overview</h2>
      <div className="row g-4 mb-4">
        {[
          {
            label: "Security Rating",
            value: ratings.security,
            className: `rating-${ratings.security}`,
          },
          {
            label: "Reliability Rating",
            value: ratings.reliability,
            className: `rating-${ratings.reliability}`,
          },
          {
            label: "Maintainability Rating",
            value: ratings.maintainability,
            className: `rating-${ratings.maintainability}`,
          },
          {
            label: "Quality Gate",
            value: quality_gate.status,
            className: `quality-gate-${quality_gate.status}`,
          },
        ].map((item, i) => (
          <div className="col-md-3" key={i}>
            <div className="metric-card text-center">
              <div className={`metric-value ${item.className}`}>
                {item.value}
              </div>
              <div className="metric-label">{item.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-4 mb-5">
        {[
          { label: "Total Issues", value: issues.total },
          { label: "Files Scanned", value: scan_info.files_scanned },
          {
            label: "Lines of Code",
            value: scan_info.lines_of_code.toLocaleString(),
          },
          {
            label: "Technical Debt",
            value: Math.round(metricData.technical_debt / 60) + "h",
          },
        ].map((item, i) => (
          <div className="col-md-3" key={i}>
            <div className="metric-card text-center">
              <div className="metric-value">{item.value}</div>
              <div className="metric-label">{item.label}</div>
            </div>
          </div>
        ))}
      </div>

      <ul className="nav nav-tabs mb-3">
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === "malware" ? "active" : ""}`}
            onClick={() => setActiveTab("malware")}
          >
            🛡 Malware Issues
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === "other" ? "active" : ""}`}
            onClick={() => setActiveTab("other")}
          >
            📄 Other Issues
          </button>
        </li>
      </ul>

      <div className="section">
  <div className="d-flex justify-content-between align-items-center mb-3">
    <h2 className="mb-0">
      {activeTab === "malware" ? "🛡 Malware Issues" : "📄 Other Issues"}
    </h2>
    <button
      className="btn btn-outline-info btn-sm"
      onClick={downloadCopilotPrompts}
    >
      💡 Download Copilot Prompts
    </button>
  </div>

  <div className="table-responsive w-100">
    <table className="table table-bordered table-hover align-middle">
      <thead className="table-light">
        <tr>
          <th>Severity</th>
          <th>Type</th>
          <th>Rule</th>
          <th>File</th>
          <th>Line</th>
          <th>Message</th>
          <th>Recommendation</th>
          <th className="text-center">Actions</th>
        </tr>
      </thead>
      <tbody>
        {(activeTab === "malware" ? malwareIssues : otherIssues).length > 0 ? (
          (activeTab === "malware" ? malwareIssues : otherIssues).map((issue) => (
            <tr key={issue.id}>
              <td>
                <span
                  className={
                    issue.rule_id?.includes("MALWARE")
                      ? "badge bg-danger"
                      : `severity-${issue.severity}`
                  }
                >
                  {issue.severity}
                </span>
              </td>
              <td>{issue.type}</td>
              <td>{issue.rule_id}</td>
              <td style={{ wordBreak: "break-word" }}>{issue.file_path}</td>
              <td className="text-center">{issue.line_number}</td>
              <td>{issue.message}</td>
              <td style={{ whiteSpace: "pre-wrap" }}>
                {issue.suggested_fix || "—"}
              </td>
              <td className="text-center">
                <div className="d-flex justify-content-center gap-2">
                  <button className="btn btn-sm btn-primary">Details</button>
                  <button
                    className="btn btn-sm btn-success"
                    onClick={() => resolveIssue(issue.id)}
                  >
                    Resolve
                  </button>
                </div>
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan="8" className="text-center">
              No {activeTab === "malware" ? "malware" : "other"} issues found.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  </div>
</div>
    </div>
  );
};

export default Dashboard;
