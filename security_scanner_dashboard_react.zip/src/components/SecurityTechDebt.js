import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';

const SecurityTechDebt = () => {
  // Place all hooks at the top of the component
  const [techDebtData, setTechDebtData] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('business_impact');
  const [showResolved, setShowResolved] = useState(true);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    fetchTechDebtData();
  }, []);

  useEffect(() => { setCurrentPage(1); }, [filterAIT, filterSPK, filterRepo, pageSize]);

  const fetchTechDebtData = async () => {
    try {
      const res = await API.get('/api/security-tech-debt');
      // Ensure the response has the expected structure
      const data = res.data || {};
      setTechDebtData({
        summary: data.summary || {},
        by_category: data.by_category || {}
      });
    } catch (error) {
      console.error('Error fetching security tech debt:', error);
      // Set default data structure on error
      setTechDebtData({
        summary: {},
        by_category: {}
      });
    }
  };

  const handleFixIssue = async (issueId) => {
    try {
      // Find the current issue to determine its status
      const currentIssue = sortedIssues.find(issue => issue.id === issueId);
      const newStatus = currentIssue?.status === 'RESOLVED' ? 'PENDING' : 'RESOLVED';
      
      await API.put(`/api/issues/${issueId}/status`, { status: newStatus });
      fetchTechDebtData();
      
      // Show success message
      const message = newStatus === 'RESOLVED' 
        ? 'Issue marked as resolved successfully!' 
        : 'Issue marked as pending successfully!';
      alert(message);
    } catch (error) {
      console.error('Failed to update issue status:', error);
      alert('Failed to update issue status. Please try again.');
    }
  };

  const handleViewDetails = (issue) => {
    setSelectedIssue(issue);
    setShowDetailsModal(true);
  };

  const handleCloseDetails = () => {
    setShowDetailsModal(false);
    setSelectedIssue(null);
  };

  if (!techDebtData) {
    return <p className="text-center mt-5">Loading security tech debt analysis...</p>;
  }

  const { summary, by_category } = techDebtData;
  
  // Ensure summary and by_category are objects
  const safeSummary = summary || {};
  const safeByCategory = by_category || {};
  
  // Get all issues for filtering and sorting
  const allIssues = safeByCategory ? Object.values(safeByCategory).flat() : [];
  
  // Add mapping functions (reuse from ThreatGuardDashboard.js)
  const aitData = [
    { id: 'AIT001', name: 'AIT-Web-Development' },
    { id: 'AIT002', name: 'AIT-Mobile-Apps' },
    { id: 'AIT003', name: 'AIT-Cloud-Services' },
    { id: 'AIT004', name: 'AIT-Data-Analytics' },
    { id: 'AIT005', name: 'AIT-Security-Tools' }
  ];
  const spkData = {
    'AIT001': [
      { id: 'SPK001', name: 'SPK-Frontend-React' },
      { id: 'SPK002', name: 'SPK-Backend-NodeJS' },
      { id: 'SPK003', name: 'SPK-Database-MongoDB' }
    ],
    'AIT002': [
      { id: 'SPK004', name: 'SPK-Android-Native' },
      { id: 'SPK005', name: 'SPK-iOS-Swift' },
      { id: 'SPK006', name: 'SPK-React-Native' }
    ],
    'AIT003': [
      { id: 'SPK007', name: 'SPK-AWS-Services' },
      { id: 'SPK008', name: 'SPK-Azure-Cloud' },
      { id: 'SPK009', name: 'SPK-GCP-Platform' }
    ],
    'AIT004': [
      { id: 'SPK010', name: 'SPK-Python-Analytics' },
      { id: 'SPK011', name: 'SPK-R-Statistics' },
      { id: 'SPK012', name: 'SPK-ML-Models' }
    ],
    'AIT005': [
      { id: 'SPK013', name: 'SPK-Penetration-Testing' },
      { id: 'SPK014', name: 'SPK-Vulnerability-Scan' },
      { id: 'SPK015', name: 'SPK-Security-Audit' }
    ]
  };
  const repoData = {
    'SPK001': [
      { id: 'REPO001', name: 'user-management-frontend' },
      { id: 'REPO002', name: 'dashboard-ui-components' },
      { id: 'REPO003', name: 'admin-panel-react' }
    ],
    'SPK002': [
      { id: 'REPO004', name: 'api-gateway-service' },
      { id: 'REPO005', name: 'user-authentication-api' },
      { id: 'REPO006', name: 'payment-processing-api' }
    ],
    // ... (add more as needed)
  };
  const getAITName = (aitId) => {
    if (!aitId) return '';
    const ait = aitData.find(ait => ait.id === aitId);
    return ait ? ait.name : aitId;
  };
  const getSPKName = (spkId) => {
    if (!spkId) return '';
    for (const spks of Object.values(spkData || {})) {
      const spk = spks.find(s => s.id === spkId);
      if (spk) return spk.name;
    }
    return spkId;
  };
  const getRepoName = (repoId) => {
    if (!repoId) return '';
    for (const repos of Object.values(repoData || {})) {
      const repo = repos.find(r => r.id === repoId);
      if (repo) return repo.name;
    }
    return repoId;
  };

  // Filter issues by selected AIT, SPK, Repo
  let filteredIssues = selectedCategory === 'all' 
    ? allIssues 
    : (safeByCategory && safeByCategory[selectedCategory]) ? safeByCategory[selectedCategory] : [];
  
  // Ensure filteredIssues is always an array
  if (!Array.isArray(filteredIssues)) {
    filteredIssues = [];
  }
  
  if (!showResolved) {
    filteredIssues = filteredIssues.filter(issue => issue.status !== 'RESOLVED');
  }
  if (filterAIT) filteredIssues = filteredIssues.filter(issue => issue.ait_tag === filterAIT);
  if (filterSPK) filteredIssues = filteredIssues.filter(issue => issue.spk_tag === filterSPK);
  if (filterRepo) filteredIssues = filteredIssues.filter(issue => issue.repo_name === filterRepo);

  // Sort issues
  const sortedIssues = [...filteredIssues].sort((a, b) => {
    if (sortBy === 'business_impact') {
      const impactOrder = { 'Critical': 3, 'High': 2, 'Medium': 1, 'Low': 0 };
      return impactOrder[b.business_impact] - impactOrder[a.business_impact];
    }
    if (sortBy === 'remediation_effort') {
      return b.remediation_effort - a.remediation_effort;
    }
    if (sortBy === 'severity') {
      const severityOrder = { 'CRITICAL': 4, 'MAJOR': 3, 'MINOR': 2, 'INFO': 1 };
      return severityOrder[b.severity] - severityOrder[a.severity];
    }
    return 0;
  });

  // Calculate paginated issues
  const totalPages = Math.ceil(filteredIssues.length / pageSize) || 1;
  const paginatedIssues = filteredIssues.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const categoryMapping = {
    'HARDCODED_CREDENTIALS': { name: 'Hardcoded Credentials', icon: '��', color: '#dc3545' },
    'HARDCODED_URLS': { name: 'Hardcoded URLs', icon: '🌐', color: '#fd7e14' },
    'INPUT_VALIDATION': { name: 'Input Validation', icon: '🛡️', color: '#ffc107' },
    'VULNERABLE_LIBRARIES': { name: 'Vulnerable Libraries', icon: '📚', color: '#6f42c1' },
    'PLAIN_TEXT_STORAGE': { name: 'Plain Text Storage', icon: '💾', color: '#dc3545' },
    'CORS_POLICY': { name: 'CORS Policy', icon: '🌍', color: '#20c997' },
    'RATE_LIMITING': { name: 'Rate Limiting', icon: '⏱️', color: '#0dcaf0' },
    'SECURE_COOKIES': { name: 'Secure Cookies', icon: '🍪', color: '#fd7e14' },
    'SSL_TLS': { name: 'SSL/TLS', icon: '🔒', color: '#dc3545' },
    'SECRETS_MANAGEMENT': { name: 'Secrets Management', icon: '🗝️', color: '#6f42c1' },
    'GENERAL_SECURITY_DEBT': { name: 'General Security Debt', icon: '⚠️', color: '#6c757d' },
    'MALICIOUS_CODE': { name: 'Malicious Code', icon: '🦠', color: '#dc3545' },
    'TIME_BASED_THREAT': { name: 'Time-Based Threat', icon: '⏰', color: '#fd7e14' },
    'USER_TARGETED_THREAT': { name: 'User-Targeted Threat', icon: '👤', color: '#dc3545' },
    'DESTRUCTIVE_ACTION': { name: 'Destructive Action', icon: '💥', color: '#dc3545' },
    'FINANCIAL_SECURITY': { name: 'Financial Security', icon: '💰', color: '#dc3545' },
    'SECURITY_ISSUE': { name: 'Security Issue', icon: '🛡️', color: '#6c757d' },
    'UNKNOWN': { name: 'Security Vulnerability', icon: '⚠️', color: '#6c757d' },
    'ACCESS_CONTROL': { name: 'Access Control', icon: '👤', color: '#198754' }
  };

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3; // Show 3 pages before/after current
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  return (
    <div className="container-fluid mt-4 px-5" style={{ background: '#fff', color: '#222', minHeight: '100vh' }}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: '#0d6efd' }}>
          🔧 Security Technical Debt Dashboard
        </h2>
        <div className="d-flex gap-3">
          <select 
            className="form-select" 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)}
            style={{ width: '200px' }}
          >
            <option value="all">All Categories</option>
            {Object.keys(safeByCategory).map(cat => (
              <option key={cat} value={cat}>
                {categoryMapping[cat]?.name || cat}
              </option>
            ))}
          </select>
          <select 
            className="form-select" 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            style={{ width: '180px' }}
          >
            <option value="business_impact">Business Impact</option>
            <option value="remediation_effort">Effort Required</option>
            <option value="severity">Severity</option>
          </select>
          <div className="form-check">
            <input 
              className="form-check-input" 
              type="checkbox" 
              id="showResolved"
              checked={showResolved}
              onChange={(e) => setShowResolved(e.target.checked)}
            />
            <label className="form-check-label" htmlFor="showResolved">
              Show Resolved
            </label>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="row g-4 mb-5">
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #dc3545' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#dc3545' }}>{safeSummary.hardcoded_credentials}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Hardcoded Credentials</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #fd7e14' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#fd7e14' }}>{safeSummary.hardcoded_urls}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Hardcoded URLs</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #ffc107' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#ffc107' }}>{safeSummary.input_validation}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Input Validation</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #6f42c1' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#6f42c1' }}>{safeSummary.vulnerable_libraries}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Vulnerable Libraries</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #198754' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#198754' }}>{safeSummary.access_control}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Access Control</div>
            </div>
          </div>
        </div>
        <div className="col-md-2">
          <div className="card text-center" style={{ background: '#fff', border: '2px solid #0d6efd' }}>
            <div className="card-body">
              <div style={{ fontSize: '2rem', color: '#0d6efd' }}>{Math.round(safeSummary.total_effort_hours)}</div>
              <div style={{ fontSize: '0.85rem', color: '#888' }}>Total Hours</div>
            </div>
          </div>
        </div>
      </div>

      {/* Category Overview */}
      <div className="row g-3 mb-5">
        {Object.entries(safeByCategory).map(([category, issues]) => {
          const categoryInfo = categoryMapping[category] || { name: category, icon: '⚠️', color: '#6c757d' };
          return (
            <div key={category} className="col-md-4">
              <div 
                className="card h-100" 
                style={{ 
                  background: '#f8f9fa', 
                  border: `2px solid ${categoryInfo.color}`,
                  cursor: 'pointer'
                }}
                onClick={() => setSelectedCategory(category)}
              >
                <div className="card-body text-center">
                  <div style={{ fontSize: '2rem' }}>{categoryInfo.icon}</div>
                  <h6 style={{ color: categoryInfo.color, marginTop: '0.5rem' }}>
                    {categoryInfo.name}
                  </h6>
                  <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: categoryInfo.color }}>
                    {issues.length}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#888' }}>
                    {Math.round(issues.reduce((sum, issue) => sum + (issue.remediation_effort || 0), 0) / 60)}h effort
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Issues Table */}
      <div className="section" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb' }}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h3 style={{ color: '#0d6efd' }}>
            {selectedCategory === 'all' ? 'All Security Tech Debt Issues' : `${categoryMapping[selectedCategory]?.name || selectedCategory} Issues`}
          </h3>
          <span className="badge bg-primary">{filteredIssues.length} issues</span>
        </div>

        {/* Add filter controls above the table */}
        <div className="mb-3 p-3 bg-light rounded">
          <h6 className="mb-2" style={{ color: '#222' }}>
            <i className="bi bi-funnel"></i> Filter by Project Hierarchy
          </h6>
          <div className="row g-2">
            <div className="col-md-3">
              <select
                className="form-select form-select-sm"
                value={filterAIT}
                onChange={(e) => setFilterAIT(e.target.value)}
              >
                <option value="">All AITs</option>
                {Array.from(new Set(allIssues.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                  <option key={ait} value={ait}>{getAITName(ait)}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3">
              <select
                className="form-select form-select-sm"
                value={filterSPK}
                onChange={(e) => setFilterSPK(e.target.value)}
              >
                <option value="">All SPKs</option>
                {Array.from(new Set(allIssues.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                  <option key={spk} value={spk}>{getSPKName(spk)}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3">
              <select
                className="form-select form-select-sm"
                value={filterRepo}
                onChange={(e) => setFilterRepo(e.target.value)}
              >
                <option value="">All Repositories</option>
                {Array.from(new Set(allIssues.map(t => t.repo_name).filter(Boolean))).map(repo => (
                  <option key={repo} value={repo}>{getRepoName(repo)}</option>
                ))}
              </select>
            </div>
            <div className="col-md-3">
              <button
                className="btn btn-outline-secondary btn-sm w-100"
                onClick={() => {
                  setFilterAIT('');
                  setFilterSPK('');
                  setFilterRepo('');
                }}
              >
                <i className="bi bi-x-circle"></i> Clear Filters
              </button>
            </div>
          </div>
          {(filterAIT || filterSPK || filterRepo) && (
            <div className="mt-2">
              <small className="text-muted">
                Showing {filteredIssues.length} of {allIssues.length} issues
              </small>
            </div>
          )}
        </div>

        <div className="table-responsive">
          <table className="table table-bordered table-hover align-middle" style={{ background: '#fff' }}>
            <thead className="table-light">
              <tr>
                <th style={{ color: '#0d6efd' }}>Status</th>
                <th style={{ color: '#0d6efd' }}>Severity</th>
                <th style={{ color: '#0d6efd' }}>Category</th>
                <th style={{ color: '#0d6efd' }}>AIT → SPK → Repo</th>
                <th style={{ color: '#0d6efd' }}>File</th>
                <th style={{ color: '#0d6efd' }}>Line</th>
                <th style={{ color: '#0d6efd' }}>Issue</th>
                <th style={{ color: '#0d6efd' }}>Business Impact</th>
                <th style={{ color: '#0d6efd' }}>Effort</th>
                <th style={{ color: '#0d6efd' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedIssues.length > 0 ? (
                paginatedIssues.map((issue) => {
                  const categoryInfo = categoryMapping[issue.debt_category] || { 
          name: issue.debt_category_display || 'Security Vulnerability', 
          icon: '⚠️', 
          color: '#6c757d' 
        };
                  const isResolved = issue.status === 'RESOLVED';
                  return (
                    <tr key={issue.id} style={{
                      opacity: isResolved ? 0.6 : 1,
                      background: isResolved ? '#f8f9fa' : '#fff',
                      textDecoration: isResolved ? 'line-through' : 'none'
                    }}>
                      <td>
                        <span className={`badge ${
                          isResolved ? 'bg-success' : 'bg-warning'
                        }`}>
                          {isResolved ? '✅ Resolved' : '⏳ Pending'}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${
                          issue.severity === 'CRITICAL' ? 'bg-danger' :
                          issue.severity === 'MAJOR' ? 'bg-warning' :
                          issue.severity === 'MINOR' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {issue.severity || 'UNKNOWN'}
                        </span>
                      </td>
                                          <td>
                      <span style={{ color: categoryInfo.color }}>
                        {categoryInfo.icon} {categoryInfo.name}
                      </span>
                    </td>
                      <td style={{ fontSize: '0.85rem' }}>
                        <div style={{ color: '#0d6efd', fontWeight: 'bold' }}>{getAITName(issue.ait_tag)}</div>
                        <div style={{ color: '#6f42c1' }}>→ {getSPKName(issue.spk_tag)}</div>
                        <div style={{ color: '#198754' }}>→ {getRepoName(issue.repo_name)}</div>
                        <div style={{ color: '#888', fontSize: '0.75rem' }}>Scan: {issue.scan_id ? issue.scan_id.substring(0, 8) : 'unknown'}...</div>
                      </td>
                      <td style={{ 
                        wordBreak: 'break-all', 
                        maxWidth: '200px',
                        fontSize: '0.85rem',
                        color: '#222'
                      }}>
                        {issue.file_name && issue.file_name !== "unknown_file" ? 
                         (typeof issue.file_name === 'string' && issue.file_name.includes("/") ? issue.file_name.split("/").pop() : 
                          typeof issue.file_name === 'string' && issue.file_name.includes("\\") ? issue.file_name.split("\\").pop() : 
                          issue.file_name) :
                         issue.file_path && issue.file_path !== "unknown_file" ? 
                         (typeof issue.file_path === 'string' && issue.file_path.includes("/") ? issue.file_path.split("/").pop() : 
                          typeof issue.file_path === 'string' && issue.file_path.includes("\\") ? issue.file_path.split("\\").pop() : 
                          issue.file_path) :
                         "Unknown File"}
                      </td>
                      <td className="text-center" style={{ color: '#0d6efd' }}>
                        {issue.line_number || 'N/A'}
                      </td>
                      <td style={{ maxWidth: '300px' }}>
                        <div style={{ fontWeight: 'bold', color: '#222', fontSize: '0.9rem' }}>
                          {issue.message || 'No message available'}
                        </div>
                        <div style={{ 
                          fontFamily: 'monospace', 
                          fontSize: '0.75rem', 
                          color: '#666',
                          background: '#f8f9fa',
                          padding: '0.25rem',
                          borderRadius: '3px',
                          marginTop: '0.25rem'
                        }}>
                          {issue.code_snippet ? issue.code_snippet.substring(0, 80) : 'No code snippet available'}...
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${
                          issue.business_impact === 'Critical' ? 'bg-danger' :
                          issue.business_impact === 'High' ? 'bg-warning text-dark' :
                          issue.business_impact === 'Medium' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {issue.business_impact || 'Medium'}
                        </span>
                      </td>
                      <td className="text-center">
                        <span style={{ fontWeight: 'bold', color: '#fd7e14' }}>
                          {issue.remediation_effort || 0}m
                        </span>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          {!isResolved ? (
                            <>
                              <button 
                                className="btn btn-sm btn-success"
                                onClick={() => handleFixIssue(issue.id)}
                                title="Mark as Fixed"
                              >
                                ✅
                              </button>
                              <button 
                                className="btn btn-sm btn-warning"
                                onClick={() => alert('Assign functionality coming soon!')}
                                title="Assign"
                              >
                                👤
                              </button>
                            </>
                          ) : (
                            <button 
                              className="btn btn-sm btn-secondary"
                              onClick={() => handleFixIssue(issue.id)}
                              title="Mark as Pending"
                            >
                              🔄
                            </button>
                          )}
                          <button 
                            className="btn btn-sm btn-info"
                            onClick={() => handleViewDetails(issue)}
                            title="View Details"
                          >
                            👁️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan="10" className="text-center" style={{ color: '#888', padding: '2rem' }}>
                    {!showResolved && allIssues.some(issue => issue.status === 'RESOLVED') 
                      ? '🎉 All issues in this category are resolved! Uncheck "Show Resolved" to see pending issues.'
                      : '🎉 No security tech debt issues found in this category!'
                    }
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Add pagination controls below the table */}
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div>
            <select className="form-select form-select-sm" style={{ width: 100, display: 'inline-block' }} value={pageSize} onChange={e => setPageSize(Number(e.target.value))}>
              {[10, 25, 50, 100].map(size => <option key={size} value={size}>{size} / page</option>)}
            </select>
            <span className="ms-2 text-muted">
              Showing {(filteredIssues.length === 0) ? 0 : ((currentPage - 1) * pageSize + 1)}-
              {Math.min(currentPage * pageSize, filteredIssues.length)} of {filteredIssues.length}
            </span>
          </div>
          <nav style={{ overflowX: 'auto', maxWidth: 400 }}>
            <ul className="pagination pagination-sm mb-0 flex-nowrap">
              <li className={`page-item${currentPage === 1 ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.max(1, p - 1))}>Prev</button> </li>
              {getPaginationWindow(currentPage, totalPages).map((page, idx) =>
                page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                  <li key={page + idx} className="page-item disabled"><span className="page-link">...</span></li>
                ) : (
                  <li key={page} className={`page-item${page === currentPage ? ' active' : ''}`}>
                    <button className="page-link" onClick={() => setCurrentPage(page)}>{page}</button>
                  </li>
                )
              )}
              <li className={`page-item${currentPage === totalPages ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}>Next</button> </li>
            </ul>
          </nav>
        </div>
      </div>

      {/* Remediation Recommendations */}
      {sortedIssues.length > 0 && (
        <div className="mt-5">
          <div className="card" style={{ background: '#f8f9fa', border: '1px solid #e5e7eb' }}>
            <div className="card-header" style={{ background: '#e9f3ff' }}>
              <h5 style={{ color: '#0d6efd' }}>🛠️ Remediation Recommendations</h5>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <h6 style={{ color: '#dc3545' }}>High Priority (Complete First)</h6>
                  <ul>
                    {sortedIssues
                      .filter(issue => issue.business_impact === 'Critical' || issue.business_impact === 'High')
                      .slice(0, 5)
                      .map(issue => (
                        <li key={issue.id} style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
                          <strong>{categoryMapping[issue.debt_category]?.name || issue.debt_category_display || 'Security Vulnerability'}:</strong> {issue.suggested_fix || 'No fix suggestion available'}
                        </li>
                      ))
                    }
                  </ul>
                </div>
                <div className="col-md-6">
                  <h6 style={{ color: '#0d6efd' }}>Implementation Timeline</h6>
                  <div style={{ fontSize: '0.9rem' }}>
                    <div className="mb-2">
                      <strong>Sprint 1 (Critical):</strong> {Math.round(
                        sortedIssues
                          .filter(i => i.business_impact === 'Critical')
                          .reduce((sum, i) => sum + (i.remediation_effort || 0), 0) / 60
                      )} hours
                    </div>
                    <div className="mb-2">
                      <strong>Sprint 2-3 (High):</strong> {Math.round(
                        sortedIssues
                          .filter(i => i.business_impact === 'High')
                          .reduce((sum, i) => sum + (i.remediation_effort || 0), 0) / 60
                      )} hours
                    </div>
                    <div className="mb-2">
                      <strong>Future Sprints (Medium/Low):</strong> {Math.round(
                        sortedIssues
                          .filter(i => ['Medium', 'Low'].includes(i.business_impact))
                          .reduce((sum, i) => sum + (i.remediation_effort || 0), 0) / 60
                      )} hours
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Issue Details Modal */}
      {showDetailsModal && selectedIssue && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header" style={{ background: '#e9f3ff' }}>
                <h5 className="modal-title" style={{ color: '#0d6efd' }}>
                  🔍 Security Tech Debt Details
                </h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={handleCloseDetails}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6 style={{ color: '#0d6efd' }}>Issue Information</h6>
                    <table className="table table-sm">
                      <tbody>
                        <tr>
                          <td><strong>Category:</strong></td>
                          <td>{categoryMapping[selectedIssue.debt_category]?.name || selectedIssue.debt_category_display || 'Security Vulnerability'}</td>
                        </tr>
                        <tr>
                          <td><strong>File:</strong></td>
                          <td>{selectedIssue.file_name && selectedIssue.file_name !== "unknown_file" ? 
                               (typeof selectedIssue.file_name === 'string' && selectedIssue.file_name.includes("/") ? selectedIssue.file_name.split("/").pop() : 
                                typeof selectedIssue.file_name === 'string' && selectedIssue.file_name.includes("\\") ? selectedIssue.file_name.split("\\").pop() : 
                                selectedIssue.file_name) :
                               selectedIssue.file_path && selectedIssue.file_path !== "unknown_file" ? 
                               (typeof selectedIssue.file_path === 'string' && selectedIssue.file_path.includes("/") ? selectedIssue.file_path.split("/").pop() : 
                                typeof selectedIssue.file_path === 'string' && selectedIssue.file_path.includes("\\") ? selectedIssue.file_path.split("\\").pop() : 
                                selectedIssue.file_path) :
                               "Unknown File"}</td>
                        </tr>
                        <tr>
                          <td><strong>Line:</strong></td>
                          <td>{selectedIssue.line_number || 'N/A'}</td>
                        </tr>
                        <tr>
                          <td><strong>Status:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.status === 'RESOLVED' ? 'bg-success' : 'bg-warning'
                            }`}>
                              {selectedIssue.status === 'RESOLVED' ? '✅ Resolved' : '⏳ Pending'}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Severity:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.severity === 'CRITICAL' ? 'bg-danger' :
                              selectedIssue.severity === 'MAJOR' ? 'bg-warning text-dark' :
                              selectedIssue.severity === 'MINOR' ? 'bg-info' : 'bg-secondary'
                            }`}>
                              {selectedIssue.severity}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Business Impact:</strong></td>
                          <td>
                            <span className={`badge ${
                              selectedIssue.business_impact === 'Critical' ? 'bg-danger' :
                              selectedIssue.business_impact === 'High' ? 'bg-warning text-dark' :
                              selectedIssue.business_impact === 'Medium' ? 'bg-info' : 'bg-secondary'
                            }`}>
                              {selectedIssue.business_impact}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Remediation Effort:</strong></td>
                          <td>{selectedIssue.remediation_effort || 0} minutes</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="col-md-6">
                    <h6 style={{ color: '#0d6efd' }}>Hierarchical Tags</h6>
                    <div style={{ background: '#f8f9fa', padding: '1rem', borderRadius: '5px' }}>
                      <div><strong>AIT:</strong> {selectedIssue.ait_tag || 'N/A'}</div>
                      <div><strong>SPK:</strong> {selectedIssue.spk_tag || 'N/A'}</div>
                      <div><strong>Repo:</strong> {selectedIssue.repo_name || 'N/A'}</div>
                      <div><strong>Scan ID:</strong> {selectedIssue.scan_id || 'N/A'}</div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Issue Description</h6>
                  <p style={{ background: '#f8f9fa', padding: '1rem', borderRadius: '5px' }}>
                    {selectedIssue.message || 'No message available'}
                  </p>
                </div>

                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Code Snippet</h6>
                  <pre style={{ 
                    background: '#f8f9fa', 
                    padding: '1rem', 
                    borderRadius: '5px',
                    fontSize: '0.85rem',
                    border: '1px solid #e5e7eb'
                  }}>
                    {selectedIssue.code_snippet || 'No code snippet available'}
                  </pre>
                </div>

                <div className="mt-3">
                  <h6 style={{ color: '#0d6efd' }}>Suggested Fix</h6>
                  <p style={{ 
                    background: '#e8f5e8', 
                    padding: '1rem', 
                    borderRadius: '5px',
                    border: '1px solid #198754'
                  }}>
                    {selectedIssue.suggested_fix || 'No fix suggestion available'}
                  </p>
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className={`btn ${selectedIssue.status === 'RESOLVED' ? 'btn-warning' : 'btn-success'}`}
                  onClick={() => {
                    handleFixIssue(selectedIssue.id);
                    handleCloseDetails();
                  }}
                >
                  {selectedIssue.status === 'RESOLVED' ? '🔄 Mark as Pending' : '✅ Mark as Resolved'}
                </button>
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={handleCloseDetails}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecurityTechDebt;