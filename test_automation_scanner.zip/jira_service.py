#!/usr/bin/env python3
"""
JIRA Service for fetching acceptance criteria
Supports both mock and real JIRA connections
"""

import logging
from typing import Dict, List, Optional
from dataclasses import dataclass
import os

logger = logging.getLogger(__name__)

# Configuration: Set to False to use real JIRA connection
USE_MOCK_CONNECTION = os.getenv('JIRA_USE_MOCK', 'true').lower() == 'true'

# JIRA Base URL - default from the image
JIRA_BASE_URL = os.getenv('JIRA_BASE_URL', 'https://asd.asd.com/')

@dataclass
class JiraIssue:
    """JIRA Issue data structure"""
    key: str
    summary: str
    acceptance_criteria: str

class JiraConnector:
    """JIRA Connector with support for both mock and real connections"""
    
    @staticmethod
    def connect(server_url: str = None):
        """
        Connect to JIRA using the logic from the image
        
        Args:
            server_url: JIRA server URL (defaults to JIRA_BASE_URL)
            
        Returns:
            JIRA connection object
        """
        if USE_MOCK_CONNECTION:
            logger.info("Connecting to JIRA (MOCK MODE). Please give this a moment.")
            mock_jira = MockJira()
            logger.info("Connection established (MOCK MODE).")
            return mock_jira
        
        # Real JIRA connection logic from the image
        try:
            # These imports are for the actual JIRA connection
            # They may not be available in all environments (hence the try-except)
            from jira import JIRA  # type: ignore
            from requests_bofa.clients import horizon  # type: ignore
            
            logger.info("Connecting to JIRA. Please give this a moment.")
            
            # Use provided server_url or default
            if not server_url:
                server_url = JIRA_BASE_URL
            
            # Initialize options
            options = {'server': server_url}
            
            # Create horizon AtlassianClient session and login
            session = horizon.AtlassianClient()
            session.login()
            
            # Copy session headers and remove Authorization if present
            session_headers = dict(session.session.headers)
            if 'Authorization' in session_headers:
                del session_headers['Authorization']
            
            # Create JIRA object
            jira = JIRA(options, get_server_info=False)
            
            # Update JIRA session headers and cookies
            jira._session.headers.update(session_headers)
            jira._session.cookies.update(session.session.cookies)
            
            # Set authentication
            jira._session.auth = session.session.auth
            
            logger.info("Connection established.")
            return jira
            
        except ImportError as e:
            logger.error(f"Failed to import JIRA libraries: {e}")
            logger.warning("Falling back to mock connection")
            return MockJira()
        except Exception as e:
            logger.error(f"Error connecting to JIRA: {e}", exc_info=True)
            logger.warning("Falling back to mock connection")
            return MockJira()

class MockJira:
    """Mock JIRA object for testing"""
    
    def issue(self, issue_key: str):
        """Mock method to get JIRA issue"""
        return MockJiraIssue(issue_key)

class MockJiraIssue:
    """Mock JIRA Issue object"""
    
    def __init__(self, issue_key: str):
        self.key = issue_key
        self.fields = MockJiraFields(issue_key)

class MockJiraFields:
    """Mock JIRA Issue Fields"""
    
    def __init__(self, issue_key: str):
        self.summary = f"Mock Summary for {issue_key}"
        # Mock acceptance criteria - in production, this would come from customfield_10229
        self.customfield_10229 = self._get_mock_acceptance_criteria(issue_key)
    
    def _get_mock_acceptance_criteria(self, issue_key: str) -> str:
        """Generate mock acceptance criteria based on issue key"""
        # This is a placeholder - replace with actual JIRA connection logic
        mock_criteria = f"""
**Acceptance Criteria for {issue_key}:**

1. User should be able to perform the primary action successfully
2. All validation rules must be enforced
3. Error messages should be clear and actionable
4. The feature should work across all supported browsers
5. Performance should meet the defined SLA requirements

**Additional Requirements:**
- All edge cases must be handled gracefully
- Logging and monitoring should be in place
- Documentation should be updated
        """.strip()
        return mock_criteria

def save_acceptance_criteria_for_issue(jira, issue_key: str, output_file: str = None) -> Dict:
    """
    Fetch acceptance criteria for a JIRA issue
    Uses the logic from the image: fetches issue and extracts acceptance criteria from customfield_10229
    
    Args:
        jira: JIRA connection object
        issue_key: JIRA issue key (e.g., 'QWE-12', 'ORCIT-67155')
        output_file: Optional output file path (not used in API, kept for compatibility)
        
    Returns:
        Dictionary with issue_key, summary, and acceptance_criteria
    """
    try:
        logger.info(f"Fetching acceptance criteria for issue: {issue_key}")
        
        # Get issue from JIRA (matching the image logic)
        issue = jira.issue(issue_key)
        issue_summary = issue.fields.summary
        
        # Get acceptance criteria from custom field (customfield_10229 as shown in image)
        # Using getattr with default value matching the image logic
        acceptance_criteria = getattr(issue.fields, "customfield_10229", "No acceptance criteria found.")
        
        # Convert to string if it's not already
        if acceptance_criteria and not isinstance(acceptance_criteria, str):
            acceptance_criteria = str(acceptance_criteria)
        
        if not acceptance_criteria or acceptance_criteria == "No acceptance criteria found.":
            logger.warning(f"No acceptance criteria found for {issue_key}")
        
        result = {
            'issue_key': issue_key,
            'summary': issue_summary,
            'acceptance_criteria': acceptance_criteria
        }
        
        logger.info(f"Successfully fetched acceptance criteria for {issue_key}")
        return result
        
    except Exception as e:
        logger.error(f"Error fetching acceptance criteria for {issue_key}: {e}", exc_info=True)
        raise Exception(f"Failed to fetch acceptance criteria for {issue_key}: {str(e)}")

def fetch_acceptance_criteria_for_issues(issue_keys: List[str], server_url: str = None) -> List[Dict]:
    """
    Fetch acceptance criteria for multiple JIRA issues
    
    Args:
        issue_keys: List of JIRA issue keys (e.g., ['QWE-12', 'QWE-13', 'ORCIT-67155'])
        server_url: Optional JIRA server URL (defaults to JIRA_BASE_URL)
        
    Returns:
        List of dictionaries with issue_key, summary, and acceptance_criteria
    """
    try:
        # Use provided server_url or default to JIRA_BASE_URL
        if not server_url:
            server_url = JIRA_BASE_URL
        
        # Connect to JIRA using the connector
        jira = JiraConnector.connect(server_url)
        
        results = []
        for issue_key in issue_keys:
            try:
                result = save_acceptance_criteria_for_issue(jira, issue_key)
                results.append(result)
            except Exception as e:
                logger.error(f"Error processing issue {issue_key}: {e}")
                # Add error result
                results.append({
                    'issue_key': issue_key,
                    'summary': f"Error: {str(e)}",
                    'acceptance_criteria': f"Failed to fetch acceptance criteria: {str(e)}"
                })
        
        return results
        
    except Exception as e:
        logger.error(f"Error connecting to JIRA: {e}", exc_info=True)
        raise Exception(f"Failed to connect to JIRA: {str(e)}")

def generate_excel_prompt(acceptance_criteria_list: List[Dict]) -> str:
    """
    Generate a prompt that can be used to create Excel file with test cases
    based on acceptance criteria
    
    Args:
        acceptance_criteria_list: List of dictionaries with issue_key, summary, and acceptance_criteria
        
    Returns:
        Formatted prompt string
    """
    prompt = """# Generate Test Case Excel File from JIRA Acceptance Criteria

You are tasked with creating a functional test case Excel file based on the acceptance criteria from JIRA tickets below.

## Excel File Format Requirements

The Excel file must follow this exact format with the following columns:

### Required Columns:
1. **unique_id** - 4-digit test case ID (e.g., "1001", "1002") for test case summary rows, or step IDs (e.g., "1 step", "2 step") for test steps
2. **type** - Test type (e.g., "test_manu")
3. **name** - Test case name (e.g., "TC_01_Verify_Script_Details_Fields")
4. **step_type** - Step type: "simple" for actions, "validation" for verifications
5. **step_description** - Detailed description of the test step

### Additional Columns (optional but recommended):
6. **description** - Test case description
7. **backlog_coverage** - Backlog coverage value
8. **designer** - Designer name
9. **owner** - Owner name
10. **test_type** - Test type/Feature Testing
11. **product_areas** - Product areas
12. **automation_candidate_udf** - Automation candidate (Yes/No)
13. **automation_status** - Automation status (e.g., "Not Automated")
14. **test_category_udf** - Test category (e.g., "System Integration")
15. **ait_udf** - AIT value
16. **team_udf** - Team value

### Excel Structure:
- **Row 1**: Headers (all column names)
- **Row 2**: Test case summary row with 4-digit unique_id (e.g., "1001")
- **Row 3 onwards**: Test steps with step IDs (e.g., "1 step", "2 step", "3 step")

### Important Notes:
- Each test case must start with a row containing a 4-digit unique_id
- Test steps should have sequential step IDs (e.g., "1 step", "2 step")
- Step descriptions should be clear, actionable, and testable
- Include both positive and negative test scenarios
- Add validation steps to verify expected outcomes

## JIRA Acceptance Criteria

"""
    
    # Add acceptance criteria for each JIRA issue
    for idx, ac_data in enumerate(acceptance_criteria_list, 1):
        prompt += f"""
### {idx}. {ac_data['issue_key']}: {ac_data['summary']}

**Acceptance Criteria:**
{ac_data['acceptance_criteria']}

---
"""
    
    prompt += """
## Instructions

Based on the acceptance criteria above, generate a comprehensive Excel file with:

1. **Test Case Summary Rows**: One row per test case with 4-digit unique_id
2. **Test Steps**: Detailed steps covering all acceptance criteria
3. **Step Types**: Use "simple" for actions (clicks, inputs, navigation) and "validation" for verifications
4. **Coverage**: Ensure all acceptance criteria are covered by test steps
5. **Completeness**: Include setup, execution, and cleanup steps where applicable

## Example Test Case Structure

For a test case with unique_id "1001":

| unique_id | type | name | step_type | step_description |
|-----------|------|------|-----------|-------------------|
| 1001 | test_manu | TC_01_Verify_Feature | | |
| 1 step | test_manu | TC_01_Verify_Feature | simple | Navigate to the application URL |
| 2 step | test_manu | TC_01_Verify_Feature | simple | Click on the feature button |
| 3 step | test_manu | TC_01_Verify_Feature | validation | Verify the feature page is displayed |
| 4 step | test_manu | TC_01_Verify_Feature | validation | Verify all required fields are present |

Generate the complete Excel file following this format for all acceptance criteria provided above.
"""
    
    return prompt
