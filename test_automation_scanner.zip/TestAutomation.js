import React, { useState } from "react";
import API from "../api";
import {
  FaFileExcel,
  FaFolder,
  FaGithub,
  FaSpinner,
  FaCheckCircle,
  FaExclamationCircle,
  FaUpload,
  FaJira,
  FaDownload
} from "react-icons/fa";

const TestAutomation = ({ jobResults, setJobResults }) => {
  // JIRA ticket IDs state
  const [jiraTicketIds, setJiraTicketIds] = useState('');
  
  // Test automation specific states
  const [testCaseFile, setTestCaseFile] = useState(null);
  const [testLocatorsPath, setTestLocatorsPath] = useState('');
  const [cloneUrl, setCloneUrl] = useState('');
  const [repoToken, setRepoToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [generatingPrompt, setGeneratingPrompt] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Handle JIRA ticket IDs change
  const handleJiraTicketIdsChange = (value) => {
    setJiraTicketIds(value);
    setError('');
    setSuccess('');
  };

  // Handle file upload
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
          file.name.endsWith('.xlsx')) {
        setTestCaseFile(file);
        setError('');
        setSuccess('');
      } else {
        setError('Please upload a valid Excel file (.xlsx)');
        setTestCaseFile(null);
      }
    }
  };

  // Validate JIRA ticket IDs format
  const validateJiraTicketIds = (ticketIds) => {
    if (!ticketIds || !ticketIds.trim()) {
      return { valid: false, error: 'Please enter at least one JIRA ticket ID' };
    }
    
    const ticketIdPattern = /^[A-Z]+-\d+$/;
    const tickets = ticketIds.split(',').map(t => t.trim()).filter(t => t);
    
    if (tickets.length === 0) {
      return { valid: false, error: 'Please enter at least one valid JIRA ticket ID' };
    }
    
    const invalidTickets = tickets.filter(t => !ticketIdPattern.test(t));
    if (invalidTickets.length > 0) {
      return { 
        valid: false, 
        error: `Invalid JIRA ticket ID format: ${invalidTickets.join(', ')}. Expected format: PROJECT-123` 
      };
    }
    
    return { valid: true, tickets };
  };

  // Handle Generate Excel Prompt
  const handleGenerateExcelPrompt = async () => {
    setError('');
    setSuccess('');
    
    const validation = validateJiraTicketIds(jiraTicketIds);
    if (!validation.valid) {
      setError(validation.error);
      return;
    }
    
    setGeneratingPrompt(true);
    
    try {
      console.log('🚀 Generating Excel prompt for JIRA tickets:', validation.tickets);
      
      const response = await API.post('/api/jira/generate-excel-prompt', {
        jira_ticket_ids: jiraTicketIds
      }, {
        responseType: 'blob' // Important for file download
      });
      
      // Create blob and download
      const blob = new Blob([response.data], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Generate filename with timestamp
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
      link.download = `excel_generation_prompt_${timestamp}.txt`;
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      setSuccess(`Excel generation prompt downloaded successfully for ${validation.tickets.length} JIRA ticket(s)!`);
      console.log('✅ Excel prompt generated and downloaded');
      
    } catch (err) {
      console.error('❌ Error generating Excel prompt:', err);
      let errorMessage = 'Failed to generate Excel prompt';
      
      if (err.response) {
        // If response is a blob (error response), try to parse it
        if (err.response.data instanceof Blob) {
          err.response.data.text().then(text => {
            try {
              const errorData = JSON.parse(text);
              setError(errorData.error || errorMessage);
            } catch (e) {
              setError(errorMessage);
            }
          }).catch(() => {
            setError(errorMessage);
          });
        } else if (err.response.data && typeof err.response.data === 'object') {
          errorMessage = err.response.data.error || errorMessage;
          setError(errorMessage);
        } else {
          setError(errorMessage);
        }
      } else {
        setError(err.message || errorMessage);
      }
    } finally {
      setGeneratingPrompt(false);
    }
  };

  // Validate form
  const validateForm = () => {
    if (!jiraTicketIds || !jiraTicketIds.trim()) {
      setError('Please enter JIRA ticket IDs');
      return false;
    }
    
    const validation = validateJiraTicketIds(jiraTicketIds);
    if (!validation.valid) {
      setError(validation.error);
      return false;
    }
    
    if (!testCaseFile) {
      setError('Please upload a test case Excel file');
      return false;
    }
    if (!testLocatorsPath.trim()) {
      setError('Please provide the test locators path');
      return false;
    }
    if (!cloneUrl.trim()) {
      setError('Please provide the repository clone URL');
      return false;
    }
    return true;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validateForm()) {
      return;
    }

    setSubmitting(true);

    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('test_case_file', testCaseFile);
      formData.append('test_locators_path', testLocatorsPath);
      formData.append('clone_url', cloneUrl);
      formData.append('jira_ticket_ids', jiraTicketIds);
      if (repoToken) {
        formData.append('repo_token', repoToken);
      }

      console.log('🚀 Submitting test automation scan:', {
        jira_ticket_ids: jiraTicketIds,
        test_locators_path: testLocatorsPath,
        clone_url: cloneUrl,
        file_name: testCaseFile.name
      });

      const response = await API.post('/api/jobs/test-automation-scan', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      console.log('✅ Test automation scan job created:', response.data);

      setSuccess(`Test automation scan job created successfully! Job ID: ${response.data.job_id}`);
      
      // Reset form (keep JIRA ticket IDs)
      setTestCaseFile(null);
      setTestLocatorsPath('');
      setCloneUrl('');
      setRepoToken('');
      setShowTokenInput(false);
      
      // Reset file input
      const fileInput = document.getElementById('testCaseFile');
      if (fileInput) {
        fileInput.value = '';
      }

      // Optionally navigate to job monitor
      setTimeout(() => {
        window.location.href = '/job-monitor';
      }, 2000);

    } catch (err) {
      console.error('❌ Error creating test automation scan job:', err);
      const errorMessage = err.response?.data?.error || err.message || 'Failed to create test automation scan job';
      setError(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container-fluid">
      <div className="card shadow-sm">
        <div className="card-header bg-info text-white">
          <h5 className="mb-0">
            <FaFileExcel className="me-2" />
            Test Automation Scan
          </h5>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            {/* JIRA Ticket IDs Input */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaJira className="me-2" />
                    JIRA Ticket IDs
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="e.g., QWE-12, QWE-13, QWE-14"
                    value={jiraTicketIds}
                    onChange={(e) => handleJiraTicketIdsChange(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    className="btn btn-success"
                    onClick={handleGenerateExcelPrompt}
                    disabled={generatingPrompt || !jiraTicketIds.trim()}
                  >
                    {generatingPrompt ? (
                      <>
                        <FaSpinner className="fa-spin me-2" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <FaDownload className="me-2" />
                        Generate Excel Prompt
                      </>
                    )}
                  </button>
                </div>
                <small className="form-text text-muted">
                  Enter JIRA ticket IDs separated by commas (e.g., QWE-12, QWE-13, QWE-14). 
                  Click "Generate Excel Prompt" to download a prompt file that can be used to generate the test case Excel file.
                </small>
              </div>
            </div>

            {/* Test Case File Upload */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaFileExcel className="me-2" />
                    Test Case Excel File (.xlsx)
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="file"
                  className="form-control"
                  id="testCaseFile"
                  accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  onChange={handleFileChange}
                  required
                />
                <small className="form-text text-muted">
                  Upload a functional test case Excel file in .xlsx format
                </small>
                {testCaseFile && (
                  <div className="mt-2">
                    <span className="badge bg-success">
                      <FaCheckCircle className="me-1" />
                      {testCaseFile.name} ({(testCaseFile.size / 1024).toFixed(2)} KB)
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Test Locators Path */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaFolder className="me-2" />
                    Test Locators Path
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g., tests/locators, src/test/resources/locators"
                  value={testLocatorsPath}
                  onChange={(e) => setTestLocatorsPath(e.target.value)}
                  required
                />
                <small className="form-text text-muted">
                  Path where test locators are available in the repository (relative to repo root)
                </small>
              </div>
            </div>

            {/* Clone URL */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaGithub className="me-2" />
                    Repository Clone URL
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://github.com/owner/repository.git"
                  value={cloneUrl}
                  onChange={(e) => setCloneUrl(e.target.value)}
                  required
                />
                <small className="form-text text-muted">
                  Full URL to clone the repository (GitHub, Bitbucket, etc.)
                </small>
              </div>
            </div>

            {/* Optional Token */}
            <div className="row mb-4">
              <div className="col-12">
                <div className="form-check mb-2">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="useToken"
                    checked={showTokenInput}
                    onChange={(e) => setShowTokenInput(e.target.checked)}
                  />
                  <label className="form-check-label" htmlFor="useToken">
                    Use authentication token (for private repositories)
                  </label>
                </div>
                {showTokenInput && (
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Enter repository token"
                    value={repoToken}
                    onChange={(e) => setRepoToken(e.target.value)}
                  />
                )}
              </div>
            </div>

            {/* Error/Success Messages */}
            {error && (
              <div className="alert alert-danger d-flex align-items-center" role="alert">
                <FaExclamationCircle className="me-2" />
                <div>{error}</div>
              </div>
            )}

            {success && (
              <div className="alert alert-success d-flex align-items-center" role="alert">
                <FaCheckCircle className="me-2" />
                <div>{success}</div>
              </div>
            )}

            {/* Submit Button */}
            <div className="row">
              <div className="col-12">
                <button
                  type="submit"
                  className="btn btn-primary btn-lg"
                  disabled={submitting || !jiraTicketIds.trim() || !testCaseFile || !testLocatorsPath || !cloneUrl}
                >
                  {submitting ? (
                    <>
                      <FaSpinner className="fa-spin me-2" />
                      Creating Scan Job...
                    </>
                  ) : (
                    <>
                      <FaUpload className="me-2" />
                      Start Test Automation Scan
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TestAutomation;

