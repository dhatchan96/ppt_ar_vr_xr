import React, { useState } from "react";
import API from "../api";
import { 
  getAitData, 
  getSpkData, 
  getRepoData,
  getAITName,
  getSPKName,
  getRepoName
} from '../config/dropdownData';
import {
  FaFileExcel,
  FaFolder,
  FaGithub,
  FaSpinner,
  FaCheckCircle,
  FaExclamationCircle,
  FaUpload
} from "react-icons/fa";

const TestAutomation = ({ jobResults, setJobResults }) => {
  // Cascading dropdown states
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');
  
  // Test automation specific states
  const [testCaseFile, setTestCaseFile] = useState(null);
  const [testLocatorsPath, setTestLocatorsPath] = useState('');
  const [cloneUrl, setCloneUrl] = useState('');
  const [repoToken, setRepoToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Get dropdown data
  const aitData = getAitData();
  const spkData = getSpkData(selectedAIT);
  const repoData = getRepoData(selectedSPK);

  // Handle dropdown changes
  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
    setError('');
    setSuccess('');
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
    setError('');
    setSuccess('');
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
    setError('');
    setSuccess('');
  };

  // Handle file upload
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
          file.name.endsWith('.xlsx')) {
        setTestCaseFile(file);
        setError('');
        setSuccess('');
      } else {
        setError('Please upload a valid Excel file (.xlsx)');
        setTestCaseFile(null);
      }
    }
  };

  // Validate form
  const validateForm = () => {
    if (!selectedAIT) {
      setError('Please select an AIT');
      return false;
    }
    if (!selectedSPK) {
      setError('Please select an SPK');
      return false;
    }
    if (!selectedRepo) {
      setError('Please select a Repository');
      return false;
    }
    if (!testCaseFile) {
      setError('Please upload a test case Excel file');
      return false;
    }
    if (!testLocatorsPath.trim()) {
      setError('Please provide the test locators path');
      return false;
    }
    if (!cloneUrl.trim()) {
      setError('Please provide the repository clone URL');
      return false;
    }
    return true;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!validateForm()) {
      return;
    }

    setSubmitting(true);

    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('test_case_file', testCaseFile);
      formData.append('test_locators_path', testLocatorsPath);
      formData.append('clone_url', cloneUrl);
      formData.append('ait_tag', selectedAIT);
      formData.append('spk_tag', selectedSPK);
      formData.append('repo_name', selectedRepo);
      if (repoToken) {
        formData.append('repo_token', repoToken);
      }

      console.log('🚀 Submitting test automation scan:', {
        ait_tag: selectedAIT,
        spk_tag: selectedSPK,
        repo_name: selectedRepo,
        test_locators_path: testLocatorsPath,
        clone_url: cloneUrl,
        file_name: testCaseFile.name
      });

      const response = await API.post('/api/jobs/test-automation-scan', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      console.log('✅ Test automation scan job created:', response.data);

      setSuccess(`Test automation scan job created successfully! Job ID: ${response.data.job_id}`);
      
      // Reset form
      setTestCaseFile(null);
      setTestLocatorsPath('');
      setCloneUrl('');
      setRepoToken('');
      setShowTokenInput(false);
      
      // Reset file input
      const fileInput = document.getElementById('testCaseFile');
      if (fileInput) {
        fileInput.value = '';
      }

      // Optionally navigate to job monitor
      setTimeout(() => {
        window.location.href = '/job-monitor';
      }, 2000);

    } catch (err) {
      console.error('❌ Error creating test automation scan job:', err);
      const errorMessage = err.response?.data?.error || err.message || 'Failed to create test automation scan job';
      setError(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container-fluid">
      <div className="card shadow-sm">
        <div className="card-header bg-info text-white">
          <h5 className="mb-0">
            <FaFileExcel className="me-2" />
            Test Automation Scan
          </h5>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            {/* AIT/SPK/Repo Dropdowns */}
            <div className="row mb-4">
              <div className="col-md-4">
                <label className="form-label">
                  <strong>AIT (Application Integration Team)</strong>
                  <span className="text-danger">*</span>
                </label>
                <select
                  className="form-select"
                  value={selectedAIT}
                  onChange={(e) => handleAITChange(e.target.value)}
                  required
                >
                  <option value="">Select AIT</option>
                  {aitData.map(ait => (
                    <option key={ait.value} value={ait.value}>
                      {ait.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-md-4">
                <label className="form-label">
                  <strong>SPK (Specific Product/Workstream Key)</strong>
                  <span className="text-danger">*</span>
                </label>
                <select
                  className="form-select"
                  value={selectedSPK}
                  onChange={(e) => handleSPKChange(e.target.value)}
                  disabled={!selectedAIT}
                  required
                >
                  <option value="">Select SPK</option>
                  {spkData.map(spk => (
                    <option key={spk.value} value={spk.value}>
                      {spk.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="col-md-4">
                <label className="form-label">
                  <strong>Repository</strong>
                  <span className="text-danger">*</span>
                </label>
                <select
                  className="form-select"
                  value={selectedRepo}
                  onChange={(e) => handleRepoChange(e.target.value)}
                  disabled={!selectedSPK}
                  required
                >
                  <option value="">Select Repository</option>
                  {repoData.map(repo => (
                    <option key={repo.value} value={repo.value}>
                      {repo.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Test Case File Upload */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaFileExcel className="me-2" />
                    Test Case Excel File (.xlsx)
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="file"
                  className="form-control"
                  id="testCaseFile"
                  accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  onChange={handleFileChange}
                  required
                />
                <small className="form-text text-muted">
                  Upload a functional test case Excel file in .xlsx format
                </small>
                {testCaseFile && (
                  <div className="mt-2">
                    <span className="badge bg-success">
                      <FaCheckCircle className="me-1" />
                      {testCaseFile.name} ({(testCaseFile.size / 1024).toFixed(2)} KB)
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Test Locators Path */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaFolder className="me-2" />
                    Test Locators Path
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="e.g., tests/locators, src/test/resources/locators"
                  value={testLocatorsPath}
                  onChange={(e) => setTestLocatorsPath(e.target.value)}
                  required
                />
                <small className="form-text text-muted">
                  Path where test locators are available in the repository (relative to repo root)
                </small>
              </div>
            </div>

            {/* Clone URL */}
            <div className="row mb-4">
              <div className="col-12">
                <label className="form-label">
                  <strong>
                    <FaGithub className="me-2" />
                    Repository Clone URL
                  </strong>
                  <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://github.com/owner/repository.git"
                  value={cloneUrl}
                  onChange={(e) => setCloneUrl(e.target.value)}
                  required
                />
                <small className="form-text text-muted">
                  Full URL to clone the repository (GitHub, Bitbucket, etc.)
                </small>
              </div>
            </div>

            {/* Optional Token */}
            <div className="row mb-4">
              <div className="col-12">
                <div className="form-check mb-2">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="useToken"
                    checked={showTokenInput}
                    onChange={(e) => setShowTokenInput(e.target.checked)}
                  />
                  <label className="form-check-label" htmlFor="useToken">
                    Use authentication token (for private repositories)
                  </label>
                </div>
                {showTokenInput && (
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Enter repository token"
                    value={repoToken}
                    onChange={(e) => setRepoToken(e.target.value)}
                  />
                )}
              </div>
            </div>

            {/* Error/Success Messages */}
            {error && (
              <div className="alert alert-danger d-flex align-items-center" role="alert">
                <FaExclamationCircle className="me-2" />
                <div>{error}</div>
              </div>
            )}

            {success && (
              <div className="alert alert-success d-flex align-items-center" role="alert">
                <FaCheckCircle className="me-2" />
                <div>{success}</div>
              </div>
            )}

            {/* Submit Button */}
            <div className="row">
              <div className="col-12">
                <button
                  type="submit"
                  className="btn btn-primary btn-lg"
                  disabled={submitting || !selectedAIT || !selectedSPK || !selectedRepo || !testCaseFile || !testLocatorsPath || !cloneUrl}
                >
                  {submitting ? (
                    <>
                      <FaSpinner className="fa-spin me-2" />
                      Creating Scan Job...
                    </>
                  ) : (
                    <>
                      <FaUpload className="me-2" />
                      Start Test Automation Scan
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TestAutomation;

