#!/usr/bin/env python3
"""
Job Manager for asynchronous repository scanning
"""

import json
import uuid
import threading
import time
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import logging
import os

logger = logging.getLogger(__name__)

class JobStatus:
    """Job status constants"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class JobManager:
    """Manages asynchronous repository scanning jobs"""
    
    def __init__(self, db_path: str = "threatguard_data/jobs.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(exist_ok=True)
        self.jobs: Dict[str, Dict] = {}
        self.init_database()
        
    def init_database(self):
        """Initialize the jobs database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS scan_jobs (
                        job_id TEXT PRIMARY KEY,
                        scan_id TEXT,
                        repo_url TEXT,
                        repo_type TEXT,
                        status TEXT,
                        progress TEXT,
                        created_at TEXT,
                        started_at TEXT,
                        completed_at TEXT,
                        result_data TEXT,
                        error_message TEXT,
                        ait_tag TEXT,
                        spk_tag TEXT,
                        repo_name TEXT
                    )
                ''')
                conn.commit()
                logger.info("Jobs database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize jobs database: {e}")
    
    def create_job(self, scan_data: Dict) -> str:
        """Create a new repository scan job"""
        job_id = str(uuid.uuid4())
        
        job = {
            'job_id': job_id,
            'scan_id': scan_data.get('scan_id'),
            'repo_url': scan_data.get('repo_url'),
            'repo_type': scan_data.get('repo_type', 'unknown'),
            'status': JobStatus.PENDING,
            'progress': 'Job created',
            'created_at': datetime.now().isoformat(),
            'started_at': None,
            'completed_at': None,
            'result_data': None,
            'error_message': None,
            'ait_tag': scan_data.get('ait_tag'),
            'spk_tag': scan_data.get('spk_tag'),
            'repo_name': scan_data.get('repo_name')
        }
        
        # Store in memory
        self.jobs[job_id] = job
        
        # Store in database
        self.save_job_to_db(job)
        
        logger.info(f"Created job {job_id} for repository {scan_data.get('repo_url')}")
        return job_id
    
    def save_job_to_db(self, job: Dict):
        """Save job to database"""
        try:
            result_data_to_save = job.get('result_data')
            logger.info(f"save_job_to_db: Saving job {job.get('job_id')}, result_data type={type(result_data_to_save)}, length={len(result_data_to_save) if result_data_to_save else 0}")
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO scan_jobs 
                    (job_id, scan_id, repo_url, repo_type, status, progress, created_at, 
                     started_at, completed_at, result_data, error_message, ait_tag, spk_tag, repo_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    job['job_id'], job['scan_id'], job['repo_url'], job['repo_type'],
                    job['status'], job['progress'], job['created_at'], job['started_at'],
                    job['completed_at'], result_data_to_save, job.get('error_message'),
                    job['ait_tag'], job['spk_tag'], job['repo_name']
                ))
                conn.commit()
                
                # Verify it was saved
                cursor.execute('SELECT result_data FROM scan_jobs WHERE job_id = ?', (job['job_id'],))
                saved_result = cursor.fetchone()
                if saved_result:
                    saved_data = saved_result[0]
                    logger.info(f"save_job_to_db: Verified save for job {job.get('job_id')}, saved result_data type={type(saved_data)}, length={len(saved_data) if saved_data else 0}")
                else:
                    logger.warning(f"save_job_to_db: Could not verify save for job {job.get('job_id')}")
        except Exception as e:
            logger.error(f"Failed to save job to database: {e}", exc_info=True)
    
    def get_job_status(self, job_id: str, force_refresh: bool = False) -> Optional[Dict]:
        """Get job status by ID"""
        # If force_refresh, always load from database
        if not force_refresh and job_id in self.jobs:
            job = self.jobs[job_id]
            logger.info(f"get_job_status: Found job {job_id} in memory, has_result_data={bool(job.get('result_data'))}, result_data_type={type(job.get('result_data'))}")
            return job
        
        # Try database (always load fresh from DB to ensure we have latest data)
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM scan_jobs WHERE job_id = ?', (job_id,))
                row = cursor.fetchone()
                
                if row:
                    columns = [desc[0] for desc in cursor.description]
                    job = dict(zip(columns, row))
                    
                    # Debug: Check what we got from database
                    result_data_from_db = job.get('result_data')
                    logger.info(f"get_job_status: Loaded job {job_id} from database, has_result_data={bool(result_data_from_db)}, result_data_type={type(result_data_from_db)}, result_data_length={len(result_data_from_db) if result_data_from_db else 0}")
                    
                    if result_data_from_db:
                        logger.info(f"get_job_status: result_data preview (first 200 chars): {str(result_data_from_db)[:200]}")
                    
                    # Update cache with fresh data from database
                    self.jobs[job_id] = job
                    return job
                else:
                    logger.warning(f"get_job_status: Job {job_id} not found in database")
        except Exception as e:
            logger.error(f"Failed to get job status: {e}", exc_info=True)
        
        return None
    
    def update_job_status(self, job_id: str, status: str, progress: str = None, 
                         result_data: Dict = None, error_message: str = None):
        """Update job status"""
        logger.info(f"update_job_status called for job {job_id}: status={status}, has_result_data={result_data is not None}")
        
        # Try to get job from memory first, if not found, try database
        if job_id not in self.jobs:
            logger.warning(f"Job {job_id} not found in memory, trying to load from database")
            # Try to load from database
            job = self.get_job_status(job_id)
            if not job:
                logger.error(f"Job {job_id} not found in database either")
                return
            logger.info(f"Loaded job {job_id} from database")
        else:
            job = self.jobs[job_id]
            logger.info(f"Using job {job_id} from memory")
        
        job['status'] = status
        job['progress'] = progress or job.get('progress', '')
        
        if status == JobStatus.RUNNING and not job.get('started_at'):
            job['started_at'] = datetime.now().isoformat()
        elif status in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
            job['completed_at'] = datetime.now().isoformat()
        
        # Always update result_data if provided (even if it's an empty dict)
        if result_data is not None:
            try:
                # Clean result_data to replace NaN values with None before JSON serialization
                cleaned_result_data = self._clean_for_json(result_data)
                job['result_data'] = json.dumps(cleaned_result_data, default=str)
                logger.info(f"Updated result_data for job {job_id}: {len(result_data)} keys, keys={list(result_data.keys())}")
                if 'locator_files' in result_data:
                    logger.info(f"Job {job_id} result_data contains {len(result_data.get('locator_files', []))} locator files")
            except Exception as e:
                logger.error(f"Failed to serialize result_data for job {job_id}: {e}", exc_info=True)
        else:
            logger.warning(f"No result_data provided for job {job_id}")
        
        if error_message:
            job['error_message'] = error_message
        
        # Ensure job is in memory cache
        self.jobs[job_id] = job
        
        # Update database
        try:
            self.save_job_to_db(job)
            logger.info(f"Saved job {job_id} to database, result_data length: {len(job.get('result_data', '')) if job.get('result_data') else 0}")
        except Exception as e:
            logger.error(f"Failed to save job {job_id} to database: {e}", exc_info=True)
        
        logger.info(f"Updated job {job_id} status to {status}: {progress}")
    
    def _clean_for_json(self, obj):
        """Recursively clean data structure to replace NaN values with None for JSON serialization"""
        import math
        
        if isinstance(obj, dict):
            return {k: self._clean_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._clean_for_json(item) for item in obj]
        elif isinstance(obj, float):
            # Check for NaN or infinity
            if math.isnan(obj) or math.isinf(obj):
                return None
            return obj
        elif hasattr(obj, '__dict__'):
            # Handle objects with __dict__ attribute
            return self._clean_for_json(obj.__dict__)
        else:
            return obj
    
    def get_all_jobs(self, limit: int = 50) -> List[Dict]:
        """Get all jobs with optional limit"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM scan_jobs 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ''', (limit,))
                
                columns = [desc[0] for desc in cursor.description]
                jobs = []
                for row in cursor.fetchall():
                    job = dict(zip(columns, row))
                    jobs.append(job)
                    # Cache in memory
                    self.jobs[job['job_id']] = job
                
                return jobs
        except Exception as e:
            logger.error(f"Failed to get all jobs: {e}")
            return []
    
    def cleanup_old_jobs(self, days: int = 7):
        """Clean up old completed/failed jobs"""
        try:
            # Handle special case: days=0 means clean up all completed jobs
            if days == 0:
                logger.info("Cleaning up ALL completed/failed/cancelled jobs")
                
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # Get count of jobs to be deleted
                    cursor.execute('''
                        SELECT COUNT(*) FROM scan_jobs 
                        WHERE status IN (?, ?, ?)
                    ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED))
                    
                    count_to_delete = cursor.fetchone()[0]
                    logger.info(f"Found {count_to_delete} jobs to clean up")
                    
                    if count_to_delete > 0:
                        # Delete all completed/failed/cancelled jobs
                        cursor.execute('''
                            DELETE FROM scan_jobs 
                            WHERE status IN (?, ?, ?)
                        ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED))
                        
                        deleted_count = cursor.rowcount
                        conn.commit()
                        
                        # Also clean up from memory cache
                        jobs_to_remove = []
                        for job_id, job in self.jobs.items():
                            if job['status'] in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED]:
                                jobs_to_remove.append(job_id)
                        
                        for job_id in jobs_to_remove:
                            del self.jobs[job_id]
                        
                        logger.info(f"Successfully cleaned up {deleted_count} jobs from database and {len(jobs_to_remove)} from memory")
                        return deleted_count
                    else:
                        logger.info("No completed/failed/cancelled jobs found to clean up")
                        return 0
            else:
                # Calculate cutoff date for time-based cleanup
                from datetime import timedelta
                cutoff_date = datetime.now() - timedelta(days=days)
                cutoff_date_str = cutoff_date.isoformat()
                
                logger.info(f"Cleaning up jobs older than {days} days (before {cutoff_date_str})")
                
                # First, get the jobs that will be deleted for logging
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # Get count of jobs to be deleted
                    cursor.execute('''
                        SELECT COUNT(*) FROM scan_jobs 
                        WHERE status IN (?, ?, ?) 
                        AND created_at < ?
                    ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, cutoff_date_str))
                    
                    count_to_delete = cursor.fetchone()[0]
                    logger.info(f"Found {count_to_delete} jobs to clean up")
                    
                    if count_to_delete > 0:
                        # Delete the old jobs
                        cursor.execute('''
                            DELETE FROM scan_jobs 
                            WHERE status IN (?, ?, ?) 
                            AND created_at < ?
                        ''', (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, cutoff_date_str))
                        
                        deleted_count = cursor.rowcount
                        conn.commit()
                        
                        # Also clean up from memory cache
                        jobs_to_remove = []
                        for job_id, job in self.jobs.items():
                            if (job['status'] in [JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED] and 
                                job['created_at'] < cutoff_date_str):
                                jobs_to_remove.append(job_id)
                        
                        for job_id in jobs_to_remove:
                            del self.jobs[job_id]
                        
                        logger.info(f"Successfully cleaned up {deleted_count} old jobs from database and {len(jobs_to_remove)} from memory")
                        return deleted_count
                    else:
                        logger.info("No old jobs found to clean up")
                        return 0
                    
        except Exception as e:
            logger.error(f"Failed to cleanup old jobs: {e}")
            logger.error(f"Database path: {self.db_path}")
            logger.error(f"Database exists: {os.path.exists(self.db_path)}")
            raise

    def cleanup_jobs_by_status(self, status: str):
        """Clean up jobs by specific status"""
        try:
            logger.info(f"Cleaning up jobs with status: {status}")
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get count of jobs to be deleted
                cursor.execute('''
                    SELECT COUNT(*) FROM scan_jobs 
                    WHERE status = ?
                ''', (status,))
                
                count_to_delete = cursor.fetchone()[0]
                logger.info(f"Found {count_to_delete} {status} jobs to clean up")
                
                if count_to_delete > 0:
                    # Delete jobs with specific status
                    cursor.execute('''
                        DELETE FROM scan_jobs 
                        WHERE status = ?
                    ''', (status,))
                    
                    deleted_count = cursor.rowcount
                    conn.commit()
                    
                    # Also clean up from memory cache
                    jobs_to_remove = []
                    for job_id, job in self.jobs.items():
                        if job['status'] == status:
                            jobs_to_remove.append(job_id)
                    
                    for job_id in jobs_to_remove:
                        del self.jobs[job_id]
                    
                    logger.info(f"Successfully cleaned up {deleted_count} {status} jobs from database and {len(jobs_to_remove)} from memory")
                    return deleted_count
                else:
                    logger.info(f"No {status} jobs found to clean up")
                    return 0
                    
        except Exception as e:
            logger.error(f"Failed to cleanup {status} jobs: {e}")
            logger.error(f"Database path: {self.db_path}")
            logger.error(f"Database exists: {os.path.exists(self.db_path)}")
            raise

# Global job manager instance
job_manager = JobManager()
