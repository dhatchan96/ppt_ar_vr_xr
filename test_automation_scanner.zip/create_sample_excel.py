#!/usr/bin/env python3
"""
Script to create a sample functional test case Excel file
Based on the ORCIT T&R test case format
"""

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

def create_sample_test_case_excel():
    """Create a sample functional test case Excel file"""
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Functional TestCase"
    
    # Define headers based on the images
    headers = [
        'unique_id',
        'type',
        'name',
        'step_type',
        'step_description',
        'description',
        'backlog_coverage',
        'designer',
        'owner',
        'test_type',
        'product_areas',
        'automation_candidate_udf',
        'automation_status',
        'test_category_udf',
        'ait_udf',
        'team_udf'
    ]
    
    # Style for header row
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    
    # Add headers to row 1 (standard Excel format)
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Test case summary row (row 2) - unique_id must be 4 digits for markdown converter
    summary_row = [
        '1001',  # unique_id - 4 digits to match test case pattern
        'test_manu',  # type
        'TC_01_Verify_Script_Details_Fields',  # name
        '',  # step_type (empty for summary)
        '',  # step_description (empty for summary)
        'Verify Script Details Accordion expands and displays all fields',  # description
        'backlog_coverage_va',  # backlog_coverage
        'Tester ID',  # designer
        'Tester ID',  # owner
        'test_type/Feature Testing',  # test_type
        'product_areas_value',  # product_areas
        'No',  # automation_candidate_udf
        'Not Automated',  # automation_status
        'test_category/System Integration',  # test_category_udf
        'ait_udf_value',  # ait_udf
        'team_udf_value'  # team_udf
    ]
    
    # Add summary row
    for col_idx, value in enumerate(summary_row, start=1):
        cell = ws.cell(row=2, column=col_idx, value=value)
        # Highlight certain cells in yellow (as shown in image)
        if col_idx in [7, 8, 9, 10, 11]:  # backlog_coverage, designer, owner, test_type, product_areas
            cell.fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    
    # Test steps (rows 3 onwards)
    test_steps = [
        ['1 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Navigate to https://orcit-mt-sit.bankofamerica.com/mt/', '', '', '', '', '', '', '', '', '', '', ''],
        ['2 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Click on Inventory', '', '', '', '', '', '', '', '', '', '', ''],
        ['3 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Click on Script Inventory', '', '', '', '', '', '', '', '', '', '', ''],
        ['4 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Click on Add Test Script', '', '', '', '', '', '', '', '', '', '', ''],
        ['5 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify user is on page https://orcit-mt-sit.bankofamerica.com/mt/inventory/script/add', '', '', '', '', '', '', '', '', '', '', ''],
        ['6 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Click on Script Details accordion', '', '', '', '', '', '', '', '', '', '', ''],
        ['7 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Details accordion is collapsed', '', '', '', '', '', '', '', '', '', '', ''],
        ['8 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'simple', 'Click on Script Details accordion again', '', '', '', '', '', '', '', '', '', '', ''],
        ['9 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Details accordion is expanded', '', '', '', '', '', '', '', '', '', '', ''],
        ['10 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Source System field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['11 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Source System is disabled text box with value Operational Risk and Compliance Integrated Technology', '', '', '', '', '', '', '', '', '', '', ''],
        ['12 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script ID field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['13 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Status dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['14 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify User Defined Script ID field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['15 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Automation dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['16 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Type dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['17 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Name field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['18 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Description field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['19 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Reporting Calculation Approach dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['20 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Use Question Weight dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['21 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify QA Required dropdown is displayed with all values', '', '', '', '', '', '', '', '', '', '', ''],
        ['22 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Re-Training Needed As Of Date field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['23 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Test Script Last Modified Date field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['24 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Test Script Last Modified By field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['25 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Test Script Effective Date field is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['26 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Developer type-ahead dropdown is displayed', '', '', '', '', '', '', '', '', '', '', ''],
        ['27 step', 'test_manu', 'TC_01_Verify_Script_Details_Fields', 'validation', 'Verify Script Live Date field is displayed', '', '', '', '', '', '', '', '', '', '', '']
    ]
    
    # Add test steps (starting from row 3)
    for row_idx, step_data in enumerate(test_steps, start=3):
        for col_idx, value in enumerate(step_data, start=1):
            ws.cell(row=row_idx, column=col_idx, value=value)
    
    # Set column widths for better readability
    column_widths = {
        'A': 12,  # unique_id
        'B': 12,  # type
        'C': 35,  # name
        'D': 12,  # step_type
        'E': 80,  # step_description
        'F': 50,  # description
        'G': 20,  # backlog_coverage
        'H': 15,  # designer
        'I': 15,  # owner
        'J': 25,  # test_type
        'K': 20,  # product_areas
        'L': 20,  # automation_candidate_udf
        'M': 18,  # automation_status
        'N': 25,  # test_category_udf
        'O': 15,  # ait_udf
        'P': 15   # team_udf
    }
    
    for col_letter, width in column_widths.items():
        ws.column_dimensions[col_letter].width = width
    
    # Freeze panes at row 2 (so headers stay visible)
    ws.freeze_panes = 'A2'
    
    # Save the file
    filename = 'sample_test_case_template.xlsx'
    wb.save(filename)
    print(f"Sample Excel file created: {filename}")
    print(f"   Location: {os.path.abspath(filename)}")
    print(f"   Rows: {ws.max_row}, Columns: {ws.max_column}")
    print(f"   Test cases: {len(test_steps)} steps")

if __name__ == '__main__':
    import os
    create_sample_test_case_excel()

