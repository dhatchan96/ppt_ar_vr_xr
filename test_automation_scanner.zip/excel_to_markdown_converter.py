#!/usr/bin/env python3
"""
Excel to Markdown Converter for Test Automation
Converts functional test case Excel files to markdown format
Based on StepsMapperExtractor script
"""

import pandas as pd
import re
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

def escape_md(val):
    """Escape markdown special characters"""
    if isinstance(val, str):
        return val.replace('|', '\\|')
    return val

def extract_steps_to_markdown(excel_file_path: str) -> str:
    """
    Extract test steps from Excel file and convert to markdown format
    
    Args:
        excel_file_path: Path to the Excel file
        
    Returns:
        Markdown string with test cases and steps
    """
    try:
        # Read Excel file
        df = pd.read_excel(excel_file_path, engine='openpyxl')
        
        # Select required columns
        required_columns = ['unique_id', 'type', 'name', 'step_type', 'step_description']
        
        # Check if all required columns exist
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            logger.warning(f"Missing columns in Excel file: {missing_columns}")
            # Use available columns
            available_columns = [col for col in required_columns if col in df.columns]
            if not available_columns:
                logger.error("No required columns found in Excel file")
                return "# Test Cases\n\nNo valid test case data found in Excel file.\n"
        else:
            available_columns = required_columns
        
        selected_df = df[available_columns].copy()
        
        # Only treat unique_id values matching 4 digits as test case start
        unique_ids = selected_df['unique_id'].astype(str)
        testcase_mask = unique_ids.str.match(r'^\d{4}$')
        start_indices = unique_ids[testcase_mask].index.tolist()
        ordered_unique_ids = unique_ids[start_indices].tolist()
        
        if not ordered_unique_ids:
            logger.warning("No test cases found with 4-digit unique_id. Processing all rows as a single test case.")
            # If no 4-digit IDs found, treat entire file as one test case
            ordered_unique_ids = ['ALL']
            start_indices = [0]
        
        # Build markdown content
        md_content = "# ExtractSteps Test Cases\n\n"
        
        for i, uid in enumerate(ordered_unique_ids):
            start_idx = start_indices[i]
            end_idx = start_indices[i + 1] if i + 1 < len(start_indices) else len(selected_df)
            sheet_df = selected_df.iloc[start_idx:end_idx]
            
            # Add test case header
            md_content += f"## Test Case {escape_md(str(uid))}\n\n"
            
            # Add test steps table
            if len(sheet_df) > 0:
                md_content += "| Type | Name | Step Type | Step Description |\n"
                md_content += "|------|------|-----------|------------------|\n"
                
                for idx, row in sheet_df.iterrows():
                    type_val = escape_md(str(row.get('type', '')))
                    name_val = escape_md(str(row.get('name', '')))
                    step_type_val = escape_md(str(row.get('step_type', '')))
                    step_desc_val = escape_md(str(row.get('step_description', '')))
                    
                    md_content += f"| {type_val} | {name_val} | {step_type_val} | {step_desc_val} |\n"
                
                md_content += "\n"
            else:
                md_content += "*No steps found for this test case.*\n\n"
        
        logger.info(f"Converted Excel to markdown: {len(ordered_unique_ids)} test cases, {len(selected_df)} total steps")
        return md_content
        
    except Exception as e:
        logger.error(f"Error converting Excel to markdown: {e}", exc_info=True)
        return f"# Error\n\nFailed to convert Excel file to markdown: {str(e)}\n"

