import React, { useState, useEffect } from "react";
import ThreatGuardDashboard from "./ThreatGuardDashboard";
import VSCodeScans from "./VSCodeScans";
import TestAutomation from "./TestAutomation";
import {
  FaCloud,
  FaDesktop,
  FaServer,
  FaFlask
} from "react-icons/fa";

const CommandCenter = ({ jobResults, setJobResults }) => {
  const [activeTab, setActiveTab] = useState("code-repo");

  // Render Code/Repo Scan Tab - Use existing ThreatGuardDashboard
  const renderCodeRepoScanTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-primary text-white">
          <h5 className="mb-0">
            <FaCloud className="me-2" />
            Code/Repo Scan - File Upload & GitHub Scanning
          </h5>
        </div>
        <div className="card-body">
          <ThreatGuardDashboard jobResults={jobResults} setJobResults={setJobResults} />
        </div>
      </div>
    </div>
  );

  // Render Plugin Scans Tab - Use existing VSCodeScans
  const renderPluginScansTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-success text-white">
          <h5 className="mb-0">
            <FaDesktop className="me-2" />
            Plugin Scans - VSCode Extension Scans
          </h5>
        </div>
        <div className="card-body">
          <VSCodeScans />
        </div>
      </div>
    </div>
  );

  // Render Pipeline Scans Tab - Use existing ThreatGuardDashboard without file upload
  const renderPipelineScansTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-info text-white">
          <h5 className="mb-0">
            <FaServer className="me-2" />
            Pipeline Scans - Security Monitoring
          </h5>
        </div>
        <div className="card-body">
          <ThreatGuardDashboard hideFileUpload={true} jobResults={jobResults} setJobResults={setJobResults} />
        </div>
      </div>
    </div>
  );

  // Render Test Automation Tab
  const renderTestAutomationTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-warning text-dark">
          <h5 className="mb-0">
            <FaFlask className="me-2" />
            Test Automation - Functional Test Case Analysis
          </h5>
        </div>
        <div className="card-body">
          <TestAutomation jobResults={jobResults} setJobResults={setJobResults} />
        </div>
      </div>
    </div>
  );

  return (
    <div className="container-fluid">
      {/* Tab Navigation */}
      <div className="row mb-4">
        <div className="col-12">
          <ul className="nav nav-tabs" id="commandCenterTabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'code-repo' ? 'active' : ''}`}
                onClick={() => setActiveTab('code-repo')}
                type="button"
                role="tab"
              >
                <FaCloud className="me-2" />
                Code/Repo Scan
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'plugin' ? 'active' : ''}`}
                onClick={() => setActiveTab('plugin')}
                type="button"
                role="tab"
              >
                <FaDesktop className="me-2" />
                Plugin Scans
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'pipeline' ? 'active' : ''}`}
                onClick={() => setActiveTab('pipeline')}
                type="button"
                role="tab"
              >
                <FaServer className="me-2" />
                Pipeline Scans
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'test-automation' ? 'active' : ''}`}
                onClick={() => setActiveTab('test-automation')}
                type="button"
                role="tab"
              >
                <FaFlask className="me-2" />
                Test Automation
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Tab Content */}
      <div className="tab-content" id="commandCenterTabContent">
        {activeTab === 'code-repo' && renderCodeRepoScanTab()}
        {activeTab === 'plugin' && renderPluginScansTab()}
        {activeTab === 'pipeline' && renderPipelineScansTab()}
        {activeTab === 'test-automation' && renderTestAutomationTab()}
      </div>
    </div>
  );
};

export default CommandCenter;
