import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { FaBars, FaShieldAlt } from "react-icons/fa";
import ThreatGuardDashboard from './components/ThreatGuardDashboard';
import ThreatIssues from './components/ThreatIssues';
import VSCodeScans from './components/VSCodeScans';
import ThreatShields from './components/ThreatShields';
import ThreatIntelligence from './components/ThreatIntelligence';
import AdminPanel from './components/AdminPanel';
import HealthCheck from './components/HealthCheck';
import ScanHistory from './components/ScanHistory';
import MetricsSummary from './components/MetricsSummary';
import Rules from './components/Rules';
import SecurityTechDebt from './components/SecurityTechDebt';
import CopilotRemediation from './components/CopilotRemediation';
import Sidebar from './components/Sidebar';

function MainLayout({ sidebarCollapsed, toggleSidebar }) {
  // Now useLocation is inside Router context
  const { pathname } = require('react-router-dom').useLocation();

  const pageTitles = {
    '/dashboard': 'ThreatGuard Dashboard',
    '/threats': 'Active Threats',
    '/vscode-scans': 'VSCode Extension Scans',
    '/rules': 'Security Rules',
    '/threat-shields': 'Threat Shields',
    '/threat-intelligence': 'Threat Intelligence',
    '/security-tech-debt': 'Tech Debt',
    '/copilot-remediation': 'Copilot Remediation',
    '/admin': 'Admin Panel',
    '/scan-history': 'Scan History',
    '/health': 'System Health',
    '/summary': 'Metrics Summary',
    '/metrics': 'Metrics',
    '/': 'ThreatGuard Dashboard'
  };

  const currentTitle = pageTitles[pathname] || 'ThreatGuard Dashboard';

  return (
    <div className="" style={{ background: "#f5f7fb", minHeight: "100vh" }}>
      <div
        className={`text-white p-2 vh-100 fixed-top ${
          sidebarCollapsed ? "sidebar-collapsed" : "sidebar-expanded"
        }`}
        style={{
          transition: "width 0.3s",
          width: sidebarCollapsed ? "70px" : "280px",
          background:
            "linear-gradient(135deg, #266fd9, #2359a8 40%, #2359a8)",
        }}
      >
        <div className="d-flex flex-column justify-content-between align-items-center mb-3">
          <span
            className="navbar-brand fw-bold d-flex align-items-center"
            style={{ fontSize: "1.5rem" }}
          >
            <FaShieldAlt className="" style={{ fontSize: "2rem" }} />
            <div className="d-flex flex-column">
              {!sidebarCollapsed && (
                <div className="d-inline-block ms-2">ThreatGuard Pro</div>
              )}
              {!sidebarCollapsed && (
                <span
                  className="ms-2"
                  style={{ fontSize: "0.7rem", letterSpacing: "0.17rem" }}
                >
                  {" "}
                  LOGIC BOMB DETECTION{" "}
                </span>
              )}
            </div>
          </span>
        </div>
        <Sidebar sidebarCollapsed={sidebarCollapsed} />
      </div>

      <div
        className=""
        style={{
          marginLeft: sidebarCollapsed ? "70px" : "280px",
          transition: "margin-left 0.3s",
          boxShadow: "0 0 2rem 0 rgba(33, 37, 41, .1)",
        }}
      >
        <nav
          className="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm px-4 fixed-top"
          style={{
            marginLeft: sidebarCollapsed ? "70px" : "280px",
            transition: "margin-left 0.3s",
          }}
        >
          <FaBars onClick={toggleSidebar} className="cursor-pointer" />
          <div className="navbar-brand ms-3">{currentTitle}</div>
          <img
            // src="./bank_of_America-Logo.wine.svg"
            src="https://via.placeholder.com/250x40?text=ThreatGuard+Logo"  
            className="img-fluid rounded-top ms-auto align-self-center"
            alt="ThreatGuard Logo"
            style={{ width: "250px", height: "40px", }}
          />
        </nav>

        <div className="container-fluid p-4" style={{ marginTop: "60px" }}>
          <Routes>
            <Route path="/dashboard" element={<ThreatGuardDashboard />} />
            <Route path="/threats" element={<ThreatIssues />} />
            <Route path="/vscode-scans" element={<VSCodeScans />} />
            <Route path="/rules" element={<Rules />} />
            <Route path="/threat-shields" element={<ThreatShields />} />
            <Route path="/threat-intelligence" element={<ThreatIntelligence />} />
            <Route path="/security-tech-debt" element={<SecurityTechDebt />} />
            <Route path="/copilot-remediation" element={<CopilotRemediation />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/scan-history" element={<ScanHistory />} />
            <Route path="/health" element={<HealthCheck />} />
            <Route path="/summary" element={<MetricsSummary />} />
            <Route path="/" element={<ThreatGuardDashboard />} />
            <Route path="/metrics" element={<MetricsSummary />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const toggleSidebar = () => setSidebarCollapsed((prev) => !prev);

  return (
    <Router>
      <MainLayout sidebarCollapsed={sidebarCollapsed} toggleSidebar={toggleSidebar} />
    </Router>
  );
}