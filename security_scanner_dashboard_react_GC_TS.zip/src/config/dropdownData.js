// Centralized configuration for AIT, SPK, and REPO dropdown data
// This file can be easily modified to update dropdown values across all pages

export const aitData = [
  { value: 'AIT001', label: 'Application Integration Team 1' },
  { value: 'AIT002', label: 'Application Integration Team 2' },
  { value: 'AIT003', label: 'Application Integration Team 3' },
  { value: 'AIT004', label: 'Application Integration Team 4' },
  { value: 'AIT005', label: 'Application Integration Team 5' }
];

export const spkData = {
  'AIT001': [
    { value: 'SPK001', label: 'Security Product Key 1' },
    { value: 'SPK002', label: 'Security Product Key 2' },
    { value: 'SPK003', label: 'Security Product Key 3' }
  ],
  'AIT002': [
    { value: 'SPK004', label: 'Security Product Key 4' },
    { value: 'SPK005', label: 'Security Product Key 5' },
    { value: 'SPK006', label: 'Security Product Key 6' }
  ],
  'AIT003': [
    { value: 'SPK007', label: 'Security Product Key 7' },
    { value: 'SPK008', label: 'Security Product Key 8' }
  ],
  'AIT004': [
    { value: 'SPK009', label: 'Security Product Key 9' },
    { value: 'SPK010', label: 'Security Product Key 10' }
  ],
  'AIT005': [
    { value: 'SPK011', label: 'Security Product Key 11' },
    { value: 'SPK012', label: 'Security Product Key 12' }
  ]
};

export const repoData = {
  'SPK001': [
    { value: 'REPO001', label: 'Repository 1' },
    { value: 'REPO002', label: 'Repository 2' },
    { value: 'REPO003', label: 'Repository 3' }
  ],
  'SPK002': [
    { value: 'REPO004', label: 'Repository 4' },
    { value: 'REPO005', label: 'Repository 5' }
  ],
  'SPK003': [
    { value: 'REPO006', label: 'Repository 6' }
  ],
  'SPK004': [
    { value: 'REPO007', label: 'Repository 7' },
    { value: 'REPO008', label: 'Repository 8' }
  ],
  'SPK005': [
    { value: 'REPO009', label: 'Repository 9' },
    { value: 'REPO010', label: 'Repository 10' },
    { value: 'REPO011', label: 'Repository 11' }
  ],
  'SPK006': [
    { value: 'REPO012', label: 'Repository 12' }
  ],
  'SPK007': [
    { value: 'REPO013', label: 'Repository 13' },
    { value: 'REPO014', label: 'Repository 14' }
  ],
  'SPK008': [
    { value: 'REPO015', label: 'Repository 15' }
  ],
  'SPK009': [
    { value: 'REPO016', label: 'Repository 16' },
    { value: 'REPO017', label: 'Repository 17' }
  ],
  'SPK010': [
    { value: 'REPO018', label: 'Repository 18' }
  ],
  'SPK011': [
    { value: 'REPO019', label: 'Repository 19' },
    { value: 'REPO020', label: 'Repository 20' }
  ],
  'SPK012': [
    { value: 'REPO021', label: 'Repository 21' },
    { value: 'REPO022', label: 'Repository 22' },
    { value: 'REPO023', label: 'Repository 23' }
  ]
};

// Helper functions for getting names
export const getAITName = (aitId) => {
  const ait = aitData.find(item => item.value === aitId);
  return ait ? ait.label : aitId;
};

export const getSPKName = (spkId) => {
  const allSpks = Object.values(spkData).flat();
  const spk = allSpks.find(item => item.value === spkId);
  return spk ? spk.label : spkId;
};

export const getRepoName = (repoId) => {
  const allRepos = Object.values(repoData).flat();
  const repo = allRepos.find(item => item.value === repoId);
  return repo ? repo.label : repoId;
};

// Helper functions for getting available options
export const getAvailableSPKs = (selectedAIT) => {
  return selectedAIT ? (spkData[selectedAIT] || []) : [];
};

export const getAvailableRepos = (selectedSPK) => {
  return selectedSPK ? (repoData[selectedSPK] || []) : [];
};

// Export all data as a single object for easy importing
export const dropdownData = {
  aitData,
  spkData,
  repoData,
  getAITName,
  getSPKName,
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
};

export default dropdownData;
