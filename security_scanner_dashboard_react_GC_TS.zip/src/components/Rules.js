import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';

const Rules = () => {
  const [rules, setRules] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formMode, setFormMode] = useState('create');
  const [formData, setFormData] = useState({
    id: '', name: '', description: '', severity: 'CRITICAL', type: 'VULNERABILITY',
    language: '*', pattern: '', remediation_effort: 30
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchRules();
  }, []);

  const fetchRules = async () => {
    try {
      const res = await API.get('/api/rules');
      setRules(Object.values(res.data));
    } catch (err) {
      console.error('Failed to fetch rules:', err);
    }
  };

  const openCreateModal = () => {
    setFormMode('create');
    setFormData({
      id: '', name: '', description: '', severity: 'BLOCKER', type: 'VULNERABILITY',
      language: '*', pattern: '', remediation_effort: 30
    });
    setShowModal(true);
  };

  const openEditModal = (rule) => {
    setFormMode('edit');
    setFormData({ ...rule });
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (formMode === 'create') {
        await API.post('/api/rules', {
          ...formData,
          enabled: true,
          custom: true,
          tags: ['custom'],
          remediation_effort: parseInt(formData.remediation_effort),
        });
      } else {
        await API.put(`/api/rules/${formData.id}`, {
          ...formData,
          remediation_effort: parseInt(formData.remediation_effort),
        });
      }
      fetchRules();
      setShowModal(false);
    } catch (err) {
      console.error('Failed to submit rule:', err);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm(`Are you sure you want to delete rule: ${id}?`)) return;
    try {
      await API.delete(`/api/rules/${id}`);
      fetchRules();
    } catch (err) {
      console.error('Failed to delete rule:', err);
    }
  };

  const handleToggle = async (id, enabled) => {
    try {
      await API.put(`/api/rules/${id}`, { enabled });
      fetchRules();
    } catch (err) {
      console.error('Failed to toggle rule:', err);
    }
  };

  // Enhanced preset rule templates
  const createPresetRule = async (preset) => {
    const presets = {
      logicBomb: {
        id: `logic-bomb-${Date.now()}`,
        name: 'Logic Bomb Detection',
        description: 'Detects time-based logic bombs and conditional triggers',
        severity: 'CRITICAL_BOMB',
        type: 'SCHEDULED_THREAT',
        language: '*',
        pattern: 'if.*(?:date|datetime|time).*[><=].*\\d{4}.*:.*(?:delete|remove|destroy)',
        remediation_effort: 90,
        enabled: true,
        custom: true,
        tags: ['logic-bomb', 'time-trigger', 'malicious-code']
      },
      userTargeted: {
        id: `user-targeted-${Date.now()}`,
        name: 'User-Targeted Logic Bomb',
        description: 'Detects malicious code that targets specific users',
        severity: 'CRITICAL_BOMB',
        type: 'TARGETED_ATTACK',
        language: '*',
        pattern: 'if.*(?:user|username|getuser|USER).*==.*["\'][^"\']*["\'].*:.*(?:delete|remove|destroy|corrupt|kill)',
        remediation_effort: 75,
        enabled: true,
        custom: true,
        tags: ['logic-bomb', 'user-targeted', 'malicious-code']
      },
      destructivePayload: {
        id: `destructive-payload-${Date.now()}`,
        name: 'Destructive Payload Detection',
        description: 'Detects potentially destructive operations',
        severity: 'CRITICAL_BOMB',
        type: 'DESTRUCTIVE_PAYLOAD',
        language: '*',
        pattern: '(?:shutil\\.rmtree|os\\.remove|subprocess\\.call.*rm|system.*(?:del|rm)|format.*c:|rmdir.*\\/s)',
        remediation_effort: 120,
        enabled: true,
        custom: true,
        tags: ['destructive-payload', 'system-damage', 'malicious-code']
      },
      financialFraud: {
        id: `financial-fraud-${Date.now()}`,
        name: 'Financial Fraud Pattern',
        description: 'Detects potential financial fraud and unauthorized money redirection',
        severity: 'CRITICAL_BOMB',
        type: 'FINANCIAL_FRAUD',
        language: '*',
        pattern: '(?:bitcoin.*address|crypto.*wallet|paypal\\.me|transfer.*money|redirect.*payment)',
        remediation_effort: 90,
        enabled: true,
        custom: true,
        tags: ['financial-fraud', 'money-redirection', 'cryptocurrency']
      }
    };

    try {
      await API.post('/api/rules', presets[preset]);
      fetchRules();
      alert(`✅ ${presets[preset].name} rule created successfully!`);
    } catch (err) {
      console.error('Failed to create preset rule:', err);
      alert('❌ Failed to create preset rule');
    }
  };

  // Enhanced filtering
  const getFilteredRules = () => {
    return rules.filter(rule => {
      const matchesSearch = rule.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           rule.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           rule.pattern.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filter === 'all' || rule.severity === filter;
      return matchesSearch && matchesFilter;
    });
  };

  return (
    <div className="">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>🛡️ Security Rules</h2>
        <button className="btn btn-primary" onClick={openCreateModal}>Create New Rule</button>
      </div>

      {/* Enhanced Preset Rules Section */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">🚀 Quick Setup - Preset Threat Detection Rules</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-3 mb-2">
              <button 
                className="btn btn-outline-danger w-100" 
                onClick={() => createPresetRule('logicBomb')}
              >
                🕐 Logic Bomb Detection
              </button>
            </div>
            <div className="col-md-3 mb-2">
              <button 
                className="btn btn-outline-secondary w-100" 
                onClick={() => createPresetRule('userTargeted')}
              >
                👤 User-Targeted Attacks
              </button>
            </div>
            <div className="col-md-3 mb-2">
              <button 
                className="btn btn-outline-danger w-100" 
                onClick={() => createPresetRule('destructivePayload')}
              >
                💥 Destructive Payloads
              </button>
            </div>
            <div className="col-md-3 mb-2">
              <button 
                className="btn btn-outline-info w-100" 
                onClick={() => createPresetRule('financialFraud')}
              >
                💰 Financial Fraud
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Search and Filter */}
      <div className="row mb-4">
        <div className="col-md-6">
          <input
            type="text"
            className="form-control"
            placeholder="Search rules by name, description, or pattern..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="col-md-3">
          <select 
            className="form-select" 
            value={filter} 
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Severities</option>
            <option value="CRITICAL_BOMB">Critical Bombs</option>
            <option value="HIGH_RISK">High Risk</option>
            <option value="MEDIUM_RISK">Medium Risk</option>
            <option value="LOW_RISK">Low Risk</option>
            <option value="SUSPICIOUS">Suspicious</option>
          </select>
        </div>
        <div className="col-md-3">
          <div className="text-end">
            <span className="badge bg-primary">
              {getFilteredRules().length} rules found
            </span>
          </div>
        </div>
      </div>

      <div className="mt-5">
        <div className="table-responsive">
          <table className="table table-bordered table-hover">
            <thead className="table-light">
              <tr>
                <th>Rule ID</th>
                <th>Name</th>
                <th>Language</th>
                <th>Severity</th>
                <th>Type</th>
                <th>Enabled</th>
                <th className="text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {getFilteredRules().map((rule) => {
                let badgeColor = 'border-primary text-primary bg-primary-subtle';
                if (rule.severity === 'CRITICAL_BOMB') {
                  badgeColor = 'border-danger text-danger bg-danger-subtle';
                } else if (rule.severity === 'HIGH_RISK') {
                  badgeColor = 'border-warning text-warning bg-warning-subtle';
                } else if (rule.severity === 'MAJOR') {
                  badgeColor = 'border-danger text-danger bg-danger-subtle';
                } else if (rule.severity === 'CRITICAL') {
                  badgeColor = 'border-danger text-danger bg-danger-subtle';
                } else if (rule.severity === 'MEDIUM_RISK') {
                  badgeColor = 'border-info text-info bg-info-subtle';
                } else if (rule.severity === 'LOW_RISK') {
                  badgeColor = 'border-secondary text-secondary bg-secondary-subtle';
                }
                return (
                  <tr key={rule.id}>
                  <td>{rule.id}</td>
                  <td>{rule.name}</td>
                  <td>{rule.language}</td>
                  <td>
                    <span className={`badge border ${badgeColor}`}>
                    {rule.severity}
                    </span>
                  </td>
                  <td>{rule.type}</td>
                  <td>
                    <span className={`badge border ${rule.enabled ? 'border-success text-success bg-success-subtle' : 'border-secondary text-secondary bg-secondary-subtle'}`}>
                    {rule.enabled ? (
                      <>
                      <i className="fas fa-check-circle me-1"></i> Enabled
                      </>
                    ) : (
                      <>
                      <i className="fas fa-times-circle me-1"></i> Disabled
                      </>
                    )}
                    </span>
                  </td>
                  <td className="text-center">
                    <div className="d-flex gap-2 justify-content-center">
                    <button className="btn btn-sm btn-outline-primary" title="Edit" onClick={() => openEditModal(rule)}>
                      <i className="fas fa-edit"></i> 
                    </button>
                    <button className="btn btn-sm btn-outline-danger" title="Delete" onClick={() => handleDelete(rule.id)}>
                      <i className="fas fa-trash-alt"></i> 
                    </button>
                    <button
                      className={`btn btn-sm ${rule.enabled ? 'btn-outline-secondary' : 'btn-outline-success'}`}
                      onClick={() => handleToggle(rule.id, !rule.enabled)}
                    >
                      <i className={`fas ${rule.enabled ? 'fa-ban' : 'fa-check'} me-1`}></i>
                      {rule.enabled ? 'Disable' : 'Enable'}
                    </button>
                    </div>
                  </td>
                  </tr>
                );
              })}
              {getFilteredRules().length === 0 && (
                <tr>
                  <td colSpan="7" className="text-center">
                    {searchTerm || filter !== 'all' ? 'No rules match your search criteria.' : 'No rules found. Create your first rule!'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="modal show d-block" tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <form onSubmit={handleSubmit}>
                <div className="modal-header">
                  <h5 className="modal-title">{formMode === 'create' ? 'Create New Rule' : 'Edit Rule'}</h5>
                  <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
                </div>
                <div className="modal-body">
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label">Rule ID</label>
                      <input
                        type="text"
                        className="form-control"
                        name="id"
                        required
                        value={formData.id}
                        disabled={formMode === 'edit'}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Name</label>
                      <input type="text" className="form-control" name="name" required value={formData.name} onChange={handleChange} />
                    </div>
                    <div className="col-12">
                      <label className="form-label">Description</label>
                      <textarea className="form-control" name="description" required value={formData.description} onChange={handleChange}></textarea>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Severity</label>
                      <select className="form-select" name="severity" value={formData.severity} onChange={handleChange}>
                        <option value="BLOCKER">Blocker</option>
                        <option value="CRITICAL">Critical</option>
                        <option value="MAJOR">Major</option>
                        <option value="MINOR">Minor</option>
                        <option value="INFO">Info</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Type</label>
                      <select className="form-select" name="type" value={formData.type} onChange={handleChange}>
                        <option value="VULNERABILITY">Vulnerability</option>
                        <option value="BUG">Bug</option>
                        <option value="CODE_SMELL">Code Smell</option>
                        <option value="SECURITY_HOTSPOT">Security Hotspot</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Language</label>
                      <select className="form-select" name="language" value={formData.language} onChange={handleChange}>
                        <option value="*">All</option>
                        <option value="python">Python</option>
                        <option value="javascript">JavaScript</option>
                        <option value="java">Java</option>
                        <option value="csharp">C#</option>
                        <option value="php">PHP</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Remediation Effort (mins)</label>
                      <input type="number" className="form-control" name="remediation_effort" value={formData.remediation_effort} onChange={handleChange} />
                    </div>
                    <div className="col-12">
                      <label className="form-label">Regex Pattern</label>
                      <input type="text" className="form-control" name="pattern" required value={formData.pattern} onChange={handleChange} />
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="submit" className="btn btn-success">{formMode === 'create' ? 'Create Rule' : 'Update Rule'}</button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rules;
