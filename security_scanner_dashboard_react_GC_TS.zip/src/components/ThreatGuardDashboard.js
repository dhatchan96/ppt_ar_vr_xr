import React, { useEffect, useState } from "react";
import API from "../api";
import "../style.css";
import { Toast } from "bootstrap";
import JSZip from "jszip";
import {
  FaProjectDiagram,
  FaBuilding,
  FaCog,
  FaFolder,
  FaShieldAlt,
  FaFlask,
  FaGithub,
  FaShieldVirus,
  FaLock,
  FaInfoCircle,
  FaBomb,
  FaExclamationTriangle,
  FaDownload,
  FaFilter,
  FaTimesCircle
} from "react-icons/fa";

const ThreatGuardDashboard = () => {
  const [metrics, setMetrics] = useState(null);
  const [recentThreats, setRecentThreats] = useState([]);
  const [health, setHealth] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [logicBombStats, setLogicBombStats] = useState(null);
  const [activeTab, setActiveTab] = useState("logicbombs");
  const [selectedThreat, setSelectedThreat] = useState(null);
  const [showThreatModal, setShowThreatModal] = useState(false);
  
  // Cascading dropdown states
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');
  const [showUploadComponent, setShowUploadComponent] = useState(false);
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  
  // GitHub repository upload states
  const [githubUrl, setGithubUrl] = useState('');
  const [scanningGithub, setScanningGithub] = useState(false);
  const [githubToken, setGithubToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(false);

  // Enhanced threat categorization with filtering
  const filteredThreats = recentThreats.filter((t) => {
    // Apply AIT filter
    if (filterAIT && t.ait_tag !== filterAIT) return false;
    // Apply SPK filter
    if (filterSPK && t.spk_tag !== filterSPK) return false;
    // Apply Repository filter
    if (filterRepo && t.repo_name !== filterRepo) return false;
    return true;
  });

  const logicBombThreats = filteredThreats.filter(
    (t) =>
      t.type?.includes("BOMB") || 
      t.rule_id?.startsWith("LOGIC_BOMB_") || 
      t.rule_id?.startsWith("MALWARE_") ||
      t.message?.toLowerCase().includes("logic bomb") ||
      t.message?.toLowerCase().includes("destructive payload") ||
      t.message?.toLowerCase().includes("file destruction") ||
      t.message?.toLowerCase().includes("conditional trigger")
  );

  const logicBombIds = new Set(logicBombThreats.map((t) => t.id));
  const otherThreats = recentThreats.filter((t) => !logicBombIds.has(t.id));

  // Enhanced threat detail functions
  const showThreatDetails = (threat) => {
    setSelectedThreat(threat);
    setShowThreatModal(true);
  };

  const getThreatSolution = (threat) => {
    const solutions = {
      'SCHEDULED_THREAT': 'Remove time-based conditions or use proper scheduling systems like cron jobs',
      'TARGETED_ATTACK': 'Remove user-specific conditions and implement proper user authentication',
      'EXECUTION_TRIGGER': 'Remove execution counters and use proper iteration controls',
      'DESTRUCTIVE_PAYLOAD': 'Replace destructive file operations with safe alternatives',
      'FINANCIAL_FRAUD': 'Remove unauthorized financial redirections and use legitimate payment systems',
      'SYSTEM_SPECIFIC_THREAT': 'Remove environment checks or replace with proper configuration management'
    };
    return solutions[threat.type] || 'Review and remove suspicious conditional logic according to security best practices';
  };

  const getThreatPriority = (threat) => {
    if (threat.severity === 'CRITICAL_BOMB' || threat.severity === 'CRITICAL') return 'IMMEDIATE';
    if (threat.severity === 'HIGH_RISK' || threat.severity === 'MAJOR') return 'HIGH';
    if (threat.severity === 'MEDIUM_RISK' || threat.severity === 'MINOR') return 'MEDIUM';
    return 'LOW';
  };

  // Dummy data for cascading dropdowns
  const aitData = [
    { id: 'AIT001', name: 'AIT-Web-Development' },
    { id: 'AIT002', name: 'AIT-Mobile-Apps' },
    { id: 'AIT003', name: 'AIT-Cloud-Services' },
    { id: 'AIT004', name: 'AIT-Data-Analytics' },
    { id: 'AIT005', name: 'AIT-Security-Tools' }
  ];

  const spkData = {
    'AIT001': [
      { id: 'SPK001', name: 'SPK-Frontend-React' },
      { id: 'SPK002', name: 'SPK-Backend-NodeJS' },
      { id: 'SPK003', name: 'SPK-Database-MongoDB' }
    ],
    'AIT002': [
      { id: 'SPK004', name: 'SPK-Android-Native' },
      { id: 'SPK005', name: 'SPK-iOS-Swift' },
      { id: 'SPK006', name: 'SPK-React-Native' }
    ],
    'AIT003': [
      { id: 'SPK007', name: 'SPK-AWS-Services' },
      { id: 'SPK008', name: 'SPK-Azure-Cloud' },
      { id: 'SPK009', name: 'SPK-GCP-Platform' }
    ],
    'AIT004': [
      { id: 'SPK010', name: 'SPK-Python-Analytics' },
      { id: 'SPK011', name: 'SPK-R-Statistics' },
      { id: 'SPK012', name: 'SPK-ML-Models' }
    ],
    'AIT005': [
      { id: 'SPK013', name: 'SPK-Penetration-Testing' },
      { id: 'SPK014', name: 'SPK-Vulnerability-Scan' },
      { id: 'SPK015', name: 'SPK-Security-Audit' }
    ]
  };

  const repoData = {
    'SPK001': [
      { id: 'REPO001', name: 'user-management-frontend' },
      { id: 'REPO002', name: 'dashboard-ui-components' },
      { id: 'REPO003', name: 'admin-panel-react' }
    ],
    'SPK002': [
      { id: 'REPO004', name: 'api-gateway-service' },
      { id: 'REPO005', name: 'user-authentication-api' },
      { id: 'REPO006', name: 'payment-processing-api' }
    ],
    'SPK003': [
      { id: 'REPO007', name: 'user-database-schema' },
      { id: 'REPO008', name: 'analytics-data-store' },
      { id: 'REPO009', name: 'audit-logs-db' }
    ],
    'SPK004': [
      { id: 'REPO010', name: 'android-user-app' },
      { id: 'REPO011', name: 'android-admin-app' },
      { id: 'REPO012', name: 'android-payment-app' }
    ],
    'SPK005': [
      { id: 'REPO013', name: 'ios-user-app' },
      { id: 'REPO014', name: 'ios-admin-app' },
      { id: 'REPO015', name: 'ios-payment-app' }
    ],
    'SPK006': [
      { id: 'REPO016', name: 'react-native-core' },
      { id: 'REPO017', name: 'react-native-ui' },
      { id: 'REPO018', name: 'react-native-api' }
    ],
    'SPK007': [
      { id: 'REPO019', name: 'aws-lambda-functions' },
      { id: 'REPO020', name: 'aws-ec2-instances' },
      { id: 'REPO021', name: 'aws-s3-storage' }
    ],
    'SPK008': [
      { id: 'REPO022', name: 'azure-functions' },
      { id: 'REPO023', name: 'azure-vm-deploy' },
      { id: 'REPO024', name: 'azure-blob-storage' }
    ],
    'SPK009': [
      { id: 'REPO025', name: 'gcp-cloud-functions' },
      { id: 'REPO026', name: 'gcp-compute-engine' },
      { id: 'REPO027', name: 'gcp-cloud-storage' }
    ],
    'SPK010': [
      { id: 'REPO028', name: 'python-data-pipeline' },
      { id: 'REPO029', name: 'python-ml-models' },
      { id: 'REPO030', name: 'python-analytics-dashboard' }
    ],
    'SPK011': [
      { id: 'REPO031', name: 'r-statistical-analysis' },
      { id: 'REPO032', name: 'r-predictive-models' },
      { id: 'REPO033', name: 'r-data-visualization' }
    ],
    'SPK012': [
      { id: 'REPO034', name: 'ml-model-training' },
      { id: 'REPO035', name: 'ml-model-deployment' },
      { id: 'REPO036', name: 'ml-feature-engineering' }
    ],
    'SPK013': [
      { id: 'REPO037', name: 'penetration-testing-tools' },
      { id: 'REPO038', name: 'security-assessment-framework' },
      { id: 'REPO039', name: 'vulnerability-database' }
    ],
    'SPK014': [
      { id: 'REPO040', name: 'vulnerability-scanner' },
      { id: 'REPO041', name: 'security-patch-manager' },
      { id: 'REPO042', name: 'threat-detection-engine' }
    ],
    'SPK015': [
      { id: 'REPO043', name: 'security-audit-framework' },
      { id: 'REPO044', name: 'compliance-checker' },
      { id: 'REPO045', name: 'security-policy-enforcer' }
    ]
  };

  // Handle dropdown changes
  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
    setShowUploadComponent(false);
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
    setShowUploadComponent(false);
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
    setShowUploadComponent(true);
  };

  // Get available options for cascading dropdowns
  const availableSPKs = selectedAIT ? spkData[selectedAIT] || [] : [];
  const availableRepos = selectedSPK ? repoData[selectedSPK] || [] : [];

  // Get display names
  const getAITName = (aitId) => {
    if (!aitId) return '';
    const ait = aitData.find(ait => ait.id === aitId);
    return ait ? ait.name : aitId;
  };
  
  const getSPKName = (spkId) => {
    if (!spkId) return '';
    for (const spks of Object.values(spkData)) {
      const spk = spks.find(s => s.id === spkId);
      if (spk) return spk.name;
    }
    return spkId;
  };
  
  const getRepoName = (repoId) => {
    if (!repoId) return '';
    for (const repos of Object.values(repoData)) {
      const repo = repos.find(r => r.id === repoId);
      if (repo) return repo.name;
    }
    return repoId;
  };

  useEffect(() => {
    // Restore metrics from localStorage if available
    const savedMetrics = localStorage.getItem("tg_metrics");
    const savedThreats = localStorage.getItem("tg_recent_threats");
    const savedLogicBombStats = localStorage.getItem("tg_logic_bomb_stats");

    if (savedMetrics) {
      setMetrics(JSON.parse(savedMetrics));
    }
    if (savedThreats) {
      setRecentThreats(JSON.parse(savedThreats));
    }
    if (savedLogicBombStats) {
      setLogicBombStats(JSON.parse(savedLogicBombStats));
    }

    // Always fetch latest health
    fetchHealth();
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      const res = await API.get("/api/command-center/metrics");
      if (res.data && !res.data.error) {
        setMetrics(res.data);
        setRecentThreats(res.data.recent_threats || []);
        console.log("All threats returned:", res.data.recent_threats);

        if (res.data.logic_bomb_analysis) {
          setLogicBombStats({
            count: Object.values(res.data.logic_bomb_analysis.by_type).reduce(
              (a, b) => a + b,
              0
            ),
            details: Object.entries(
              res.data.logic_bomb_analysis.by_type || {}
            ).map(([type, count]) => `${type.replace("_", " ")}: ${count}`),
          });
        }
      }
    } catch (error) {
      // Fallback to older API if command center doesn't exist
      try {
        const res = await API.get("/api/dashboard/metrics");
        if (res.data && !res.data.error) {
          // Calculate threat density for fallback
          const totalIssues = res.data.issues?.total || 0;
          const linesOfCode = res.data.scan_info?.lines_of_code || 1000;
          const threatDensity = linesOfCode > 0 ? (totalIssues / linesOfCode) * 1000 : 0;
          
          // Calculate shield effectiveness and status for fallback
          const criticalIssues = res.data.issues?.by_severity?.CRITICAL || 0;
          const highIssues = res.data.issues?.by_severity?.HIGH || 0;
          let shieldEffectiveness = 85.0;
          let shieldStatus = "PROTECTED";
          
          if (criticalIssues > 0) {
            shieldEffectiveness = Math.max(30.0, 85.0 - (criticalIssues * 15.0));
            shieldStatus = "BLOCKED";
          } else if (highIssues > 2) {
            shieldEffectiveness = Math.max(50.0, 85.0 - (highIssues * 5.0));
            shieldStatus = "ALERT";
          } else if (totalIssues > 5) {
            shieldEffectiveness = Math.max(70.0, 85.0 - (totalIssues * 2.0));
            shieldStatus = "ALERT";
          } else if (totalIssues <= 2) {
            shieldEffectiveness = 95.0;
            shieldStatus = "PROTECTED";
          }
          
          // Calculate neutralization urgency for fallback
          let neutralizationUrgency = 24.0;
          if (criticalIssues > 0) {
            neutralizationUrgency = 2.0;
          } else if (highIssues > 0) {
            neutralizationUrgency = 6.0;
          } else if (totalIssues > 5) {
            neutralizationUrgency = 12.0;
          }
          
          setMetrics({
            threat_ratings: {
              logic_bomb_risk_score: calculateRiskScore(res.data),
            },
            scan_info: res.data.scan_info,
            threat_shield: { 
              status: shieldStatus, 
              protection_effectiveness: shieldEffectiveness 
            },
            threats: { critical_bombs: criticalIssues },
            threat_intelligence: { threat_level: "MEDIUM" },
            logic_bomb_metrics: {
              threat_density: threatDensity,
              detection_confidence_avg: 85.0,
              neutralization_urgency_hours: neutralizationUrgency,
              trigger_complexity_score: 0.0,
              payload_severity_score: 0.0,
              time_bomb_count: 0,
              user_bomb_count: 0,
              counter_bomb_count: 0,
              destructive_payload_count: 0,
            }
          });
          setRecentThreats(res.data.recent_issues || []);
        }
    } catch (fallbackError) {
        // Properly handle the exception by logging and notifying the user
        console.error("Failed to fetch metrics:", fallbackError);
        showToast("Failed to fetch metrics. Please try again.", "error");
    }
    }
  };

  const calculateRiskScore = (data) => {
    const totalIssues = data.issues?.total || 0;
    const criticalIssues = data.issues?.by_severity?.CRITICAL || 0;
    return Math.min(100, (criticalIssues * 20) + (totalIssues * 2));
  };

  const fetchHealth = async () => {
    try {
      const res = await API.get("/api/health");
      setHealth(res.data);
    } catch (err) {
      console.error("Failed to fetch health info:", err);
    }
  };

  const neutralizeThreat = async (id) => {
    try {
      await API.post(`/api/threats/${id}/neutralize`);
      fetchMetrics();
      showToast("Threat neutralized successfully!", "success");
    } catch (error) {
      // Fallback to older API
      try {
        await API.put(`/api/issues/${id}/status`, { status: "RESOLVED" });
        fetchMetrics();
        showToast("Threat neutralized successfully!", "success");
      } catch (fallbackError) {
        console.error("Failed to neutralize threat:", fallbackError);
      showToast("Failed to neutralize threat", "error");
      }
    }
  };

  const handleFileDrop = async (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = e.dataTransfer.items;
    const files = await extractFilesFromItems(items);
    handleUpload(files);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    handleUpload(files);
  };

  const extractFilesFromItems = async (items) => {
    const traverseFileTree = (item, path = "") => {
      return new Promise((resolve) => {
        if (item.isFile) {
          item.file((file) => {
            file.fullPath = path + file.name;
            resolve([file]);
          });
        } else if (item.isDirectory) {
          const dirReader = item.createReader();
          dirReader.readEntries(async (entries) => {
            const results = await Promise.all(
              entries.map((entry) =>
                traverseFileTree(entry, path + item.name + "/")
              )
            );
            resolve(results.flat());
          });
        }
      });
    };

    const entries = Array.from(items).map((item) => item.webkitGetAsEntry());
    const all = await Promise.all(
      entries.map((entry) => traverseFileTree(entry))
    );
    return all.flat();
  };

  const handleUpload = async (files) => {
    if (!files.length) return;

    setMetrics(null);
    setRecentThreats([]);
    setLogicBombStats(null);

    const fileContents = [];

    for (const file of files) {
      const ext = file.name.split(".").pop().toLowerCase();

      if (ext === "zip") {
        const zip = new JSZip();
        const zipData = await zip.loadAsync(file);
        for (const [relativePath, zipEntry] of Object.entries(zipData.files)) {
          if (!zipEntry.dir) {
            const content = await zipEntry.async("text");
            fileContents.push({
              id: generateId(),
              name: zipEntry.name,
              type: getFileLanguage(zipEntry.name),
              content: content,
            });
          }
        }
      } else {
        const content = await readFileContent(file);
        fileContents.push({
          id: generateId(),
          name: file.fullPath || file.webkitRelativePath || file.name,
          type: getFileLanguage(file.name),
          content: content,
        });
      }
    }

    // Enhanced payload with hierarchical tagging from dropdowns
    const projectName = `${getAITName(selectedAIT)}-${getSPKName(selectedSPK)}-${getRepoName(selectedRepo)}`;
    const payload = {
      scan_id: generateId(),
      scan_type: "manual",
      project_id: `${selectedAIT}-${selectedSPK}-${selectedRepo}-${Date.now()}`,
      project_name: projectName,
      timestamp: new Date().toISOString(),
      file_contents: fileContents,
      // Add hierarchical tags from dropdowns
      ait_tag: selectedAIT || "AIT",
      spk_tag: selectedSPK || "SPK-SECURITY",
      repo_name: selectedRepo || fileContents[0]?.name.split('/')[0] || "security-repo"
    };

    try {
      setUploading(true);
      const response = await API.post("/api/scan/files", payload);

      // Use scan response for immediate UI update
      const scanData = response.data;
      setMetrics(scanData);

      // Enhanced metrics normalization with proper fallbacks
      const normalizedMetrics = {
        ...scanData,
        // Ensure all UI values are properly populated
        scan_info: {
          project_id: scanData.project_id || payload.project_id,
          scan_date: scanData.timestamp || payload.timestamp,
          files_scanned: scanData.files_scanned || fileContents.length,
          lines_of_code: scanData.lines_of_code || 0,
          duration_ms: scanData.duration_ms || 0,
          ait_tag: payload.ait_tag,
          spk_tag: payload.spk_tag,
          repo_name: payload.repo_name
        },
        // Ensure threats have the selected hierarchical tags
        recent_threats: (scanData.recent_threats || []).map(threat => ({
          ...threat,
          ait_tag: threat.ait_tag || payload.ait_tag,
          spk_tag: threat.spk_tag || payload.spk_tag,
          repo_name: threat.repo_name || payload.repo_name
        })),
        threat_ratings: {
          security_rating: scanData.summary?.security_rating || scanData.metrics?.security_rating || "A",
          reliability_rating: scanData.summary?.reliability_rating || scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.summary?.maintainability_rating || scanData.metrics?.maintainability_rating || "A",
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0
        },
        threat_shield: {
          status: scanData.threat_shield?.status || (scanData.summary?.quality_gate_passed ? "PROTECTED" : "ALERT"),
          message: scanData.threat_shield?.message || "Threat Shield Active",
          protection_effectiveness: scanData.threat_shield?.protection_effectiveness || 85
        },
        threat_intelligence: {
          threat_level: scanData.summary?.threat_level || scanData.threat_intelligence?.threat_level || "MINIMAL",
          total_threats: scanData.summary?.total_issues || 0,
          critical_bombs: scanData.summary?.critical_threats || 0,
          threat_distribution: scanData.issue_breakdown?.by_type || {},
          recommendations: scanData.threat_intelligence?.recommendations || []
        },
        logic_bomb_metrics: {
          SCHEDULED_THREAT: scanData.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
          TARGETED_ATTACK: scanData.logic_bomb_metrics?.TARGETED_ATTACK || 0,
          EXECUTION_TRIGGER: scanData.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
          DESTRUCTIVE_PAYLOAD: scanData.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
          FINANCIAL_FRAUD: scanData.logic_bomb_metrics?.FINANCIAL_FRAUD || 0,
          SYSTEM_SPECIFIC_THREAT: scanData.logic_bomb_metrics?.SYSTEM_SPECIFIC_THREAT || 0,
          CONNECTION_BASED_THREAT: scanData.logic_bomb_metrics?.CONNECTION_BASED_THREAT || 0
        },
        metrics: {
          security_rating: scanData.metrics?.security_rating || scanData.summary?.security_rating || "A",
          reliability_rating: scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.metrics?.maintainability_rating || "B",
          coverage: scanData.metrics?.coverage || 85,
          duplications: scanData.metrics?.duplications || 2.5,
          technical_debt_hours: scanData.metrics?.technical_debt_hours || Math.round(scanData.summary?.total_issues * 0.5) || 0
        },
        // Ensure proper values for dashboard display
        files_scanned: scanData.files_scanned || fileContents.length,
        lines_of_code: scanData.lines_of_code || fileContents.reduce((sum, f) => sum + (f.content.split('\n').length || 0), 0),
        summary: {
          ...scanData.summary,
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0,
          threat_level: scanData.summary?.threat_level || "MINIMAL",
          quality_gate_passed: scanData.summary?.quality_gate_passed !== false,
          total_issues: scanData.summary?.total_issues || 0,
          critical_threats: scanData.summary?.critical_threats || 0
        }
      };

      setMetrics(normalizedMetrics);
      
      // Flatten all issues with hierarchical tags
      const allIssues = [];
      if (scanData.file_results) {
        scanData.file_results.forEach((file) => {
          if (file.issues) {
            file.issues.forEach(issue => {
              // Add hierarchical tags to each issue
              issue.ait_tag = payload.ait_tag;
              issue.spk_tag = payload.spk_tag;
              issue.repo_name = payload.repo_name;
              issue.scan_id = scanData.scan_id;
              issue.file_name = file.file_name;
              allIssues.push(issue);
            });
          }
        });
      }
      setRecentThreats(allIssues);

      // Enhanced logic bomb stats
      if (scanData.logic_bomb_metrics) {
        const logicBombCount = Object.values(scanData.logic_bomb_metrics).reduce((a, b) => a + b, 0);
        const stats = Object.entries(scanData.logic_bomb_metrics)
          .filter(([k, v]) => v > 0)
          .map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`);
        
        setLogicBombStats({ 
          count: logicBombCount, 
          details: stats,
          breakdown: scanData.logic_bomb_metrics
        });
      }

      // Save to localStorage with proper structure
      localStorage.setItem("tg_metrics", JSON.stringify(normalizedMetrics));
      localStorage.setItem("tg_recent_threats", JSON.stringify(allIssues));
      if (logicBombStats) {
        localStorage.setItem("tg_logic_bomb_stats", JSON.stringify(logicBombStats));
      }

      showToast(
        `Enhanced security scan completed! AIT→${payload.spk_tag}→${payload.repo_name}: ${allIssues.length} threats found. Risk Score: ${normalizedMetrics.threat_ratings.logic_bomb_risk_score}/100`,
        allIssues.length > 0 ? "warning" : "success"
      );

      // Optionally, refresh dashboard metrics after a short delay
      setTimeout(() => {
        fetchMetrics();
      }, 1000);
      fetchHealth();
    } catch (err) {
      console.error(err);
      showToast("Logic bomb scan failed. Please try again.", "error");
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => "id_" + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const map = {
      py: "python",
      js: "javascript",
      ts: "typescript",
      java: "java",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      cpp: "cpp",
      cs: "csharp",
      rb: "ruby",
      php: "php",
      go: "golang",
      rs: "rust",
      c: "c",
    };
    return map[ext] || "unknown";
  };

  const showToast = (message, type) => {
    const toastEl = document.getElementById(`${type}Toast`);
    if (toastEl) {
      toastEl.querySelector(".toast-body").textContent = message;
      new Toast(toastEl).show();
    }
  };

  const timeAgo = (isoTime) => {
    const diffMs = Date.now() - new Date(isoTime).getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "just now";
    if (diffMin === 1) return "1 minute ago";
    return `${diffMin} minutes ago`;
  };

  const downloadThreatPrompts = async () => {
    try {
      const res = await API.get("/api/threat-prompts/download", {
        responseType: "blob",
      });

      const blob = new Blob([res.data], { type: "application/zip" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "threatguard_prompts.zip";
      link.click();
    } catch (err) {
      console.error("Failed to download prompts:", err);
      showToast("Failed to download threat prompts.", "error");
    }
  };

  // if (!metrics)
  //   return <p className="text-center mt-5">Loading ThreatGuard metrics...</p>;

  const {
    threat_ratings,
    scan_info,
    threat_shield,
    threats,
    threat_intelligence,
  } = metrics || {};

  // Calculate scan date and time
  const scanDateTime = scan_info?.scan_date
    ? new Date(scan_info.scan_date)
    : new Date();
  const scanDate = scanDateTime.toLocaleDateString();
  const scanTime = scanDateTime.toLocaleTimeString();

  const summary = metrics?.summary || {};
  const threatInt = metrics?.threat_intelligence || {};
  const logicBombMetrics = metrics?.logic_bomb_metrics || {};
  const threatShield = metrics?.threat_shield || {};

  const detectionMetricCards = [
    {
      label: "Logic Bomb Risk Score",
      value: `${
        summary.logic_bomb_risk_score ??
        threat_ratings?.logic_bomb_risk_score ??
        0
      }/100`,
      className:
        (summary.logic_bomb_risk_score ??
          threat_ratings?.logic_bomb_risk_score ??
          0) >= 70
          ? "text-danger"
          : (summary.logic_bomb_risk_score ??
              threat_ratings?.logic_bomb_risk_score ??
              0) >= 40
          ? "text-warning"
          : "text-success",
    },
    {
      label: "Threat Exposure Level",
      value: summary.threat_level || threatInt.threat_level || "MINIMAL",
      className:
        (summary.threat_level || threatInt.threat_level) === "CRITICAL"
          ? "text-danger"
          : (summary.threat_level || threatInt.threat_level) === "HIGH"
          ? "text-warning"
          : "text-success",
    },
    {
      label: "Critical Logic Bombs",
      value: threatInt.critical_bombs ?? summary.critical_threats ?? 0,
      className: "text-danger",
    },
    {
      label: "Threat Shield Status",
      value: threatShield.status || "UNKNOWN",
      className:
        threatShield.status === "PROTECTED"
          ? "text-success"
          : threatShield.status === "BLOCKED"
          ? "text-danger"
          : "text-warning",
    },
    // {
    //   label: "Threat Density",
    //   value: `${(metrics?.logic_bomb_metrics?.threat_density || 0).toFixed(1)}/1K`,
    //   className:
    //     (metrics?.logic_bomb_metrics?.threat_density || 0) >= 5.0
    //       ? "text-danger"
    //       : (metrics?.logic_bomb_metrics?.threat_density || 0) >= 2.0
    //       ? "text-warning"
    //       : "text-success",
    // },
  ];

  // Add pagination state for threats table
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3;
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  // Get filtered threats for the current tab
  const displayedThreats = activeTab === "logicbombs" ? logicBombThreats : otherThreats;
  const totalPages = Math.ceil(displayedThreats.length / pageSize) || 1;
  const paginatedThreats = displayedThreats.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  useEffect(() => { setCurrentPage(1); }, [activeTab, filterAIT, filterSPK, filterRepo, pageSize, displayedThreats.length]);

  // GitHub repository scan handler
  const handleGithubScan = async () => {
    if (!githubUrl.trim()) {
      showToast('Please enter a GitHub repository URL', 'error');
      return;
    }

    // Clear previous data
    setMetrics(null);
    setRecentThreats([]);
    setLogicBombStats(null);

    const payload = {
      scan_id: generateId(),
      scan_type: "github",
      project_id: `github-scan-${Date.now()}`,
      project_name: "GitHub Repository Scan",
      timestamp: new Date().toISOString(),
      github_url: githubUrl.trim(),
      github_token: githubToken.trim() || undefined, // Only send if provided
      // Add hierarchical tags
      ait_tag: "AIT",
      spk_tag: "SPK-SECURITY",
      repo_name: "github-repo"
    };

    try {
      setScanningGithub(true);
      const response = await API.post("/api/scan/github", payload);

      const scanData = response.data;
      
      // Enhanced metrics normalization with proper fallbacks
      const normalizedMetrics = {
        ...scanData,
        // Ensure all UI values are properly populated
        scan_info: {
          project_id: scanData.project_id || payload.project_id,
          scan_date: scanData.timestamp || payload.timestamp,
          files_scanned: scanData.files_scanned || scanData.github_info?.files_count || 0,
          lines_of_code: scanData.lines_of_code || 0,
          duration_ms: scanData.duration_ms || 0,
          ait_tag: payload.ait_tag,
          spk_tag: payload.spk_tag,
          repo_name: payload.repo_name,
          github_info: scanData.github_info
        },
        threat_ratings: {
          security_rating: scanData.summary?.security_rating || scanData.metrics?.security_rating || "A",
          reliability_rating: scanData.summary?.reliability_rating || scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.summary?.maintainability_rating || scanData.metrics?.maintainability_rating || "A",
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0
        },
        threat_shield: {
          status: scanData.threat_shield?.status || (scanData.summary?.quality_gate_passed ? "PROTECTED" : "ALERT"),
          message: scanData.threat_shield?.message || "Threat Shield Active",
          protection_effectiveness: scanData.threat_shield?.protection_effectiveness || 85
        },
        threat_intelligence: {
          threat_level: scanData.summary?.threat_level || scanData.threat_intelligence?.threat_level || "MINIMAL",
          total_threats: scanData.summary?.total_issues || 0,
          critical_bombs: scanData.summary?.critical_threats || 0,
          threat_distribution: scanData.issue_breakdown?.by_type || {},
          recommendations: scanData.threat_intelligence?.recommendations || []
        },
        logic_bomb_metrics: {
          SCHEDULED_THREAT: scanData.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
          TARGETED_ATTACK: scanData.logic_bomb_metrics?.TARGETED_ATTACK || 0,
          EXECUTION_TRIGGER: scanData.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
          DESTRUCTIVE_PAYLOAD: scanData.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
          FINANCIAL_FRAUD: scanData.logic_bomb_metrics?.FINANCIAL_FRAUD || 0,
          SYSTEM_SPECIFIC_THREAT: scanData.logic_bomb_metrics?.SYSTEM_SPECIFIC_THREAT || 0,
          CONNECTION_BASED_THREAT: scanData.logic_bomb_metrics?.CONNECTION_BASED_THREAT || 0
        },
        metrics: {
          security_rating: scanData.metrics?.security_rating || scanData.summary?.security_rating || "A",
          reliability_rating: scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.metrics?.maintainability_rating || "B",
          coverage: scanData.metrics?.coverage || 85,
          duplications: scanData.metrics?.duplications || 2.5,
          technical_debt_hours: scanData.metrics?.technical_debt_hours || Math.round(scanData.summary?.total_issues * 0.5) || 0
        },
        // Ensure proper values for dashboard display
        files_scanned: scanData.files_scanned || scanData.github_info?.files_count || 0,
        lines_of_code: scanData.lines_of_code || 0,
        summary: {
          ...scanData.summary,
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0,
          threat_level: scanData.summary?.threat_level || "MINIMAL",
          quality_gate_passed: scanData.summary?.quality_gate_passed !== false,
          total_issues: scanData.summary?.total_issues || 0,
          critical_threats: scanData.summary?.critical_threats || 0
        }
      };

      setMetrics(normalizedMetrics);
      
      // Flatten all issues with hierarchical tags
      const allIssues = [];
      if (scanData.file_results) {
        scanData.file_results.forEach((file) => {
          if (file.issues) {
            file.issues.forEach(issue => {
              // Add hierarchical tags to each issue
              issue.ait_tag = payload.ait_tag;
              issue.spk_tag = payload.spk_tag;
              issue.repo_name = payload.repo_name;
              issue.scan_id = scanData.scan_id;
              issue.file_name = file.file_name;
              allIssues.push(issue);
            });
          }
        });
      }
      setRecentThreats(allIssues);

      // Enhanced logic bomb stats
      if (scanData.logic_bomb_metrics) {
        const logicBombCount = Object.values(scanData.logic_bomb_metrics).reduce((a, b) => a + b, 0);
        const stats = Object.entries(scanData.logic_bomb_metrics)
          .filter(([k, v]) => v > 0)
          .map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`);
        
        setLogicBombStats({ 
          count: logicBombCount, 
          details: stats,
          breakdown: scanData.logic_bomb_metrics
        });
      }

      // Save to localStorage with proper structure
      localStorage.setItem("tg_metrics", JSON.stringify(normalizedMetrics));
      localStorage.setItem("tg_recent_threats", JSON.stringify(allIssues));
      if (logicBombStats) {
        localStorage.setItem("tg_logic_bomb_stats", JSON.stringify(logicBombStats));
      }

      const filesCount = scanData.github_info?.files_count || 0;
      const isPrivate = scanData.github_info?.is_private || false;
      showToast(
        `GitHub scan completed! Found ${allIssues.length} threats in ${filesCount} files. Risk Score: ${normalizedMetrics.threat_ratings.logic_bomb_risk_score}/100${isPrivate ? ' (Private Repo)' : ''}`,
        allIssues.length > 0 ? "warning" : "success"
      );
      
      // Clear the input after successful scan
      setGithubUrl('');
      setGithubToken('');
      setShowTokenInput(false);
      fetchHealth();
    } catch (err) {
      console.error(err);
      const errorMsg = err.response?.data?.error || 'Failed to scan GitHub repository';
      showToast(errorMsg, 'error');
      
      // Handle authentication errors
      if (err.response?.status === 401) {
        setShowTokenInput(true);
      }
    } finally {
      setScanningGithub(false);
    }
  };

  return (
    <div>
      {!metrics && (
        <div className="alert alert-warning mt-3">
          ⚠️ Metrics not loaded. Please upload a scan file to begin.
          <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      )}
      
      <div>
        {/* System Status Header */}
        {health && (
          <div
            className={`alert d-flex align-items-center justify-content-between ${
              health.status === "healthy" ? "alert-success" : "alert-danger"
            } mb-4`}
            style={{
              // background: "#f8f9fa",
              border: "1px solid #d1d5db",
              color: health.status === "healthy" ? "#198754" : "#dc3545",
            }}
          >
            <span>
              {health.status === "healthy"
                ? `🛡️ ThreatGuard Pro operational. Logic bomb detection active. Last scan: ${timeAgo(
                    health.timestamp
                  )}.`
                : `⚠️ ThreatGuard Pro experiencing issues. Last checked: ${timeAgo(
                    health.timestamp
                  )}.`}
            </span>
            <button
              type="button"
              className="btn-close ms-3"
              data-bs-dismiss="alert"
              aria-label="Close"
            ></button>
          </div>
        )}

        {/* Project Selection - Cascading Dropdowns */}
        <div
          className="card mb-5 shadow"
          style={{ background: "#fff", border: "1px solid #e5e7eb" }}
        >
          <div
            className="card-header d-flex justify-content-between align-items-center"
            style={{
              background: "#f8f9fa",
              borderBottom: "1px solid #e5e7eb",
            }}
          >
            <h5 className="mb-0" style={{ color: "#222" }}>
              <FaProjectDiagram className="me-2" /> Project Configuration
            </h5>
            <div>
              <span className="badge bg-primary me-2">HIERARCHICAL</span>
              <span className="badge bg-info">AIT → SPK → REPO</span>
            </div>
          </div>
          <div className="card-body" style={{ background: "#f8f9fa" }}>
            <div className="row g-3">
              {/* AIT Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaBuilding className="me-2" /> AIT (Application Inventory Tool)
                </label>
                <select
                  className="form-select"
                  value={selectedAIT}
                  onChange={(e) => handleAITChange(e.target.value)}
                  style={{ border: "1px solid #ced4da" }}
                >
                  <option value="">Select AIT...</option>
                  {aitData.map((ait) => (
                    <option key={ait.id} value={ait.id}>
                      {ait.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* SPK Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaCog className="me-2" /> SPK (Software Product Key)
                </label>
                <select
                  className="form-select"
                  value={selectedSPK}
                  onChange={(e) => handleSPKChange(e.target.value)}
                  disabled={!selectedAIT}
                  style={{ 
                    border: "1px solid #ced4da",
                    opacity: selectedAIT ? 1 : 0.6
                  }}
                >
                  <option value="">Select SPK...</option>
                  {availableSPKs.map((spk) => (
                    <option key={spk.id} value={spk.id}>
                      {spk.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Repository Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaFolder className="me-2" /> Repository
                </label>
                <select
                  className="form-select"
                  value={selectedRepo}
                  onChange={(e) => handleRepoChange(e.target.value)}
                  disabled={!selectedSPK}
                  style={{ 
                    border: "1px solid #ced4da",
                    opacity: selectedSPK ? 1 : 0.6
                  }}
                >
                  <option value="">Select Repository...</option>
                  {availableRepos.map((repo) => (
                    <option key={repo.id} value={repo.id}>
                      {repo.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Project Summary */}
            {selectedAIT && selectedSPK && selectedRepo && (
              <div className="mt-3 p-3 bg-light rounded">
                <h6 className="mb-2" style={{ color: "#222" }}>
                  <i className="bi bi-info-circle"></i> Selected Project:
                </h6>
                <div className="row">
                  <div className="col-md-4">
                    <strong>AIT:</strong> {getAITName(selectedAIT)}
                  </div>
                  <div className="col-md-4">
                    <strong>SPK:</strong> {getSPKName(selectedSPK)}
                  </div>
                  <div className="col-md-4">
                    <strong>Repository:</strong> {getRepoName(selectedRepo)}
                  </div>
                </div>
                <div className="mt-2">
                  <span className="badge bg-success">
                    ✅ Ready for file upload
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Quick Logic Bomb Scan - Only show when all dropdowns are selected */}
        {showUploadComponent && (
          <div
            className="card mb-5 shadow"
            style={{ background: "#fff", border: "1px solid #e5e7eb" }}
          >
            <div
              className="card-header d-flex justify-content-between align-items-center"
              style={{
                background: "#f8f9fa",
                borderBottom: "1px solid #e5e7eb",
              }}
            >
              <h5 className="mb-0" style={{ color: "#222" }}>
                <FaShieldAlt className="me-2" /> Logic Bomb Detection Scanner
              </h5>
              <div>
                <span className="badge bg-secondary me-2">
                  <FaFlask className="me-1" /> THREAT FOCUSED
                </span>
                <button className="btn btn-outline-secondary btn-sm">
                  ⚙️ Advanced Detection
                </button>
              </div>
            </div>
            <div
              className="card-body upload-area"
              style={{
                background: "#f8f9fa",
                border: "1px dashed #b0b0b0",
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleFileDrop}
            >
              <input
                type="file"
                id="fileInput"
                hidden
                multiple
                webkitdirectory="true"
                mozdirectory="true"
                directory="true"
                onChange={handleFileSelect}
              />
              <div className="mb-3">
                <FaShieldVirus
                  style={{ fontSize: "3rem", color: "#0d6efd" }}
                />
                <h5 className="mt-3" style={{ color: "#222" }}>
                  Drop your source code for instant logic bomb detection
                </h5>
                <small style={{ color: "#666" }}>
                  Project: {getAITName(selectedAIT)} → {getSPKName(selectedSPK)} → {getRepoName(selectedRepo)}
                </small>
              </div>
              <div className="d-flex justify-content-center gap-3 mt-4">
                <button
                  className="btn btn-primary"
                  onClick={() => document.getElementById("fileInput").click()}
                  disabled={uploading}
                >
                  {uploading
                    ? "🔍 Scanning for Logic Bombs..."
                    : "🎯 Scan for Logic Bombs"}
                </button>
                <button className="btn btn-outline-secondary">
                  🧪 Try Sample Threats
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GitHub Repository Upload Section */}
        <div
          className="card mb-5 shadow"
          style={{ background: "#fff", border: "1px solid #e5e7eb" }}
        >
          <div
            className="card-header d-flex justify-content-between align-items-center"
            style={{
              background: "#f8f9fa",
              borderBottom: "1px solid #e5e7eb",
            }}
          >
            <h5 className="mb-0" style={{ color: "#222" }}>
              <FaGithub className="me-2" /> GitHub Repository Scanner
            </h5>
            <div>
              <span className="badge bg-success me-2">GITHUB INTEGRATION</span>
              <span className="badge bg-info">REMOTE SCAN</span>
            </div>
          </div>
          <div
            className="card-body"
            style={{
              background: "#f8f9fa",
              border: "1px solid #e5e7eb",
            }}
          >
            <div className="d-flex align-items-start mb-3">
              <FaGithub style={{ fontSize: "3rem", color: "#333" }} />
              <div className="ms-3">
                <h5 className="mb-0" style={{ color: "#222" }}> Scan GitHub repositories for logic bombs and security threats </h5>
                <small style={{ color: "#666" }}> Enter a GitHub repository URL to automatically clone and scan for threats </small>
              </div>
            </div>
            <div className="d-flex justify-content-center gap-3 mt-4">
              <input
                type="text"
                className="form-control"
                placeholder="https://github.com/owner/repository"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
                style={{ minWidth: '400px' }}
                disabled={scanningGithub}
              />
              <button
                className="btn btn-primary"
                style={{ minWidth: '180px' }}
                onClick={handleGithubScan}
                disabled={scanningGithub || !githubUrl.trim()}
              >
                {scanningGithub
                  ? "🔍 Scanning GitHub..."
                  : "📦 Scan GitHub Repo"}
              </button>
            </div>
            
            {/* GitHub Token Input (shown when needed) */}
            {showTokenInput && (
              <div className="mt-3 p-3 bg-warning bg-opacity-10 border border-warning rounded">
                <div className="d-flex align-items-center gap-2 mb-2">
                  <FaLock className="text-warning me-1" />
                  <span className="text-warning fw-bold">Private Repository Detected</span>
                </div>
                <small className="text-muted d-block mb-3">
                  This appears to be a private repository. Please provide your GitHub token to access it.
                </small>
                <div className="d-flex justify-content-center gap-3">
                  <input
                    type="password"
                    className="form-control"
                    placeholder="GitHub Personal Access Token"
                    value={githubToken}
                    onChange={(e) => setGithubToken(e.target.value)}
                    style={{ minWidth: '300px' }}
                    disabled={scanningGithub}
                  />
                  <button
                    className="btn btn-warning"
                    onClick={handleGithubScan}
                    disabled={scanningGithub || !githubToken.trim()}
                  >
                    🔐 Scan Private Repo
                  </button>
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => {
                      setShowTokenInput(false);
                      setGithubToken('');
                    }}
                    disabled={scanningGithub}
                  >
                    Cancel
                  </button>
                </div>
                <div className="mt-2 text-center">
                  <small className="text-muted">
                    <FaInfoCircle className="me-1" />
                    Create a token at <a href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer">GitHub Settings</a> with 'repo' scope
                  </small>
                </div>
              </div>
            )}
            
            <div className="mt-3 text-center">
              <small style={{ color: "#666" }}>
                <i className="bi bi-info-circle"></i> 
                Supports public and private repositories. Large repositories may take longer to scan.
              </small>
            </div>
          </div>
        </div>

        {/* Project & Scan Info */}
        {metrics && (
          <>
            <div className="row g-4 mb-4">
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.scan_info?.files_scanned ?? metrics.files_scanned ?? metrics.file_results?.length ?? 0}
                  </div>
                  <div className="metric-label">Files Scanned</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.scan_info?.lines_of_code?.toLocaleString() ?? metrics.lines_of_code?.toLocaleString() ?? 0}
                  </div>
                  <div className="metric-label">Lines of Code</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.coverage ?? metrics.scan_info?.coverage ?? 0}%
                  </div>
                  <div className="metric-label">Coverage</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.duplications ?? metrics.scan_info?.duplications ?? 0}%
                  </div>
                  <div className="metric-label">Duplications</div>
                </div>
              </div>
            </div>
            <div className="row g-4 mb-4">
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.security_rating ?? metrics.scan_info?.security_rating ?? "-"}
                  </div>
                  <div className="metric-label">Security Rating</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.reliability_rating ?? metrics.scan_info?.reliability_rating ?? "-"}
                  </div>
                  <div className="metric-label">Reliability Rating</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.maintainability_rating ?? metrics.scan_info?.maintainability_rating ?? "-"}
                  </div>
                  <div className="metric-label">Maintainability</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.technical_debt_hours ?? metrics.scan_info?.technical_debt_hours ?? 0}h
                  </div>
                  <div className="metric-label">Technical Debt</div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Quality Gate */}
        {metrics && (
  <div className="mb-4">
    <span
      className={`badge ${
        metrics.summary?.quality_gate_passed ? "bg-success" : "bg-danger"
      }`}
    >
      Quality Gate:{" "}
      {metrics.summary?.quality_gate_passed ? "PASSED" : "FAILED"}
    </span>
  </div>
)}

        {/* Per-File Scan Results */}
        {Array.isArray(metrics?.file_results) && metrics.file_results.length > 0 && (
          <div className="mb-5">
            <h5 >Per-File Scan Results</h5>
            <div className="table-responsive">
              <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                  <tr>
                    <th>File</th>
                    <th>Type</th>
                    <th>Lines</th>
                    <th>Threat Level</th>
                    <th>Critical Threats</th>
                    <th>Issues</th>
                    <th>Logic Bombs</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {metrics.file_results.map((file) => (
                    <tr key={file.file_id}>
                      <td>{file.file_name}</td>
                      <td>{file.file_type}</td>
                      <td>{file.lines_scanned}</td>
                      <td>{file.threat_level}</td>
                      <td>{file.critical_threats}</td>
                      <td>{file.issues_count}</td>
                      <td>{file.logic_bomb_count}</td>
                      <td>{file.scan_status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Toast Notifications */}
        <div
          className="position-fixed bottom-0 end-0 p-3"
          style={{ zIndex: 1055 }}
        >
          <div
            id="successToast"
            className="toast align-items-center text-white bg-success border-0"
            role="alert"
          >
            <div className="d-flex">
              <div className="toast-body">
                ✅ Operation completed successfully!
              </div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
          <div
            id="warningToast"
            className="toast align-items-center text-white bg-warning border-0"
            role="alert"
          >
            <div className="d-flex">
              <div className="toast-body">⚠️ Logic bombs detected!</div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
          <div
            id="errorToast"
            className="toast align-items-center text-white bg-danger border-0"
            role="alert"
          >
            <div className="d-flex">
              <div className="toast-body">
                ❌ Operation failed. Please try again.
              </div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
        </div>

        {/* Logic Bomb Stats */}
        {logicBombStats?.details?.length > 0 && (
          <div
            className="section mt-5"
            style={{
              background: "#fff",
              border: "1px solid #e5e7eb",
              padding: "1.5rem",
              borderRadius: "8px",
            }}
          >
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h4 className="mb-0" >
                🚨 Logic Bomb Patterns Detected
              </h4>
            </div>
            <div className="table-responsive w-100">
              <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                  <tr>
                    <th >Threat Type</th>
                    <th >Occurrences</th>
                  </tr>
                </thead>
                <tbody>
                  {logicBombStats.details.map((entry, idx) => {
                    const [type, count] = entry.split(":");
                    return (
                      <tr key={idx}>
                        <td className="fw-bold" style={{ color: "#dc3545" }}>
                          {type.trim()}
                        </td>
                        <td style={{ color: "#222" }}>{count.trim()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Enhanced Scan Information */}
        <div className="mb-5">
          <div className="card text-start shadow">
            <div className="card-header" style={{ background: "#f8f9fa", borderBottom: "1px solid #e5e7eb" }}>
              <h3 className="mb-0" >📊 Latest Scan Information</h3>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scan_info?.project_id || "No scan data"}
                  </div>
                  <div style={{ color: "#888" }}>Project ID</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#0d6efd",
                    }}
                  >
                    {scan_info?.project_name || `${getAITName(selectedAIT) || getAITName(scan_info?.ait_tag)}-${getSPKName(selectedSPK) || getSPKName(scan_info?.spk_tag)}-${getRepoName(selectedRepo) || getRepoName(scan_info?.repo_name)}` || "Project Name"}
                  </div>
                  <div style={{ color: "#888" }}>Project Name</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scanDate}
                  </div>
                  <div style={{ color: "#888" }}>Scan Date</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scanTime}
                  </div>
                  <div style={{ color: "#888" }}>Scan Time</div>
                </div>
              </div>
              <div className="row mt-3">
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#0d6efd",
                    }}
                  >
                    {scan_info?.duration_ms ? `${scan_info.duration_ms}ms` : "0ms"}
                  </div>
                  <div style={{ color: "#888" }}>Duration</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#198754",
                    }}
                  >
                    {getAITName(selectedAIT) || getAITName(scan_info?.ait_tag) || "AIT"}
                  </div>
                  <div style={{ color: "#888" }}>AIT</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#6f42c1",
                    }}
                  >
                    {getSPKName(selectedSPK) || getSPKName(scan_info?.spk_tag) || "SPK"}
                  </div>
                  <div style={{ color: "#888" }}>SPK</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#fd7e14",
                    }}
                  >
                    {getRepoName(selectedRepo) || getRepoName(scan_info?.repo_name) || "Repository"}
                  </div>
                  <div style={{ color: "#888" }}>Repository</div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

        <h3 className="mb-4" >
          🛡️ Logic Bomb Detection Metrics
        </h3>
        <div className="row g-4 mb-4">
          {detectionMetricCards.map((item, i) => (
            <div className="col-md-3" key={i}>
              <div
                className="metric-card text-center shadow"
                style={{
                  background: "#fff",
                  border: "1px solid #e5e7eb",
                  color: "#222",
                  padding: "1.5rem",
                  borderRadius: "8px",
                }}
              >
                <div
                  className={`metric-value ${item.className}`}
                  style={{ fontSize: "2.5rem", fontWeight: "bold" }}
                >
                  {item.value}
                </div>
                <div className="metric-label" style={{ color: "#888" }}>
                  {item.label}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Logic Bomb Pattern Breakdown */}
{metrics?.logic_bomb_metrics && (
  <div className="row g-4 mb-4">
    {[
      {
        label: "Scheduled Threat",
        value: metrics.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
        description: "Date/time triggered threats",
        color: "#dc3545",
      },
      {
        label: "Targeted Attack",
        value: metrics.logic_bomb_metrics?.TARGETED_ATTACK || 0,
        description: "User-targeted attacks",
        color: "#0d6efd",
      },
      {
        label: "Execution Trigger",
        value: metrics.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
        description: "Execution-based triggers",
        color: "#198754",
      },
      {
        label: "Destructive Payloads",
        value: metrics.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
        description: "Direct destructive actions",
        color: "#fd7e14",
      },
    ].map((item, i) => (
      <div className="col-md-3" key={i}>
        <div
          className="metric-card text-center shadow"
          style={{
            background: "#f8f9fa",
            // border: `1px solid ${item.color}`,
            color: "#222",
            padding: "1.5rem",
            borderRadius: "8px",
          }}
        >
          <div
            className="metric-value"
            style={{ fontSize: "2rem" }}
          >
            {item.value}
          </div>
          <div
            className="metric-label"
            style={{ color: "#222", fontWeight: "bold" }}
          >
            {item.label}
          </div>
          <div
            style={{
              color: "#888",
              fontSize: "0.8rem",
              marginTop: "0.5rem",
            }}
          >
            {item.description}
          </div>
        </div>
      </div>
    ))}
  </div>
)}

        {/* Advanced Logic Bomb Metrics */}
        {/* Advanced Logic Bomb Metrics */}
{metrics?.logic_bomb_metrics && (
  <div className="row g-4 mb-5">
    {[
      {
        label: "Trigger Complexity",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.trigger_complexity_score || 0
        )}%`,
        description: "Sophistication of trigger mechanisms",
      },
      {
        label: "Payload Severity",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.payload_severity_score || 0
        )}%`,
        description: "Potential damage assessment",
      },
      {
        label: "Detection Confidence",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.detection_confidence_avg || 0
        )}%`,
        description: "Average detection confidence",
      },
      {
        label: "Threat Density",
        value: `${Math.min(100, Math.round(
          (metrics.logic_bomb_metrics?.threat_density || 0) / 100
        ))}%`,
        description: "Threat density percentage (capped at 100%)",
      },
    ].map((item, i) => {
      console.log(`Rendering metric ${i}:`, item);
      return (
        <div className="col-md-3" key={i}>
          <div
            className="metric-card text-center"
            style={{
              background: "#fff",
              border: "1px solid #e5e7eb",
              color: "#222",
              padding: "1.5rem",
              borderRadius: "8px",
            }}
          >
            <div
              className="metric-value"
              style={{ fontSize: "1.8rem" }}
            >
              {item.value}
            </div>
            <div
              className="metric-label"
              style={{
                color: "#222",
                fontSize: "0.9rem",
                fontWeight: "bold",
              }}
            >
              {item.label}
            </div>
            <div
              style={{
                color: "#888",
                fontSize: "0.75rem",
                marginTop: "0.3rem",
              }}
            >
              {item.description}
            </div>
          </div>
        </div>
      );
    })}
  </div>
)}

        {/* Enhanced Threat Intelligence Summary */}
        {threat_intelligence && (
          <div
            className="mb-5 shadow"
            style={{
              background: "#ffffff",
              padding: "1.5rem",
              borderRadius: "8px",
              border: "1px solid #e5e7eb",
            }}
          >
            <h3 className="mb-4">
              🧠 Current Threat Intelligence Assessment
            </h3>
            <div className="row">
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "2rem",
                    fontWeight: "bold",
                    color:
                      threat_intelligence.threat_level === "CRITICAL"
                        ? "#dc3545"
                        : threat_intelligence.threat_level === "HIGH"
                        ? "#fd7e14"
                        : "#198754",
                  }}
                >
                  {threat_intelligence.threat_level}
                </div>
                <div style={{ color: "#888" }}>Current Threat Level</div>
              </div>
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "bold",
                    color: "#0d6efd",
                  }}
                >
                  {Math.round(
                    metrics.logic_bomb_metrics?.neutralization_urgency_hours ||
                      0
                  )}
                  h
                </div>
                <div style={{ color: "#888" }}>Neutralization Urgency</div>
              </div>
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "bold",
                    color:
                      threat_shield?.protection_effectiveness >= 80
                        ? "#198754"
                        : threat_shield?.protection_effectiveness >= 60
                        ? "#fd7e14"
                        : "#dc3545",
                  }}
                >
                  {Math.round(threat_shield?.protection_effectiveness || 0)}%
                </div>
                <div style={{ color: "#888" }}>Shield Effectiveness</div>
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-12">
                <h5 style={{ color: "#dc3545", marginBottom: "1.5rem" }}>
                  🚨 Immediate Actions Required:
                </h5>
                <ul style={{ listStyle: "none", padding: 0 }}>
                  {(
                    metrics.threat_analysis?.recommended_actions ||
                    threat_intelligence.recommendations ||
                    []
                  )
                    .slice(0, 3)
                    .map((rec, idx) => (
                      <li
                        key={idx}
                        style={{
                          padding: "0.7rem",
                          borderLeft: "4px solid #dc3545",
                          paddingLeft: "1rem",
                          margin: "0.75rem 0",
                          background: "#f5f0f0",
                          color: "#222",
                          borderRadius: "4px"
                        }}
                      >
                        <strong style={{ color: "#dc3545" }}>ACTION:</strong>{" "}
                        {rec}
                      </li>
                    ))}
                </ul>
              </div>
            </div>
            </div>
        )}

        {/* Threat Tabs */}
        <ul
          className="nav nav-tabs mb-3"
          style={{ borderBottom: "2px solid #e5e7eb" }}
        >
          <li className="nav-item">
            <button
              className={`nav-link ${
                activeTab === "logicbombs" ? "active" : ""
              }`}
              onClick={() => setActiveTab("logicbombs")}
              style={{
                color: activeTab === "logicbombs" ? "#0d6efd" : "#888",
                background:
                  activeTab === "logicbombs" ? "#f8f9fa" : "transparent",
                border: "none",
                borderBottom:
                  activeTab === "logicbombs"
                    ? "3px solid #0d6efd"
                    : "3px solid transparent",
              }}
            >
              🚨 Logic Bomb Threats
            </button>
          </li>
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === "other" ? "active" : ""}`}
              onClick={() => setActiveTab("other")}
              style={{
                color: activeTab === "other" ? "#0d6efd" : "#888",
                background: activeTab === "other" ? "#f8f9fa" : "transparent",
                border: "none",
                borderBottom:
                  activeTab === "other"
                    ? "3px solid #0d6efd"
                    : "3px solid transparent",
              }}
            >
              📄 Other Security Issues
            </button>
          </li>
        </ul>

        {/* Threat Analysis Table */}
        <div
          className="section"
          style={{
            background: "#fff",
            border: "1px solid #e5e7eb",
            padding: "1.5rem",
            borderRadius: "8px",
          }}
        >
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h2 className="mb-0">
              {activeTab === "logicbombs"
                ? "🚨 Logic Bomb Threats"
                : "📄 Other Security Issues"}
            </h2>
            <button
              className="btn btn-outline-primary btn-sm"
              onClick={downloadThreatPrompts}
              style={{ borderColor: "#0d6efd", color: "#0d6efd" }}
            >
              🤖 Download AI Prompts
            </button>
          </div>

          {/* Filter Controls */}
          <div className="mb-3 py-3 bg-light rounded">
            <h6 className="mb-2" style={{ color: "#222" }}>
              <FaFilter /> Filter Threats
            </h6>
            <div className="row g-2">
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterAIT}
                  onChange={(e) => setFilterAIT(e.target.value)}
                >
                  <option value="">All AITs</option>
                  {Array.from(new Set(recentThreats.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                    <option key={ait} value={ait}>{getAITName(ait)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterSPK}
                  onChange={(e) => setFilterSPK(e.target.value)}
                >
                  <option value="">All SPKs</option>
                  {Array.from(new Set(recentThreats.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                    <option key={spk} value={spk}>{getSPKName(spk)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterRepo}
                  onChange={(e) => setFilterRepo(e.target.value)}
                >
                  <option value="">All Repositories</option>
                  {Array.from(new Set(recentThreats.map(t => t.repo_name).filter(Boolean))).map(repo => (
                    <option key={repo} value={repo}>{getRepoName(repo)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <button
                  className="btn btn-outline-secondary btn-sm w-100"
                  onClick={() => {
                    setFilterAIT('');
                    setFilterSPK('');
                    setFilterRepo('');
                  }}
                >
                  <FaTimesCircle /> Clear Filters
                </button>
              </div>
            </div>
            {(filterAIT || filterSPK || filterRepo) && (
              <div className="mt-2">
                <small className="text-muted">
                  Showing {filteredThreats.length} of {recentThreats.length} threats
                </small>
              </div>
            )}
          </div>

          <div className="table-responsive w-100">
            <table className="table table-bordered table-hover align-middle">
              <thead className="table-light">
                <tr className="text-center">
                  <th >Threat Level</th>
                  <th >Type</th>
                  <th >AIT</th>
                  <th >SPK</th>
                  <th >Repository</th>
                  {/* <th >Rule</th> */}
                  <th style={{minWidth: "150px"}}>File Name</th>
                  <th >Line #</th>
                  <th >Code Snippet</th>
                  <th >Trigger Analysis</th>
                  <th >Payload Risk</th>
                  <th >Neutralization</th>
                  <th className="text-center" >
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {paginatedThreats.length > 0 ? (
                  paginatedThreats.map((threat, idx) => (
                    <tr 
                      key={threat.id}
                      style={{ cursor: 'pointer' }}
                      onClick={() => showThreatDetails(threat)}
                      onMouseEnter={(e) => e.target.parentElement.style.backgroundColor = '#f8f9fa'}
                      onMouseLeave={(e) => e.target.parentElement.style.backgroundColor = ''}
                    >
                      <td>
                        {(() => {
                          let badgeClass = "border-secondary text-secondary bg-secondary-subtle";
                          if (threat.severity === "CRITICAL_BOMB") {
                            badgeClass = "border-danger text-danger bg-danger-subtle";
                          } else if (threat.severity === "HIGH_RISK") {
                            badgeClass = "border-warning text-warning bg-warning-subtle";
                          } else if (threat.severity === "MEDIUM_RISK") {
                            badgeClass = "border-info text-info bg-info-subtle";
                          }
                          return (
                            <span className={`badge border ${badgeClass}`}>
                              {threat.severity}
                            </span>
                          );
                        })()}
                      </td>
                      <td style={{ color: "#222" }}>{threat.type}</td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getAITName(threat.ait_tag)}
                      </td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getSPKName(threat.spk_tag)}
                      </td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getRepoName(threat.repo_name)}
                      </td>
                      {/* <td style={{ color: "#888", fontSize: "0.9rem" }}>
                        {threat.rule_id}
                      </td> */}
                      <td
                        style={{
                          wordBreak: "break-all",
                          color: "#222",
                          maxWidth: "300px",
                          whiteSpace: "normal",
                          overflow: "auto",
                        }}
                      >
                        {(() => {
                          const fileName = threat.file_name?.split("/").pop() || 
                                          threat.file_name?.split("\\").pop() ||
                                          threat.file_path?.split("/").pop() || 
                                          threat.file_path?.split("\\").pop() || 
                                          threat.name?.split("/").pop() ||
                                          threat.name?.split("\\").pop() ||
                                          threat.file_path || 
                                          threat.name ||
                                          "Unknown File";
                          
                          // Debug: Log if we're getting "Unknown File"
                          if (fileName === "Unknown File") {
                            console.log('File name extraction failed for threat:', {
                              id: threat.id,
                              file_name: threat.file_name,
                              file_path: threat.file_path,
                              name: threat.name
                            });
                          }
                          
                          return fileName;
                        })()}
                      </td>
                      <td style={{ color: "#555" }}>{threat.line_number}</td>
                      <td
                        style={{
                          fontFamily: "monospace",
                          fontSize: "0.8rem",
                          color: "#333",
                        }}
                      >
                        {threat.code_snippet}
                      </td>

                      {/* <td className="text-center" style={{ color: "#0d6efd" }}>
                        {threat.line_number}
                      </td> */}
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#fd7e14",
                          fontSize: "0.85rem",
                        }}
                      >
                        {threat.trigger_analysis ||
                          "Conditional trigger detected"}
                      </td>
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#dc3545",
                          fontSize: "0.85rem",
                        }}
                      >
                        {threat.payload_analysis || "Potential system impact"}
                      </td>
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#198754",
                          fontSize: "0.85rem",
                          maxWidth: "200px",
                        }}
                      >
                        {threat.suggested_fix || "Neutralization guide pending"}
                      </td>
                      <td className="text-center">
                        <div className="d-flex justify-content-center gap-2">
                          <button
                            className="btn btn-outline-danger btn-sm"
                            style={{
                              
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              neutralizeThreat(threat.id);
                            }}
                          >
                            Neutralize
                          </button>
                          <button 
                            className="btn btn-sm btn-outline-secondary"
                            onClick={(e) => {
                              e.stopPropagation();
                              showThreatDetails(threat);
                            }}
                          >
                            Details
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={12} className="text-center">No threats found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="d-flex justify-content-between align-items-center mt-3">
            <div>
              <select className="form-select form-select-sm" style={{ width: 100, display: 'inline-block' }} value={pageSize} onChange={e => setPageSize(Number(e.target.value))}>
                {[10, 25, 50, 100].map(size => <option key={size} value={size}>{size} / page</option>)}
              </select>
              <span className="ms-2 text-muted">
                Showing {(displayedThreats.length === 0) ? 0 : ((currentPage - 1) * pageSize + 1)}-
                {Math.min(currentPage * pageSize, displayedThreats.length)} of {displayedThreats.length}
              </span>
            </div>
            <nav style={{ overflowX: 'auto', maxWidth: 400 }}>
              <ul className="pagination pagination-sm mb-0 flex-nowrap">
                <li className={`page-item${currentPage === 1 ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.max(1, p - 1))}>Prev</button> </li>
                {getPaginationWindow(currentPage, totalPages).map((page, idx) =>
                  page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                    <li key={page + idx} className="page-item disabled"><span className="page-link">...</span></li>
                  ) : (
                    <li key={page} className={`page-item${page === currentPage ? ' active' : ''}`}>
                      <button className="page-link" onClick={() => setCurrentPage(page)}>{page}</button>
                    </li>
                  )
                )}
                <li className={`page-item${currentPage === totalPages ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}>Next</button> </li>
              </ul>
            </nav>
          </div>
        </div>

        {/* Threat Statistics */}
        {recentThreats.length > 0 && (
          <div className="row g-4 mt-4">
            <div className="col-md-6">
              <div
                className="card shadow h-100"
                style={{ background: "#fff", border: "1px solid #e5e7eb" }}
              >
                <div
                  className="card-header"
                  style={{
                    // background: "#f8f9fa",
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  <h5 >🎯 Threat Distribution</h5>
                </div>
                <div className="card-body">
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Logic Bomb Threats</span>
                      <span className="badge bg-danger-subtle text-danger">
                        {logicBombThreats.length}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Other Security Issues</span>
                      <span className="badge bg-warning-subtle text-warning">
                        {otherThreats.length}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Logic Bomb Risk Score</span>
                      <span
                        className={`badge ${
                          (summary.logic_bomb_risk_score ??
                            threat_ratings?.logic_bomb_risk_score ??
                            0) >= 70
                            ? "bg-danger-subtle text-danger"
                            : (summary.logic_bomb_risk_score ??
                                threat_ratings?.logic_bomb_risk_score ??
                                0) >= 40
                            ? "bg-warning-subtle text-warning"
                            : "bg-success-subtle text-success"
                        }`}
                      >
                        {summary.logic_bomb_risk_score ??
                          threat_ratings?.logic_bomb_risk_score ??
                          0}
                        /100
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Threat Density</span>
                      <span className="badge bg-info">
                        {Math.min(100, Math.round(
                          (metrics.logic_bomb_metrics?.threat_density || 0) / 100
                        ))}
                        %
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Critical Bomb Ratio</span>
                      <span
                        className={`badge ${
                          metrics.logic_bomb_metrics?.critical_bomb_ratio >= 50
                            ? "bg-danger-subtle text-danger"
                            : metrics.logic_bomb_metrics?.critical_bomb_ratio >=
                              25
                            ? "bg-warning-subtle text-warning"
                            : "bg-success-subtle text-success"
                        }`}
                      >
                        {Math.round(
                          metrics.logic_bomb_metrics?.critical_bomb_ratio || 0
                        )}
                        %
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div
                className="card shadow h-100"
                style={{
                  background: "#fff",
                  border: "1px solid #e5e7eb",
                  color: "#222",
                }}
              >
                <div
                  className="card-header"
                  style={{
                    // background: "#f8f9fa",
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  <h5 >🛡️ Protection Status</h5>
                </div>
                <div className="card-body">
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Threat Shield</span>
                      <span
                        className={`badge ${
                          threat_shield?.status === "PROTECTED"
                            ? "bg-success-subtle text-success"
                            : threat_shield?.status === "BLOCKED"
                            ? "bg-danger-subtle text-danger"
                            : "bg-warning-subtle text-warning"
                        }`}
                      >
                        {threat_shield?.status || "UNKNOWN"}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Detection Engine</span>
                      <span className="badge bg-success-subtle text-success">ACTIVE</span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>AI Analysis</span>
                      <span className="badge bg-info-subtle text-info">ENABLED</span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Shield Effectiveness</span>
                      <span
                        className={`badge ${
                          threat_shield?.protection_effectiveness >= 80
                            ? "bg-success-subtle text-success"
                            : threat_shield?.protection_effectiveness >= 60
                            ? "bg-warning-subtle text-warning"
                            : "bg-danger-subtle text-danger"
                        }`}
                      >
                        {Math.round(
                          threat_shield?.protection_effectiveness || 0
                        )}
                        %
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Threat Detail Modal */}
        {showThreatModal && selectedThreat && (
          <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">
                    🚨 Threat Details - {selectedThreat.severity}
                  </h5>
                  <button 
                    type="button" 
                    className="btn-close" 
                    onClick={() => setShowThreatModal(false)}
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6">
                      <h6>Threat Information</h6>
                      <p><strong>Type:</strong> {selectedThreat.type || 'Unknown'}</p>
                      <p><strong>Priority:</strong> 
                        <span className={`badge ms-2 ${
                          getThreatPriority(selectedThreat) === 'IMMEDIATE' ? 'bg-danger' :
                          getThreatPriority(selectedThreat) === 'HIGH' ? 'bg-warning' :
                          getThreatPriority(selectedThreat) === 'MEDIUM' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {getThreatPriority(selectedThreat)}
                        </span>
                      </p>
                      <p><strong>File:</strong> {selectedThreat.file_name?.split("/").pop() || 
                                                selectedThreat.file_path?.split("/").pop() || 
                                                selectedThreat.file_path?.split("\\").pop() || 
                                                selectedThreat.file_path || 
                                                "Unknown File"}</p>
                      <p><strong>Line:</strong> {selectedThreat.line_number}</p>
                      <p><strong>Status:</strong> 
                        <span className={`badge ms-2 ${
                          selectedThreat.status === 'ACTIVE_THREAT' ? 'bg-danger' : 'bg-success'
                        }`}>
                          {selectedThreat.status}
                        </span>
                      </p>
                    </div>
                    <div className="col-md-6">
                      <h6>Code Snippet</h6>
                      <pre className="bg-light p-2 rounded" style={{ fontSize: '0.8rem' }}>
                        {selectedThreat.code_snippet || 'No code snippet available'}
                      </pre>
                    </div>
                  </div>
                  <div className="mt-3">
                    <h6>Solution</h6>
                    <p className="text-muted">{getThreatSolution(selectedThreat)}</p>
                  </div>
                  {selectedThreat.trigger_analysis && (
                    <div className="mt-3">
                      <h6>Trigger Analysis</h6>
                      <p className="text-info">{selectedThreat.trigger_analysis}</p>
                    </div>
                  )}
                  {selectedThreat.payload_analysis && (
                    <div className="mt-3">
                      <h6>Payload Analysis</h6>
                      <p className="text-danger">{selectedThreat.payload_analysis}</p>
                    </div>
                  )}
                </div>
                <div className="modal-footer">
                  <button 
                    type="button" 
                    className="btn btn-secondary" 
                    onClick={() => setShowThreatModal(false)}
                  >
                    Close
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-danger" 
                    onClick={() => {
                      neutralizeThreat(selectedThreat.id);
                      setShowThreatModal(false);
                    }}
                  >
                    Neutralize Threat
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* System Information Footer */}
        <div
          className="mt-5 pt-4"
          style={{
            borderTop: "1px solid #e5e7eb",
            color: "#888",
            fontSize: "0.9rem",
          }}
        >
          <div className="row">
            <div className="col-md-6">
              <strong >ThreatGuard Pro</strong> -
              Advanced Logic Bomb Detection System
              <br />
              Specialized in Scheduled Threat, Targeted Attack, Execution
              Trigger & destructive payloads
            </div>
            <div className="col-md-6 text-end">
              Last Update: {new Date().toLocaleString()}
              <br />
              System Status:{" "}
              <span style={{ color: "#198754" }}>🟢 Operational</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThreatGuardDashboard;
