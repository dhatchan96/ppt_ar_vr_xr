import React, { useEffect, useState } from "react";
import API from "../api";
import "../style.css";

const ThreatIssues = () => {
  const [threats, setThreats] = useState([]);
  const [filter, setFilter] = useState("all");
  
  // Hierarchical filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');

  // Add pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    fetchThreats();
  }, []);

  const fetchThreats = async () => {
    try {
      const res = await API.get("/api/threats");
      setThreats(res.data || []);
    } catch (err) {
      console.error("Failed to fetch threats:", err);
    }
  };

  const handleStatusToggle = async (id) => {
    const threat = threats.find((t) => t.id === id);
    const newStatus =
      threat.status === "ACTIVE_THREAT" ? "NEUTRALIZED" : "ACTIVE_THREAT";
    try {
      await API.put(`/api/threats/${id}/status`, { status: newStatus });
      fetchThreats();
    } catch (err) {
      console.error("Failed to update threat status:", err);
    }
  };

  const neutralizeThreat = async (id) => {
    if (!window.confirm("Are you sure you want to neutralize this threat?"))
      return;
    try {
      await API.post(`/api/threats/${id}/neutralize`);
      fetchThreats();
    } catch (err) {
      console.error("Failed to neutralize threat:", err);
    }
  };

  // Helper functions for getting display names
  const getAITName = (aitId) => {
    if (!aitId) return '';
    // Dummy data for display names
    const aitData = {
      'AIT001': 'AIT-Web-Development',
      'AIT002': 'AIT-Mobile-Apps',
      'AIT003': 'AIT-Cloud-Services',
      'AIT004': 'AIT-Data-Analytics',
      'AIT005': 'AIT-Security-Tools'
    };
    return aitData[aitId] || aitId;
  };
  
  const getSPKName = (spkId) => {
    if (!spkId) return '';
    // Dummy data for display names
    const spkData = {
      'SPK001': 'SPK-Frontend-React',
      'SPK002': 'SPK-Backend-NodeJS',
      'SPK003': 'SPK-Database-MongoDB',
      'SPK004': 'SPK-Android-Native',
      'SPK005': 'SPK-iOS-Swift',
      'SPK006': 'SPK-React-Native'
    };
    return spkData[spkId] || spkId;
  };
  
  const getRepoName = (repoId) => {
    if (!repoId) return '';
    // Dummy data for display names
    const repoData = {
      'REPO001': 'user-management-frontend',
      'REPO002': 'dashboard-ui-components',
      'REPO003': 'admin-panel-react',
      'REPO004': 'api-gateway-service',
      'REPO005': 'user-authentication-api',
      'REPO006': 'payment-processing-api'
    };
    return repoData[repoId] || repoId;
  };

  const filteredThreats = threats.filter((threat) => {
    // Apply type filter
    if (filter === "logicbombs") {
      if (!(threat.type?.includes("BOMB") || threat.rule_id?.startsWith("LOGIC_BOMB_"))) {
        return false;
      }
    } else if (filter === "active") {
      if (threat.status !== "ACTIVE_THREAT") {
        return false;
      }
    } else if (filter === "critical") {
      if (threat.severity !== "CRITICAL_BOMB") {
        return false;
      }
    }
    
    // Apply hierarchical filters
    if (filterAIT && threat.ait_tag !== filterAIT) return false;
    if (filterSPK && threat.spk_tag !== filterSPK) return false;
    if (filterRepo && threat.repo_name !== filterRepo) return false;
    
    return true;
  });

  // Calculate paginated threats
  const totalPages = Math.ceil(filteredThreats.length / pageSize) || 1;
  const paginatedThreats = filteredThreats.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Reset to page 1 if filters change
  useEffect(() => { setCurrentPage(1); }, [filter, filterAIT, filterSPK, filterRepo, pageSize, threats.length]);

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3; // Show 3 pages before/after current
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  return (
    <div
      className=""
      style={{ background: "#fff", color: "#222", minHeight: "100vh" }}
    >
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: "#0d6efd" }}>🚨 Active Threat Management</h2>
        <div>
          <select
            className="form-select"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{
              background: "#f8f9fa",
              color: "#222",
              border: "1px solid #b0b0b0",
            }}
          >
            <option value="all">All Threats</option>
            <option value="logicbombs">Logic Bomb Threats</option>
            <option value="active">Active Threats</option>
            <option value="critical">Critical Threats</option>
          </select>
        </div>
      </div>

      {/* Hierarchical Filter Controls */}
      <div className="mb-4 p-3 bg-light rounded">
        <h6 className="mb-2" style={{ color: "#222" }}>
          <i className="bi bi-funnel"></i> Filter by Project Hierarchy
        </h6>
        <div className="row g-2">
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterAIT}
              onChange={(e) => setFilterAIT(e.target.value)}
            >
              <option value="">All AITs</option>
              {Array.from(new Set(threats.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                <option key={ait} value={ait}>{getAITName(ait)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterSPK}
              onChange={(e) => setFilterSPK(e.target.value)}
            >
              <option value="">All SPKs</option>
              {Array.from(new Set(threats.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                <option key={spk} value={spk}>{getSPKName(spk)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select form-select-sm"
              value={filterRepo}
              onChange={(e) => setFilterRepo(e.target.value)}
            >
              <option value="">All Repositories</option>
              {Array.from(new Set(threats.map(t => t.repo_name).filter(Boolean))).map(repo => (
                <option key={repo} value={repo}>{getRepoName(repo)}</option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <button
              className="btn btn-outline-secondary btn-sm w-100"
              onClick={() => {
                setFilterAIT('');
                setFilterSPK('');
                setFilterRepo('');
              }}
            >
              <i className="bi bi-x-circle"></i> Clear Filters
            </button>
          </div>
        </div>
        {(filterAIT || filterSPK || filterRepo) && (
          <div className="mt-2">
            <small className="text-muted">
              Showing {filteredThreats.length} of {threats.length} threats
            </small>
          </div>
        )}
      </div>

      {/* Threat Statistics Cards */}
      <div className="row g-4 mb-4">
        <div className="col-md-3">
          <div
            className="card text-center"
            style={{ background: "#fff", border: "1px solid #808080" }}
          >
            <div className="card-body">
              <h3 style={{ color: "#222222" }}>
                {threats.filter((t) => t.severity === "CRITICAL_BOMB").length}
              </h3>
              <p style={{ color: "#888" }}>Critical Logic Bombs</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div
            className="card text-center"
            style={{ background: "#fff", border: "1px solid #808080" }}
          >
            <div className="card-body">
              <h3 style={{ color: "#222222" }}>
                {threats.filter((t) => t.status === "ACTIVE_THREAT").length}
              </h3>
              <p style={{ color: "#888" }}>Active Threats</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div
            className="card text-center"
            style={{ background: "#fff", border: "1px solid #808080" }}
          >
            <div className="card-body">
              <h3 style={{ color: "#222222" }}>
                {threats.filter((t) => t.status === "NEUTRALIZED").length}
              </h3>
              <p style={{ color: "#888" }}>Neutralized</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div
            className="card text-center"
            style={{ background: "#fff", border: "1px solid #808080" }}
          >
            <div className="card-body">
              <h3 style={{ color: "#222222" }}>{threats.length}</h3>
              <p style={{ color: "#888" }}>Total Threats</p>
            </div>
          </div>
        </div>
      </div>

      <div
        className="mt-5"
        style={{ background: "#f8f9fa", border: "1px solid #e5e7eb" }}
      >
        <div className="table-responsive w-100">
          <table
            className="table table-bordered table-hover align-middle table-sm"
            style={{ minWidth: "1200px", background: "#fff" }}
          >
            <thead className="table-light">
              <tr>
                <th>#</th>
                <th>Threat Level</th>
                <th>Type</th>
                <th>AIT</th>
                <th>SPK</th>
                <th>Repository</th>
                <th>Rule</th>
                <th>File</th>
                <th>Line</th>
                <th>Trigger Analysis</th>
                <th>Status</th>
                <th className="text-center">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {paginatedThreats.length > 0 ? (
                paginatedThreats.map((threat, index) => (
                  <tr key={threat.id}>
                    <td style={{ color: "#888" }}>{(currentPage - 1) * pageSize + index + 1}</td>
                    <td>
                      {(() => {
                        let badgeClass = "border-secondary text-secondary bg-secondary-subtle";
                        if (threat.severity === "CRITICAL_BOMB") {
                          badgeClass = "border-danger text-danger bg-danger-subtle";
                        } else if (threat.severity === "HIGH_RISK") {
                          badgeClass = "border-warning text-warning bg-warning-subtle";
                        } else if (threat.severity === "MEDIUM_RISK") {
                          badgeClass = "border-info text-info bg-info-subtle";
                        }
                        return (
                          <span className={`badge border ${badgeClass}`}>
                            {threat.severity}
                          </span>
                        );
                      })()}
                    </td>
                    <td style={{ color: "#222" }}>{threat.type}</td>
                    <td style={{ color: "#666", fontSize: "0.85rem" }}>
                      {getAITName(threat.ait_tag) || threat.ait_tag || "AIT"}
                    </td>
                    <td style={{ color: "#666", fontSize: "0.85rem" }}>
                      {getSPKName(threat.spk_tag) || threat.spk_tag || "SPK"}
                    </td>
                    <td style={{ color: "#666", fontSize: "0.85rem" }}>
                      {getRepoName(threat.repo_name) || threat.repo_name || "Repo"}
                    </td>
                    <td style={{ color: "#888", fontSize: "0.85rem" }}>
                      {threat.rule_id}
                    </td>
                    <td
                      style={{
                        wordBreak: "break-all",
                        color: "#222",
                        maxWidth: "300px",
                        whiteSpace: "normal",
                        overflow: "auto",
                      }}
                    >
                      {threat.file_name?.split("/").pop() || 
                       threat.file_path?.split("/").pop() || 
                       threat.file_path?.split("\\").pop() || 
                       threat.file_path || 
                       "Unknown File"}
                    </td>
                    <td className="text-center" >
                      {threat.line_number}
                    </td>
                    <td
                      style={{
                        whiteSpace: "pre-wrap",
                        maxWidth: "250px",
                        // color: "#fd7e14",
                        fontSize: "0.85rem",
                      }}
                    >
                      {threat.trigger_analysis || "Analysis pending"}
                    </td>
                    <td>
                      {(() => {
                        let statusBadgeClass = "border-secondary text-secondary bg-secondary-subtle";
                        if (threat.status === "NEUTRALIZED") {
                          statusBadgeClass = "border-success text-success bg-success-subtle";
                        } else if (threat.status === "ACTIVE_THREAT") {
                          statusBadgeClass = "border-danger text-danger bg-danger-subtle";
                        } else if (threat.status === "UNDER_REVIEW") {
                          statusBadgeClass = "border-warning text-warning bg-warning-subtle";
                        }
                        return (
                          <span className={`badge border ${statusBadgeClass}`}>
                            {threat.status}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="text-center">
                      <div className="d-flex justify-content-center gap-2">
                        <button
                          className="btn btn-sm btn-outline-success"
                          onClick={() => neutralizeThreat(threat.id)}
                          disabled={threat.status === "NEUTRALIZED"}
                        >
                          {threat.status === "NEUTRALIZED"
                            ? "Neutralized"
                            : "Neutralize"}
                        </button>
                        <button
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => handleStatusToggle(threat.id)}
                        >
                          {threat.status === "ACTIVE_THREAT"
                            ? "Resolve"
                            : "Reactivate"}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan={12} className="text-center">No threats found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Add pagination controls below the table */}
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div>
            <select className="form-select form-select-sm" style={{ width: 100, display: 'inline-block' }} value={pageSize} onChange={e => setPageSize(Number(e.target.value))}>
              {[10, 25, 50, 100].map(size => <option key={size} value={size}>{size} / page</option>)}
            </select>
            <span className="ms-2 text-muted">
              Showing {(filteredThreats.length === 0) ? 0 : ((currentPage - 1) * pageSize + 1)}-
              {Math.min(currentPage * pageSize, filteredThreats.length)} of {filteredThreats.length}
            </span>
          </div>
          <nav style={{ overflowX: 'auto', maxWidth: 400 }}>
            <ul className="pagination pagination-sm mb-0 flex-nowrap">
              <li className={`page-item${currentPage === 1 ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.max(1, p - 1))}>Prev</button> </li>
              {getPaginationWindow(currentPage, totalPages).map((page, idx) =>
                page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                  <li key={page + idx} className="page-item disabled"><span className="page-link">...</span></li>
                ) : (
                  <li key={page} className={`page-item${page === currentPage ? ' active' : ''}`}>
                    <button className="page-link" onClick={() => setCurrentPage(page)}>{page}</button>
                  </li>
                )
              )}
              <li className={`page-item${currentPage === totalPages ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}>Next</button> </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default ThreatIssues;
