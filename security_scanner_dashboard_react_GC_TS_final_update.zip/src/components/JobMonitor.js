import React, { useState, useEffect } from 'react';
import { FaSpinner, FaCheck, FaTimes, FaEye, FaTrash, FaPlay, FaPause, FaFilter, FaDownload, FaArrowLeft } from 'react-icons/fa';
import API from '../api';

const JobMonitor = ({ onJobComplete, isStandalone = false, onBack }) => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [cleanupInProgress, setCleanupInProgress] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Unique values for dropdowns
  const [uniqueAITs, setUniqueAITs] = useState([]);
  const [uniqueSPKs, setUniqueSPKs] = useState([]);
  const [uniqueRepos, setUniqueRepos] = useState([]);
  const [uniqueStatuses, setUniqueStatuses] = useState([]);
  
  // Custom dropdown state for cleanup
  const [showCleanupDropdown, setShowCleanupDropdown] = useState(false);

  useEffect(() => {
    loadJobs();
    // Poll for job updates every 5 seconds
    const interval = setInterval(loadJobs, 5000);
    setPollingInterval(interval);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    applyFilters();
  }, [jobs, filterAIT, filterSPK, filterRepo, filterStatus]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showCleanupDropdown && !event.target.closest('.btn-group')) {
        console.log('🧹 Clicking outside dropdown, closing it');
        setShowCleanupDropdown(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [showCleanupDropdown]);

  // Debug dropdown state changes
  useEffect(() => {
    console.log('🧹 Dropdown state changed:', showCleanupDropdown);
  }, [showCleanupDropdown]);

  const loadJobs = async () => {
    try {
      setLoading(true);
      console.log('🔄 Loading jobs...');
      
      // Add cache-busting parameter to ensure fresh data
      const timestamp = Date.now();
      const response = await API.get(`/api/jobs?limit=50&_t=${timestamp}`);
      const jobsData = response.data.jobs || [];
      console.log(`📋 Loaded ${jobsData.length} jobs:`, jobsData.map(job => ({ id: job.job_id, status: job.status })));
      setJobs(jobsData);
      
      // Extract unique values for filters
      const aits = Array.from(new Set(jobsData.map(job => job.ait_tag).filter(Boolean)));
      const spks = Array.from(new Set(jobsData.map(job => job.spk_tag).filter(Boolean)));
      const repos = Array.from(new Set(jobsData.map(job => job.repo_name).filter(Boolean)));
      const statuses = Array.from(new Set(jobsData.map(job => job.status).filter(Boolean)));
      
      setUniqueAITs(aits);
      setUniqueSPKs(spks);
      setUniqueRepos(repos);
      setUniqueStatuses(statuses);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...jobs];
    
    if (filterAIT) {
      filtered = filtered.filter(job => job.ait_tag === filterAIT);
    }
    
    if (filterSPK) {
      filtered = filtered.filter(job => job.spk_tag === filterSPK);
    }
    
    if (filterRepo) {
      filtered = filtered.filter(job => job.repo_name === filterRepo);
    }
    
    if (filterStatus) {
      filtered = filtered.filter(job => job.status === filterStatus);
    }
    
    setFilteredJobs(filtered);
  };

  const clearFilters = () => {
    setFilterAIT('');
    setFilterSPK('');
    setFilterRepo('');
    setFilterStatus('');
  };

  const getDisplayName = (value, type) => {
    if (!value) return 'Unknown';
    
    switch (type) {
      case 'ait':
        return value === 'AIT' ? 'Default AIT' : value;
      case 'spk':
        return value === 'SPK-DEFAULT' ? 'Default SPK' : value;
      case 'repo':
        return value === 'unknown-repo' ? 'Unknown Repository' : value;
      default:
        return value;
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <FaPause className="text-warning" />;
      case 'running':
        return <FaSpinner className="text-primary fa-spin" />;
      case 'completed':
        return <FaCheck className="text-success" />;
      case 'failed':
        return <FaTimes className="text-danger" />;
      case 'cancelled':
        return <FaTimes className="text-secondary" />;
      default:
        return <FaEye className="text-muted" />;
    }
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'badge bg-warning text-dark',
      running: 'badge bg-primary',
      completed: 'badge bg-success',
      failed: 'badge bg-danger',
      cancelled: 'badge bg-secondary'
    };
    return statusClasses[status] || 'badge bg-secondary';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  const getDuration = (startedAt, completedAt) => {
    if (!startedAt) return 'N/A';
    const start = new Date(startedAt);
    const end = completedAt ? new Date(completedAt) : new Date();
    const duration = Math.round((end - start) / 1000);
    return `${duration}s`;
  };

  const truncateError = (errorMessage, maxLength = 50) => {
    if (!errorMessage) return '';
    if (errorMessage.length <= maxLength) return errorMessage;
    return errorMessage.substring(0, maxLength) + '...';
  };

  const cancelJob = async (jobId) => {
    try {
      await API.post(`/api/jobs/${jobId}/cancel`);
      showToast('Job cancelled successfully', 'success');
      loadJobs();
    } catch (error) {
      showToast('Failed to cancel job', 'error');
    }
  };

  const showJobDetails = (job) => {
    setSelectedJob(job);
    setShowDetails(true);
  };

  const showToast = (message, type = 'info') => {
    // Simple toast implementation - you can replace with your preferred toast library
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  const cleanupOldJobs = async (days = 7) => {
    console.log('🧹 Cleanup button clicked with days:', days);
    alert(`Cleanup function called with ${days} days! Check console for details.`);
    
    // Determine cleanup message based on days
    let cleanupMessage = '';
    if (days === 0) {
      cleanupMessage = 'Are you sure you want to clean up ALL completed/failed jobs?\n\n' +
                      'This will permanently delete ALL jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    } else if (days === 1) {
      cleanupMessage = 'Are you sure you want to clean up completed/failed jobs from the last 24 hours?\n\n' +
                      'This will permanently delete jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    } else {
      cleanupMessage = `Are you sure you want to clean up completed/failed jobs older than ${days} days?\n\n` +
                      'This will permanently delete jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    }
    
    // Add confirmation dialog
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      console.log('🧹 Cleanup cancelled by user');
      return;
    }
    
    console.log('🧹 Cleanup confirmed by user, proceeding...');
    
    try {
      setCleanupInProgress(true);
      
      // Temporarily pause polling to avoid race conditions
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cleanup');
      }
      
      console.log('🧹 Starting cleanup with days:', days);
      const response = await API.post(`/api/jobs/cleanup?days=${days}`);
      const data = response.data;
      
      console.log('✅ Cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} old jobs`, 'success');
      } else {
        showToast('No old jobs found to clean up', 'info');
      }
      
      // Force reload jobs immediately after cleanup
      console.log('🔄 Reloading jobs after cleanup...');
      await loadJobs();
      
      // Wait a moment and reload again to ensure we have the latest data
      setTimeout(async () => {
        console.log('🔄 Second reload after cleanup...');
        await loadJobs();
      }, 1000);
      
      // Restart polling after cleanup
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cleanup');
      
    } catch (error) {
      console.error('Cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup jobs';
      showToast(errorMessage, 'error');
      
      // Restart polling even if cleanup failed
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  // If not standalone, render as embedded component
  if (!isStandalone) {
    return (
      <div className="card">
        <div className="card-header d-flex justify-content-between align-items-center">
          <h5 className="mb-0">
            <FaSpinner className="me-2" />
            Repository Scan Jobs
          </h5>
          <div>
            <button 
              className="btn btn-sm btn-outline-secondary me-2" 
              onClick={loadJobs}
              disabled={loading}
            >
              {loading ? <FaSpinner className="fa-spin" /> : 'Refresh'}
            </button>
            <div className="btn-group btn-group-sm position-relative">
              <button 
                className="btn btn-outline-warning dropdown-toggle" 
                onClick={() => {
                  console.log('🧹 Cleanup button clicked (embedded), current state:', showCleanupDropdown);
                  setShowCleanupDropdown(!showCleanupDropdown);
                }}
                disabled={cleanupInProgress}
              >
              <button 
                className="btn btn-outline-danger btn-sm ms-2" 
                onClick={() => {
                  console.log('🧹 Test cleanup button clicked');
                  cleanupOldJobs(1);
                }}
                disabled={cleanupInProgress}
              >
                Test Cleanup
              </button>
                {cleanupInProgress ? (
                  <>
                    <FaSpinner className="fa-spin me-1" />
                    Cleaning...
                  </>
                ) : (
                  <>
                    <FaTrash className="me-1" />
                    Cleanup
                  </>
                )}
              </button>
              {showCleanupDropdown && (
                <ul className="dropdown-menu show position-absolute" style={{ top: '100%', left: '0', zIndex: 1000 }}>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(1); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 24 hours</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(3); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 3 days</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(7); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 7 days</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(30); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 30 days</button></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><button className="dropdown-item text-danger" onClick={() => { cleanupOldJobs(0); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>All completed jobs</button></li>
                </ul>
              )}
            </div>
          </div>
        </div>
        <div className="card-body">
          {cleanupInProgress && (
            <div className="alert alert-info text-center mb-3">
              <FaSpinner className="fa-spin me-2" />
              Cleaning up old jobs... Please wait.
            </div>
          )}
          
          {jobs.length === 0 ? (
            <div className="text-center text-muted py-4">
              <FaEye className="mb-3" style={{ fontSize: '3rem' }} />
              <p>No scan jobs found</p>
              <small>Repository scans will appear here</small>
            </div>
          ) : (
                         <div className="table-responsive">
               <table className="table table-hover job-monitor-table">
                <thead>
                  <tr>
                    <th>Status</th>
                    <th>Repository</th>
                    <th>Progress</th>
                    <th>Created</th>
                    <th>Duration</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((job) => (
                    <tr key={job.job_id}>
                      <td>
                        <div className="d-flex align-items-center">
                          {getStatusIcon(job.status)}
                          <span className={`ms-2 ${getStatusBadge(job.status)}`}>
                            {job.status}
                          </span>
                        </div>
                      </td>
                      <td>
                        <div>
                          <strong>{job.repo_url?.split('/').pop() || 'Unknown'}</strong>
                          <br />
                          <small className="text-muted">{job.repo_url}</small>
                        </div>
                      </td>
                      <td>
                        <div className="progress" style={{ height: '8px', borderRadius: '4px' }}>
                          <div 
                            className={`progress-bar ${
                              job.status === 'completed' ? 'bg-success' :
                              job.status === 'failed' ? 'bg-danger' :
                              job.status === 'running' ? 'bg-primary' :
                              'bg-secondary'
                            }`}
                            style={{ 
                              width: job.status === 'completed' ? '100%' :
                                     job.status === 'failed' ? '100%' :
                                     job.status === 'running' ? '50%' : '0%',
                              borderRadius: '4px',
                              transition: 'width 0.3s ease'
                            }}
                          >
                          </div>
                        </div>
                        <small className="job-progress-text">
                          {job.progress}
                        </small>
                        {job.error_message && (
                          <div className="error-message mt-1" title={job.error_message}>
                            {truncateError(job.error_message)}
                          </div>
                        )}
                      </td>
                      <td>
                        <small>{formatDate(job.created_at)}</small>
                      </td>
                      <td>
                        <small>{getDuration(job.started_at, job.completed_at)}</small>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <button
                            className="btn btn-outline-primary"
                            onClick={() => showJobDetails(job)}
                            title="View Details"
                          >
                            <FaEye />
                          </button>
                          {job.status === 'running' && (
                            <button
                              className="btn btn-outline-warning"
                              onClick={() => cancelJob(job.job_id)}
                              title="Cancel Job"
                            >
                              <FaTimes />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Job Details Modal */}
        {showDetails && selectedJob && (
          <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
            <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">Job Details</h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={() => setShowDetails(false)}
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6">
                      <h6>Job Information</h6>
                      <table className="table table-sm">
                        <tbody>
                          <tr>
                            <td><strong>Job ID:</strong></td>
                            <td><code>{selectedJob.job_id}</code></td>
                          </tr>
                          <tr>
                            <td><strong>Status:</strong></td>
                            <td>
                              <span className={getStatusBadge(selectedJob.status)}>
                                {selectedJob.status}
                              </span>
                            </td>
                          </tr>
                          <tr>
                            <td><strong>Repository:</strong></td>
                            <td>{selectedJob.repo_url}</td>
                          </tr>
                          <tr>
                            <td><strong>Type:</strong></td>
                            <td>{selectedJob.repo_type}</td>
                          </tr>
                          <tr>
                            <td><strong>Created:</strong></td>
                            <td>{formatDate(selectedJob.created_at)}</td>
                          </tr>
                          <tr>
                            <td><strong>Started:</strong></td>
                            <td>{formatDate(selectedJob.started_at)}</td>
                          </tr>
                          <tr>
                            <td><strong>Completed:</strong></td>
                            <td>{formatDate(selectedJob.completed_at)}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <div className="col-md-6">
                      <h6>Progress & Results</h6>
                      <div className="mb-3">
                        <strong>Progress:</strong>
                        <p className="text-muted">{selectedJob.progress}</p>
                      </div>
                      {selectedJob.error_message && (
                        <div className="mb-3">
                          <strong>Error:</strong>
                          <div className="alert alert-danger">
                            {selectedJob.error_message}
                          </div>
                        </div>
                      )}
                      {selectedJob.result_data && (
                        <div className="mb-3">
                          <strong>Results:</strong>
                          <div className="alert alert-success">
                            <p><strong>Files Scanned:</strong> {selectedJob.result_data.files_scanned || 'N/A'}</p>
                            <p><strong>Threats Found:</strong> {selectedJob.result_data.summary?.total_issues || 0}</p>
                            <p><strong>Risk Score:</strong> {selectedJob.result_data.summary?.logic_bomb_risk_score || 0}/100</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowDetails(false)}
                  >
                    Close
                  </button>
                  {selectedJob.status === 'completed' && selectedJob.result_data && (
                    <button
                      type="button"
                      className="btn btn-primary"
                      onClick={() => {
                        console.log('🔍 View Results clicked for job:', selectedJob.job_id);
                        onJobComplete(selectedJob.result_data);
                        setShowDetails(false);
                      }}
                    >
                      View Results
                    </button>
                  )}
                </div>
              </div>
            </div>
            <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
          </div>
        )}
      </div>
    );
  }

  // Standalone page render
  return (
    <div className="container-fluid mt-4 px-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div className="d-flex align-items-center">
          {onBack && (
            <button 
              className="btn btn-outline-secondary me-3"
              onClick={onBack}
            >
              <FaArrowLeft className="me-1" />
              Back
            </button>
          )}
          <h2>🔍 Job Monitor</h2>
        </div>
        <div className="d-flex gap-2">
          <button 
            className={`btn btn-outline-primary btn-sm ${showFilters ? 'active' : ''}`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <FaFilter className="me-1" />
            Filters
          </button>
          <button 
            className="btn btn-outline-secondary btn-sm"
            onClick={clearFilters}
            disabled={!filterAIT && !filterSPK && !filterRepo && !filterStatus}
          >
            Clear
          </button>
          <button 
            className="btn btn-outline-info btn-sm" 
            onClick={loadJobs}
            disabled={loading}
          >
            {loading ? <FaSpinner className="fa-spin" /> : 'Refresh'}
          </button>
        </div>
      </div>

      {/* Filter Section */}
      {showFilters && (
        <div className="card mb-4">
          <div className="card-header">
            <h6 className="mb-0">
              <FaFilter className="me-2" />
              Filter Jobs
            </h6>
          </div>
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label">AIT (Application Integration Team)</label>
                <select
                  className="form-select"
                  value={filterAIT}
                  onChange={(e) => setFilterAIT(e.target.value)}
                >
                  <option value="">All AITs</option>
                  {uniqueAITs.map(ait => (
                    <option key={ait} value={ait}>
                      {getDisplayName(ait, 'ait')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">SPK (Specific Product/Workstream Key)</label>
                <select
                  className="form-select"
                  value={filterSPK}
                  onChange={(e) => setFilterSPK(e.target.value)}
                >
                  <option value="">All SPKs</option>
                  {uniqueSPKs.map(spk => (
                    <option key={spk} value={spk}>
                      {getDisplayName(spk, 'spk')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">Repository Name</label>
                <select
                  className="form-select"
                  value={filterRepo}
                  onChange={(e) => setFilterRepo(e.target.value)}
                >
                  <option value="">All Repositories</option>
                  {uniqueRepos.map(repo => (
                    <option key={repo} value={repo}>
                      {getDisplayName(repo, 'repo')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">Job Status</label>
                <select
                  className="form-select"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <option value="">All Statuses</option>
                  {uniqueStatuses.map(status => (
                    <option key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            {/* Active Filters Display */}
            {(filterAIT || filterSPK || filterRepo || filterStatus) && (
              <div className="mt-3">
                <small className="text-muted">Active filters:</small>
                <div className="d-flex flex-wrap gap-2 mt-1">
                  {filterAIT && (
                    <span className="badge bg-primary">
                      AIT: {getDisplayName(filterAIT, 'ait')}
                    </span>
                  )}
                  {filterSPK && (
                    <span className="badge bg-info">
                      SPK: {getDisplayName(filterSPK, 'spk')}
                    </span>
                  )}
                  {filterRepo && (
                    <span className="badge bg-success">
                      Repo: {getDisplayName(filterRepo, 'repo')}
                    </span>
                  )}
                  {filterStatus && (
                    <span className="badge bg-warning">
                      Status: {filterStatus.charAt(0).toUpperCase() + filterStatus.slice(1)}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Statistics Summary */}
      <div className="row mb-4">
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-primary">{filteredJobs.length}</h4>
              <small className="text-muted">Filtered Jobs</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-success">{jobs.length}</h4>
              <small className="text-muted">Total Jobs</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-warning">
                {filteredJobs.filter(job => job.status === 'running').length}
              </h4>
              <small className="text-muted">Running Jobs</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-info">
                {filteredJobs.filter(job => job.status === 'completed').length}
              </h4>
              <small className="text-muted">Completed Jobs</small>
            </div>
          </div>
        </div>
      </div>

      {/* Cleanup Controls */}
      <div className="card mb-4">
        <div className="card-header">
          <h6 className="mb-0">
            <FaTrash className="me-2" />
            Job Management
          </h6>
        </div>
        <div className="card-body">
          <div className="d-flex gap-2">
                         <div className="btn-group position-relative">
               <button 
                 className="btn btn-outline-warning dropdown-toggle" 
                 onClick={() => {
                   console.log('🧹 Cleanup button clicked (standalone), current state:', showCleanupDropdown);
                   setShowCleanupDropdown(!showCleanupDropdown);
                 }}
                 disabled={cleanupInProgress}
               >
                {cleanupInProgress ? (
                  <>
                    <FaSpinner className="fa-spin me-1" />
                    Cleaning...
                  </>
                ) : (
                  <>
                    <FaTrash className="me-1" />
                    Cleanup Jobs
                  </>
                )}
              </button>
              {showCleanupDropdown && (
                <ul className="dropdown-menu show position-absolute" style={{ top: '100%', left: '0', zIndex: 1000 }}>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(1); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 24 hours</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(3); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 3 days</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(7); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 7 days</button></li>
                  <li><button className="dropdown-item" onClick={() => { cleanupOldJobs(30); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>Last 30 days</button></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><button className="dropdown-item text-danger" onClick={() => { cleanupOldJobs(0); setShowCleanupDropdown(false); }} disabled={cleanupInProgress}>All completed jobs</button></li>
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Jobs Table */}
      <div className="card">
        <div className="card-header">
          <h6 className="mb-0">
            <FaEye className="me-2" />
            Job Results ({filteredJobs.length} of {jobs.length} jobs)
          </h6>
        </div>
        <div className="card-body p-0">
          {cleanupInProgress && (
            <div className="alert alert-info text-center m-3">
              <FaSpinner className="fa-spin me-2" />
              Cleaning up old jobs... Please wait.
            </div>
          )}
          
          {filteredJobs.length === 0 ? (
            <div className="text-center text-muted py-5">
              <FaEye className="mb-3" style={{ fontSize: '3rem' }} />
              <p>{jobs.length === 0 ? 'No scan jobs found' : 'No jobs match the current filters'}</p>
              <small>Repository scans will appear here</small>
            </div>
          ) : (
                         <div className="table-responsive">
               <table className="table table-hover mb-0 job-monitor-table">
                <thead className="table-light">
                  <tr>
                    <th>Status</th>
                    <th>Repository</th>
                    <th>AIT</th>
                    <th>SPK</th>
                    <th>Progress</th>
                    <th>Created</th>
                    <th>Duration</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredJobs.map((job) => (
                    <tr key={job.job_id}>
                      <td>
                        <div className="d-flex align-items-center">
                          {getStatusIcon(job.status)}
                          <span className={`ms-2 ${getStatusBadge(job.status)}`}>
                            {job.status}
                          </span>
                        </div>
                      </td>
                      <td>
                        <div>
                          <strong>{job.repo_url?.split('/').pop() || job.repo_name || 'Unknown'}</strong>
                          <br />
                          <small className="text-muted">{job.repo_url}</small>
                        </div>
                      </td>
                      <td>
                        <span className="badge bg-primary">
                          {getDisplayName(job.ait_tag, 'ait')}
                        </span>
                      </td>
                      <td>
                        <span className="badge bg-info">
                          {getDisplayName(job.spk_tag, 'spk')}
                        </span>
                      </td>
                      <td>
                        <div className="progress" style={{ height: '8px', borderRadius: '4px' }}>
                          <div 
                            className={`progress-bar ${
                              job.status === 'completed' ? 'bg-success' :
                              job.status === 'failed' ? 'bg-danger' :
                              job.status === 'running' ? 'bg-primary' :
                              'bg-secondary'
                            }`}
                            style={{ 
                              width: job.status === 'completed' ? '100%' :
                                     job.status === 'failed' ? '100%' :
                                     job.status === 'running' ? '50%' : '0%',
                              borderRadius: '4px',
                              transition: 'width 0.3s ease'
                            }}
                          >
                          </div>
                        </div>
                        <small className="job-progress-text">
                          {job.progress}
                        </small>
                        {job.error_message && (
                          <div className="error-message mt-1" title={job.error_message}>
                            {truncateError(job.error_message)}
                          </div>
                        )}
                      </td>
                      <td>
                        <small>
                          {new Date(job.created_at).toLocaleDateString()}<br/>
                          {new Date(job.created_at).toLocaleTimeString()}
                        </small>
                      </td>
                      <td>
                        <small>{getDuration(job.started_at, job.completed_at)}</small>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <button
                            className="btn btn-outline-primary"
                            onClick={() => showJobDetails(job)}
                            title="View Details"
                          >
                            <FaEye />
                          </button>
                          {job.status === 'running' && (
                            <button
                              className="btn btn-outline-warning"
                              onClick={() => cancelJob(job.job_id)}
                              title="Cancel Job"
                            >
                              <FaTimes />
                            </button>
                          )}
                          {job.status === 'completed' && job.result_data && (
                            <button
                              className="btn btn-outline-success"
                              onClick={() => {
                                console.log('🔍 View Results clicked for job:', job.job_id);
                                onJobComplete(job.result_data);
                              }}
                              title="View Results"
                            >
                              <FaDownload />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Job Details Modal */}
      {showDetails && selectedJob && (
        <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
          <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Job Details</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowDetails(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6>Job Information</h6>
                    <table className="table table-sm">
                      <tbody>
                        <tr>
                          <td><strong>Job ID:</strong></td>
                          <td><code>{selectedJob.job_id}</code></td>
                        </tr>
                        <tr>
                          <td><strong>Status:</strong></td>
                          <td>
                            <span className={getStatusBadge(selectedJob.status)}>
                              {selectedJob.status}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Repository:</strong></td>
                          <td>{selectedJob.repo_url}</td>
                        </tr>
                        <tr>
                          <td><strong>Type:</strong></td>
                          <td>{selectedJob.repo_type}</td>
                        </tr>
                        <tr>
                          <td><strong>AIT:</strong></td>
                          <td>{getDisplayName(selectedJob.ait_tag, 'ait')}</td>
                        </tr>
                        <tr>
                          <td><strong>SPK:</strong></td>
                          <td>{getDisplayName(selectedJob.spk_tag, 'spk')}</td>
                        </tr>
                        <tr>
                          <td><strong>Created:</strong></td>
                          <td>{formatDate(selectedJob.created_at)}</td>
                        </tr>
                        <tr>
                          <td><strong>Started:</strong></td>
                          <td>{formatDate(selectedJob.started_at)}</td>
                        </tr>
                        <tr>
                          <td><strong>Completed:</strong></td>
                          <td>{formatDate(selectedJob.completed_at)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="col-md-6">
                    <h6>Progress & Results</h6>
                    <div className="mb-3">
                      <strong>Progress:</strong>
                      <p className="text-muted">{selectedJob.progress}</p>
                    </div>
                    {selectedJob.error_message && (
                      <div className="mb-3">
                        <strong>Error:</strong>
                        <div className="alert alert-danger">
                          {selectedJob.error_message}
                        </div>
                      </div>
                    )}
                    {selectedJob.result_data && (
                      <div className="mb-3">
                        <strong>Results:</strong>
                        <div className="alert alert-success">
                          <p><strong>Files Scanned:</strong> {selectedJob.result_data.files_scanned || 'N/A'}</p>
                          <p><strong>Threats Found:</strong> {selectedJob.result_data.summary?.total_issues || 0}</p>
                          <p><strong>Risk Score:</strong> {selectedJob.result_data.summary?.logic_bomb_risk_score || 0}/100</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowDetails(false)}
                >
                  Close
                </button>
                {selectedJob.status === 'completed' && selectedJob.result_data && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => {
                      console.log('🔍 View Results clicked for job:', selectedJob.job_id);
                      onJobComplete(selectedJob.result_data);
                      setShowDetails(false);
                    }}
                  >
                    View Results
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
        </div>
      )}
    </div>
  );

  const handleShowErrorDetails = (errorMessage, job) => {
    setSelectedError({ errorMessage, job });
    setShowErrorDetails(true);
  };
};

export default JobMonitor;
