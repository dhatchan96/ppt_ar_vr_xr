import React, { useEffect, useState } from "react";
import API from "../api";

// Global flag to prevent any metrics API calls when job results are active
let globalMetricsAPIDisabled = false;

// Create a protected API wrapper
const createProtectedAPI = (isJobResultsActive, disableMetricsAPI) => {
  const originalGet = API.get;
  return {
    ...API,
    get: async (url, config) => {
      // Log all API calls to metrics endpoints
      if (url.includes('/api/command-center/metrics')) {
        console.log(`🔍 API call to ${url} - isJobResultsActive: ${isJobResultsActive.current}, disableMetricsAPI: ${disableMetricsAPI}, globalDisabled: ${globalMetricsAPIDisabled}`);
      }
      
      // Block any calls to metrics endpoints when job results are active, API is disabled, or global flag is set
      if ((isJobResultsActive.current || disableMetricsAPI || globalMetricsAPIDisabled) && url.includes('/api/command-center/metrics')) {
        console.log(`🚫 BLOCKED API call to ${url} - job results are active, API disabled, or global flag set`);
        return { data: null, error: 'blocked' };
      }
      console.log(`✅ ALLOWED API call to ${url}`);
      return originalGet(url, config);
    }
  };
};
import "../style.css";
import { Toast } from "bootstrap";
import JSZip from "jszip";
import { 
  getAitData, 
  getSpkData, 
  getRepoData,
  getAITName,
  getSPKName,
  getRepoName,
  initializeDropdownData
} from '../config/dropdownData';

import {
  FaProjectDiagram,
  FaBuilding,
  FaCog,
  FaFolder,
  FaShieldAlt,
  FaFlask,
  FaGithub,
  FaShieldVirus,
  FaLock,
  FaInfoCircle,
  FaBomb,
  FaExclamationTriangle,
  FaDownload,
  FaFilter,
  FaTimesCircle,
  FaSync,
  FaArrowLeft,
  FaSpinner
} from "react-icons/fa";

const ThreatGuardDashboard = ({ hideFileUpload = false, jobResults, setJobResults }) => {
  // Global flag to prevent any metrics API calls when job results are active
  const isJobResultsActive = React.useRef(false);
  const isMounted = React.useRef(true);
  const [metrics, setMetrics] = useState(null);
  
  // Simple flag to disable command-center metrics API calls
  const [disableMetricsAPI, setDisableMetricsAPI] = useState(false);
  
  // Create protected API with current disableMetricsAPI state
  const protectedAPI = React.useMemo(() => 
    createProtectedAPI(isJobResultsActive, disableMetricsAPI), 
    [disableMetricsAPI]
  );
  
  // Wrapper for setMetrics to add debugging and protection
  const setMetricsWithDebug = (newMetrics, source = 'unknown') => {
    console.log(`🔍 setMetrics called from ${source}:`, {
      hasJobResults,
      isProcessingJobResults,
      isInitialized,
      newMetricsKeys: Object.keys(newMetrics || {}),
      currentMetricsKeys: Object.keys(metrics || {})
    });
    
    // Block any metrics updates if job results are active or being processed
    if (hasJobResults || isProcessingJobResults) {
      console.log(`🚫 BLOCKED setMetrics from ${source} - job results are active`);
      return;
    }
    
    // Block metrics updates during initial job results processing
    if (isInitialized && source !== 'jobResults') {
      console.log(`🚫 BLOCKED setMetrics from ${source} - component initialized with job results`);
      return;
    }
    
    console.log(`✅ ALLOWED setMetrics from ${source}`);
    setMetrics(newMetrics);
  };
  
  // Wrapper for setRecentThreats to add protection
  const setRecentThreatsWithDebug = (newThreats, source = 'unknown') => {
    console.log(`🔍 setRecentThreats called from ${source}:`, {
      hasJobResults,
      isProcessingJobResults,
      isInitialized,
      threatsCount: newThreats?.length || 0
    });
    
    // Block any threats updates if job results are active or being processed
    if (hasJobResults || isProcessingJobResults) {
      console.log(`🚫 BLOCKED setRecentThreats from ${source} - job results are active`);
      return;
    }
    
    // Block threats updates during initial job results processing
    if (isInitialized && source !== 'jobResults') {
      console.log(`🚫 BLOCKED setRecentThreats from ${source} - component initialized with job results`);
      return;
    }
    
    console.log(`✅ ALLOWED setRecentThreats from ${source}`);
    setRecentThreats(newThreats);
  };
  const [recentThreats, setRecentThreats] = useState([]);
  const [health, setHealth] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [logicBombStats, setLogicBombStats] = useState(null);
  const [vulnerabilityStats, setVulnerabilityStats] = useState(null);
  const [activeTab, setActiveTab] = useState("logicbombs");
  const [selectedThreat, setSelectedThreat] = useState(null);
  const [showThreatModal, setShowThreatModal] = useState(false);
  
  // Cascading dropdown states
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');
  const [showUploadComponent, setShowUploadComponent] = useState(false);
  const [showScanOptions, setShowScanOptions] = useState(false);
  const [showGithubScanComponent, setShowGithubScanComponent] = useState(false);
  const [constructedRepoUrl, setConstructedRepoUrl] = useState('');
  const [repoUrlValidation, setRepoUrlValidation] = useState({ isValid: false, message: '' });
  const [isValidatingRepo, setIsValidatingRepo] = useState(false);
  const [showManualUrlEdit, setShowManualUrlEdit] = useState(false);
  const [manualRepoUrl, setManualRepoUrl] = useState('');
  
  // Dynamic dropdown data
  const [dynamicAitData, setDynamicAitData] = useState([]);
  const [dynamicSpkData, setDynamicSpkData] = useState({});
  const [dynamicRepoData, setDynamicRepoData] = useState({});
  const [refreshingDropdowns, setRefreshingDropdowns] = useState(false);
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  
  // GitHub repository upload states
  const [repoUrl, setRepoUrl] = useState('');
  const [scanningRepo, setScanningRepo] = useState(false);
  const [repoToken, setRepoToken] = useState('');
  const [showTokenInput, setShowTokenInput] = useState(false);
  const [repoType, setRepoType] = useState('github'); // 'github' or 'bitbucket'
  const [scanProgress, setScanProgress] = useState('');
  
  // Job monitoring states
  const [currentJobId, setCurrentJobId] = useState(null);
  
  // Hierarchical data state
  const [hierarchicalData, setHierarchicalData] = useState(null);
  
  // Flag to prevent fetchMetrics from overriding job results
  const [hasJobResults, setHasJobResults] = useState(false);
  const [isProcessingJobResults, setIsProcessingJobResults] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Enhanced threat categorization with filtering
  const filteredThreats = recentThreats.filter((t) => {
    // Apply AIT filter
    if (filterAIT && t.ait_tag !== filterAIT) return false;
    // Apply SPK filter
    if (filterSPK && t.spk_tag !== filterSPK) return false;
    // Apply Repository filter
    if (filterRepo && t.repo_name !== filterRepo) return false;
    return true;
  });



  const logicBombThreats = filteredThreats.filter(
    (t) =>
      t.type?.includes("BOMB") || 
      t.type === "SCHEDULED_THREAT" ||
      t.type === "TARGETED_ATTACK" ||
      t.type === "EXECUTION_TRIGGER" ||
      t.type === "SYSTEM_SPECIFIC_THREAT" ||
      t.type === "CONNECTION_BASED_THREAT" ||
      t.type === "DESTRUCTIVE_PAYLOAD" ||
      t.type === "FINANCIAL_FRAUD" ||
      t.rule_id?.startsWith("LOGIC_BOMB_") || 
      t.rule_id?.startsWith("MALWARE_") ||
      t.message?.toLowerCase().includes("logic bomb") ||
      t.message?.toLowerCase().includes("destructive payload") ||
      t.message?.toLowerCase().includes("file destruction") ||
      t.message?.toLowerCase().includes("conditional trigger")
  );

  // Tech debt threats filtering
  const techDebtThreats = filteredThreats.filter(
    (t) =>
      t.type?.toLowerCase().includes("vulnerability") ||
      t.type?.toLowerCase().includes("security debt") ||
      t.type?.toLowerCase().includes("security tech debt") ||
      t.type?.toLowerCase().includes("security_tech_debt") ||
      t.rule_id?.toLowerCase().includes("vulnerability") ||
      t.rule_id?.toLowerCase().includes("security_debt") ||
      t.rule_id?.toLowerCase().includes("security_tech_debt") ||
      t.message?.toLowerCase().includes("vulnerability") ||
      t.message?.toLowerCase().includes("security debt") ||
      t.message?.toLowerCase().includes("security tech debt")
  );

  // Get threats that are neither logic bombs nor tech debt (other malicious code)
  const logicBombIds = new Set(logicBombThreats.map((t) => t.id));
  const techDebtIds = new Set(techDebtThreats.map((t) => t.id));
  const otherMaliciousThreats = filteredThreats.filter((t) => !logicBombIds.has(t.id) && !techDebtIds.has(t.id));

  // Combine logic bombs and other malicious threats for the malicious code tab
  const maliciousCodeThreats = [...logicBombThreats, ...otherMaliciousThreats];

  // Enhanced threat detail functions
  const showThreatDetails = (threat) => {
    setSelectedThreat(threat);
    setShowThreatModal(true);
  };

  const getThreatSolution = (threat) => {
    const solutions = {
      'SCHEDULED_THREAT': 'Remove time-based conditions or use proper scheduling systems like cron jobs',
      'TARGETED_ATTACK': 'Remove user-specific conditions and implement proper user authentication',
      'EXECUTION_TRIGGER': 'Remove execution counters and use proper iteration controls',
      'DESTRUCTIVE_PAYLOAD': 'Replace destructive file operations with safe alternatives',
      'FINANCIAL_FRAUD': 'Remove unauthorized financial redirections and use legitimate payment systems',
      'SYSTEM_SPECIFIC_THREAT': 'Remove environment checks or replace with proper configuration management'
    };
    return solutions[threat.type] || 'Review and remove suspicious conditional logic according to security best practices';
  };

  const getThreatPriority = (threat) => {
    if (threat.severity === 'CRITICAL_BOMB' || threat.severity === 'CRITICAL') return 'IMMEDIATE';
    if (threat.severity === 'HIGH_RISK' || threat.severity === 'MAJOR') return 'HIGH';
    if (threat.severity === 'MEDIUM_RISK' || threat.severity === 'MINOR') return 'MEDIUM';
    return 'LOW';
  };

  // Use dropdown data directly (already in correct format)
  // Use dynamic data if available, otherwise fallback to config data
  const aitData = dynamicAitData.length > 0 ? dynamicAitData : getAitData();
  const spkData = Object.keys(dynamicSpkData).length > 0 ? dynamicSpkData : getSpkData(selectedAIT);
  const repoData = Object.keys(dynamicRepoData).length > 0 ? dynamicRepoData : getRepoData(selectedSPK);

  // Handle dropdown changes
  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
    setShowUploadComponent(false);
    setShowScanOptions(false);
    setShowGithubScanComponent(false);
    setConstructedRepoUrl('');
    setRepoUrlValidation({ isValid: false, message: '' });
    
    // Load SPK data for the selected AIT
    if (aitId) {
      const spkDataForAIT = getSpkData(aitId);
      setDynamicSpkData({ [aitId]: spkDataForAIT });
    } else {
      setDynamicSpkData({});
    }
    setDynamicRepoData({});
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
    setShowUploadComponent(false);
    setShowScanOptions(false);
    setShowGithubScanComponent(false);
    setConstructedRepoUrl('');
    setRepoUrlValidation({ isValid: false, message: '' });
    
    // Load Repository data for the selected SPK
    if (spkId) {
      const repoDataForSPK = getRepoData(spkId);
      setDynamicRepoData({ [spkId]: repoDataForSPK });
    } else {
      setDynamicRepoData({});
    }
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
    if (repoId) {
      setShowScanOptions(true);
      setShowUploadComponent(false);
      // Construct repository URL when all three are selected
      constructRepositoryUrl(selectedAIT, selectedSPK, repoId);
    } else {
      setShowScanOptions(false);
      setConstructedRepoUrl('');
      setRepoUrlValidation({ isValid: false, message: '' });
    }
  };

  // Construct repository URL from dropdown selections
  const constructRepositoryUrl = (ait, spk, repo) => {
    if (ait && spk && repo) {
      // Get AIT name for URL construction (use name, not ID)
      let aitName = ait;
      
      // If ait is a number (AIT ID), get the corresponding name
      if (hierarchicalData && hierarchicalData[ait]) {
        aitName = hierarchicalData[ait].ait_name || ait;
      }
      
      // Format: https://{SPK}@scm.horizon.{AIT_NAME}.com/scm/{repo}.git
      const constructedUrl = `https://${spk}@scm.horizon.${aitName.toLowerCase()}.com/scm/${repo}.git`;
      setConstructedRepoUrl(constructedUrl);
      console.log('🔗 Constructed repository URL:', constructedUrl);
      console.log('🔗 Using AIT ID:', ait, 'AIT Name:', aitName);
      
      // Validate the constructed URL
      validateRepositoryUrl(constructedUrl);
    }
  };

  // Validate repository URL by checking if it exists
  const validateRepositoryUrl = async (url) => {
    if (!url) return;
    
    setIsValidatingRepo(true);
    setRepoUrlValidation({ isValid: false, message: 'Validating repository...' });
    
    try {
      // For demo purposes, we'll simulate validation
      // In a real implementation, you would make a HEAD request to check if the repository exists
      setTimeout(() => {
        // Check if URL follows the correct format
        const isValidFormat = /^https:\/\/[^@]+@scm\.horizon\.[^\/]+\/scm\/[^\/]+\.git$/.test(url);
        
        if (isValidFormat) {
          setRepoUrlValidation({ 
            isValid: true, 
            message: 'Repository URL format is valid. Please verify manually if repository exists.' 
          });
        } else {
          setRepoUrlValidation({ 
            isValid: false, 
            message: 'Invalid repository URL format. Please edit manually.' 
          });
        }
        setIsValidatingRepo(false);
      }, 1000);
      
    } catch (error) {
      console.error('Repository validation error:', error);
      setRepoUrlValidation({ 
        isValid: false, 
        message: 'Unable to validate repository. Please check manually.' 
      });
      setIsValidatingRepo(false);
    }
  };

  // Handle manual URL editing
  const handleManualUrlEdit = () => {
    setShowManualUrlEdit(true);
    setManualRepoUrl(constructedRepoUrl);
  };

  // Save manual URL changes
  const saveManualUrl = () => {
    if (manualRepoUrl.trim()) {
      setConstructedRepoUrl(manualRepoUrl);
      validateRepositoryUrl(manualRepoUrl);
      setShowManualUrlEdit(false);
    }
  };

  // Cancel manual URL editing
  const cancelManualUrlEdit = () => {
    setShowManualUrlEdit(false);
    setManualRepoUrl('');
  };

  // Get available options for cascading dropdowns
  const availableSPKs = selectedAIT ? spkData[selectedAIT] || [] : [];
  const availableRepos = selectedSPK ? repoData[selectedSPK] || [] : [];

  // Helper functions from centralized config

  // Function to refresh dropdown data
  const refreshDropdownData = async () => {
    // Check if component is still mounted
    if (!isMounted.current) {
      console.log('🔍 Component unmounted, skipping refreshDropdownData');
      return;
    }

    setRefreshingDropdowns(true);
    try {
      await initializeDropdownData();
      
      // Check if component is still mounted before updating state
      if (!isMounted.current) {
        console.log('🔍 Component unmounted during refreshDropdownData, stopping');
        return;
      }
      
      setDynamicAitData(getAitData());
      setDynamicSpkData({});
      setDynamicRepoData({});
      
      // Load hierarchical data for URL construction
      try {
        const response = await API.get('/api/admin/hierarchical-data');
        if (response.data.success && isMounted.current) {
          setHierarchicalData(response.data.data);
          console.log('📊 Loaded hierarchical data for URL construction');
        }
      } catch (error) {
        console.error('Error loading hierarchical data:', error);
      }
      
      // Show success message with null check and mounted check
      if (isMounted.current) {
        const successToast = document.getElementById('successToast');
        if (successToast) {
          const toastBody = successToast.querySelector('.toast-body');
          if (toastBody) {
            toastBody.textContent = '✅ Dropdown data refreshed successfully!';
            const toast = new Toast(successToast);
            toast.show();
          }
        }
      }
    } catch (error) {
      console.error('Error refreshing dropdown data:', error);
      // Show error message with null check and mounted check
      if (isMounted.current) {
        const errorToast = document.getElementById('errorToast');
        if (errorToast) {
          const toastBody = errorToast.querySelector('.toast-body');
          if (toastBody) {
            toastBody.textContent = '❌ Failed to refresh dropdown data. Please try again.';
            const toast = new Toast(errorToast);
            toast.show();
          }
        }
      }
    } finally {
      if (isMounted.current) {
        setRefreshingDropdowns(false);
      }
    }
  };

  useEffect(() => {
    console.log('🔍 Initial useEffect triggered:', { hasJobResults, isProcessingJobResults });
    
    // Load saved stats from localStorage
    const savedLogicBombStats = localStorage.getItem("logicBombStats");
    const savedVulnerabilityStats = localStorage.getItem("vulnerabilityStats");
    
    if (savedLogicBombStats) {
      setLogicBombStats(JSON.parse(savedLogicBombStats));
    }
    if (savedVulnerabilityStats) {
      setVulnerabilityStats(JSON.parse(savedVulnerabilityStats));
    }

    // Always fetch latest health
    fetchHealth();
    
    // Only fetch metrics if we don't have job results, not processing job results, and no job results prop
    if (!hasJobResults && !isProcessingJobResults && !disableMetricsAPI && !jobResults) {
      console.log('🔍 Fetching metrics in initial useEffect');
      fetchMetrics();
    } else {
      console.log('🔍 Skipping metrics fetch in initial useEffect - job results active, API disabled, or jobResults prop present');
    }
    
    // Load dropdown data and update component state (only if not processing job results)
    // Add a small delay to ensure DOM is ready
    let dropdownTimeout;
    if (!isProcessingJobResults) {
      console.log('🔍 Refreshing dropdown data in initial useEffect');
      dropdownTimeout = setTimeout(() => {
        refreshDropdownData();
      }, 100);
    } else {
      console.log('🔍 Skipping dropdown refresh in initial useEffect - processing job results');
    }

    // Cleanup function
    return () => {
      if (dropdownTimeout) {
        clearTimeout(dropdownTimeout);
      }
    };
  }, [hasJobResults, isProcessingJobResults, disableMetricsAPI, jobResults]);

  // Cleanup effect to handle component unmount
  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  // Handle job results when passed from Job Monitor
  useEffect(() => {
    console.log('🔍 Job results useEffect triggered, jobResults:', jobResults);
    if (jobResults) {
      console.log('🔍 Processing job results in ThreatGuardDashboard:', jobResults);
      
      // IMMEDIATELY disable metrics API calls to prevent race conditions
      globalMetricsAPIDisabled = true;
      setDisableMetricsAPI(true);
      isJobResultsActive.current = true;
      console.log('🔍 IMMEDIATELY disabled metrics API calls - job results active');
      console.log('🔍 Global flag set to true, disableMetricsAPI flag set to true');
      
      setIsProcessingJobResults(true);
      setIsInitialized(true);
      
      // Use the same logic as the original handleJobComplete function
      const scanData = jobResults;
      
      console.log('🔍 scanData structure:', {
        hasFileResults: !!scanData.file_results,
        fileResultsLength: scanData.file_results?.length || 0,
        hasSummary: !!scanData.summary,
        summary: scanData.summary,
        hasIssues: !!scanData.issues,
        issuesLength: scanData.issues?.length || 0,
        hasLogicBombMetrics: !!scanData.logic_bomb_metrics,
        logicBombMetrics: scanData.logic_bomb_metrics,
        hasThreatIntelligence: !!scanData.threat_intelligence,
        threatIntelligence: scanData.threat_intelligence,
        hasThreatShield: !!scanData.threat_shield,
        threatShield: scanData.threat_shield,
        allKeys: Object.keys(scanData)
      });
      
      // Enhanced metrics normalization with proper fallbacks (same as original handleJobComplete)
      const normalizedMetrics = {
        ...scanData,
        // Ensure all UI values are properly populated
        scan_info: {
          project_id: scanData.project_id || 'repo-scan',
          scan_date: scanData.timestamp || new Date().toISOString(),
          files_scanned: scanData.files_scanned || scanData.repo_info?.files_count || 0,
          lines_of_code: scanData.lines_of_code || 0,
          duration_ms: scanData.duration_ms || 0,
          ait_tag: scanData.ait_tag,
          spk_tag: scanData.spk_tag,
          repo_name: scanData.repo_name,
          repo_info: scanData.repo_info
        },
        threat_ratings: {
          security_rating: scanData.summary?.security_rating || scanData.metrics?.security_rating || "A",
          reliability_rating: scanData.summary?.reliability_rating || scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.summary?.maintainability_rating || scanData.metrics?.maintainability_rating || "A",
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0
        },
        threat_shield: {
          status: scanData.threat_shield?.status || (scanData.summary?.quality_gate_passed ? "PROTECTED" : "ALERT"),
          message: scanData.threat_shield?.message || "Threat Shield Active",
          protection_effectiveness: scanData.threat_shield?.protection_effectiveness || 85
        },
        threat_intelligence: {
          threat_level: scanData.summary?.threat_level || scanData.threat_intelligence?.threat_level || "MINIMAL",
          total_threats: scanData.summary?.total_issues || 0,
          critical_bombs: scanData.summary?.critical_threats || 0,
          threat_distribution: scanData.issue_breakdown?.by_type || {},
          recommendations: scanData.threat_intelligence?.recommendations || []
        },
        logic_bomb_metrics: (() => {
          // If logic_bomb_metrics already exists, use it
          if (scanData.logic_bomb_metrics) {
            return {
              SCHEDULED_THREAT: scanData.logic_bomb_metrics.SCHEDULED_THREAT || 0,
              TARGETED_ATTACK: scanData.logic_bomb_metrics.TARGETED_ATTACK || 0,
              EXECUTION_TRIGGER: scanData.logic_bomb_metrics.EXECUTION_TRIGGER || 0,
              DESTRUCTIVE_PAYLOAD: scanData.logic_bomb_metrics.DESTRUCTIVE_PAYLOAD || 0,
              FINANCIAL_FRAUD: scanData.logic_bomb_metrics.FINANCIAL_FRAUD || 0,
              SYSTEM_SPECIFIC_THREAT: scanData.logic_bomb_metrics.SYSTEM_SPECIFIC_THREAT || 0,
              CONNECTION_BASED_THREAT: scanData.logic_bomb_metrics.CONNECTION_BASED_THREAT || 0,
              trigger_complexity_score: scanData.logic_bomb_metrics.trigger_complexity_score || 0,
              payload_severity_score: scanData.logic_bomb_metrics.payload_severity_score || 0,
              detection_confidence_avg: scanData.logic_bomb_metrics.detection_confidence_avg || 85,
              threat_density: scanData.logic_bomb_metrics.threat_density || 0,
              neutralization_urgency_hours: scanData.logic_bomb_metrics.neutralization_urgency_hours || 24,
              critical_bomb_ratio: scanData.logic_bomb_metrics.critical_bomb_ratio || 0
            };
          }
          
          // If no logic_bomb_metrics, try to create from issues
          const allIssues = [];
          if (scanData.file_results && Array.isArray(scanData.file_results)) {
            scanData.file_results.forEach(fileResult => {
              if (fileResult.issues && Array.isArray(fileResult.issues)) {
                allIssues.push(...fileResult.issues);
              }
            });
          }
          if (scanData.issues && Array.isArray(scanData.issues)) {
            allIssues.push(...scanData.issues);
          }
          
          // Count different types of threats
          const threatCounts = {
            SCHEDULED_THREAT: 0,
            TARGETED_ATTACK: 0,
            EXECUTION_TRIGGER: 0,
            DESTRUCTIVE_PAYLOAD: 0,
            FINANCIAL_FRAUD: 0,
            SYSTEM_SPECIFIC_THREAT: 0,
            CONNECTION_BASED_THREAT: 0
          };
          
          let unmappedThreats = 0;
          
          console.log('🔍 Processing issues for logic bomb metrics:', allIssues.map(issue => ({
            type: issue.type || issue.threat_type || 'UNKNOWN',
            severity: issue.severity || issue.risk_level,
            description: issue.description || issue.message,
            line: issue.line || issue.line_number
          })));
          
          allIssues.forEach(issue => {
            const type = issue.type || issue.threat_type || 'UNKNOWN';
            console.log(`🔍 Issue type: ${type}, severity: ${issue.severity || issue.risk_level}`);
            
            // Map various threat types to our categories
            let mappedType = type;
            if (type.includes('SCHEDULED') || type.includes('TIME') || type.includes('DATE')) {
              mappedType = 'SCHEDULED_THREAT';
            } else if (type.includes('TARGETED') || type.includes('USER') || type.includes('SPECIFIC')) {
              mappedType = 'TARGETED_ATTACK';
            } else if (type.includes('EXECUTION') || type.includes('TRIGGER') || type.includes('LAUNCH')) {
              mappedType = 'EXECUTION_TRIGGER';
            } else if (type.includes('DESTRUCTIVE') || type.includes('DELETE') || type.includes('REMOVE') || type.includes('DESTROY')) {
              mappedType = 'DESTRUCTIVE_PAYLOAD';
            } else if (type.includes('FINANCIAL') || type.includes('MONEY') || type.includes('PAYMENT')) {
              mappedType = 'FINANCIAL_FRAUD';
            } else if (type.includes('SYSTEM') || type.includes('OS') || type.includes('PLATFORM')) {
              mappedType = 'SYSTEM_SPECIFIC_THREAT';
            } else if (type.includes('CONNECTION') || type.includes('NETWORK') || type.includes('HTTP')) {
              mappedType = 'CONNECTION_BASED_THREAT';
            }
            
            if (threatCounts.hasOwnProperty(mappedType)) {
              threatCounts[mappedType]++;
              console.log(`🔍 Mapped ${type} to ${mappedType}, count: ${threatCounts[mappedType]}`);
            } else {
              unmappedThreats++;
              console.log(`🔍 Unknown threat type: ${type}, added to unmapped count: ${unmappedThreats}`);
            }
          });
          
          // Distribute unmapped threats to destructive payloads as fallback
          if (unmappedThreats > 0) {
            console.log(`🔍 Distributing ${unmappedThreats} unmapped threats to DESTRUCTIVE_PAYLOAD`);
            threatCounts.DESTRUCTIVE_PAYLOAD += unmappedThreats;
          }
          
          const totalThreats = allIssues.length;
          const criticalThreats = allIssues.filter(issue => 
            issue.severity === 'critical' || issue.risk_level === 'critical'
          ).length;
          
          console.log('🔍 Final threat counts:', threatCounts);
          console.log('🔍 Total threats:', totalThreats, 'Critical threats:', criticalThreats);
          
          return {
            ...threatCounts,
            trigger_complexity_score: Math.min(100, Math.max(0, (totalThreats * 10) + (criticalThreats * 20))),
            payload_severity_score: Math.min(100, Math.max(0, criticalThreats * 25)),
            detection_confidence_avg: 85,
            threat_density: totalThreats > 0 ? (totalThreats / (scanData.files_scanned || 1)) * 1000 : 0,
            neutralization_urgency_hours: criticalThreats > 0 ? 24 : 72,
            critical_bomb_ratio: totalThreats > 0 ? (criticalThreats / totalThreats) * 100 : 0
          };
        })(),
        metrics: {
          security_rating: scanData.metrics?.security_rating || scanData.summary?.security_rating || "A",
          reliability_rating: scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.metrics?.maintainability_rating || "B",
          coverage: scanData.metrics?.coverage || 85,
          duplications: scanData.metrics?.duplications || 2.5,
          technical_debt_hours: scanData.metrics?.technical_debt_hours || Math.round(scanData.summary?.total_issues * 0.5) || 0
        },
        files_scanned: scanData.files_scanned || scanData.repo_info?.files_count || 0,
        lines_of_code: scanData.lines_of_code || 0,
        summary: {
          ...scanData.summary,
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0,
          threat_level: scanData.summary?.threat_level || "MINIMAL",
          quality_gate_passed: scanData.summary?.quality_gate_passed !== false,
          total_issues: scanData.summary?.total_issues || 0,
          critical_threats: scanData.summary?.critical_threats || 0
        }
      };

      console.log('🔍 Normalized metrics for job results:', {
        logicBombMetrics: normalizedMetrics.logic_bomb_metrics,
        threatIntelligence: normalizedMetrics.threat_intelligence,
        threatShield: normalizedMetrics.threat_shield,
        summary: normalizedMetrics.summary,
        threatRatings: normalizedMetrics.threat_ratings
      });
      
      setMetricsWithDebug(normalizedMetrics, 'jobResults');

      // Flatten all issues with hierarchical tags from file_results (same as original)
      const allIssues = [];
      if (scanData.file_results && Array.isArray(scanData.file_results)) {
        scanData.file_results.forEach(fileResult => {
          if (fileResult.issues && Array.isArray(fileResult.issues)) {
            allIssues.push(...fileResult.issues);
          }
        });
      }
      
      // Also check for any direct issues array (fallback)
      if (scanData.issues && Array.isArray(scanData.issues)) {
        allIssues.push(...scanData.issues);
      }
      if (scanData.advanced_threats && Array.isArray(scanData.advanced_threats)) {
        allIssues.push(...scanData.advanced_threats);
      }
      if (scanData.logic_bomb_issues && Array.isArray(scanData.logic_bomb_issues)) {
        allIssues.push(...scanData.logic_bomb_issues);
      }

      console.log('🔍 Extracted issues:', {
        totalIssues: allIssues.length,
        issuesFromFileResults: scanData.file_results?.reduce((sum, file) => sum + (file.issues?.length || 0), 0) || 0,
        sampleIssues: allIssues.slice(0, 3)
      });

      setRecentThreatsWithDebug(allIssues, 'jobResults');

      // Update logic bomb stats
      if (scanData.logic_bomb_metrics) {
        setLogicBombStats(scanData.logic_bomb_metrics);
      }

      // Show success message (same as original)
      const filesCount = scanData.repo_info?.files_count || 0;
      const isPrivate = scanData.repo_info?.is_private || false;
      const repoTypeName = scanData.repo_info?.repo_type === 'github' ? 'GitHub' :
                          scanData.repo_info?.repo_type === 'bitbucket_cloud' ? 'Bitbucket Cloud' :
                          scanData.repo_info?.repo_type === 'bitbucket_server' ? 'Bitbucket Server' : 'Repository';

      showToast(
        `${repoTypeName} scan completed! Found ${allIssues.length} threats in ${filesCount} files. Risk Score: ${normalizedMetrics.threat_ratings.logic_bomb_risk_score}/100${isPrivate ? ' (Private Repo)' : ''}`,
        allIssues.length > 0 ? "warning" : "success"
      );

      // Set flag to prevent fetchMetrics from overriding job results
      setHasJobResults(true);
      setIsProcessingJobResults(false);
      isJobResultsActive.current = true;
      setDisableMetricsAPI(true);
      
      // Clear job results after processing to prevent re-processing
      if (setJobResults) {
        setJobResults(null);
      }
    }
  }, [jobResults, setJobResults]);

  const fetchMetrics = async () => {
    console.log('🔍 fetchMetrics called:', { 
      hasJobResults, 
      isProcessingJobResults, 
      isInitialized,
      isJobResultsActive: isJobResultsActive.current,
      disableMetricsAPI,
      globalMetricsAPIDisabled
    });
    
    // IMMEDIATE check: if metrics API is disabled, don't call it
    if (disableMetricsAPI || isJobResultsActive.current || globalMetricsAPIDisabled) {
      console.log('🚫 BLOCKED fetchMetrics - metrics API is disabled, job results active, or global flag set');
      return;
    }
    
    // Don't override if we have job results or are processing job results
    if (hasJobResults || isProcessingJobResults || isJobResultsActive.current) {
      console.log('🔍 Skipping fetchMetrics update because job results are active or being processed');
      return;
    }
    
    // Don't override if component is initialized with job results
    if (isInitialized) {
      console.log('🔍 Skipping fetchMetrics update because component is initialized with job results');
      return;
    }
    
    try {
      console.log('🔍 Making API call to /api/command-center/metrics');
      const res = await protectedAPI.get("/api/command-center/metrics");
      if (res.data && !res.data.error) {
        // Only update metrics if we don't already have scan-specific metrics
        // This prevents overriding scan-specific metrics with all-threats metrics
        if (!metrics || !metrics.scan_info?.scan_id) {
          setMetricsWithDebug(res.data, 'fetchMetrics-command-center');
          setRecentThreatsWithDebug(res.data.recent_threats || [], 'fetchMetrics-command-center');
        }

        if (res.data.logic_bomb_analysis) {
          setLogicBombStats({
            count: Object.values(res.data.logic_bomb_analysis.by_type).reduce(
              (a, b) => a + b,
              0
            ),
            details: Object.entries(
              res.data.logic_bomb_analysis.by_type || {}
            ).map(([type, count]) => `${type.replace("_", " ")}: ${count}`),
          });
        }
      }
    } catch (error) {
      // Fallback to older API if command center doesn't exist
      try {
        const res = await protectedAPI.get("/api/dashboard/metrics");
        if (res.data && !res.data.error) {
                  // Don't override if we have job results or are processing job results
        if (hasJobResults || isProcessingJobResults) {
          console.log('🔍 Skipping fallback fetchMetrics update because job results are active or being processed');
          return;
        }
          
          // Calculate threat density for fallback
          const totalIssues = res.data.issues?.total || 0;
          const linesOfCode = res.data.scan_info?.lines_of_code || 1000;
          const threatDensity = linesOfCode > 0 ? (totalIssues / linesOfCode) * 1000 : 0;
          
          // Calculate shield effectiveness and status for fallback
          const criticalIssues = res.data.issues?.by_severity?.CRITICAL || 0;
          const highIssues = res.data.issues?.by_severity?.HIGH || 0;
          let shieldEffectiveness = 85.0;
          let shieldStatus = "PROTECTED";
          
          if (criticalIssues > 0) {
            shieldEffectiveness = Math.max(30.0, 85.0 - (criticalIssues * 15.0));
            shieldStatus = "BLOCKED";
          } else if (highIssues > 2) {
            shieldEffectiveness = Math.max(50.0, 85.0 - (highIssues * 5.0));
            shieldStatus = "ALERT";
          } else if (totalIssues > 5) {
            shieldEffectiveness = Math.max(70.0, 85.0 - (totalIssues * 2.0));
            shieldStatus = "ALERT";
          } else if (totalIssues <= 2) {
            shieldEffectiveness = 95.0;
            shieldStatus = "PROTECTED";
          }
          
          // Calculate neutralization urgency for fallback
          let neutralizationUrgency = 24.0;
          if (criticalIssues > 0) {
            neutralizationUrgency = 2.0;
          } else if (highIssues > 0) {
            neutralizationUrgency = 6.0;
          } else if (totalIssues > 5) {
            neutralizationUrgency = 12.0;
          }
          
          setMetricsWithDebug({
            threat_ratings: {
              logic_bomb_risk_score: calculateRiskScore(res.data),
            },
            scan_info: res.data.scan_info,
            threat_shield: { 
              status: shieldStatus, 
              protection_effectiveness: shieldEffectiveness 
            },
            threats: { critical_bombs: criticalIssues },
            threat_intelligence: { threat_level: "MEDIUM" },
            logic_bomb_metrics: {
              threat_density: threatDensity,
              detection_confidence_avg: 85.0,
              neutralization_urgency_hours: neutralizationUrgency,
              trigger_complexity_score: 0.0,
              payload_severity_score: 0.0,
              time_bomb_count: 0,
              user_bomb_count: 0,
              counter_bomb_count: 0,
              destructive_payload_count: 0,
            }
          }, 'fetchMetrics-fallback');
          setRecentThreatsWithDebug(res.data.recent_issues || [], 'fetchMetrics-fallback');
        }
    } catch (fallbackError) {
        // Properly handle the exception by logging and notifying the user
        console.error("Failed to fetch metrics:", fallbackError);
        showToast("Failed to fetch metrics. Please try again.", "error");
    }
    }
  };

  const calculateRiskScore = (data) => {
    const totalIssues = data.issues?.total || 0;
    const criticalIssues = data.issues?.by_severity?.CRITICAL || 0;
    return Math.min(100, (criticalIssues * 20) + (totalIssues * 2));
  };

  const fetchHealth = async () => {
    try {
      const res = await API.get("/api/health");
      setHealth(res.data);
    } catch (err) {
      console.error("Failed to fetch health info:", err);
    }
  };

  const neutralizeThreat = async (id) => {
    try {
      await API.post(`/api/threats/${id}/neutralize`);
      fetchMetrics();
      showToast("Threat neutralized successfully!", "success");
    } catch (error) {
      // Fallback to older API
      try {
        await API.put(`/api/issues/${id}/status`, { status: "RESOLVED" });
        fetchMetrics();
        showToast("Threat neutralized successfully!", "success");
      } catch (fallbackError) {
        console.error("Failed to neutralize threat:", fallbackError);
      showToast("Failed to neutralize threat", "error");
      }
    }
  };

  const handleFileDrop = async (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = e.dataTransfer.items;
    const files = await extractFilesFromItems(items);
    handleUpload(files);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    handleUpload(files);
  };

  const extractFilesFromItems = async (items) => {
    const traverseFileTree = (item, path = "") => {
      return new Promise((resolve) => {
        if (item.isFile) {
          item.file((file) => {
            file.fullPath = path + file.name;
            resolve([file]);
          });
        } else if (item.isDirectory) {
          const dirReader = item.createReader();
          dirReader.readEntries(async (entries) => {
            const results = await Promise.all(
              entries.map((entry) =>
                traverseFileTree(entry, path + item.name + "/")
              )
            );
            resolve(results.flat());
          });
        }
      });
    };

    const entries = Array.from(items).map((item) => item.webkitGetAsEntry());
    const all = await Promise.all(
      entries.map((entry) => traverseFileTree(entry))
    );
    return all.flat();
  };

  const handleUpload = async (files) => {
    if (!files.length) return;

    // Only clear metrics if not processing job results
    if (!isProcessingJobResults) {
      setMetricsWithDebug(null, 'handleUpload-clear');
      setRecentThreatsWithDebug([], 'handleUpload-clear');
      setLogicBombStats(null);
    }

    const fileContents = [];

    for (const file of files) {
      const ext = file.name.split(".").pop().toLowerCase();

      if (ext === "zip") {
        const zip = new JSZip();
        const zipData = await zip.loadAsync(file);
        for (const [relativePath, zipEntry] of Object.entries(zipData.files)) {
          if (!zipEntry.dir) {
            const content = await zipEntry.async("text");
            fileContents.push({
              id: generateId(),
              name: zipEntry.name,
              type: getFileLanguage(zipEntry.name),
              content: content,
            });
          }
        }
      } else {
        const content = await readFileContent(file);
        fileContents.push({
          id: generateId(),
          name: file.fullPath || file.webkitRelativePath || file.name,
          type: getFileLanguage(file.name),
          content: content,
        });
      }
    }

    // Enhanced payload with hierarchical tagging from dropdowns
    const projectName = `${getAITName(selectedAIT)}-${getSPKName(selectedSPK)}-${getRepoName(selectedRepo)}`;
    const payload = {
      scan_id: generateId(),
      scan_type: "manual",
      project_id: `${selectedAIT}-${selectedSPK}-${selectedRepo}-${Date.now()}`,
      project_name: projectName,
      timestamp: new Date().toISOString(),
      file_contents: fileContents,
      // Add hierarchical tags from dropdowns
      ait_tag: selectedAIT || "AIT",
      spk_tag: selectedSPK || "SPK-SECURITY",
      repo_name: selectedRepo || fileContents[0]?.name.split('/')[0] || "security-repo"
    };

    try {
      setUploading(true);
      
      // Reset job results flag when starting a new file upload
      setHasJobResults(false);
      
      const response = await API.post("/api/scan/files", payload);

      // Use scan response for immediate UI update
      const scanData = response.data;
      setMetricsWithDebug(scanData, 'handleUpload-initial');

      // Enhanced metrics normalization with proper fallbacks
      const normalizedMetrics = {
        ...scanData,
        // Ensure all UI values are properly populated
        scan_info: {
          project_id: scanData.project_id || payload.project_id,
          scan_date: scanData.timestamp || payload.timestamp,
          files_scanned: scanData.files_scanned || fileContents.length,
          lines_of_code: scanData.lines_of_code || 0,
          duration_ms: scanData.duration_ms || 0,
          ait_tag: payload.ait_tag,
          spk_tag: payload.spk_tag,
          repo_name: payload.repo_name
        },
        // Ensure threats have the selected hierarchical tags
        recent_threats: (scanData.recent_threats || []).map(threat => ({
          ...threat,
          ait_tag: threat.ait_tag || payload.ait_tag,
          spk_tag: threat.spk_tag || payload.spk_tag,
          repo_name: threat.repo_name || payload.repo_name
        })),
        threat_ratings: {
          security_rating: scanData.summary?.security_rating || scanData.metrics?.security_rating || "A",
          reliability_rating: scanData.summary?.reliability_rating || scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.summary?.maintainability_rating || scanData.metrics?.maintainability_rating || "A",
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0
        },
        threat_shield: {
          status: scanData.threat_shield?.status || (scanData.summary?.quality_gate_passed ? "PROTECTED" : "ALERT"),
          message: scanData.threat_shield?.message || "Threat Shield Active",
          protection_effectiveness: scanData.threat_shield?.protection_effectiveness || 85
        },
        threat_intelligence: {
          threat_level: scanData.summary?.threat_level || scanData.threat_intelligence?.threat_level || "MINIMAL",
          total_threats: scanData.summary?.total_issues || 0,
          critical_bombs: scanData.summary?.critical_threats || 0,
          threat_distribution: scanData.issue_breakdown?.by_type || {},
          recommendations: scanData.threat_intelligence?.recommendations || []
        },
        logic_bomb_metrics: {
          SCHEDULED_THREAT: scanData.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
          TARGETED_ATTACK: scanData.logic_bomb_metrics?.TARGETED_ATTACK || 0,
          EXECUTION_TRIGGER: scanData.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
          DESTRUCTIVE_PAYLOAD: scanData.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
          FINANCIAL_FRAUD: scanData.logic_bomb_metrics?.FINANCIAL_FRAUD || 0,
          SYSTEM_SPECIFIC_THREAT: scanData.logic_bomb_metrics?.SYSTEM_SPECIFIC_THREAT || 0,
          CONNECTION_BASED_THREAT: scanData.logic_bomb_metrics?.CONNECTION_BASED_THREAT || 0
        },
        metrics: {
          security_rating: scanData.metrics?.security_rating || scanData.summary?.security_rating || "A",
          reliability_rating: scanData.metrics?.reliability_rating || "A",
          maintainability_rating: scanData.metrics?.maintainability_rating || "B",
          coverage: scanData.metrics?.coverage || 85,
          duplications: scanData.metrics?.duplications || 2.5,
          technical_debt_hours: scanData.metrics?.technical_debt_hours || Math.round(scanData.summary?.total_issues * 0.5) || 0
        },
        // Ensure proper values for dashboard display
        files_scanned: scanData.files_scanned || fileContents.length,
        lines_of_code: scanData.lines_of_code || fileContents.reduce((sum, f) => sum + (f.content.split('\n').length || 0), 0),
        summary: {
          ...scanData.summary,
          logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0,
          threat_level: scanData.summary?.threat_level || "MINIMAL",
          quality_gate_passed: scanData.summary?.quality_gate_passed !== false,
          total_issues: scanData.summary?.total_issues || 0,
          critical_threats: scanData.summary?.critical_threats || 0
        }
      };

      setMetricsWithDebug(normalizedMetrics, 'handleUpload-normalized');
      
      // Flatten all issues with hierarchical tags
      const allIssues = [];
      if (scanData.file_results) {
        scanData.file_results.forEach((file) => {
          if (file.issues) {
            file.issues.forEach(issue => {
              // Add hierarchical tags to each issue
              issue.ait_tag = payload.ait_tag;
              issue.spk_tag = payload.spk_tag;
              issue.repo_name = payload.repo_name;
              issue.scan_id = scanData.scan_id;
              issue.file_name = file.file_name;
              allIssues.push(issue);
            });
          }
        });
      }
      setRecentThreatsWithDebug(allIssues, 'handleUpload');

      // Enhanced logic bomb stats
      if (scanData.logic_bomb_metrics) {
        const logicBombCount = Object.values(scanData.logic_bomb_metrics).reduce((a, b) => a + b, 0);
        const stats = Object.entries(scanData.logic_bomb_metrics)
          .filter(([k, v]) => v > 0)
          .map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`);
        
        setLogicBombStats({ 
          count: logicBombCount, 
          details: stats,
          breakdown: scanData.logic_bomb_metrics
        });
      }

      // Calculate vulnerability stats
      const vulnerabilityThreats = allIssues.filter(
        (t) =>
          t.type?.toLowerCase().includes("vulnerability") ||
          t.type?.toLowerCase().includes("security debt") ||
          t.type?.toLowerCase().includes("security tech debt") ||
          t.type?.toLowerCase().includes("security_tech_debt") ||
          t.rule_id?.toLowerCase().includes("vulnerability") ||
          t.rule_id?.toLowerCase().includes("security_debt") ||
          t.rule_id?.toLowerCase().includes("security_tech_debt") ||
          t.message?.toLowerCase().includes("vulnerability") ||
          t.message?.toLowerCase().includes("security debt") ||
          t.message?.toLowerCase().includes("security tech debt")
      );

      if (vulnerabilityThreats.length > 0) {
        // Group vulnerabilities by type
        const vulnerabilityTypes = {};
        vulnerabilityThreats.forEach(threat => {
          const type = threat.type || 'Unknown Vulnerability';
          vulnerabilityTypes[type] = (vulnerabilityTypes[type] || 0) + 1;
        });

        const vulnerabilityCount = vulnerabilityThreats.length;
        const stats = Object.entries(vulnerabilityTypes)
          .map(([k, v]) => `${k.replace(/_/g, " ")}: ${v}`);

        setVulnerabilityStats({
          count: vulnerabilityCount,
          details: stats,
          breakdown: vulnerabilityTypes
        });
      } else {
        setVulnerabilityStats(null);
      }

      // Save to localStorage with proper structure
      localStorage.setItem("tg_metrics", JSON.stringify(normalizedMetrics));
      localStorage.setItem("tg_recent_threats", JSON.stringify(allIssues));
      if (logicBombStats) {
        localStorage.setItem("tg_logic_bomb_stats", JSON.stringify(logicBombStats));
      }

      showToast(
        `Enhanced security scan completed! AIT→${payload.spk_tag}→${payload.repo_name}: ${allIssues.length} threats found. Risk Score: ${normalizedMetrics.threat_ratings.logic_bomb_risk_score}/100`,
        allIssues.length > 0 ? "warning" : "success"
      );

      // Fetch scan-specific metrics to show only current scan threats
      if (scanData.scan_id && !hasJobResults && !isProcessingJobResults && !isJobResultsActive.current && !disableMetricsAPI) {
        try {
          console.log('🔍 Making scan-specific API call to /api/command-center/metrics');
          const metricsResponse = await protectedAPI.get(`/api/command-center/metrics?scan_id=${scanData.scan_id}`);
          if (metricsResponse.data && !metricsResponse.data.error) {
            setMetricsWithDebug(metricsResponse.data, 'handleUpload-scan-specific');
            setRecentThreatsWithDebug(metricsResponse.data.recent_threats || [], 'handleUpload-scan-specific');
            console.log(`DEBUG: Updated metrics for scan_id: ${scanData.scan_id}`);
          }
        } catch (metricsError) {
          console.error("Failed to fetch scan-specific metrics:", metricsError);
        }
      }
      fetchHealth();
    } catch (err) {
      console.error(err);
      showToast("Malicious scan failed. Please try again.", "error");
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => "id_" + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const map = {
      py: "python",
      js: "javascript",
      ts: "typescript",
      java: "java",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      cpp: "cpp",
      cs: "csharp",
      rb: "ruby",
      php: "php",
      go: "golang",
      rs: "rust",
      c: "c",
    };
    return map[ext] || "unknown";
  };

  const showToast = (message, type) => {
    const toastEl = document.getElementById(`${type}Toast`);
    if (toastEl) {
      toastEl.querySelector(".toast-body").textContent = message;
      new Toast(toastEl).show();
    }
  };

  const timeAgo = (isoTime) => {
    const diffMs = Date.now() - new Date(isoTime).getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "just now";
    if (diffMin === 1) return "1 minute ago";
    return `${diffMin} minutes ago`;
  };

  const downloadThreatPrompts = async () => {
    try {
      const res = await API.get("/api/threat-prompts/download", {
        responseType: "blob",
      });

      const blob = new Blob([res.data], { type: "application/zip" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "threatguard_prompts.zip";
      link.click();
    } catch (err) {
      console.error("Failed to download prompts:", err);
      showToast("Failed to download threat prompts.", "error");
    }
  };

  // if (!metrics)
  //   return <p className="text-center mt-5">Loading ThreatGuard metrics...</p>;

  const {
    threat_ratings,
    scan_info,
    threat_shield,
    threats,
    threat_intelligence,
  } = metrics || {};

  // Calculate scan date and time
  const scanDateTime = scan_info?.scan_date
    ? new Date(scan_info.scan_date)
    : new Date();
  const scanDate = scanDateTime.toLocaleDateString();
  const scanTime = scanDateTime.toLocaleTimeString();

  const summary = metrics?.summary || {};
  const threatInt = metrics?.threat_intelligence || {};
  const logicBombMetrics = metrics?.logic_bomb_metrics || {};
  const threatShield = metrics?.threat_shield || {};

  const detectionMetricCards = [
    {
                    label: "Malicious Risk Score",
      value: `${
        summary.logic_bomb_risk_score ??
        threat_ratings?.logic_bomb_risk_score ??
        0
      }/100`,
      className:
        (summary.logic_bomb_risk_score ??
          threat_ratings?.logic_bomb_risk_score ??
          0) >= 70
          ? "text-danger"
          : (summary.logic_bomb_risk_score ??
              threat_ratings?.logic_bomb_risk_score ??
              0) >= 40
          ? "text-warning"
          : "text-success",
    },
    {
      label: "Threat Exposure Level",
      value: summary.threat_level || threatInt.threat_level || "MINIMAL",
      className:
        (summary.threat_level || threatInt.threat_level) === "CRITICAL"
          ? "text-danger"
          : (summary.threat_level || threatInt.threat_level) === "HIGH"
          ? "text-warning"
          : "text-success",
    },
    {
                    label: "Critical Malicious Threats",
      value: threatInt.critical_bombs ?? summary.critical_threats ?? 0,
      className: "text-danger",
    },
    {
      label: "Threat Shield Status",
      value: threatShield.status || "UNKNOWN",
      className:
        threatShield.status === "PROTECTED"
          ? "text-success"
          : threatShield.status === "BLOCKED"
          ? "text-danger"
          : "text-warning",
    },
    // {
    //   label: "Threat Density",
    //   value: `${(metrics?.logic_bomb_metrics?.threat_density || 0).toFixed(1)}/1K`,
    //   className:
    //     (metrics?.logic_bomb_metrics?.threat_density || 0) >= 5.0
    //       ? "text-danger"
    //       : (metrics?.logic_bomb_metrics?.threat_density || 0) >= 2.0
    //       ? "text-warning"
    //       : "text-success",
    // },
  ];

  // Add pagination state for threats table
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3;
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  // Get filtered threats for the current tab
  const displayedThreats = activeTab === "logicbombs" ? maliciousCodeThreats : techDebtThreats;
  const totalPages = Math.ceil(displayedThreats.length / pageSize) || 1;
  const paginatedThreats = displayedThreats.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  useEffect(() => { setCurrentPage(1); }, [activeTab, filterAIT, filterSPK, filterRepo, pageSize, displayedThreats.length]);

  // Repository scan handler (GitHub and Bitbucket) - Now using async jobs
  const handleRepoScan = async () => {
    if (!repoUrl.trim()) {
      showToast('Please enter a repository URL', 'error');
      return;
    }

    const payload = {
      scan_id: generateId(),
      scan_type: "repository",
      project_id: `${repoType}-scan-${Date.now()}`,
      project_name: `${repoType === 'github' ? 'GitHub' : 'Bitbucket'} Repository Scan`,
      timestamp: new Date().toISOString(),
      repo_url: repoUrl.trim(),
      repo_token: repoToken.trim() || undefined, // Only send if provided
      // Use selected dropdown values for hierarchical tagging
      ait_tag: selectedAIT || "AIT",
      spk_tag: selectedSPK || "SPK-SECURITY",
      repo_name: selectedRepo || `${repoType}-repo`
    };

    try {
      setScanningRepo(true);
      setScanProgress('Creating scan job...');
      
      // Reset job results flag when starting a new scan
      setHasJobResults(false);
      
      // Create async job instead of direct scan
      const response = await API.post("/api/jobs/scan-repository", payload);
      
      const jobData = response.data;
      setCurrentJobId(jobData.job_id);
      
      showToast(`Repository scan job created! Job ID: ${jobData.job_id}`, 'success');
      // Navigate to job monitor page instead of showing embedded component
      window.location.href = '/job-monitor';
      
      // Clear the input after successful job creation
      setRepoUrl('');
      setRepoToken('');
      setShowTokenInput(false);
      setScanProgress('');
      
    } catch (err) {
      console.error(err);
      
      // Handle timeout errors specifically
      if (err.code === 'ECONNABORTED' || err.message.includes('timeout')) {
        showToast('Repository scan timed out. The repository might be too large or the connection is slow. Please try again or use a smaller repository.', 'warning');
        return;
      }
      
      const errorData = err.response?.data;
      const errorMsg = errorData?.error || 'Failed to create scan job';
      const errorDetails = errorData?.details || '';
      const requiresAuth = errorData?.requires_auth || false;
      const repoType = errorData?.repo_type || 'unknown';
      
      // Show detailed error message
      if (errorDetails) {
        showToast(`${errorMsg}: ${errorDetails}`, 'error');
      } else {
        showToast(errorMsg, 'error');
      }
      
      // Handle authentication errors
      if (err.response?.status === 401 || err.response?.status === 403 || requiresAuth) {
        setShowTokenInput(true);
        // Show specific message for private repositories
        if (requiresAuth) {
          const repoTypeName = repoType === 'github' ? 'GitHub' : 
                              repoType === 'bitbucket_cloud' ? 'Bitbucket Cloud' : 
                              repoType === 'bitbucket_server' ? 'Bitbucket Server' : 'Repository';
          showToast(`This ${repoTypeName} repository requires authentication. Please provide an access token.`, 'warning');
        }
      }
    } finally {
      setScanningRepo(false);
      setScanProgress('');
    }
  };

  // Functions to show specific scan options
  const showFileUpload = () => {
    setShowUploadComponent(true);
    setShowScanOptions(false);
    setShowGithubScanComponent(false);
  };

  const showRepoScan = () => {
    setShowUploadComponent(false);
    setShowScanOptions(false);
    setShowGithubScanComponent(true);
    
    // Pre-populate the repository URL with the constructed URL
    if (constructedRepoUrl && repoUrlValidation.isValid) {
      setRepoUrl(constructedRepoUrl);
      console.log('🔗 Pre-populated repository URL:', constructedRepoUrl);
    }
  };

  // Handle job completion
  const handleJobComplete = (resultData) => {
    // Process the completed job results
    const scanData = resultData;
    
    console.log('🔍 handleJobComplete called with resultData:', resultData);
    console.log('🔍 scanData structure:', {
      hasFileResults: !!scanData.file_results,
      fileResultsLength: scanData.file_results?.length || 0,
      hasSummary: !!scanData.summary,
      summary: scanData.summary,
      hasIssues: !!scanData.issues,
      issuesLength: scanData.issues?.length || 0
    });
    
    // Enhanced metrics normalization with proper fallbacks
    const normalizedMetrics = {
      ...scanData,
      // Ensure all UI values are properly populated
      scan_info: {
        project_id: scanData.project_id || 'repo-scan',
        scan_date: scanData.timestamp || new Date().toISOString(),
        files_scanned: scanData.files_scanned || scanData.repo_info?.files_count || 0,
        lines_of_code: scanData.lines_of_code || 0,
        duration_ms: scanData.duration_ms || 0,
        ait_tag: scanData.ait_tag,
        spk_tag: scanData.spk_tag,
        repo_name: scanData.repo_name,
        repo_info: scanData.repo_info
      },
      threat_ratings: {
        security_rating: scanData.summary?.security_rating || scanData.metrics?.security_rating || "A",
        reliability_rating: scanData.summary?.reliability_rating || scanData.metrics?.reliability_rating || "A",
        maintainability_rating: scanData.summary?.maintainability_rating || scanData.metrics?.maintainability_rating || "A",
        logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0
      },
      threat_shield: {
        status: scanData.threat_shield?.status || (scanData.summary?.quality_gate_passed ? "PROTECTED" : "ALERT"),
        message: scanData.threat_shield?.message || "Threat Shield Active",
        protection_effectiveness: scanData.threat_shield?.protection_effectiveness || 85
      },
      threat_intelligence: {
        threat_level: scanData.summary?.threat_level || scanData.threat_intelligence?.threat_level || "MINIMAL",
        total_threats: scanData.summary?.total_issues || 0,
        critical_bombs: scanData.summary?.critical_threats || 0,
        threat_distribution: scanData.issue_breakdown?.by_type || {},
        recommendations: scanData.threat_intelligence?.recommendations || []
      },
      logic_bomb_metrics: {
        SCHEDULED_THREAT: scanData.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
        TARGETED_ATTACK: scanData.logic_bomb_metrics?.TARGETED_ATTACK || 0,
        EXECUTION_TRIGGER: scanData.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
        DESTRUCTIVE_PAYLOAD: scanData.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
        FINANCIAL_FRAUD: scanData.logic_bomb_metrics?.FINANCIAL_FRAUD || 0,
        SYSTEM_SPECIFIC_THREAT: scanData.logic_bomb_metrics?.SYSTEM_SPECIFIC_THREAT || 0,
        CONNECTION_BASED_THREAT: scanData.logic_bomb_metrics?.CONNECTION_BASED_THREAT || 0,
        trigger_complexity_score: scanData.logic_bomb_metrics?.trigger_complexity_score || 0,
        payload_severity_score: scanData.logic_bomb_metrics?.payload_severity_score || 0,
        detection_confidence_avg: scanData.logic_bomb_metrics?.detection_confidence_avg || 85,
        threat_density: scanData.logic_bomb_metrics?.threat_density || 0,
        neutralization_urgency_hours: scanData.logic_bomb_metrics?.neutralization_urgency_hours || 24,
        critical_bomb_ratio: scanData.logic_bomb_metrics?.critical_bomb_ratio || 0
      },
      metrics: {
        security_rating: scanData.metrics?.security_rating || scanData.summary?.security_rating || "A",
        reliability_rating: scanData.metrics?.reliability_rating || "A",
        maintainability_rating: scanData.metrics?.maintainability_rating || "B",
        coverage: scanData.metrics?.coverage || 85,
        duplications: scanData.metrics?.duplications || 2.5,
        technical_debt_hours: scanData.metrics?.technical_debt_hours || Math.round(scanData.summary?.total_issues * 0.5) || 0
      },
      files_scanned: scanData.files_scanned || scanData.repo_info?.files_count || 0,
      lines_of_code: scanData.lines_of_code || 0,
      summary: {
        ...scanData.summary,
        logic_bomb_risk_score: scanData.summary?.logic_bomb_risk_score || 0,
        threat_level: scanData.summary?.threat_level || "MINIMAL",
        quality_gate_passed: scanData.summary?.quality_gate_passed !== false,
        total_issues: scanData.summary?.total_issues || 0,
        critical_threats: scanData.summary?.critical_threats || 0
      }
    };

    setMetricsWithDebug(normalizedMetrics, 'handleRepoScan');

    // Flatten all issues with hierarchical tags from file_results
    const allIssues = [];
    if (scanData.file_results && Array.isArray(scanData.file_results)) {
      scanData.file_results.forEach(fileResult => {
        if (fileResult.issues && Array.isArray(fileResult.issues)) {
          allIssues.push(...fileResult.issues);
        }
      });
    }
    
    // Also check for any direct issues array (fallback)
    if (scanData.issues && Array.isArray(scanData.issues)) {
      allIssues.push(...scanData.issues);
    }
    if (scanData.advanced_threats && Array.isArray(scanData.advanced_threats)) {
      allIssues.push(...scanData.advanced_threats);
    }
    if (scanData.logic_bomb_issues && Array.isArray(scanData.logic_bomb_issues)) {
      allIssues.push(...scanData.logic_bomb_issues);
    }

    console.log('🔍 Extracted issues:', {
      totalIssues: allIssues.length,
      issuesFromFileResults: scanData.file_results?.reduce((sum, file) => sum + (file.issues?.length || 0), 0) || 0,
      sampleIssues: allIssues.slice(0, 3)
    });

    setRecentThreatsWithDebug(allIssues, 'handleRepoScan');

    // Update logic bomb stats
    if (scanData.logic_bomb_metrics) {
      setLogicBombStats(scanData.logic_bomb_metrics);
    }

    // Show success message
    const filesCount = scanData.repo_info?.files_count || 0;
    const isPrivate = scanData.repo_info?.is_private || false;
    const repoTypeName = scanData.repo_info?.repo_type === 'github' ? 'GitHub' :
                        scanData.repo_info?.repo_type === 'bitbucket_cloud' ? 'Bitbucket Cloud' :
                        scanData.repo_info?.repo_type === 'bitbucket_server' ? 'Bitbucket Server' : 'Repository';

    showToast(
      `${repoTypeName} scan completed! Found ${allIssues.length} threats in ${filesCount} files. Risk Score: ${normalizedMetrics.threat_ratings.logic_bomb_risk_score}/100${isPrivate ? ' (Private Repo)' : ''}`,
      allIssues.length > 0 ? "warning" : "success"
    );

    // Hide job monitor and show results
    
    setCurrentJobId(null);
  };

  return (
    <div>
      {!metrics && (
        <div className="alert alert-warning mt-3">
          ⚠️ Metrics not loaded. Please upload a scan file to begin.
          <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      )}
      
      {jobResults && (
        <div className="alert alert-info mt-3">
          🔄 Processing job results... Please wait.
          <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      )}
      
      {hasJobResults && !jobResults && (
        <div className="alert alert-success mt-3">
          ✅ Job results loaded successfully. 
          <span className="badge bg-warning ms-2">Metrics API Disabled</span>
          <button 
            type="button" 
            className="btn btn-outline-secondary btn-sm ms-2"
                            onClick={() => {
                  console.log('🔍 User requested to switch to general metrics');
                  globalMetricsAPIDisabled = false;
                  setHasJobResults(false);
                  setIsProcessingJobResults(false);
                  setIsInitialized(false);
                  isJobResultsActive.current = false;
                  setDisableMetricsAPI(false);
                  console.log('🔍 Global flag set to false, disableMetricsAPI flag set to false');
                  console.log('🔍 All flags reset, calling fetchMetrics...');
                  fetchMetrics();
                  showToast('Switched to general dashboard metrics', 'info');
                }}
          >
            Show General Metrics
          </button>
          <button type="button" className="btn-close ms-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      )}
      
      <div>
        {/* System Status Header */}
        {health && (
          <div
            className={`alert d-flex align-items-center justify-content-between ${
              health.status === "healthy" ? "alert-success" : "alert-danger"
            } mb-4`}
            style={{
              // background: "#f8f9fa",
              border: "1px solid #d1d5db",
              color: health.status === "healthy" ? "#198754" : "#dc3545",
            }}
          >
            <span>
              {health.status === "healthy"
                ? `🛡️ ThreatGuard Pro operational. Last scan: ${timeAgo(
                    health.timestamp
                  )}.`
                : `⚠️ ThreatGuard Pro experiencing issues. Last checked: ${timeAgo(
                    health.timestamp
                  )}.`}
            </span>
            <button
              type="button"
              className="btn-close ms-3"
              data-bs-dismiss="alert"
              aria-label="Close"
            ></button>
          </div>
        )}

        {/* Job Monitor Link */}
        <div className="mb-3">
          <a
            href="/job-monitor"
            className="btn btn-outline-info btn-sm"
          >
            <FaSpinner className="me-2" />
            View Job Monitor
          </a>
        </div>

        {/* Project Selection - Cascading Dropdowns - Only show when file upload is not hidden */}
        {!hideFileUpload && (
          <div
            className="card mb-5 shadow"
            style={{ background: "#fff", border: "1px solid #e5e7eb" }}
          >
          <div
            className="card-header d-flex justify-content-between align-items-center"
            style={{
              background: "#f8f9fa",
              borderBottom: "1px solid #e5e7eb",
            }}
          >
            <h5 className="mb-0" style={{ color: "#222" }}>
              <FaProjectDiagram className="me-2" /> Project Configuration
            </h5>
            <div className="d-flex align-items-center">
              <button
                className="btn btn-outline-primary btn-sm me-2"
                onClick={refreshDropdownData}
                disabled={refreshingDropdowns}
                title="Refresh dropdown data from Admin Data Management"
              >
                <FaSync className={`me-1 ${refreshingDropdowns ? 'fa-spin' : ''}`} />
                {refreshingDropdowns ? 'Refreshing...' : 'Refresh Data'}
              </button>
              <span className="badge bg-primary me-2">HIERARCHICAL</span>
              <span className="badge bg-info">AIT → SPK → REPO</span>
            </div>
          </div>
          <div className="card-body" style={{ background: "#f8f9fa" }}>
            <div className="row g-3">
              {/* AIT Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaBuilding className="me-2" /> AIT (Application Inventory Tool)
                </label>
                <select
                  className="form-select"
                  value={selectedAIT}
                  onChange={(e) => handleAITChange(e.target.value)}
                  style={{ border: "1px solid #ced4da" }}
                >
                  <option value="">Select AIT...</option>
                  {aitData.map((ait) => (
                    <option key={ait.value} value={ait.value}>
                      {ait.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* SPK Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaCog className="me-2" /> SPK (Software Product Key)
                </label>
                <select
                  className="form-select"
                  value={selectedSPK}
                  onChange={(e) => handleSPKChange(e.target.value)}
                  disabled={!selectedAIT}
                  style={{ 
                    border: "1px solid #ced4da",
                    opacity: selectedAIT ? 1 : 0.6
                  }}
                >
                  <option value="">Select SPK...</option>
                  {availableSPKs.map((spk) => (
                    <option key={spk.value} value={spk.value}>
                      {spk.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Repository Dropdown */}
              <div className="col-md-4">
                <label className="form-label fw-bold" style={{ color: "#222" }}>
                  <FaFolder className="me-2" /> Repository
                </label>
                <select
                  className="form-select"
                  value={selectedRepo}
                  onChange={(e) => handleRepoChange(e.target.value)}
                  disabled={!selectedSPK}
                  style={{ 
                    border: "1px solid #ced4da",
                    opacity: selectedSPK ? 1 : 0.6
                  }}
                >
                  <option value="">Select Repository...</option>
                  {availableRepos.map((repo) => (
                    <option key={repo.value} value={repo.value}>
                      {repo.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Project Summary */}
            {selectedAIT && selectedSPK && selectedRepo && (
              <div className="mt-3 p-3 bg-light rounded">
                <h6 className="mb-2" style={{ color: "#222" }}>
                  <i className="bi bi-info-circle"></i> Selected Project:
                </h6>
                <div className="row">
                  <div className="col-md-4">
                    <strong>AIT:</strong> {getAITName(selectedAIT)}
                  </div>
                  <div className="col-md-4">
                    <strong>SPK:</strong> {getSPKName(selectedSPK)}
                  </div>
                  <div className="col-md-4">
                    <strong>Repository:</strong> {getRepoName(selectedRepo)}
                  </div>
                </div>
                
                {/* Repository URL Construction */}
                {constructedRepoUrl && (
                  <div className="mt-3">
                    <h6 className="mb-2" style={{ color: "#222" }}>
                      <i className="bi bi-link-45deg"></i> Constructed Repository URL:
                    </h6>
                    <div className="input-group">
                      <input
                        type="text"
                        className="form-control"
                        value={constructedRepoUrl}
                        readOnly
                        style={{ 
                          fontFamily: 'monospace',
                          fontSize: '0.9rem'
                        }}
                      />
                      <button
                        className="btn btn-outline-secondary"
                        type="button"
                        onClick={handleManualUrlEdit}
                        title="Edit URL manually"
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                    </div>
                    
                    {/* URL Validation Status */}
                    <div className="mt-2">
                      {isValidatingRepo ? (
                        <div className="d-flex align-items-center">
                          <div className="spinner-border spinner-border-sm me-2" role="status">
                            <span className="visually-hidden">Validating...</span>
                          </div>
                          <span className="text-muted">Validating repository...</span>
                        </div>
                      ) : (
                        <div className={`alert alert-${repoUrlValidation.isValid ? 'success' : 'warning'} py-2`}>
                          <div className="d-flex justify-content-between align-items-center">
                            <small>
                              {repoUrlValidation.isValid ? '✅' : '⚠️'} {repoUrlValidation.message}
                            </small>
                            {!repoUrlValidation.isValid && (
                              <button
                                className="btn btn-sm btn-outline-warning"
                                onClick={handleManualUrlEdit}
                              >
                                Edit URL
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="mt-2">
                  <span className="badge bg-success">
                    ✅ Ready for repository scan
                  </span>
                </div>
              </div>
            )}
            
            {/* Manual URL Edit Modal */}
            {showManualUrlEdit && (
              <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
                <div className="modal-dialog" style={{ zIndex: 1055 }}>
                  <div className="modal-content">
                    <div className="modal-header">
                      <h5 className="modal-title">
                        <i className="bi bi-pencil"></i> Edit Repository URL
                      </h5>
                      <button
                        type="button"
                        className="btn-close"
                        onClick={cancelManualUrlEdit}
                      ></button>
                    </div>
                    <div className="modal-body">
                      <div className="mb-3">
                        <label className="form-label">
                          <strong>Repository URL:</strong>
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          value={manualRepoUrl}
                          onChange={(e) => setManualRepoUrl(e.target.value)}
                          placeholder="https://username@domain.com/scm/repository.git"
                          style={{ fontFamily: 'monospace' }}
                        />
                        <div className="form-text">
                          Format: https://{selectedSPK}@scm.horizon.{selectedAIT?.toLowerCase()}.com/scm/{selectedRepo}.git
                        </div>
                      </div>
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={cancelManualUrlEdit}
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={saveManualUrl}
                        disabled={!manualRepoUrl.trim()}
                      >
                        Save URL
                      </button>
                    </div>
                  </div>
                </div>
                <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
              </div>
            )}
          </div>
        </div>
        )}

        {/* Scan Options - Show when all dropdowns are selected */}
        {showScanOptions && !hideFileUpload && (
          <div
            className="card mb-5 shadow"
            style={{ background: "#fff", border: "1px solid #e5e7eb" }}
          >
            <div
              className="card-header d-flex justify-content-between align-items-center"
              style={{
                background: "#f8f9fa",
                borderBottom: "1px solid #e5e7eb",
              }}
            >
              <h5 className="mb-0" style={{ color: "#222" }}>
                <FaShieldAlt className="me-2" />Choose Scan Method
              </h5>
              <div>
                <span className="badge bg-primary me-2">
                  <FaProjectDiagram className="me-1" /> PROJECT: {getAITName(selectedAIT)} → {getSPKName(selectedSPK)} → {getRepoName(selectedRepo)}
                </span>
              </div>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-6">
                  <div className="card h-100 border-primary">
                    <div className="card-body text-center">
                      <FaShieldVirus style={{ fontSize: "3rem", color: "#0d6efd" }} />
                      <h5 className="mt-3">File Upload Scan</h5>
                      <p className="text-muted">
                        Upload your source code files or folders for instant threat detection
                      </p>
                      <button
                        className="btn btn-primary"
                        onClick={showFileUpload}
                      >
                        <FaFolder className="me-2" />
                        Upload Files
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="card h-100 border-success">
                    <div className="card-body text-center">
                      <FaGithub style={{ fontSize: "3rem", color: "#28a745" }} />
                      <h5 className="mt-3">Repository Scan</h5>
                      <p className="text-muted">
                        Scan repositories from GitHub or Bitbucket for comprehensive threat analysis
                      </p>
                      <button
                        className="btn btn-success"
                        onClick={showRepoScan}
                      >
                        <FaGithub className="me-2" />
                        Scan Repository
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Malicious Scan - Only show when all dropdowns are selected and file upload is not hidden */}
        {showUploadComponent && !hideFileUpload && (
          <div
            className="card mb-5 shadow"
            style={{ background: "#fff", border: "1px solid #e5e7eb" }}
          >
            <div
              className="card-header d-flex justify-content-between align-items-center"
              style={{
                background: "#f8f9fa",
                borderBottom: "1px solid #e5e7eb",
              }}
            >
              <h5 className="mb-0" style={{ color: "#222" }}>
                <FaShieldAlt className="me-2" />File Upload Scanner
              </h5>
              <div>
                <span className="badge bg-primary me-2">
                  <FaProjectDiagram className="me-1" /> PROJECT: {getAITName(selectedAIT)} → {getSPKName(selectedSPK)} → {getRepoName(selectedRepo)}
                </span>
                <span className="badge bg-secondary me-2">
                  <FaFlask className="me-1" /> THREAT FOCUSED
                </span>
                <button className="btn btn-outline-secondary btn-sm">
                  ⚙️ Advanced Detection
                </button>
              </div>
            </div>
            <div
              className="card-body upload-area"
              style={{
                background: "#f8f9fa",
                border: "1px dashed #b0b0b0",
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleFileDrop}
            >
              <input
                type="file"
                id="fileInput"
                hidden
                multiple
                webkitdirectory="true"
                mozdirectory="true"
                directory="true"
                onChange={handleFileSelect}
              />
              <div className="mb-3">
                <FaShieldVirus
                  style={{ fontSize: "3rem", color: "#0d6efd" }}
                />
                <h5 className="mt-3" style={{ color: "#222" }}>
                  Drop your source code for instant malicious detection
                </h5>
                <small style={{ color: "#666" }}>
                  Project: {getAITName(selectedAIT)} → {getSPKName(selectedSPK)} → {getRepoName(selectedRepo)}
                </small>
              </div>
              <div className="d-flex justify-content-center gap-3 mt-4">
                <button
                  className="btn btn-primary"
                  onClick={() => document.getElementById("fileInput").click()}
                  disabled={uploading}
                >
                  {uploading
                                  ? "🔍 Scanning for Malicious Threats..."
              : "🎯 Scan for Malicious Threats"}
                </button>
                <button className="btn btn-outline-secondary">
                  🧪 Try Sample Threats
                </button>
              </div>
              
              {/* Back to Scan Options Button */}
              <div className="mt-4 text-center">
                <button
                  className="btn btn-outline-secondary"
                  onClick={() => {
                    setShowUploadComponent(false);
                    setShowScanOptions(true);
                  }}
                >
                  <FaArrowLeft className="me-2" />
                  Back to Scan Options
                </button>
              </div>
            </div>
          </div>
        )}

        {/* GitHub Repository Upload Section - Only show when GitHub scan is selected */}
        {showGithubScanComponent && !hideFileUpload && (
          <div
            className="card mb-5 shadow"
            style={{ background: "#fff", border: "1px solid #e5e7eb" }}
          >
          <div
            className="card-header d-flex justify-content-between align-items-center"
            style={{
              background: "#f8f9fa",
              borderBottom: "1px solid #e5e7eb",
            }}
          >
            <h5 className="mb-0" style={{ color: "#222" }}>
              <FaGithub className="me-2" /> Repository Scanner
            </h5>
            <div>
              <span className="badge bg-primary me-2">
                <FaProjectDiagram className="me-1" /> PROJECT: {getAITName(selectedAIT)} → {getSPKName(selectedSPK)} → {getRepoName(selectedRepo)}
              </span>
              <span className="badge bg-success me-2">INTEGRATION</span>
              <span className="badge bg-info">REMOTE SCAN</span>
            </div>
          </div>
          <div
            className="card-body"
            style={{
              background: "#f8f9fa",
              border: "1px solid #e5e7eb",
            }}
          >
            <div className="d-flex align-items-start mb-3">
              <FaGithub style={{ fontSize: "3rem", color: "#333" }} />
              <div className="ms-3">
                <h5 className="mb-0" style={{ color: "#222" }}> Scan repositories </h5>
                <small style={{ color: "#666" }}> Enter a GitHub or Bitbucket repository URL to automatically clone and scan for threats </small>
                <br />
                <small style={{ color: "#888", fontSize: "0.8rem" }}>💡 Tip: Smaller repositories scan faster. Large repositories may take 1-2 minutes.</small>
              </div>
            </div>
            
            {/* Constructed URL Display */}
            {constructedRepoUrl && (
              <div className="mb-3 p-3 bg-light border rounded">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="mb-0" style={{ color: "#222" }}>
                    <i className="bi bi-link-45deg"></i> Constructed Repository URL:
                  </h6>
                  <span className={`badge ${repoUrlValidation.isValid ? 'bg-success' : 'bg-warning'}`}>
                    {repoUrlValidation.isValid ? '✅ Valid' : '⚠️ Needs Review'}
                  </span>
                </div>
                <div className="input-group">
                  <input
                    type="text"
                    className="form-control"
                    value={constructedRepoUrl}
                    readOnly
                    style={{ 
                      fontFamily: 'monospace',
                      fontSize: '0.9rem',
                      backgroundColor: repoUrlValidation.isValid ? '#d4edda' : '#fff3cd'
                    }}
                  />
                  <button
                    className="btn btn-outline-secondary"
                    type="button"
                    onClick={() => setRepoUrl(constructedRepoUrl)}
                    title="Use this URL"
                    disabled={!repoUrlValidation.isValid}
                  >
                    <i className="bi bi-check-circle"></i> Use
                  </button>
                </div>
                <small className="text-muted">
                  {repoUrlValidation.message}
                </small>
              </div>
            )}
                          <div className="d-flex justify-content-center gap-3 mt-4">
                <input
                  type="text"
                  className="form-control"
                  placeholder="https://github.com/owner/repo or https://bitbucket.org/owner/repo"
                  value={repoUrl}
                  onChange={(e) => setRepoUrl(e.target.value)}
                  style={{ minWidth: '400px' }}
                  disabled={scanningRepo}
                />
                <button
                  className="btn btn-primary"
                  style={{ minWidth: '180px' }}
                  onClick={handleRepoScan}
                  disabled={scanningRepo || !repoUrl.trim() || (constructedRepoUrl && !repoUrlValidation.isValid)}
                >
                  {scanningRepo
                    ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Scanning Repository...
                      </>
                    )
                    : constructedRepoUrl && !repoUrlValidation.isValid
                    ? "⚠️ Validate URL First"
                    : "📦 Scan Repository"}
                </button>
              </div>
              
              {/* Progress message */}
              {scanningRepo && scanProgress && (
                <div className="text-center mt-3">
                  <div className="alert alert-info" role="alert">
                    <div className="d-flex align-items-center justify-content-center">
                      <div className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></div>
                      <span>{scanProgress}</span>
                    </div>
                  </div>
                </div>
              )}
            
            {/* GitHub Token Input (shown when needed) */}
            {showTokenInput && (
              <div className="mt-3 p-3 bg-warning bg-opacity-10 border border-warning rounded">
                <div className="d-flex align-items-center gap-2 mb-2">
                  <FaLock className="text-warning me-1" />
                  <span className="text-warning fw-bold">Private Repository Detected</span>
                </div>
                <small className="text-muted d-block mb-3">
                  This appears to be a private repository. Please provide your access token to access it.
                </small>
                <div className="d-flex justify-content-center gap-3">
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Access Token (GitHub/Bitbucket)"
                    value={repoToken}
                    onChange={(e) => setRepoToken(e.target.value)}
                    style={{ minWidth: '300px' }}
                    disabled={scanningRepo}
                  />
                  <button
                    className="btn btn-warning"
                    onClick={handleRepoScan}
                    disabled={scanningRepo || !repoToken.trim()}
                  >
                    🔐 Scan Private Repo
                  </button>
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => {
                      setShowTokenInput(false);
                      setRepoToken('');
                    }}
                    disabled={scanningRepo}
                  >
                    Cancel
                  </button>
                </div>
                <div className="mt-2 text-center">
                  <small className="text-muted">
                    <FaInfoCircle className="me-1" />
                    Create tokens at: 
                    <a href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer" className="ms-1">GitHub</a> | 
                    <a href="https://bitbucket.org/account/settings/app-passwords/" target="_blank" rel="noopener noreferrer" className="ms-1">Bitbucket</a>
                  </small>
                </div>
              </div>
            )}
            
            <div className="mt-3 text-center">
              <small style={{ color: "#666" }}>
                <i className="bi bi-info-circle"></i> 
                Supports public and private repositories. Large repositories may take longer to scan.
              </small>
            </div>
            
            {/* Back to Scan Options Button */}
            <div className="mt-4 text-center">
              <button
                className="btn btn-outline-secondary"
                onClick={() => {
                  setShowGithubScanComponent(false);
                  setShowScanOptions(true);
                }}
              >
                <FaArrowLeft className="me-2" />
                Back to Scan Options
              </button>
            </div>
          </div>
        </div>
        )}

        {/* Project & Scan Info */}
        {metrics && (
          <>
            <div className="row g-4 mb-4">
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.scan_info?.files_scanned ?? metrics.files_scanned ?? metrics.file_results?.length ?? 0}
                  </div>
                  <div className="metric-label">Files Scanned</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.scan_info?.lines_of_code?.toLocaleString() ?? metrics.lines_of_code?.toLocaleString() ?? 0}
                  </div>
                  <div className="metric-label">Lines of Code</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.coverage ?? metrics.scan_info?.coverage ?? 0}%
                  </div>
                  <div className="metric-label">Coverage</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.duplications ?? metrics.scan_info?.duplications ?? 0}%
                  </div>
                  <div className="metric-label">Duplications</div>
                </div>
              </div>
            </div>
            <div className="row g-4 mb-4">
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.security_rating ?? metrics.scan_info?.security_rating ?? "-"}
                  </div>
                  <div className="metric-label">Security Rating</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.reliability_rating ?? metrics.scan_info?.reliability_rating ?? "-"}
                  </div>
                  <div className="metric-label">Reliability Rating</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.maintainability_rating ?? metrics.scan_info?.maintainability_rating ?? "-"}
                  </div>
                  <div className="metric-label">Maintainability</div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="metric-card text-center shadow">
                  <div className="metric-value">
                    {metrics.metrics?.technical_debt_hours ?? metrics.scan_info?.technical_debt_hours ?? 0}h
                  </div>
                  <div className="metric-label">Technical Debt</div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Quality Gate */}
        {metrics && (
  <div className="mb-4">
    <span
      className={`badge ${
        metrics.summary?.quality_gate_passed ? "bg-success" : "bg-danger"
      }`}
    >
      Quality Gate:{" "}
      {metrics.summary?.quality_gate_passed ? "PASSED" : "FAILED"}
    </span>
  </div>
)}

        {/* Per-File Scan Results
        {Array.isArray(metrics?.file_results) && metrics.file_results.length > 0 && (
          <div className="mb-5">
            <h5 >Per-File Scan Results</h5>
            <div className="table-responsive">
              <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                  <tr>
                    <th>File</th>
                    <th>Type</th>
                    <th>Lines</th>
                    <th>Threat Level</th>
                    <th>Critical Threats</th>
                    <th>Issues</th>
                    <th>Logic Bombs</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {metrics.file_results.map((file) => (
                    <tr key={file.file_id}>
                      <td>{file.file_name}</td>
                      <td>{file.file_type}</td>
                      <td>{file.lines_scanned}</td>
                      <td>{file.threat_level}</td>
                      <td>{file.critical_threats}</td>
                      <td>{file.issues_count}</td>
                      <td>{file.logic_bomb_count}</td>
                      <td>{file.scan_status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )} */}

        {/* Toast Notifications */}
        <div
          className="position-fixed bottom-0 end-0 p-3"
          style={{ zIndex: 1055 }}
        >
          <div
            id="successToast"
            className="toast align-items-center text-white bg-success border-0"
            role="alert"
          >
            <div className="d-flex">
              <div className="toast-body">
                ✅ Operation completed successfully!
              </div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
          <div
            id="warningToast"
            className="toast align-items-center text-white bg-warning border-0"
            role="alert"
          >
            <div className="d-flex">
                              <div className="toast-body">⚠️ Malicious threats detected!</div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
          <div
            id="errorToast"
            className="toast align-items-center text-white bg-danger border-0"
            role="alert"
          >
            <div className="d-flex">
              <div className="toast-body">
                ❌ Operation failed. Please try again.
              </div>
              <button
                type="button"
                className="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
              ></button>
            </div>
          </div>
        </div>

        {/* Malicious Stats */}
        {logicBombStats?.details?.length > 0 && (
          <div
            className="section mt-5"
            style={{
              background: "#fff",
              border: "1px solid #e5e7eb",
              padding: "1.5rem",
              borderRadius: "8px",
            }}
          >
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h4 className="mb-0" >
                🚨 Malicious Patterns Detected
              </h4>
            </div>
            <div className="table-responsive w-100">
              <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                  <tr>
                    <th >Malicious Type</th>
                    <th >Occurrences</th>
                  </tr>
                </thead>
                <tbody>
                  {logicBombStats.details.map((entry, idx) => {
                    const [type, count] = entry.split(":");
                    return (
                      <tr key={idx}>
                        <td className="fw-bold" style={{ color: "#dc3545" }}>
                          {type.trim()}
                        </td>
                        <td style={{ color: "#222" }}>{count.trim()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Vulnerability Stats */}
        {vulnerabilityStats?.details?.length > 0 && (
          <div
            className="section mt-5"
            style={{
              background: "#fff",
              border: "1px solid #e5e7eb",
              padding: "1.5rem",
              borderRadius: "8px",
            }}
          >
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h4 className="mb-0" >
                🛡️ Vulnerability Patterns Detected
              </h4>
            </div>
            <div className="table-responsive w-100">
              <table className="table table-bordered table-hover align-middle">
                <thead className="table-light">
                  <tr>
                    <th >Vulnerability Type</th>
                    <th >Occurrences</th>
                  </tr>
                </thead>
                <tbody>
                  {vulnerabilityStats.details.map((entry, idx) => {
                    const [type, count] = entry.split(":");
                    return (
                      <tr key={idx}>
                        <td className="fw-bold" style={{ color: "#fd7e14" }}>
                          {type.trim()}
                        </td>
                        <td style={{ color: "#222" }}>{count.trim()}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Enhanced Scan Information */}
        <div className="mb-5">
          <div className="card text-start shadow">
            <div className="card-header" style={{ background: "#f8f9fa", borderBottom: "1px solid #e5e7eb" }}>
              <h3 className="mb-0" >📊 Latest Scan Information</h3>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scan_info?.project_id || "No scan data"}
                  </div>
                  <div style={{ color: "#888" }}>Project ID</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#0d6efd",
                    }}
                  >
                    {scan_info?.project_name || `${getAITName(selectedAIT) || getAITName(scan_info?.ait_tag)}-${getSPKName(selectedSPK) || getSPKName(scan_info?.spk_tag)}-${getRepoName(selectedRepo) || getRepoName(scan_info?.repo_name)}` || "Project Name"}
                  </div>
                  <div style={{ color: "#888" }}>Project Name</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scanDate}
                  </div>
                  <div style={{ color: "#888" }}>Scan Date</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      color: "#222",
                    }}
                  >
                    {scanTime}
                  </div>
                  <div style={{ color: "#888" }}>Scan Time</div>
                </div>
              </div>
              <div className="row mt-3">
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#0d6efd",
                    }}
                  >
                    {scan_info?.duration_ms ? `${scan_info.duration_ms}ms` : "0ms"}
                  </div>
                  <div style={{ color: "#888" }}>Duration</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#198754",
                    }}
                  >
                    {getAITName(selectedAIT) || getAITName(scan_info?.ait_tag) || "AIT"}
                  </div>
                  <div style={{ color: "#888" }}>AIT</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#6f42c1",
                    }}
                  >
                    {getSPKName(selectedSPK) || getSPKName(scan_info?.spk_tag) || "SPK"}
                  </div>
                  <div style={{ color: "#888" }}>SPK</div>
                </div>
                <div className="col-md-3">
                  <div
                    style={{
                      fontSize: "1.2rem",
                      fontWeight: "bold",
                      // color: "#fd7e14",
                    }}
                  >
                    {getRepoName(selectedRepo) || getRepoName(scan_info?.repo_name) || "Repository"}
                  </div>
                  <div style={{ color: "#888" }}>Repository</div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

        <h3 className="mb-4" >
          🛡️ Malicious Detection Metrics
        </h3>
        <div className="row g-4 mb-4">
          {detectionMetricCards.map((item, i) => (
            <div className="col-md-3" key={i}>
              <div
                className="metric-card text-center shadow"
                style={{
                  background: "#fff",
                  border: "1px solid #e5e7eb",
                  color: "#222",
                  padding: "1.5rem",
                  borderRadius: "8px",
                }}
              >
                <div
                  className={`metric-value ${item.className}`}
                  style={{ fontSize: "2.5rem", fontWeight: "bold" }}
                >
                  {item.value}
                </div>
                <div className="metric-label" style={{ color: "#888" }}>
                  {item.label}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Malicious Pattern Breakdown */}
{metrics?.logic_bomb_metrics && (
  <div className="row g-4 mb-4">
    {[
      {
        label: "Scheduled Threat",
        value: metrics.logic_bomb_metrics?.SCHEDULED_THREAT || 0,
        description: "Date/time triggered threats",
        color: "#dc3545",
      },
      {
        label: "Targeted Attack",
        value: metrics.logic_bomb_metrics?.TARGETED_ATTACK || 0,
        description: "User-targeted attacks",
        color: "#0d6efd",
      },
      {
        label: "Execution Trigger",
        value: metrics.logic_bomb_metrics?.EXECUTION_TRIGGER || 0,
        description: "Execution-based triggers",
        color: "#198754",
      },
      {
        label: "Destructive Payloads",
        value: metrics.logic_bomb_metrics?.DESTRUCTIVE_PAYLOAD || 0,
        description: "Direct destructive actions",
        color: "#fd7e14",
      },
    ].map((item, i) => (
      <div className="col-md-3" key={i}>
        <div
          className="metric-card text-center shadow"
          style={{
            background: "#f8f9fa",
            // border: `1px solid ${item.color}`,
            color: "#222",
            padding: "1.5rem",
            borderRadius: "8px",
          }}
        >
          <div
            className="metric-value"
            style={{ fontSize: "2rem" }}
          >
            {item.value}
          </div>
          <div
            className="metric-label"
            style={{ color: "#222", fontWeight: "bold" }}
          >
            {item.label}
          </div>
          <div
            style={{
              color: "#888",
              fontSize: "0.8rem",
              marginTop: "0.5rem",
            }}
          >
            {item.description}
          </div>
        </div>
      </div>
    ))}
  </div>
)}

        {/* Advanced Malicious Metrics */}
        {/* Advanced Malicious Metrics */}
{metrics?.logic_bomb_metrics && (
  <div className="row g-4 mb-5">
    {[
      {
        label: "Trigger Complexity",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.trigger_complexity_score || 0
        )}%`,
        description: "Sophistication of trigger mechanisms",
      },
      {
        label: "Payload Severity",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.payload_severity_score || 0
        )}%`,
        description: "Potential damage assessment",
      },
      {
        label: "Detection Confidence",
        value: `${Math.round(
          metrics.logic_bomb_metrics?.detection_confidence_avg || 0
        )}%`,
        description: "Average detection confidence",
      },
      {
        label: "Threat Density",
        value: `${Math.min(100, Math.round(
          (metrics.logic_bomb_metrics?.threat_density || 0) / 100
        ))}%`,
        description: "Threat density percentage (capped at 100%)",
      },
    ].map((item, i) => {
      console.log(`Rendering metric ${i}:`, item);
      return (
        <div className="col-md-3" key={i}>
          <div
            className="metric-card text-center"
            style={{
              background: "#fff",
              border: "1px solid #e5e7eb",
              color: "#222",
              padding: "1.5rem",
              borderRadius: "8px",
            }}
          >
            <div
              className="metric-value"
              style={{ fontSize: "1.8rem" }}
            >
              {item.value}
            </div>
            <div
              className="metric-label"
              style={{
                color: "#222",
                fontSize: "0.9rem",
                fontWeight: "bold",
              }}
            >
              {item.label}
            </div>
            <div
              style={{
                color: "#888",
                fontSize: "0.75rem",
                marginTop: "0.3rem",
              }}
            >
              {item.description}
            </div>
          </div>
        </div>
      );
    })}
  </div>
)}

        {/* Enhanced Threat Intelligence Summary */}
        {threat_intelligence && (
          <div
            className="mb-5 shadow"
            style={{
              background: "#ffffff",
              padding: "1.5rem",
              borderRadius: "8px",
              border: "1px solid #e5e7eb",
            }}
          >
            <h3 className="mb-4">
              🧠 Current Threat Intelligence Assessment
            </h3>
            <div className="row">
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "2rem",
                    fontWeight: "bold",
                    color:
                      threat_intelligence.threat_level === "CRITICAL"
                        ? "#dc3545"
                        : threat_intelligence.threat_level === "HIGH"
                        ? "#fd7e14"
                        : "#198754",
                  }}
                >
                  {threat_intelligence.threat_level}
                </div>
                <div style={{ color: "#888" }}>Current Threat Level</div>
              </div>
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "bold",
                    color: "#0d6efd",
                  }}
                >
                  {Math.round(
                    metrics.logic_bomb_metrics?.neutralization_urgency_hours ||
                      0
                  )}
                  h
                </div>
                <div style={{ color: "#888" }}>Neutralization Urgency</div>
              </div>
              <div className="col-md-4">
                <div
                  style={{
                    fontSize: "1.5rem",
                    fontWeight: "bold",
                    color:
                      threat_shield?.protection_effectiveness >= 80
                        ? "#198754"
                        : threat_shield?.protection_effectiveness >= 60
                        ? "#fd7e14"
                        : "#dc3545",
                  }}
                >
                  {Math.round(threat_shield?.protection_effectiveness || 0)}%
                </div>
                <div style={{ color: "#888" }}>Shield Effectiveness</div>
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-12">
                <h5 style={{ color: "#dc3545", marginBottom: "1.5rem" }}>
                  🚨 Immediate Actions Required:
                </h5>
                <ul style={{ listStyle: "none", padding: 0 }}>
                  {(
                    metrics.threat_analysis?.recommended_actions ||
                    threat_intelligence.recommendations ||
                    []
                  )
                    .slice(0, 3)
                    .map((rec, idx) => (
                      <li
                        key={idx}
                        style={{
                          padding: "0.7rem",
                          borderLeft: "4px solid #dc3545",
                          paddingLeft: "1rem",
                          margin: "0.75rem 0",
                          background: "#f5f0f0",
                          color: "#222",
                          borderRadius: "4px"
                        }}
                      >
                        <strong style={{ color: "#dc3545" }}>ACTION:</strong>{" "}
                        {rec}
                      </li>
                    ))}
                </ul>
              </div>
            </div>
            </div>
        )}

        {/* Threat Tabs */}
        <ul
          className="nav nav-tabs mb-3"
          style={{ borderBottom: "2px solid #e5e7eb" }}
        >
          <li className="nav-item">
            <button
              className={`nav-link ${
                activeTab === "logicbombs" ? "active" : ""
              }`}
              onClick={() => setActiveTab("logicbombs")}
              style={{
                color: activeTab === "logicbombs" ? "#0d6efd" : "#888",
                background:
                  activeTab === "logicbombs" ? "#f8f9fa" : "transparent",
                border: "none",
                borderBottom:
                  activeTab === "logicbombs"
                    ? "3px solid #0d6efd"
                    : "3px solid transparent",
              }}
            >
              🚨 Malicious Code
            </button>
          </li>
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === "other" ? "active" : ""}`}
              onClick={() => setActiveTab("other")}
              style={{
                color: activeTab === "other" ? "#0d6efd" : "#888",
                background: activeTab === "other" ? "#f8f9fa" : "transparent",
                border: "none",
                borderBottom:
                  activeTab === "other"
                    ? "3px solid #0d6efd"
                    : "3px solid transparent",
              }}
            >
              📄 Tech Debt & Vulnerabilites
            </button>
          </li>
        </ul>

        {/* Threat Analysis Table */}
        <div
          className="section"
          style={{
            background: "#fff",
            border: "1px solid #e5e7eb",
            padding: "1.5rem",
            borderRadius: "8px",
          }}
        >
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h2 className="mb-0">
              {activeTab === "logicbombs"
                ? "🚨 Malicious Code"
                : "📄 Tech Debt & Vulnerabilites"}
            </h2>
            <button
              className="btn btn-outline-primary btn-sm"
              onClick={downloadThreatPrompts}
              style={{ borderColor: "#0d6efd", color: "#0d6efd" }}
            >
              🤖 Download AI Prompts
            </button>
          </div>

          {/* Filter Controls */}
          <div className="mb-3 py-3 bg-light rounded">
            <h6 className="mb-2" style={{ color: "#222" }}>
              <FaFilter /> Filter Threats
            </h6>
            <div className="row g-2">
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterAIT}
                  onChange={(e) => setFilterAIT(e.target.value)}
                >
                  <option value="">All AITs</option>
                  {Array.from(new Set(recentThreats.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                    <option key={ait} value={ait}>{getAITName(ait)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterSPK}
                  onChange={(e) => setFilterSPK(e.target.value)}
                >
                  <option value="">All SPKs</option>
                  {Array.from(new Set(recentThreats.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                    <option key={spk} value={spk}>{getSPKName(spk)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <select
                  className="form-select form-select-sm"
                  value={filterRepo}
                  onChange={(e) => setFilterRepo(e.target.value)}
                >
                  <option value="">All Repositories</option>
                  {Array.from(new Set(recentThreats.map(t => t.repo_name).filter(Boolean))).map(repo => (
                    <option key={repo} value={repo}>{getRepoName(repo)}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-3">
                <button
                  className="btn btn-outline-secondary btn-sm w-100"
                  onClick={() => {
                    setFilterAIT('');
                    setFilterSPK('');
                    setFilterRepo('');
                  }}
                >
                  <FaTimesCircle /> Clear Filters
                </button>
              </div>
            </div>
            {(filterAIT || filterSPK || filterRepo) && (
              <div className="mt-2">
                <small className="text-muted">
                  Showing {filteredThreats.length} of {recentThreats.length} threats
                </small>
              </div>
            )}
          </div>

          <div className="table-responsive w-100">
            <table className="table table-bordered table-hover align-middle">
              <thead className="table-light">
                <tr className="text-center">
                  <th >Threat Level</th>
                  <th >Type</th>
                  <th >AIT</th>
                  <th >SPK</th>
                  <th >Repository</th>
                  {/* <th >Rule</th> */}
                  <th style={{minWidth: "150px"}}>File Name</th>
                  <th >Line #</th>
                  <th >Code Snippet</th>
                  <th >Trigger Analysis</th>
                  <th >Payload Risk</th>
                  <th >Neutralization</th>
                  <th className="text-center" >
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {paginatedThreats.length > 0 ? (
                  paginatedThreats.map((threat, idx) => (
                    <tr 
                      key={threat.id}
                      style={{ cursor: 'pointer' }}
                      onClick={() => showThreatDetails(threat)}
                      onMouseEnter={(e) => e.target.parentElement.style.backgroundColor = '#f8f9fa'}
                      onMouseLeave={(e) => e.target.parentElement.style.backgroundColor = ''}
                    >
                      <td>
                        {(() => {
                          let badgeClass = "border-secondary text-secondary bg-secondary-subtle";
                          if (threat.severity === "CRITICAL_BOMB") {
                            badgeClass = "border-danger text-danger bg-danger-subtle";
                          } else if (threat.severity === "HIGH_RISK") {
                            badgeClass = "border-warning text-warning bg-warning-subtle";
                          } else if (threat.severity === "MEDIUM_RISK") {
                            badgeClass = "border-info text-info bg-info-subtle";
                          }
                          return (
                            <span className={`badge border ${badgeClass}`}>
                              {threat.severity}
                            </span>
                          );
                        })()}
                      </td>
                      <td style={{ color: "#222" }}>{threat.type}</td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getAITName(threat.ait_tag)}
                      </td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getSPKName(threat.spk_tag)}
                      </td>
                      <td style={{ color: "#666", fontSize: "0.9rem" }}>
                        {getRepoName(threat.repo_name)}
                      </td>
                      {/* <td style={{ color: "#888", fontSize: "0.9rem" }}>
                        {threat.rule_id}
                      </td> */}
                      <td
                        style={{
                          wordBreak: "break-all",
                          color: "#222",
                          maxWidth: "300px",
                          whiteSpace: "normal",
                          overflow: "auto",
                        }}
                      >
                        {(() => {
                          const fileName = threat.file_name?.split("/").pop() || 
                                          threat.file_name?.split("\\").pop() ||
                                          threat.file_path?.split("/").pop() || 
                                          threat.file_path?.split("\\").pop() || 
                                          threat.name?.split("/").pop() ||
                                          threat.name?.split("\\").pop() ||
                                          threat.file_path || 
                                          threat.name ||
                                          "Unknown File";
                          
                          // Debug: Log if we're getting "Unknown File"
                          if (fileName === "Unknown File") {
                            console.log('File name extraction failed for threat:', {
                              id: threat.id,
                              file_name: threat.file_name,
                              file_path: threat.file_path,
                              name: threat.name
                            });
                          }
                          
                          return fileName;
                        })()}
                      </td>
                      <td style={{ color: "#555" }}>{threat.line_number}</td>
                      <td
                        style={{
                          fontFamily: "monospace",
                          fontSize: "0.8rem",
                          color: "#333",
                        }}
                      >
                        {threat.code_snippet}
                      </td>

                      {/* <td className="text-center" style={{ color: "#0d6efd" }}>
                        {threat.line_number}
                      </td> */}
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#fd7e14",
                          fontSize: "0.85rem",
                        }}
                      >
                        {threat.trigger_analysis ||
                          "Conditional trigger detected"}
                      </td>
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#dc3545",
                          fontSize: "0.85rem",
                        }}
                      >
                        {threat.payload_analysis || "Potential system impact"}
                      </td>
                      <td
                        style={{
                          whiteSpace: "pre-wrap",
                          // color: "#198754",
                          fontSize: "0.85rem",
                          maxWidth: "200px",
                        }}
                      >
                        {threat.suggested_fix || "Neutralization guide pending"}
                      </td>
                      <td className="text-center">
                        <div className="d-flex justify-content-center gap-2">
                          <button
                            className="btn btn-outline-danger btn-sm"
                            style={{
                              
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              neutralizeThreat(threat.id);
                            }}
                          >
                            Neutralize
                          </button>
                          <button 
                            className="btn btn-sm btn-outline-secondary"
                            onClick={(e) => {
                              e.stopPropagation();
                              showThreatDetails(threat);
                            }}
                          >
                            Details
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan={12} className="text-center">No threats found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="d-flex justify-content-between align-items-center mt-3">
            <div>
              <select className="form-select form-select-sm" style={{ width: 100, display: 'inline-block' }} value={pageSize} onChange={e => setPageSize(Number(e.target.value))}>
                {[10, 25, 50, 100].map(size => <option key={size} value={size}>{size} / page</option>)}
              </select>
              <span className="ms-2 text-muted">
                Showing {(displayedThreats.length === 0) ? 0 : ((currentPage - 1) * pageSize + 1)}-
                {Math.min(currentPage * pageSize, displayedThreats.length)} of {displayedThreats.length}
              </span>
            </div>
            <nav style={{ overflowX: 'auto', maxWidth: 400 }}>
              <ul className="pagination pagination-sm mb-0 flex-nowrap">
                <li className={`page-item${currentPage === 1 ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.max(1, p - 1))}>Prev</button> </li>
                {getPaginationWindow(currentPage, totalPages).map((page, idx) =>
                  page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                    <li key={page + idx} className="page-item disabled"><span className="page-link">...</span></li>
                  ) : (
                    <li key={page} className={`page-item${page === currentPage ? ' active' : ''}`}>
                      <button className="page-link" onClick={() => setCurrentPage(page)}>{page}</button>
                    </li>
                  )
                )}
                <li className={`page-item${currentPage === totalPages ? ' disabled' : ''}`}> <button className="page-link" onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}>Next</button> </li>
              </ul>
            </nav>
          </div>
        </div>

        {/* Threat Statistics */}
        {recentThreats.length > 0 && (
          <div className="row g-4 mt-4">
            <div className="col-md-6">
              <div
                className="card shadow h-100"
                style={{ background: "#fff", border: "1px solid #e5e7eb" }}
              >
                <div
                  className="card-header"
                  style={{
                    // background: "#f8f9fa",
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  <h5 >🎯 Threat Distribution</h5>
                </div>
                <div className="card-body">
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Malicious Threats</span>
                      <span className="badge bg-danger-subtle text-danger">
                        {logicBombThreats.length}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Tech Debt & Vulnerabilites</span>
                      <span className="badge bg-warning-subtle text-warning">
                        {techDebtThreats.length}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Malicious Risk Score</span>
                      <span
                        className={`badge ${
                          (summary.logic_bomb_risk_score ??
                            threat_ratings?.logic_bomb_risk_score ??
                            0) >= 70
                            ? "bg-danger-subtle text-danger"
                            : (summary.logic_bomb_risk_score ??
                                threat_ratings?.logic_bomb_risk_score ??
                                0) >= 40
                            ? "bg-warning-subtle text-warning"
                            : "bg-success-subtle text-success"
                        }`}
                      >
                        {summary.logic_bomb_risk_score ??
                          threat_ratings?.logic_bomb_risk_score ??
                          0}
                        /100
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Threat Density</span>
                      <span className="badge bg-info">
                        {Math.min(100, Math.round(
                          (metrics.logic_bomb_metrics?.threat_density || 0) / 100
                        ))}
                        %
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Critical Bomb Ratio</span>
                      <span
                        className={`badge ${
                          metrics.logic_bomb_metrics?.critical_bomb_ratio >= 50
                            ? "bg-danger-subtle text-danger"
                            : metrics.logic_bomb_metrics?.critical_bomb_ratio >=
                              25
                            ? "bg-warning-subtle text-warning"
                            : "bg-success-subtle text-success"
                        }`}
                      >
                        {Math.round(
                          metrics.logic_bomb_metrics?.critical_bomb_ratio || 0
                        )}
                        %
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <div
                className="card shadow h-100"
                style={{
                  background: "#fff",
                  border: "1px solid #e5e7eb",
                  color: "#222",
                }}
              >
                <div
                  className="card-header"
                  style={{
                    // background: "#f8f9fa",
                    borderBottom: "1px solid #e5e7eb",
                  }}
                >
                  <h5 >🛡️ Protection Status</h5>
                </div>
                <div className="card-body">
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Threat Shield</span>
                      <span
                        className={`badge ${
                          threat_shield?.status === "PROTECTED"
                            ? "bg-success-subtle text-success"
                            : threat_shield?.status === "BLOCKED"
                            ? "bg-danger-subtle text-danger"
                            : "bg-warning-subtle text-warning"
                        }`}
                      >
                        {threat_shield?.status || "UNKNOWN"}
                      </span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Detection Engine</span>
                      <span className="badge bg-success-subtle text-success">ACTIVE</span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>AI Analysis</span>
                      <span className="badge bg-info-subtle text-info">ENABLED</span>
                    </div>
                  </div>
                  <div className="mb-3">
                    <div className="d-flex justify-content-between">
                      <span>Shield Effectiveness</span>
                      <span
                        className={`badge ${
                          threat_shield?.protection_effectiveness >= 80
                            ? "bg-success-subtle text-success"
                            : threat_shield?.protection_effectiveness >= 60
                            ? "bg-warning-subtle text-warning"
                            : "bg-danger-subtle text-danger"
                        }`}
                      >
                        {Math.round(
                          threat_shield?.protection_effectiveness || 0
                        )}
                        %
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Threat Detail Modal */}
        {showThreatModal && selectedThreat && (
          <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">
                    🚨 Threat Details - {selectedThreat.severity}
                  </h5>
                  <button 
                    type="button" 
                    className="btn-close" 
                    onClick={() => setShowThreatModal(false)}
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="row">
                    <div className="col-md-6">
                      <h6>Threat Information</h6>
                      <p><strong>Type:</strong> {selectedThreat.type || 'Unknown'}</p>
                      <p><strong>Priority:</strong> 
                        <span className={`badge ms-2 ${
                          getThreatPriority(selectedThreat) === 'IMMEDIATE' ? 'bg-danger' :
                          getThreatPriority(selectedThreat) === 'HIGH' ? 'bg-warning' :
                          getThreatPriority(selectedThreat) === 'MEDIUM' ? 'bg-info' : 'bg-secondary'
                        }`}>
                          {getThreatPriority(selectedThreat)}
                        </span>
                      </p>
                      <p><strong>File:</strong> {selectedThreat.file_name?.split("/").pop() || 
                                                selectedThreat.file_path?.split("/").pop() || 
                                                selectedThreat.file_path?.split("\\").pop() || 
                                                selectedThreat.file_path || 
                                                "Unknown File"}</p>
                      <p><strong>Line:</strong> {selectedThreat.line_number}</p>
                      <p><strong>Status:</strong> 
                        <span className={`badge ms-2 ${
                          selectedThreat.status === 'ACTIVE_THREAT' ? 'bg-danger' : 'bg-success'
                        }`}>
                          {selectedThreat.status}
                        </span>
                      </p>
                    </div>
                    <div className="col-md-6">
                      <h6>Code Snippet</h6>
                      <pre className="bg-light p-2 rounded" style={{ fontSize: '0.8rem' }}>
                        {selectedThreat.code_snippet || 'No code snippet available'}
                      </pre>
                    </div>
                  </div>
                  <div className="mt-3">
                    <h6>Solution</h6>
                    <p className="text-muted">{getThreatSolution(selectedThreat)}</p>
                  </div>
                  {selectedThreat.trigger_analysis && (
                    <div className="mt-3">
                      <h6>Trigger Analysis</h6>
                      <p className="text-info">{selectedThreat.trigger_analysis}</p>
                    </div>
                  )}
                  {selectedThreat.payload_analysis && (
                    <div className="mt-3">
                      <h6>Payload Analysis</h6>
                      <p className="text-danger">{selectedThreat.payload_analysis}</p>
                    </div>
                  )}
                </div>
                <div className="modal-footer">
                  <button 
                    type="button" 
                    className="btn btn-secondary" 
                    onClick={() => setShowThreatModal(false)}
                  >
                    Close
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-danger" 
                    onClick={() => {
                      neutralizeThreat(selectedThreat.id);
                      setShowThreatModal(false);
                    }}
                  >
                    Neutralize Threat
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* System Information Footer */}
        <div
          className="mt-5 pt-4"
          style={{
            borderTop: "1px solid #e5e7eb",
            color: "#888",
            fontSize: "0.9rem",
          }}
        >
          <div className="row">
            <div className="col-md-6">
              <strong >ThreatGuard Pro</strong> -
              Advanced Malicious Detection System
              <br />
              Specialized in Scheduled Threat, Targeted Attack, Execution
              Trigger & destructive payloads
            </div>
            <div className="col-md-6 text-end">
              Last Update: {new Date().toLocaleString()}
              <br />
              System Status:{" "}
              <span style={{ color: "#198754" }}>🟢 Operational</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThreatGuardDashboard;
