import React, { useState, useEffect } from 'react';
import { copilotAPI, vscodeAgentAPI, vscodeCopilotAPI } from '../api';
import API from '../api';
import './CopilotRemediation.css';

// Helper function to get file name from path
const Path = (path) => {
  return path.split('/').pop() || path.split('\\').pop() || path;
};

const CopilotRemediation = () => {
  const [projects, setProjects] = useState([]);
  const [agentStatus, setAgentStatus] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileContents, setFileContents] = useState(null);
  const [showFileModal, setShowFileModal] = useState(false);
  const [availableFiles, setAvailableFiles] = useState([]);
  const [processingScan, setProcessingScan] = useState(null);
  const [vscodePrompts, setVscodePrompts] = useState({});
  const [showVscodeModal, setShowVscodeModal] = useState(false);
  const [selectedVscodeFile, setSelectedVscodeFile] = useState(null);
  const [diffData, setDiffData] = useState(null);
  const [selectedScanId, setSelectedScanId] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [taskDetails, setTaskDetails] = useState({});
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showInstructionsModal, setShowInstructionsModal] = useState(false);
  const [instructions, setInstructions] = useState({});
  const [workspaceData, setWorkspaceData] = useState({});
  const [showWorkspaceModal, setShowWorkspaceModal] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState({});
  const [copilotPrompts, setCopilotPrompts] = useState({});
  const [showCopilotPromptsModal, setShowCopilotPromptsModal] = useState(false);
  const [activeTab, setActiveTab] = useState('projects');
  const [vulnerabilities, setVulnerabilities] = useState([]);
  const [vulnerabilitiesLoading, setVulnerabilitiesLoading] = useState(false);
  const [generatedPrompts, setGeneratedPrompts] = useState(() => {
    // Load generated prompts from localStorage on component mount
    const saved = localStorage.getItem('generatedPrompts');
    return saved ? JSON.parse(saved) : {};
  });
  const [showTerraformModal, setShowTerraformModal] = useState(false);
  const [terraformContent, setTerraformContent] = useState('');
  const [generatingTerraform, setGeneratingTerraform] = useState(false);
  const [hostname, setHostname] = useState('');
  const [currentVulnerability, setCurrentVulnerability] = useState(null);
  
  // Sorting state
  const [sortField, setSortField] = useState(null);
  const [sortDirection, setSortDirection] = useState('asc');

  useEffect(() => {
    loadProjects();
    loadAgentStatus();
  }, [refreshTrigger]);

  useEffect(() => {
    if (activeTab === 'vulnerabilities') {
      loadVulnerabilities();
    }
  }, [activeTab]);

  const loadProjects = async () => {
    try {
      setLoading(true);
      console.log('🔄 Loading projects...');
      const response = await copilotAPI.getProjects();
      console.log('📦 Projects API response:', response);
      console.log('📦 Projects data:', response.data);
      console.log('📦 Projects array:', response.data?.projects);
      setProjects(response.data?.projects || []);
      console.log('✅ Projects loaded:', response.data?.projects?.length || 0, 'projects');
    } catch (error) {
      console.error('❌ Error loading projects:', error);
      console.error('❌ Error details:', error.response?.data);
      console.error('❌ Error status:', error.response?.status);
      setProjects([]);
    } finally {
      setLoading(false);
    }
  };

  const loadAgentStatus = async () => {
    try {
      const status = await copilotAPI.getAgentStatus();
      setAgentStatus(status);
    } catch (error) {
      console.error('Error loading agent status:', error);
    }
  };

  const loadVulnerabilities = async () => {
    try {
      setVulnerabilitiesLoading(true);
      console.log('🔄 Loading vulnerabilities...');
      
      // Use the same API approach as EnhancedVulnerabilityManagement
      let apiVulnerabilities = [];
      try {
        const response = await API.get('/api/v1/vulnerabilities/enhanced?page=1&per_page=100');
        const data = response.data;
        
        if (data.success) {
          apiVulnerabilities = data.vulnerabilities || [];
          console.log('✅ API Vulnerabilities loaded:', apiVulnerabilities.length, 'vulnerabilities');
          
          // Log details about the vulnerabilities
          const scanResults = apiVulnerabilities.filter(v => v.source === 'scan_result');
          const sampleData = apiVulnerabilities.filter(v => !v.source || v.source !== 'scan_result');
          console.log('📊 Breakdown:', {
            total: apiVulnerabilities.length,
            scanResults: scanResults.length,
            sampleData: sampleData.length
          });
          
          if (scanResults.length > 0) {
            console.log('🔍 Sample scan result:', scanResults[0]);
          }
        } else {
          console.error('❌ Error loading API vulnerabilities:', data.error);
        }
      } catch (apiError) {
        console.error('❌ Error loading API vulnerabilities:', apiError);
      }
      
      // Load any persisted Excel data from localStorage and merge with API data
      const persistedExcelData = localStorage.getItem('excel_vulnerabilities');
      if (persistedExcelData) {
        try {
          const parsedExcelData = JSON.parse(persistedExcelData);
          console.log('✅ Excel data loaded:', parsedExcelData.length, 'vulnerabilities');
          
          // Merge API data with Excel data, avoiding duplicates
          const existingIds = new Set(apiVulnerabilities.map(v => v.id));
          const newExcelVulns = parsedExcelData.filter(v => !existingIds.has(v.id));
          const mergedVulnerabilities = [...apiVulnerabilities, ...newExcelVulns];
          
          setVulnerabilities(mergedVulnerabilities);
          console.log(`✅ Total vulnerabilities loaded: ${apiVulnerabilities.length} API + ${parsedExcelData.length} Excel (${newExcelVulns.length} new) = ${mergedVulnerabilities.length} total`);
        } catch (error) {
          console.error('❌ Error loading persisted Excel data:', error);
          localStorage.removeItem('excel_vulnerabilities');
          setVulnerabilities(apiVulnerabilities);
        }
      } else {
        setVulnerabilities(apiVulnerabilities);
      }
      
      // If no API data and no Excel data, set empty array
      if (apiVulnerabilities.length === 0 && !persistedExcelData) {
        setVulnerabilities([]);
      }
    } catch (error) {
      console.error('❌ Error in loadVulnerabilities:', error);
      setVulnerabilities([]);
    } finally {
      setVulnerabilitiesLoading(false);
    }
  };

  // Vulnerability-specific functions
  const generateTerraformPrompt = (vulnerability, customHostname = '') => {
    const hostnamePlaceholder = customHostname || 'YOUR_HOSTNAME_HERE';
    
    const basePrompt = `# GitHub Copilot Terraform Generation Prompt

## Vulnerability Context
You are a DevOps engineer tasked with creating a Terraform configuration to remediate a security vulnerability.

**AIT Tag**: ${vulnerability.ait_tag || 'AIT-Unknown'}
**Vulnerability**: ${vulnerability.title || vulnerability.description}
**Severity**: ${vulnerability.severity || 'Unknown'}
**Risk Score**: ${vulnerability.risk_score || 'N/A'}
**Target Hostname**: ${hostnamePlaceholder}

## Remediation Action Required
${vulnerability.remediation_action || 'Update to latest version'}

## Your Task
Generate a complete Terraform (.tf) configuration file that:

1. **Addresses the specific vulnerability** mentioned above
2. **Implements the remediation action** specified
3. **Follows AWS best practices** for security and infrastructure
4. **Includes monitoring and alerting** via CloudWatch
5. **Provides automated backup solutions**
6. **Uses proper resource naming** with the AIT tag as prefix
7. **Includes comprehensive documentation** in comments
8. **Configures the target hostname** as specified above

## Expected Output
A single, complete Terraform configuration file (.tf) that can be applied directly to AWS infrastructure.

## Example Structure
- AWS provider configuration
- Security groups with proper rules
- EC2 instances or other relevant resources
- CloudWatch monitoring and alarms
- User data scripts for automated remediation
- Proper tagging and documentation
- Hostname configuration for the target system

Please generate the complete Terraform configuration now.`;

    return basePrompt;
  };

  const handleRunTerraform = async (vulnerability) => {
    try {
      setGeneratingTerraform(true);
      const prompt = generateTerraformPrompt(vulnerability);
      
      // Store the generated prompt for this vulnerability
      const newPrompts = {
        ...generatedPrompts,
        [vulnerability.id]: prompt
      };
      setGeneratedPrompts(newPrompts);
      // Save to localStorage for persistence
      localStorage.setItem('generatedPrompts', JSON.stringify(newPrompts));
      
      // Show success message
      alert('GitHub Copilot prompt generated successfully! Click "View Prompt" to see the prompt.');
    } catch (error) {
      console.error('Error generating prompt:', error);
      alert('Error generating prompt: ' + error.message);
    } finally {
      setGeneratingTerraform(false);
    }
  };

  const handleViewTerraformPrompt = (vulnerability) => {
    // Check if prompt has been generated for this vulnerability
    const prompt = generatedPrompts[vulnerability.id];
    if (prompt) {
      setCurrentVulnerability(vulnerability);
      setTerraformContent(prompt);
      setHostname(''); // Reset hostname for new vulnerability
      setShowTerraformModal(true);
    } else {
      alert('Please click "Run" first to create the GitHub Copilot prompt for this vulnerability.');
    }
  };

  const updatePromptWithHostname = (newHostname) => {
    if (currentVulnerability) {
      const updatedPrompt = generateTerraformPrompt(currentVulnerability, newHostname);
      setTerraformContent(updatedPrompt);
    }
  };

  const handleHostnameChange = (e) => {
    const newHostname = e.target.value;
    setHostname(newHostname);
    updatePromptWithHostname(newHostname);
  };

  const startAgent = async () => {
    try {
      await copilotAPI.startAgent();
      loadAgentStatus();
    } catch (error) {
      console.error('Error starting agent:', error);
    }
  };

  const stopAgent = async () => {
    try {
      await copilotAPI.stopAgent();
      loadAgentStatus();
    } catch (error) {
      console.error('Error stopping agent:', error);
    }
  };

  const processVscodeAgent = async (scanId) => {
    try {
      console.log('🔄 Processing VS Code agent for scan:', scanId);
      setProcessingScan(scanId);
      
      // First test the endpoint
      try {
        await vscodeAgentAPI.testEndpoint();
        console.log('✅ VS Code agent endpoint is working');
      } catch (error) {
        console.error('❌ VS Code agent endpoint test failed:', error);
        alert(`VS Code agent endpoint test failed: ${error.message}`);
        return;
      }
      
      const result = await vscodeAgentAPI.processAgent(scanId);
      console.log('✅ VS Code agent processing result:', result);
      
      // Reload projects to show updated status
      setRefreshTrigger(prev => prev + 1);
      
      // Load prompts for this scan
      await loadVscodePrompts(scanId);
      
    } catch (error) {
      console.error('❌ Error processing VS Code agent:', error);
      alert(`Error processing scan: ${error.message || 'Unknown error'}`);
    } finally {
      setProcessingScan(null);
    }
  };

  const loadVscodePrompts = async (scanId) => {
    try {
      console.log('📋 Loading VS Code prompts for scan:', scanId);
      const prompts = await vscodeAgentAPI.getPrompts(scanId);
      console.log('✅ VS Code prompts loaded:', prompts);
      setVscodePrompts(prev => ({ ...prev, [scanId]: prompts }));
      
      // Set the selected scan ID for the modal
      setSelectedScanId(scanId);
      
      // Show the prompts modal
      setShowVscodeModal(true);
      
    } catch (error) {
      console.error('❌ Error loading VS Code prompts:', error);
      alert(`Error loading prompts: ${error.message || 'Unknown error'}`);
    }
  };

  const showFileSelection = async (scanId) => {
    try {
      console.log('🔍 Getting available files for VS Code agent scan:', scanId);
      
      let availableFiles = [];
      
      // First try to get files from copilot task JSON
      try {
        const taskResponse = await copilotAPI.getTaskDetails(scanId);
        if (taskResponse.data && taskResponse.data.file_paths) {
          // Extract file information from copilot task
          availableFiles = Object.entries(taskResponse.data.file_paths).map(([filePath, fileInfo]) => ({
            file_name: fileInfo.file_name,
            file_path: fileInfo.file_path,
            source_file_path: fileInfo.source_file_path,
            status: 'completed', // Assume completed if in task
            scan_id: scanId
          }));
          console.log('📁 Files found in copilot task:', availableFiles);
        }
      } catch (error) {
        console.log('No copilot task found, trying VS Code prompts...');
      }
      
      // If no files found in copilot task, try VS Code prompts
      if (availableFiles.length === 0) {
        try {
          const promptsData = await vscodeAgentAPI.getPrompts(scanId);
          
          if (promptsData && promptsData.prompts) {
            // Extract file information from prompts
            availableFiles = promptsData.prompts.map(prompt => ({
              file_name: prompt.file_name,
              file_path: prompt.file_path,
              status: prompt.status,
              remediated_file: prompt.remediated_file,
              source_file_path: prompt.source_file_path,
              scan_id: scanId
            }));
            console.log('📁 Files found in VS Code prompts:', availableFiles);
          }
        } catch (error) {
          console.error('No prompts data found for scan:', scanId);
        }
      }
      
      if (availableFiles.length === 0) {
        console.error('No files found for scan:', scanId);
        alert('No files found for this scan');
        return;
      }
      
      console.log('📁 Available files for viewing:', availableFiles);
      setAvailableFiles(availableFiles);
      setSelectedFile(null);
      setFileContents(null);
      setShowFileModal(true);
      setSelectedScanId(scanId); // Set the selected scan ID
    } catch (error) {
      console.error('Error fetching available files:', error);
    }
  };

  const viewFile = async () => {
    if (!selectedFile) return;
    
    try {
      console.log('🔍 Viewing file:', selectedFile);
      console.log('📁 Available files:', availableFiles);
      
      // Get the selected file data
      const fileData = availableFiles[selectedFile];
      if (!fileData) {
        console.error('No file data found for selection:', selectedFile);
        return;
      }
      
      console.log('📄 File data:', fileData);
      
      // Get the diff data for this file
              const diffData = await vscodeAgentAPI.getDiff(fileData.scan_id || selectedScanId, fileData.file_name);
      console.log('📊 Diff data received:', diffData);
      
      setDiffData(diffData);
              setSelectedVscodeFile({ 
          scanId: fileData.scan_id || selectedScanId, 
          fileName: fileData.file_name 
        });
        setShowFileModal(false);
        setShowVscodeModal(true);
    } catch (error) {
      console.error('Error fetching file contents:', error);
    }
  };

  const viewVscodeDiff = async (scanId, fileName) => {
    try {
      const diff = await vscodeAgentAPI.getDiff(scanId, fileName);
      setDiffData(diff);
      setSelectedVscodeFile({ scanId, fileName });
      setShowVscodeModal(true);
    } catch (error) {
      console.error('Error fetching VS Code diff:', error);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed':
        return <span className="badge badge-success">Completed</span>;
      case 'pending':
        return <span className="badge badge-warning">Pending</span>;
      case 'processing':
        return <span className="badge badge-info">Processing</span>;
      case 'error':
        return <span className="badge badge-danger">Error</span>;
      default:
        return <span className="badge badge-secondary">Unknown</span>;
    }
  };

  const formatTimestamp = (timestamp) => {
    if (!timestamp || timestamp === 'unknown') return 'Unknown';
    try {
      return new Date(timestamp).toLocaleString();
    } catch (e) {
      return timestamp;
    }
  };

  const getFixStatistics = (fileContents) => {
    if (!fileContents || !fileContents.remediated_content) return null;
    
    const originalLines = fileContents.original_content.split('\n').length;
    const remediatedLines = fileContents.remediated_content.split('\n').length;
    const addedLines = remediatedLines - originalLines;
    
    return {
      originalLines,
      remediatedLines,
      addedLines,
      percentageChange: ((addedLines / originalLines) * 100).toFixed(1)
    };
  };

  const getDiffStatistics = (diffData) => {
    if (!diffData || !diffData.diff) return null;
    
    const { statistics } = diffData.diff;
    return {
      totalOriginalLines: statistics.total_original_lines,
      totalRemediatedLines: statistics.total_remediated_lines,
      addedCount: statistics.added_count,
      removedCount: statistics.removed_count,
      modifiedCount: statistics.modified_count,
      totalChanges: statistics.added_count + statistics.removed_count + statistics.modified_count
    };
  };

  const highlightRemediatedLines = (content, diffData) => {
    if (!content || !diffData || !diffData.diff) return content;
    
    const lines = content.split('\n');
    const { added_lines, modified_lines } = diffData.diff;
    
    return lines.map((line, index) => {
      const lineNumber = index + 1;
      const isAdded = added_lines.some(added => added.line_number === lineNumber);
      const isModified = modified_lines.some(modified => modified.line_number === lineNumber);
      
      let className = '';
      if (isAdded) className = 'line-added';
      else if (isModified) className = 'line-modified';
      
      return (
        <div key={index} className={`line ${className}`}>
          <span className="line-number">{lineNumber}</span>
          <span className="line-content">{line}</span>
        </div>
      );
    });
  };

  const refreshData = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  // Sorting functions
  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortedProjects = () => {
    if (!sortField) return projects;

    return [...projects].sort((a, b) => {
      let aValue, bValue;

      if (sortField === 'status') {
        aValue = a.status || '';
        bValue = b.status || '';
      } else if (sortField === 'timestamp') {
        aValue = new Date(a.timestamp || 0);
        bValue = new Date(b.timestamp || 0);
      } else {
        return 0;
      }

      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return <i className="fas fa-sort text-muted"></i>;
    return sortDirection === 'asc' ? 
      <i className="fas fa-sort-up text-primary"></i> : 
      <i className="fas fa-sort-down text-primary"></i>;
  };

  // Load task details for a specific scan
  const loadTaskDetails = async (scanId) => {
    try {
      console.log('📋 Loading task details for scan:', scanId);
      const response = await copilotAPI.getTaskDetails(scanId);
      console.log('✅ Task details loaded:', response);
      setTaskDetails(prev => ({ ...prev, [scanId]: response.data }));
      setShowTaskModal(true);
    } catch (error) {
      console.error('❌ Error loading task details:', error);
      alert(`Error loading task details: ${error.message || 'Unknown error'}`);
    }
  };

  // Load VS Code instructions for a scan
  const loadInstructions = async (scanId) => {
    try {
      console.log('📖 Loading VS Code instructions for scan:', scanId);
      const response = await vscodeCopilotAPI.getInstructions(scanId);
      console.log('✅ Instructions loaded:', response);
      setInstructions(prev => ({ ...prev, [scanId]: response }));
      setShowInstructionsModal(true);
    } catch (error) {
      console.error('❌ Error loading instructions:', error);
      alert(`Error loading instructions: ${error.message || 'Unknown error'}`);
    }
  };

  // Load VS Code workspace for a scan
  const loadWorkspace = async (scanId) => {
    try {
      console.log('🏗️ Loading VS Code workspace for scan:', scanId);
      const response = await vscodeCopilotAPI.getWorkspace(scanId);
      console.log('✅ Workspace loaded:', response);
      setWorkspaceData(prev => ({ ...prev, [scanId]: response }));
      setShowWorkspaceModal(true);
    } catch (error) {
      console.error('❌ Error loading workspace:', error);
      alert(`Error loading workspace: ${error.message || 'Unknown error'}`);
    }
  };

  // Download VS Code files for a scan
  const downloadVscodeFiles = async (scanId) => {
    try {
      console.log('📥 Downloading VS Code files for scan:', scanId);
      setDownloadProgress(prev => ({ ...prev, [scanId]: 'downloading' }));
      
      const result = await vscodeCopilotAPI.downloadFiles(scanId);
      console.log('✅ Download completed:', result);
      
      setDownloadProgress(prev => ({ ...prev, [scanId]: 'completed' }));
      setTimeout(() => {
        setDownloadProgress(prev => ({ ...prev, [scanId]: null }));
      }, 3000);
      
    } catch (error) {
      console.error('❌ Error downloading files:', error);
      setDownloadProgress(prev => ({ ...prev, [scanId]: 'error' }));
      alert(`Error downloading files: ${error.message || 'Unknown error'}`);
      
      setTimeout(() => {
        setDownloadProgress(prev => ({ ...prev, [scanId]: null }));
      }, 3000);
    }
  };

  // Process copilot task for a scan
  const processCopilotTask = async (scanId) => {
    try {
      console.log('🔄 Processing copilot task for scan:', scanId);
      setProcessingScan(scanId);
      
      const result = await copilotAPI.processTask(scanId);
      console.log('✅ Copilot task processing result:', result);
      
      // Reload projects to show updated status
      setRefreshTrigger(prev => prev + 1);
      
    } catch (error) {
      console.error('❌ Error processing copilot task:', error);
      alert(`Error processing copilot task: ${error.message || 'Unknown error'}`);
    } finally {
      setProcessingScan(null);
    }
  };

  // Load copilot prompts for a scan
  const loadCopilotPrompts = async (scanId) => {
    try {
      console.log('📋 Loading copilot prompts for scan:', scanId);
      
      // Get task details to extract prompts
      const taskResponse = await copilotAPI.getTaskDetails(scanId);
      console.log('✅ Task details loaded:', taskResponse);
      
      if (taskResponse.data && taskResponse.data.suggested_remediations) {
        const prompts = [];
        
        // Convert suggested remediations to prompts
        Object.entries(taskResponse.data.suggested_remediations).forEach(([filePath, remediations]) => {
          if (remediations && remediations.length > 0) {
            const fileInfo = taskResponse.data.file_paths?.[filePath] || {};
            
            // Create a comprehensive prompt for each file
            let promptText = `# Security Remediation Prompt for ${fileInfo.file_name || filePath}\n\n`;
            promptText += `## File Information\n`;
            promptText += `- File: ${fileInfo.file_name || filePath}\n`;
            promptText += `- Path: ${filePath}\n`;
            promptText += `- Issues Found: ${remediations.length}\n\n`;
            
            promptText += `## Security Issues to Fix\n\n`;
            
            remediations.forEach((remediation, index) => {
              promptText += `### Issue ${index + 1}: ${remediation.severity} - ${remediation.type}\n`;
              promptText += `- **Line**: ${remediation.line_number || 'Unknown'}\n`;
              promptText += `- **Message**: ${remediation.message}\n`;
              promptText += `- **Code Snippet**: \`\`\`\n${remediation.code_snippet}\n\`\`\`\n`;
              promptText += `- **Suggested Fix**: ${remediation.suggested_fix}\n`;
              promptText += `- **Threat Level**: ${remediation.threat_level}\n`;
              promptText += `- **Effort**: ${remediation.effort_minutes} minutes\n\n`;
            });
            
            promptText += `## Instructions\n`;
            promptText += `Please review the code and apply the suggested fixes to address the security vulnerabilities. `;
            promptText += `Focus on removing dangerous operations and implementing secure alternatives.\n\n`;
            promptText += `## Expected Output\n`;
            promptText += `Provide the remediated code with all security issues fixed. `;
            promptText += `Include comments explaining what was changed and why.\n`;
            
            prompts.push({
              file_name: fileInfo.file_name || Path(filePath).name,
              file_path: filePath,
              prompt_text: promptText,
              issues_count: remediations.length,
              severity: remediations.some(r => r.severity === 'CRITICAL_BOMB') ? 'CRITICAL' : 'HIGH'
            });
          }
        });
        
        setCopilotPrompts(prev => ({ ...prev, [scanId]: prompts }));
        setShowCopilotPromptsModal(true);
        
        console.log('✅ Copilot prompts loaded:', prompts);
      } else {
        alert('No remediation suggestions found for this scan');
      }
      
    } catch (error) {
      console.error('❌ Error loading copilot prompts:', error);
      alert(`Error loading copilot prompts: ${error.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="copilot-remediation">
      {/* Tab Navigation - Moved to Top */}
      <div className="tab-navigation mb-4">
        <ul className="nav nav-tabs">
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'projects' ? 'active' : ''}`}
              onClick={() => setActiveTab('projects')}
              style={{
                color: activeTab === 'projects' ? '#0d6efd' : '#888',
                background: activeTab === 'projects' ? '#f8f9fa' : 'transparent',
                border: 'none',
                borderBottom: activeTab === 'projects' ? '3px solid #0d6efd' : '3px solid transparent',
                padding: '10px 20px',
                cursor: 'pointer'
              }}
            >
              <i className="fas fa-list"></i> Issue Remediation 
            </button>
          </li>
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'vulnerabilities' ? 'active' : ''}`}
              onClick={() => setActiveTab('vulnerabilities')}
              style={{
                color: activeTab === 'vulnerabilities' ? '#0d6efd' : '#888',
                background: activeTab === 'vulnerabilities' ? '#f8f9fa' : 'transparent',
                border: 'none',
                borderBottom: activeTab === 'vulnerabilities' ? '3px solid #0d6efd' : '3px solid transparent',
                padding: '10px 20px',
                cursor: 'pointer'
              }}
            >
              <i className="fas fa-shield-alt"></i> Vulnerabilities Remediation
            </button>
          </li>
        </ul>
      </div>

      {/* Dynamic Header Content */}
      {activeTab === 'projects' && (
        <div className="header">
          <div className="header-content">
            {/* <h2><i className="fas fa-list"></i> Issue Remediation</h2>
            <p>Automated security issue remediation using Threat Copilot extension. Process uploaded projects and generate remediation prompts for security issues.</p> */}
          </div>
          
          <div className="info-cards">
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">📁</span>
                <i className="fas fa-folder-open"></i>
              </div>
              <div className="info-card-content">
                <h6>Total Projects</h6>
                <p>{projects.length}</p>
              </div>
            </div>
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">🤖</span>
                <i className="fas fa-robot"></i>
              </div>
              <div className="info-card-content">
                <h6>Agent Status</h6>
                <p>{agentStatus.status || 'Unknown'}</p>
              </div>
            </div>
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">🔗</span>
                <i className="fas fa-code-branch"></i>
              </div>
              <div className="info-card-content">
                <h6>Integration Type</h6>
                <p>Threat Extension</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'vulnerabilities' && (
        <div className="header">
          <div className="header-content">
            {/* <h2><i className="fas fa-shield-alt"></i> Vulnerability Remediation</h2> */}
            {/* <p>Automated vulnerability remediation using Threat Copilot. Generate Terraform prompts and remediation strategies for identified security vulnerabilities.</p> */}
          </div>
          
          <div className="info-cards">
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">🛡️</span>
                <i className="fas fa-shield-alt"></i>
              </div>
              <div className="info-card-content">
                <h6>Total Vulnerabilities</h6>
                <p>{vulnerabilities.length}</p>
              </div>
            </div>
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">🔧</span>
                <i className="fas fa-tools"></i>
              </div>
              <div className="info-card-content">
                <h6>Remediation Type</h6>
                <p>Terraform</p>
              </div>
            </div>
            <div className="info-card">
              <div className="info-card-icon">
                <span className="emoji-icon">⚡</span>
                <i className="fas fa-bolt"></i>
              </div>
              <div className="info-card-content">
                <h6>Automation</h6>
                <p>AI-Powered</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Agent Status Panel */}
      <div className="agent-status-panel">
        <div className="agent-status-header">
          <h5><i className="fas fa-robot"></i> Threat Copilot Agent</h5>
          <div className="agent-controls">
            <button 
              className="btn btn-success btn-sm" 
              onClick={startAgent}
              disabled={agentStatus.status === 'running'}
            >
              <i className="fas fa-play"></i> Start Agent
            </button>
            <button 
              className="btn btn-danger btn-sm" 
              onClick={stopAgent}
              disabled={agentStatus.status !== 'running'}
            >
              <i className="fas fa-stop"></i> Stop Agent
            </button>
          </div>
        </div>
        <div className="agent-stats">
          <div className="stat-item">
            <span className="stat-label">Status:</span>
            <span className="stat-value">{agentStatus.status || 'Unknown'}</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Type:</span>
            <span className="stat-value">Extension</span>
          </div>
          <div className="stat-item">
            <span className="stat-label">Last Check:</span>
            <span className="stat-value">{agentStatus.timestamp || 'Never'}</span>
          </div>
        </div>
      </div>

      {/* Projects Table */}
      {activeTab === 'projects' && (
        <div className="projects-section">
          <div className="section-header">
            <h5><i className="fas fa-list"></i> Issue Remediation </h5>
            <div className="section-actions">
              <button className="btn btn-outline-primary btn-sm" onClick={refreshData}>
                <i className="fas fa-sync-alt"></i> Refresh
              </button>
            </div>
          </div>
        
        {loading ? (
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Loading projects...</p>
          </div>
        ) : projects.length === 0 ? (
          <div className="no-projects">
            <div className="no-projects-icon">
              <i className="fas fa-folder-open"></i>
            </div>
            <h4>No Projects Found</h4>
            <p>Upload files to get started with Threat Copilot remediation.</p>
            <button className="btn btn-primary" onClick={refreshData}>
              <i className="fas fa-sync-alt"></i> Refresh
            </button>
          </div>
        ) : (
          <div className="projects-table">
            <div className="table-responsive">
              <table className="table">
                <thead>
                  <tr>
                    <th>Project</th>
                    <th>Folders/Files</th>
                    <th>Issues</th>
                    <th 
                      className="sortable-header" 
                      onClick={() => handleSort('status')}
                      style={{ cursor: 'pointer' }}
                    >
                      Status {getSortIcon('status')}
                    </th>
                    <th 
                      className="sortable-header" 
                      onClick={() => handleSort('timestamp')}
                      style={{ cursor: 'pointer' }}
                    >
                      Timestamp {getSortIcon('timestamp')}
                    </th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {getSortedProjects().map((project) => (
                    <tr key={project.scan_id}>
                      <td>
                        <div className="project-info">
                          <div className="project-name">{project.project_name}</div>
                          <div className="project-id">ID: {project.scan_id}</div>
                        </div>
                      </td>
                      <td>
                        <div className="file-count">
                          <span className="file-count-number">{project.file_count}</span>
                          <span className="file-count-label">Folders/Files</span>
                        </div>
                      </td>
                      <td>
                        <div className="issues-info">
                          <div className="total-issues">
                            <span className="issues-number">{project.total_issues}</span>
                            <span className="issues-label">total</span>
                          </div>
                          {project.critical_issues > 0 && (
                            <div className="critical-issues">
                              <span className="critical-number">{project.critical_issues}</span>
                              <span className="critical-label">critical</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td>{getStatusBadge(project.status)}</td>
                      <td>
                        <div className="timestamp">
                          {formatTimestamp(project.timestamp)}
                        </div>
                      </td>
                      <td>
                        <div className="action-buttons d-flex flex-column gap-1">
                          {/* Process Threat Agent Button */}
                          {project.status !== 'completed' && (
                            <button 
                              className="btn btn-primary btn-sm w-100 mb-1"
                              onClick={() => {
                                console.log('🔄 Process VS Code Agent button clicked for scan:', project.scan_id);
                                processVscodeAgent(project.scan_id);
                              }}
                              disabled={processingScan === project.scan_id}
                              title="Process with VS Code Agent"
                            >
                              {processingScan === project.scan_id ? (
                                <>
                                  <i className="fas fa-spinner fa-spin"></i> Processing...
                                </>
                              ) : (
                                <>
                                  <i className="fas fa-play"></i> Threat Agent
                                </>
                              )}
                            </button>
                          )}
                          
                          {/* View Copilot Prompts Button */}
                          <button 
                            className="btn btn-outline-secondary btn-sm w-100 mb-1"
                            onClick={() => {
                              console.log('📋 View Copilot Prompts button clicked for scan:', project.scan_id);
                              loadCopilotPrompts(project.scan_id);
                            }}
                            title="View Copilot Prompts"
                          >
                            <i className="fas fa-file-code"></i> View Prompts
                          </button>
                          
                          {/* Task Details Button */}
                          <button 
                            className="btn btn-outline-info btn-sm w-100 mb-1"
                            onClick={() => {
                              console.log('📋 Task Details button clicked for scan:', project.scan_id);
                              loadTaskDetails(project.scan_id);
                            }}
                            title="View Task Details"
                          >
                            <i className="fas fa-info-circle"></i> Details
                          </button>
                          
                          {/* Download Threat Files Button */}
                          <button 
                            className="btn btn-outline-warning btn-sm w-100 mb-1"
                            onClick={() => {
                              console.log('📥 Download button clicked for scan:', project.scan_id);
                              downloadVscodeFiles(project.scan_id);
                            }}
                            disabled={downloadProgress[project.scan_id]}
                            title="Download Threat Files"
                          >
                            {downloadProgress[project.scan_id] === 'downloading' ? (
                              <>
                                <i className="fas fa-spinner fa-spin"></i> Downloading...
                              </>
                            ) : downloadProgress[project.scan_id] === 'completed' ? (
                              <>
                                <i className="fas fa-check"></i> Downloaded
                              </>
                            ) : downloadProgress[project.scan_id] === 'error' ? (
                              <>
                                <i className="fas fa-exclamation-triangle"></i> Error
                              </>
                            ) : (
                              <>
                                <i className="fas fa-download"></i> Download
                              </>
                            )}
                          </button>
                          
                          {/* Prompts Button - Show for projects with VS Code prompts */}
                          {project.has_vscode_prompts && (
                            <button 
                              className="btn btn-info btn-sm w-100"
                              onClick={() => {
                                console.log('📋 Prompts button clicked for scan:', project.scan_id);
                                loadVscodePrompts(project.scan_id);
                              }}
                              title="View Threat Prompts"
                            >
                               <i className="fas fa-eye"></i> View Remediated
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
      )}

      {/* Vulnerabilities Table */}
      {activeTab === 'vulnerabilities' && (
        <div className="vulnerabilities-section">
          <div className="section-header">
            <h5><i className="fas fa-shield-alt"></i> Vulnerability Remediation</h5>
            <div className="section-actions">
              {/* Excel Data Indicator */}
              {localStorage.getItem('excel_vulnerabilities') && (() => {
                try {
                  const excelData = JSON.parse(localStorage.getItem('excel_vulnerabilities'));
                  return (
                    <span className="badge bg-info me-2" title={`${excelData.length} Excel records loaded and merged`}>
                      📁 {excelData.length} Excel Records
                    </span>
                  );
                } catch (error) {
                  return (
                    <span className="badge bg-info me-2" title="Excel data is loaded and merged">
                      📁 Excel Data Loaded
                    </span>
                  );
                }
              })()}
              <button className="btn btn-outline-primary btn-sm" onClick={loadVulnerabilities}>
                <i className="fas fa-sync-alt"></i> Refresh
              </button>
            </div>
          </div>
          
          {vulnerabilitiesLoading ? (
            <div className="loading-spinner">
              <div className="spinner"></div>
              <p>Loading vulnerabilities...</p>
            </div>
          ) : vulnerabilities.length === 0 ? (
            <div className="no-projects">
              <div className="no-projects-icon">
                <i className="fas fa-shield-alt"></i>
              </div>
              <h4>No Vulnerabilities Found</h4>
              <p>No vulnerabilities are currently available for remediation.</p>
              <button className="btn btn-primary" onClick={loadVulnerabilities}>
                <i className="fas fa-sync-alt"></i> Refresh
              </button>
            </div>
          ) : (
            <div className="projects-table">
              <div className="table-responsive">
                <table className="table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>AIT</th>
                      <th>Vulnerability</th>
                      <th>Severity</th>
                      <th>Remediation Action</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vulnerabilities.map((vulnerability) => (
                      <tr key={vulnerability.id}>
                        <td>
                          <div className="project-info">
                            <div className="project-id">{vulnerability.id?.substring(0, 8)}...</div>
                          </div>
                        </td>
                        <td>
                          <span className="badge bg-info">
                            {vulnerability.ait_tag || 'AIT-Unknown'}
                          </span>
                        </td>
                        <td>
                          <div className="project-info">
                            <div className="project-name">{vulnerability.title || vulnerability.description}</div>
                          </div>
                        </td>
                        <td>
                          <span className={`badge ${
                            vulnerability.severity === 'CRITICAL_BOMB' ? 'bg-danger' :
                            vulnerability.severity === 'HIGH_RISK' ? 'bg-warning' :
                            vulnerability.severity === 'MEDIUM_RISK' ? 'bg-info' :
                            vulnerability.severity === 'LOW_RISK' ? 'bg-success' : 'bg-secondary'
                          }`}>
                            {vulnerability.severity === 'CRITICAL_BOMB' ? 'Critical' :
                             vulnerability.severity === 'HIGH_RISK' ? 'High' :
                             vulnerability.severity === 'MEDIUM_RISK' ? 'Medium' :
                             vulnerability.severity === 'LOW_RISK' ? 'Low' : 'Unknown'}
                          </span>
                        </td>
                        <td>
                          <div className="project-info">
                            <div className="project-name">{vulnerability.remediation_action || 'Update to latest version'}</div>
                          </div>
                        </td>
                        <td>
                          <div className="action-buttons d-flex flex-column gap-1">
                            {/* Run Terraform Generation Button */}
                            <button 
                              className="btn btn-secondary btn-sm w-100 mb-1"
                              onClick={() => {
                                console.log('🔄 Generate Terraform prompt for vulnerability:', vulnerability.id);
                                handleRunTerraform(vulnerability);
                              }}
                              disabled={generatingTerraform}
                              title="Generate Threat Copilot Terraform Prompt"
                            >
                              {generatingTerraform ? (
                                <>
                                  <i className="fas fa-spinner fa-spin"></i> Generating...
                                </>
                              ) : (
                                <>
                                  <i className="fas fa-robot"></i> Run
                                </>
                              )}
                            </button>
                            
                            {/* View Terraform Prompt Button */}
                            <button 
                              className="btn btn-outline-secondary btn-sm w-100"
                              onClick={() => {
                                console.log('📋 View Terraform prompt for vulnerability:', vulnerability.id);
                                handleViewTerraformPrompt(vulnerability);
                              }}
                              disabled={!generatedPrompts[vulnerability.id]}
                              title={!generatedPrompts[vulnerability.id] ? 'Click "Run" first to create Threat Copilot prompt' : 'View Threat Copilot prompt'}
                            >
                              <i className="fas fa-file-code"></i> View Prompt
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* File Selection Modal */}
      {showFileModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-file"></i> Select File to View
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowFileModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <div className="file-selection">
                  <label>Choose a file to view:</label>
                  <select 
                    className="form-control"
                    onChange={(e) => setSelectedFile(availableFiles[e.target.value])}
                  >
                    <option value="">Select a file...</option>
                    {availableFiles.map((file, index) => (
                      <option key={index} value={index}>
                        {file.file_name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowFileModal(false)}
                >
                  Cancel
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary" 
                  onClick={viewFile}
                  disabled={!selectedFile}
                >
                  <i className="fas fa-eye"></i> View File
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* File Contents Modal */}
      {fileContents && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-file-code"></i> File Comparison
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setFileContents(null)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <div className="file-comparison">
                  <div className="file-section">
                    <h6><i className="fas fa-file"></i> Original File</h6>
                    <div className="file-content original">
                      <pre>{fileContents.original_content}</pre>
                    </div>
                  </div>
                  <div className="file-section">
                    <h6><i className="fas fa-file-code"></i> Remediated File</h6>
                    <div className="file-content remediated">
                      <pre>{fileContents.remediated_content}</pre>
                    </div>
                  </div>
                </div>
                
                {getFixStatistics(fileContents) && (
                  <div className="fix-statistics">
                    <h6><i className="fas fa-chart-bar"></i> Fix Statistics</h6>
                    <div className="stats-grid">
                      <div className="stat-item">
                        <span className="stat-label">Original Lines:</span>
                        <span className="stat-value">{getFixStatistics(fileContents).originalLines}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Remediated Lines:</span>
                        <span className="stat-value">{getFixStatistics(fileContents).remediatedLines}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Added Lines:</span>
                        <span className="stat-value">{getFixStatistics(fileContents).addedLines}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Change %:</span>
                        <span className="stat-value">{getFixStatistics(fileContents).percentageChange}%</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setFileContents(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VS Code Prompts Modal */}
      {showVscodeModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-file-code"></i> Threat Copilot Prompts
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => {
                    setShowVscodeModal(false);
                    setSelectedScanId(null);
                  }}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {selectedScanId && vscodePrompts[selectedScanId] && (
                  <div className="prompts-section">
                    <h6><i className="fas fa-folder"></i> Scan ID: {selectedScanId}</h6>
                    <div className="prompts-list">
                      {vscodePrompts[selectedScanId].prompts && vscodePrompts[selectedScanId].prompts.map((prompt, index) => (
                        <div key={index} className="prompt-item">
                          <div className="prompt-header">
                            <strong><i className="fas fa-file"></i> {prompt.file_name}</strong>
                            <span className={`badge badge-${prompt.status === 'completed' ? 'success' : 'warning'}`}>
                              {prompt.status}
                            </span>
                          </div>
                          <div className="prompt-content">
                            <p><strong>Security Issues Found:</strong> {prompt.security_issues.length}</p>
                            {prompt.security_issues.map((issue, idx) => (
                              <div key={idx} className="security-issue">
                                <span className="issue-severity">{issue.severity}</span>
                                <span className="issue-description">{issue.description}</span>
                                <span className="issue-line">Line {issue.line}</span>
                              </div>
                            ))}
                            <div className="prompt-actions">
                              <button 
                                className="btn btn-info btn-sm"
                                onClick={() => viewVscodeDiff(selectedScanId, prompt.file_name)}
                              >
                                <i className="fas fa-eye"></i> View Diff
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {(!selectedScanId || !vscodePrompts[selectedScanId]) && (
                  <div className="no-prompts">
                    <p>No prompts found for this scan.</p>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => {
                    setShowVscodeModal(false);
                    setSelectedScanId(null);
                  }}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VS Code Diff Modal */}
      {diffData && (
        <div className="copilotModel modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-code-branch"></i> Threat Diff: {selectedVscodeFile?.fileName}
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setDiffData(null)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <div className="github-diff-container">
                  <div className="diff-header">
                    <div className="diff-file-info">
                      <span className="file-name">{selectedVscodeFile?.fileName}</span>
                      <span className="diff-stats">
                        {getDiffStatistics(diffData) && (
                          <>
                            <span className="stat-added">+{getDiffStatistics(diffData).addedCount}</span>
                            <span className="stat-removed">-{getDiffStatistics(diffData).removedCount}</span>
                          </>
                        )}
                      </span>
                    </div>
                  </div>
                  
                  <div className="diff-content">
                    <div className="diff-pane original-pane">
                      <div className="pane-header">
                        <span className="pane-title">Original</span>
                      </div>
                      <div className="pane-content">
                        <div className="line-numbers">
                          {diffData.original_content.split('\n').map((line, index) => (
                            <div key={index} className="line-number">{index + 1}</div>
                          ))}
                        </div>
                        <div className="code-content">
                          {diffData.original_content.split('\n').map((line, index) => {
                            const lineNumber = index + 1;
                            const isRemoved = diffData.diff?.removed_lines?.some(removed => removed.line_number === lineNumber);
                            const isModified = diffData.diff?.modified_lines?.some(modified => modified.line_number === lineNumber);
                            
                            let className = 'line';
                            if (isRemoved) className += ' line-removed';
                            else if (isModified) className += ' line-modified';
                            
                            return (
                              <div key={index} className={className}>
                                <span className="line-text">{line || ' '}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                    
                    <div className="diff-pane modified-pane">
                      <div className="pane-header">
                        <span className="pane-title">Modified</span>
                      </div>
                      <div className="pane-content">
                        <div className="line-numbers">
                          {diffData.remediated_content.split('\n').map((line, index) => (
                            <div key={index} className="line-number">{index + 1}</div>
                          ))}
                        </div>
                        <div className="code-content">
                          {diffData.remediated_content.split('\n').map((line, index) => {
                            const lineNumber = index + 1;
                            const isAdded = diffData.diff?.added_lines?.some(added => added.line_number === lineNumber);
                            const isModified = diffData.diff?.modified_lines?.some(modified => modified.line_number === lineNumber);
                            
                            let className = 'line';
                            if (isAdded) className += ' line-added';
                            else if (isModified) className += ' line-modified';
                            
                            return (
                              <div key={index} className={className}>
                                <span className="line-text">{line || ' '}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {getDiffStatistics(diffData) && (
                  <div className="diff-statistics">
                    <h6><i className="fas fa-chart-bar"></i> Diff Statistics</h6>
                    <div className="stats-grid">
                      <div className="stat-item">
                        <span className="stat-label">Total Changes:</span>
                        <span className="stat-value">{getDiffStatistics(diffData).totalChanges}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Added Lines:</span>
                        <span className="stat-value">{getDiffStatistics(diffData).addedCount}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Removed Lines:</span>
                        <span className="stat-value">{getDiffStatistics(diffData).removedCount}</span>
                      </div>
                      <div className="stat-item">
                        <span className="stat-label">Modified Lines:</span>
                        <span className="stat-value">{getDiffStatistics(diffData).modifiedCount}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setDiffData(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Task Details Modal */}
      {showTaskModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-info-circle"></i> Copilot Task Details
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowTaskModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {Object.entries(taskDetails).map(([scanId, taskData]) => (
                  <div key={scanId} className="task-details">
                    <h6><i className="fas fa-folder"></i> Scan ID: {scanId}</h6>
                    <div className="task-summary">
                      <div className="summary-item">
                        <strong>Status:</strong> {taskData.status || 'Unknown'}
                      </div>
                      <div className="summary-item">
                        <strong>Project ID:</strong> {taskData.project_id || 'N/A'}
                      </div>
                      <div className="summary-item">
                        <strong>Timestamp:</strong> {formatTimestamp(taskData.timestamp)}
                      </div>
                      <div className="summary-item">
                        <strong>Total Issues:</strong> {taskData.issues_summary?.total_issues || 0}
                      </div>
                      <div className="summary-item">
                        <strong>Critical Issues:</strong> {taskData.issues_summary?.critical_issues || 0}
                      </div>
                    </div>
                    
                    {taskData.threat_intelligence && (
                      <div className="threat-intelligence">
                        <h6><i className="fas fa-shield-alt"></i> Threat Intelligence</h6>
                        <div className="threat-summary">
                          <div className="threat-item">
                            <strong>Threat Level:</strong> {taskData.threat_intelligence.threat_level}
                          </div>
                          <div className="threat-item">
                            <strong>Total Threats:</strong> {taskData.threat_intelligence.total_threats}
                          </div>
                          <div className="threat-item">
                            <strong>Critical Bombs:</strong> {taskData.threat_intelligence.critical_bombs}
                          </div>
                        </div>
                        {taskData.threat_intelligence.recommendations && (
                          <div className="recommendations">
                            <h6>Recommendations:</h6>
                            <ul>
                              {taskData.threat_intelligence.recommendations.map((rec, idx) => (
                                <li key={idx}>{rec}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {taskData.file_results && (
                      <div className="file-results">
                        <h6><i className="fas fa-file"></i> File Results</h6>
                        <div className="file-list">
                          {taskData.file_results.map((file, idx) => (
                            <div key={idx} className="file-item">
                              <div className="file-header">
                                <strong>{file.file_name}</strong>
                                <span className={`badge badge-${file.threat_level === 'CRITICAL' ? 'danger' : 'warning'}`}>
                                  {file.threat_level}
                                </span>
                              </div>
                              <div className="file-stats">
                                <span>Issues: {file.issues_count}</span>
                                <span>Lines: {file.lines_scanned}</span>
                                <span>Critical: {file.critical_threats}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowTaskModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VS Code Instructions Modal */}
      {showInstructionsModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-book"></i> Threat Instructions
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowInstructionsModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {Object.entries(instructions).map(([scanId, instructionData]) => (
                  <div key={scanId} className="instructions-section">
                    <h6><i className="fas fa-folder"></i> Scan ID: {scanId}</h6>
                    <div className="instructions-content">
                      <div className="instruction-item">
                        <h6><i className="fas fa-tools"></i> Setup Instructions</h6>
                        <pre className="instruction-code">{instructionData.setup_instructions || 'No setup instructions available'}</pre>
                      </div>
                      <div className="instruction-item">
                        <h6><i className="fas fa-cog"></i> Configuration</h6>
                        <pre className="instruction-code">{instructionData.configuration || 'No configuration available'}</pre>
                      </div>
                      <div className="instruction-item">
                        <h6><i className="fas fa-play"></i> Usage Instructions</h6>
                        <pre className="instruction-code">{instructionData.usage_instructions || 'No usage instructions available'}</pre>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowInstructionsModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VS Code Workspace Modal */}
      {showWorkspaceModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-folder-open"></i> Threat Workspace
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowWorkspaceModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {Object.entries(workspaceData).map(([scanId, workspaceInfo]) => (
                  <div key={scanId} className="workspace-section">
                    <h6><i className="fas fa-folder"></i> Scan ID: {scanId}</h6>
                    <div className="workspace-content">
                      <div className="workspace-item">
                        <h6><i className="fas fa-file-code"></i> Workspace Configuration</h6>
                        <pre className="workspace-code">{JSON.stringify(workspaceInfo.workspace_config || {}, null, 2)}</pre>
                      </div>
                      <div className="workspace-item">
                        <h6><i className="fas fa-cog"></i> Settings</h6>
                        <pre className="workspace-code">{JSON.stringify(workspaceInfo.settings || {}, null, 2)}</pre>
                      </div>
                      <div className="workspace-item">
                        <h6><i className="fas fa-list"></i> Extensions</h6>
                        <pre className="workspace-code">{JSON.stringify(workspaceInfo.extensions || [], null, 2)}</pre>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowWorkspaceModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Copilot Prompts Modal */}
      {showCopilotPromptsModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-file-code"></i> Copilot Prompts
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowCopilotPromptsModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                {Object.entries(copilotPrompts).map(([scanId, prompts]) => (
                  <div key={scanId} className="copilot-prompts-section">
                    <h6><i className="fas fa-folder"></i> Scan ID: {scanId}</h6>
                    <div className="prompts-list">
                      {prompts.map((prompt, index) => (
                        <div key={index} className="prompt-item">
                          <div className="prompt-header">
                            <strong><i className="fas fa-file"></i> {prompt.file_name}</strong>
                            <span className={`badge badge-${prompt.severity === 'CRITICAL' ? 'danger' : 'warning'}`}>
                              {prompt.severity}
                            </span>
                            <span className="badge badge-info">{prompt.issues_count} issues</span>
                          </div>
                          <div className="prompt-content">
                            <div className="prompt-actions">
                              <button 
                                className="btn btn-primary btn-sm"
                                onClick={() => {
                                  navigator.clipboard.writeText(prompt.prompt_text);
                                  alert('Prompt copied to clipboard!');
                                }}
                                title="Copy Prompt to Clipboard"
                              >
                                <i className="fas fa-copy"></i> Copy Prompt
                              </button>
                              <button 
                                className="btn btn-outline-info btn-sm"
                                onClick={() => {
                                  const textArea = document.createElement('textarea');
                                  textArea.value = prompt.prompt_text;
                                  document.body.appendChild(textArea);
                                  textArea.select();
                                  document.execCommand('copy');
                                  document.body.removeChild(textArea);
                                  alert('Prompt copied to clipboard!');
                                }}
                                title="Copy Prompt (Fallback)"
                              >
                                <i className="fas fa-clipboard"></i> Copy (Fallback)
                              </button>
                            </div>
                            <div className="prompt-text-container">
                              <h6><i className="fas fa-code"></i> Prompt Text:</h6>
                              <pre className="prompt-text">{prompt.prompt_text}</pre>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowCopilotPromptsModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Terraform Prompt Modal */}
      {showTerraformModal && (
        <div className="modal fade show" style={{ display: 'block' }} tabIndex="-1">
          <div className="modal-dialog modal-xl">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-file-code"></i> Threat Copilot Terraform Prompt
                </h5>
                <button 
                  type="button" 
                  className="close" 
                  onClick={() => setShowTerraformModal(false)}
                >
                  <span>&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <div className="terraform-prompt-section">
                  {/* Hostname Input Section */}
                  <div className="hostname-input-section mb-3">
                    <div className="row">
                      <div className="col-md-6">
                        <label htmlFor="hostnameInput" className="form-label">
                          <i className="fas fa-server"></i> Target Hostname:
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="hostnameInput"
                          placeholder="Enter target hostname (e.g., web-server-01, api-gateway-prod)"
                          value={hostname}
                          onChange={handleHostnameChange}
                        />
                        <div className="form-text">
                          Enter the hostname that will be used in the Terraform configuration. 
                          This will replace the placeholder in the prompt.
                        </div>
                      </div>
                      <div className="col-md-6 d-flex align-items-end">
                        <div className="alert alert-info mb-0">
                          <i className="fas fa-info-circle"></i>
                          <strong>Tip:</strong> The hostname will be automatically updated in the prompt below as you type.
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="prompt-actions mb-3">
                    <button 
                      className="btn btn-primary btn-sm"
                      onClick={() => {
                        navigator.clipboard.writeText(terraformContent);
                        alert('Terraform prompt copied to clipboard!');
                      }}
                      title="Copy Prompt to Clipboard"
                    >
                      <i className="fas fa-copy"></i> Copy Prompt
                    </button>
                    <button 
                      className="btn btn-outline-info btn-sm"
                      onClick={() => {
                        const textArea = document.createElement('textarea');
                        textArea.value = terraformContent;
                        document.body.appendChild(textArea);
                        textArea.select();
                        document.execCommand('copy');
                        document.body.removeChild(textArea);
                        alert('Terraform prompt copied to clipboard!');
                      }}
                      title="Copy Prompt (Fallback)"
                    >
                      <i className="fas fa-clipboard"></i> Copy (Fallback)
                    </button>
                  </div>
                  <div className="prompt-text-container">
                    <h6><i className="fas fa-code"></i> Terraform Prompt:</h6>
                    <pre className="prompt-text" style={{ 
                      backgroundColor: '#f8f9fa', 
                      padding: '1rem', 
                      borderRadius: '4px',
                      fontSize: '0.9rem',
                      whiteSpace: 'pre-wrap',
                      wordWrap: 'break-word'
                    }}>
                      {terraformContent}
                    </pre>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowTerraformModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CopilotRemediation;