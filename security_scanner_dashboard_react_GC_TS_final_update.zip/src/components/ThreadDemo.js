// components/ThreadDemo.js
import React, { useState } from "react";
import API from "../api";
import JSZip from "jszip";
import { Toast } from "bootstrap";
import { 
  aitData, 
  spkData, 
  repoData, 
  getAITName, 
  getSPKName, 
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
} from '../config/dropdownData';

export default function ThreadDemo() {
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');



  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
  };

  const handleFileDrop = async (e) => {
    e.preventDefault();
    setDragOver(false);
    const items = e.dataTransfer.items;
    const files = await extractFilesFromItems(items);
    handleUpload(files);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    handleUpload(files);
  };

  const extractFilesFromItems = async (items) => {
    const traverseFileTree = (item, path = "") => {
      return new Promise((resolve) => {
        if (item.isFile) {
          item.file((file) => {
            file.fullPath = path + file.name;
            resolve([file]);
          });
        } else if (item.isDirectory) {
          const dirReader = item.createReader();
          dirReader.readEntries(async (entries) => {
            const results = await Promise.all(
              entries.map((entry) =>
                traverseFileTree(entry, path + item.name + "/")
              )
            );
            resolve(results.flat());
          });
        }
      });
    };

    const results = await Promise.all(
      Array.from(items).map((item) => traverseFileTree(item))
    );
    return results.flat();
  };

  const handleUpload = async (files) => {
    if (!files.length) return;
    if (!selectedAIT || !selectedSPK || !selectedRepo) {
      alert('Please select AIT, SPK, and Repository before uploading files.');
      return;
    }

    const fileContents = [];
    for (const file of files) {
      try {
        if (file.name.endsWith('.zip')) {
          const zip = new JSZip();
          const zipContent = await zip.loadAsync(file);
          for (const [filename, zipFile] of Object.entries(zipContent.files)) {
            if (!zipFile.dir) {
              const content = await zipFile.async('string');
              fileContents.push({
                id: generateId(),
                name: filename,
                type: getFileLanguage(filename),
                content: content,
              });
            }
          }
        } else {
          const content = await readFileContent(file);
          fileContents.push({
            id: generateId(),
            name: file.name,
            type: getFileLanguage(file.name),
            content: content,
          });
        }
      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
      }
    }

    const payload = {
      scan_id: generateId(),
      scan_type: "manual",
      project_id: `thread-demo-${Date.now()}`,
      project_name: "Thread Demo Scan",
      timestamp: new Date().toISOString(),
      file_contents: fileContents,
      ait_tag: selectedAIT,
      spk_tag: selectedSPK,
      repo_name: selectedRepo
    };

    try {
      setUploading(true);
      await API.post("/api/scan/files", payload);
      alert("✅ File scanned successfully");
    } catch (err) {
      console.error(err);
      alert("❌ Scan failed");
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => "id_" + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const map = {
      py: "python",
      js: "javascript",
      ts: "typescript",
      java: "java",
      html: "html",
      css: "css",
      json: "json",
      xml: "xml",
      sql: "sql",
      cpp: "cpp",
      cs: "csharp",
      rb: "ruby",
      php: "php",
      zip: "zip",
    };
    return map[ext] || "unknown";
  };

  const availableSPKs = getAvailableSPKs(selectedAIT);
  const availableRepos = getAvailableRepos(selectedSPK);

  return (
    <div className="container-fluid mt-4 px-5">
      <h2 className="mb-4">Thread Demo: Drag & Drop Scan</h2>
      
      {/* Project Selection Dropdowns */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="mb-0">Project Configuration</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4">
              <label className="form-label">AIT (Application Integration Team)</label>
              <select 
                className="form-select" 
                value={selectedAIT} 
                onChange={(e) => handleAITChange(e.target.value)}
              >
                <option value="">Select AIT</option>
                {Object.keys(aitData).map(ait => (
                  <option key={ait} value={ait}>{getAITName(ait)}</option>
                ))}
              </select>
            </div>
            
            <div className="col-md-4">
              <label className="form-label">SPK (Security Product Key)</label>
              <select 
                className="form-select" 
                value={selectedSPK} 
                onChange={(e) => handleSPKChange(e.target.value)}
                disabled={!selectedAIT}
                style={{ opacity: selectedAIT ? 1 : 0.6 }}
              >
                <option value="">Select SPK</option>
                {availableSPKs.map(spk => (
                  <option key={spk} value={spk}>{getSPKName(spk)}</option>
                ))}
              </select>
            </div>
            
            <div className="col-md-4">
              <label className="form-label">Repository</label>
              <select 
                className="form-select" 
                value={selectedRepo} 
                onChange={(e) => handleRepoChange(e.target.value)}
                disabled={!selectedSPK}
                style={{ opacity: selectedSPK ? 1 : 0.6 }}
              >
                <option value="">Select Repository</option>
                {availableRepos.map(repo => (
                  <option key={repo} value={repo}>{getRepoName(repo)}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Selected Project Summary */}
          {selectedAIT && selectedSPK && selectedRepo && (
            <div className="alert alert-info mt-3">
              <strong>Selected Project:</strong><br />
              <strong>AIT:</strong> {getAITName(selectedAIT)}<br />
              <strong>SPK:</strong> {getSPKName(selectedSPK)}<br />
              <strong>Repository:</strong> {getRepoName(selectedRepo)}
            </div>
          )}
        </div>
      </div>

      {/* File Upload Area */}
      <div
        className={`card p-5 border border-primary ${dragOver ? "bg-info bg-opacity-25" : "bg-light"}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleFileDrop}
        style={{ transition: "background 0.3s ease" }}
      >
        <input
          type="file"
          id="fileInput"
          hidden
          multiple
          webkitdirectory="true"
          mozdirectory="true"
          directory="true"
          onChange={handleFileSelect}
        />
        <div className="text-center">
          <i className="bi bi-cloud-upload" style={{ fontSize: "3rem", color: "#0d6efd" }}></i>
          <h5 className="mt-3">Drop source files or folders to scan</h5>
          <small className="text-muted">Supports zip files and folders</small>
          <div className="mt-4">
            <button
              className="btn btn-primary"
              onClick={() => document.getElementById("fileInput").click()}
              disabled={uploading || !selectedAIT || !selectedSPK || !selectedRepo}
            >
              {uploading ? "Scanning..." : "📂 Browse Files or Folder"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
