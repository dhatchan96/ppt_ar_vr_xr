// Centralized configuration for AIT, SPK, and REPO dropdown data
// This file loads data from the admin API for dynamic dropdown values

import API from '../api';

// Default fallback data
export const defaultAitData = [
  { value: 'AIT001', label: 'Application Integration Team 1' },
  { value: 'AIT002', label: 'Application Integration Team 2' },
  { value: 'AIT003', label: 'Application Integration Team 3' },
  { value: 'AIT004', label: 'Application Integration Team 4' },
  { value: 'AIT005', label: 'Application Integration Team 5' }
];

export const defaultSpkData = {
  'AIT001': [
    { value: 'SPK001', label: 'Security Product Key 1' },
    { value: 'SPK002', label: 'Security Product Key 2' },
    { value: 'SPK003', label: 'Security Product Key 3' }
  ],
  'AIT002': [
    { value: 'SPK004', label: 'Security Product Key 4' },
    { value: 'SPK005', label: 'Security Product Key 5' },
    { value: 'SPK006', label: 'Security Product Key 6' }
  ],
  'AIT003': [
    { value: 'SPK007', label: 'Security Product Key 7' },
    { value: 'SPK008', label: 'Security Product Key 8' }
  ],
  'AIT004': [
    { value: 'SPK009', label: 'Security Product Key 9' },
    { value: 'SPK010', label: 'Security Product Key 10' }
  ],
  'AIT005': [
    { value: 'SPK011', label: 'Security Product Key 11' },
    { value: 'SPK012', label: 'Security Product Key 12' }
  ]
};

export const defaultRepoData = {
  'SPK001': [
    { value: 'REPO001', label: 'Repository 1' },
    { value: 'REPO002', label: 'Repository 2' },
    { value: 'REPO003', label: 'Repository 3' }
  ],
  'SPK002': [
    { value: 'REPO004', label: 'Repository 4' },
    { value: 'REPO005', label: 'Repository 5' }
  ],
  'SPK003': [
    { value: 'REPO006', label: 'Repository 6' }
  ],
  'SPK004': [
    { value: 'REPO007', label: 'Repository 7' },
    { value: 'REPO008', label: 'Repository 8' }
  ],
  'SPK005': [
    { value: 'REPO009', label: 'Repository 9' },
    { value: 'REPO010', label: 'Repository 10' },
    { value: 'REPO011', label: 'Repository 11' }
  ],
  'SPK006': [
    { value: 'REPO012', label: 'Repository 12' }
  ],
  'SPK007': [
    { value: 'REPO013', label: 'Repository 13' },
    { value: 'REPO014', label: 'Repository 14' }
  ],
  'SPK008': [
    { value: 'REPO015', label: 'Repository 15' }
  ],
  'SPK009': [
    { value: 'REPO016', label: 'Repository 16' },
    { value: 'REPO017', label: 'Repository 17' }
  ],
  'SPK010': [
    { value: 'REPO018', label: 'Repository 18' }
  ],
  'SPK011': [
    { value: 'REPO019', label: 'Repository 19' },
    { value: 'REPO020', label: 'Repository 20' }
  ],
  'SPK012': [
    { value: 'REPO021', label: 'Repository 21' },
    { value: 'REPO022', label: 'Repository 22' },
    { value: 'REPO023', label: 'Repository 23' }
  ]
};

// Dynamic data loading functions
let cachedAitData = null;
let cachedSpkData = {};
let cachedRepoData = {};
let hierarchicalData = null;

export const loadHierarchicalData = async () => {
  try {
    // Add cache-busting parameter to force fresh data
    const timestamp = Date.now();
    const response = await API.get(`/api/admin/hierarchical-data?_t=${timestamp}`);
    if (response.data.success) {
      hierarchicalData = response.data.data;
      
      // Convert hierarchical data to dropdown format
      cachedAitData = Object.entries(hierarchicalData).map(([aitTag, aitData]) => ({
        value: aitTag,
        label: aitData.ait_name || aitTag
      }));
      
      console.log('🔄 Loaded hierarchical data:', hierarchicalData);
      console.log('🔄 Cached AIT data:', cachedAitData);
      
      Object.entries(hierarchicalData).forEach(([aitTag, aitData]) => {
        cachedSpkData[aitTag] = Object.entries(aitData.spks || {}).map(([spkTag, spkData]) => ({
          value: spkTag,
          label: spkData.spk_name || spkTag
        }));
        
        Object.entries(aitData.spks || {}).forEach(([spkTag, spkData]) => {
          cachedRepoData[spkTag] = (spkData.repos || []).map((repo, index) => ({
            value: repo.repo_name,
            label: repo.repo_name
          }));
        });
      });
      
      return true;
    }
  } catch (error) {
    console.error('Error loading hierarchical data:', error);
  }
  return false;
};

// Get AIT data (with fallback)
export const getAitData = () => {
  if (cachedAitData) {
    // Format AIT data to show only ID
    return cachedAitData.map(ait => ({
      value: ait.value, // This will be the AIT_ID (number)
      label: ait.value // Show only the numerical ID
    }));
  }
  return defaultAitData;
};

// Get SPK data for a specific AIT (with fallback)
export const getSpkData = (aitTag) => {
  return cachedSpkData[aitTag] || defaultSpkData[aitTag] || [];
};

// Get Repository data for a specific SPK (with fallback)
export const getRepoData = (spkTag) => {
  return cachedRepoData[spkTag] || defaultRepoData[spkTag] || [];
};

// Helper functions for getting names
export const getAITName = (aitId) => {
  if (!aitId) return 'Unknown AIT';
  
  // Try cached data first
  if (cachedAitData) {
    const ait = cachedAitData.find(item => item.value === aitId);
    if (ait) return ait.label;
  }
  
  // Try hierarchical data
  if (hierarchicalData && hierarchicalData[aitId]) {
    return hierarchicalData[aitId].ait_name || aitId;
  }
  
  // Fallback to default data
  const ait = defaultAitData.find(item => item.value === aitId);
  return ait ? ait.label : aitId;
};

export const getSPKName = (spkId) => {
  if (!spkId) return 'Unknown SPK';
  
  // Try cached data first
  const allSpks = Object.values(cachedSpkData).flat();
  const spk = allSpks.find(item => item.value === spkId);
  if (spk) return spk.label;
  
  // Try hierarchical data
  if (hierarchicalData) {
    for (const [aitTag, aitData] of Object.entries(hierarchicalData)) {
      if (aitData.spks && aitData.spks[spkId]) {
        return aitData.spks[spkId].spk_name || spkId;
      }
    }
  }
  
  // Fallback to default data
  const allDefaultSpks = Object.values(defaultSpkData).flat();
  const defaultSpk = allDefaultSpks.find(item => item.value === spkId);
  return defaultSpk ? defaultSpk.label : spkId;
};

export const getRepoName = (repoId) => {
  if (!repoId) return 'Unknown Repository';
  
  // Try cached data first
  const allRepos = Object.values(cachedRepoData).flat();
  const repo = allRepos.find(item => item.value === repoId);
  if (repo) return repo.label;
  
  // Try hierarchical data
  if (hierarchicalData) {
    for (const [aitTag, aitData] of Object.entries(hierarchicalData)) {
      for (const [spkTag, spkData] of Object.entries(aitData.spks || {})) {
        const repo = spkData.repos?.find(r => r.repo_name === repoId);
        if (repo) return repo.repo_name;
      }
    }
  }
  
  // Fallback to default data
  const allDefaultRepos = Object.values(defaultRepoData).flat();
  const defaultRepo = allDefaultRepos.find(item => item.value === repoId);
  return defaultRepo ? defaultRepo.label : repoId;
};

// Initialize data loading
export const initializeDropdownData = async () => {
  await loadHierarchicalData();
};

// Export for backward compatibility
export const aitData = getAitData;
export const spkData = getSpkData;
export const repoData = getRepoData;
