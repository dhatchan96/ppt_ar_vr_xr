"""
Knowledge Base Database Manager for ThreatGuard Pro
SQLite-based storage for remediation templates and security guidance
"""

import json
import logging
import sqlite3
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class KnowledgeBaseDB:
    """SQLite database manager for Knowledge Base templates"""
    
    def __init__(self, data_dir: str = "threatguard_data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        self.db_path = self.data_dir / "knowledge_base.db"
        self.init_database()
    
    def init_database(self):
        """Initialize SQLite database for knowledge base templates"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create knowledge_base_templates table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS knowledge_base_templates (
                        id TEXT PRIMARY KEY,
                        title TEXT NOT NULL,
                        description TEXT,
                        category TEXT,
                        content_type TEXT,
                        content TEXT,
                        ai_copilot_prompt TEXT,
                        remediation_template TEXT,
                        created_at TEXT,
                        updated_at TEXT,
                        created_by TEXT,
                        tags TEXT,  -- JSON array as string
                        severity_levels TEXT,  -- JSON array as string
                        applicable_languages TEXT,  -- JSON array as string
                        metadata TEXT,  -- JSON object as string
                        is_active BOOLEAN DEFAULT 1,
                        version INTEGER DEFAULT 1
                    )
                ''')
                
                # Create indexes for better performance
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_kb_templates_category 
                    ON knowledge_base_templates(category)
                ''')
                
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_kb_templates_created_at 
                    ON knowledge_base_templates(created_at)
                ''')
                
                cursor.execute('''
                    CREATE INDEX IF NOT EXISTS idx_kb_templates_active 
                    ON knowledge_base_templates(is_active)
                ''')
                
                conn.commit()
                logger.info("Knowledge Base SQLite database initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Knowledge Base SQLite database: {e}")
    
    def save_template(self, template: Dict[str, Any]) -> bool:
        """Save a knowledge base template to SQLite"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Convert lists to JSON strings for storage
                tags_json = json.dumps(template.get('tags', []))
                severity_levels_json = json.dumps(template.get('severity_levels', []))
                applicable_languages_json = json.dumps(template.get('applicable_languages', []))
                metadata_json = json.dumps(template.get('metadata', {}))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO knowledge_base_templates 
                    (id, title, description, category, content_type, content,
                     ai_copilot_prompt, remediation_template, created_at, 
                     updated_at, created_by, tags, severity_levels, 
                     applicable_languages, metadata, is_active, version)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    template.get('id'),
                    template.get('title'),
                    template.get('description'),
                    template.get('category'),
                    template.get('content_type'),
                    template.get('content'),
                    template.get('ai_copilot_prompt'),
                    template.get('remediation_template'),
                    template.get('created_at'),
                    template.get('updated_at'),
                    template.get('created_by'),
                    tags_json,
                    severity_levels_json,
                    applicable_languages_json,
                    metadata_json,
                    template.get('is_active', True),
                    template.get('version', 1)
                ))
                conn.commit()
                return True
        except Exception as e:
            logger.error(f"Error saving knowledge base template to SQLite: {e}")
            return False
    
    def get_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific knowledge base template by ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM knowledge_base_templates 
                    WHERE id = ? AND is_active = 1
                ''', (template_id,))
                
                row = cursor.fetchone()
                if row:
                    template = dict(row)
                    # Convert JSON strings back to lists/objects
                    template['tags'] = json.loads(template['tags'] or '[]')
                    template['severity_levels'] = json.loads(template['severity_levels'] or '[]')
                    template['applicable_languages'] = json.loads(template['applicable_languages'] or '[]')
                    template['metadata'] = json.loads(template['metadata'] or '{}')
                    return template
                return None
        except Exception as e:
            logger.error(f"Error getting knowledge base template from SQLite: {e}")
            return None
    
    def get_all_templates(self, filters: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """Get all knowledge base templates with optional filtering"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                query = "SELECT * FROM knowledge_base_templates WHERE is_active = 1"
                params = []
                
                if filters:
                    if 'category' in filters and filters['category'] != 'all':
                        query += " AND category = ?"
                        params.append(filters['category'])
                    
                    if 'search' in filters and filters['search']:
                        query += " AND (title LIKE ? OR description LIKE ? OR tags LIKE ?)"
                        search_term = f"%{filters['search']}%"
                        params.extend([search_term, search_term, search_term])
                    
                    if 'severity' in filters and filters['severity']:
                        query += " AND severity_levels LIKE ?"
                        params.append(f'%"{filters["severity"]}"%')
                
                query += " ORDER BY created_at DESC"
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                templates = []
                for row in rows:
                    template = dict(row)
                    # Convert JSON strings back to lists/objects
                    template['tags'] = json.loads(template['tags'] or '[]')
                    template['severity_levels'] = json.loads(template['severity_levels'] or '[]')
                    template['applicable_languages'] = json.loads(template['applicable_languages'] or '[]')
                    template['metadata'] = json.loads(template['metadata'] or '{}')
                    templates.append(template)
                
                return templates
        except Exception as e:
            logger.error(f"Error getting knowledge base templates from SQLite: {e}")
            return []
    
    def update_template(self, template_id: str, updates: Dict[str, Any]) -> bool:
        """Update a knowledge base template"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Prepare update fields
                update_fields = []
                params = []
                
                for key, value in updates.items():
                    if key in ['tags', 'severity_levels', 'applicable_languages', 'metadata']:
                        update_fields.append(f"{key} = ?")
                        params.append(json.dumps(value))
                    elif key == 'updated_at':
                        update_fields.append(f"{key} = ?")
                        params.append(datetime.now().isoformat())
                    else:
                        update_fields.append(f"{key} = ?")
                        params.append(value)
                
                if update_fields:
                    params.append(template_id)
                    query = f"UPDATE knowledge_base_templates SET {', '.join(update_fields)} WHERE id = ?"
                    cursor.execute(query, params)
                    conn.commit()
                    return cursor.rowcount > 0
                return False
        except Exception as e:
            logger.error(f"Error updating knowledge base template in SQLite: {e}")
            return False
    
    def delete_template(self, template_id: str, soft_delete: bool = True) -> bool:
        """Delete a knowledge base template (soft delete by default)"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                if soft_delete:
                    cursor.execute('''
                        UPDATE knowledge_base_templates 
                        SET is_active = 0, updated_at = ?
                        WHERE id = ?
                    ''', (datetime.now().isoformat(), template_id))
                else:
                    cursor.execute('DELETE FROM knowledge_base_templates WHERE id = ?', (template_id,))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Error deleting knowledge base template from SQLite: {e}")
            return False
    
    def search_templates(self, query: str, category: str = None) -> List[Dict[str, Any]]:
        """Search knowledge base templates by query"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                search_query = '''
                    SELECT * FROM knowledge_base_templates 
                    WHERE is_active = 1 AND (
                        title LIKE ? OR 
                        description LIKE ? OR 
                        tags LIKE ? OR
                        github_copilot_prompt LIKE ? OR
                        remediation_template LIKE ?
                    )
                '''
                params = []
                search_term = f"%{query}%"
                params.extend([search_term, search_term, search_term, search_term, search_term])
                
                if category and category != 'all':
                    search_query += " AND category = ?"
                    params.append(category)
                
                search_query += " ORDER BY created_at DESC"
                cursor.execute(search_query, params)
                rows = cursor.fetchall()
                
                templates = []
                for row in rows:
                    template = dict(row)
                    # Convert JSON strings back to lists/objects
                    template['tags'] = json.loads(template['tags'] or '[]')
                    template['severity_levels'] = json.loads(template['severity_levels'] or '[]')
                    template['applicable_languages'] = json.loads(template['applicable_languages'] or '[]')
                    template['metadata'] = json.loads(template['metadata'] or '{}')
                    templates.append(template)
                
                return templates
        except Exception as e:
            logger.error(f"Error searching knowledge base templates in SQLite: {e}")
            return []
    
    def get_templates_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Get templates by specific category"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                cursor.execute(
                    "SELECT * FROM knowledge_base_templates WHERE category = ? AND is_active = 1 ORDER BY created_at DESC",
                    (category,)
                )
                rows = cursor.fetchall()
                
                templates = []
                for row in rows:
                    template = dict(row)
                    # Convert JSON strings back to lists/objects
                    template['tags'] = json.loads(template['tags'] or '[]')
                    template['severity_levels'] = json.loads(template['severity_levels'] or '[]')
                    template['applicable_languages'] = json.loads(template['applicable_languages'] or '[]')
                    template['metadata'] = json.loads(template['metadata'] or '{}')
                    templates.append(template)
                
                return templates
        except Exception as e:
            logger.error(f"Error getting templates by category from SQLite: {e}")
            return []
    
    def search_templates(self, query: str) -> List[Dict[str, Any]]:
        """Search templates by query string"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                search_term = f"%{query}%"
                cursor.execute('''
                    SELECT * FROM knowledge_base_templates 
                    WHERE is_active = 1 AND (
                        title LIKE ? OR 
                        description LIKE ? OR 
                        content LIKE ? OR
                        tags LIKE ?
                    )
                    ORDER BY created_at DESC
                ''', (search_term, search_term, search_term, search_term))
                
                rows = cursor.fetchall()
                
                templates = []
                for row in rows:
                    template = dict(row)
                    # Convert JSON strings back to lists/objects
                    template['tags'] = json.loads(template['tags'] or '[]')
                    template['severity_levels'] = json.loads(template['severity_levels'] or '[]')
                    template['applicable_languages'] = json.loads(template['applicable_languages'] or '[]')
                    template['metadata'] = json.loads(template['metadata'] or '{}')
                    templates.append(template)
                
                return templates
        except Exception as e:
            logger.error(f"Error searching templates in SQLite: {e}")
            return []
    
    def get_template_stats(self) -> Dict[str, Any]:
        """Get statistics about knowledge base templates"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Total templates
                cursor.execute("SELECT COUNT(*) FROM knowledge_base_templates WHERE is_active = 1")
                total_templates = cursor.fetchone()[0]
                
                # Templates by category
                cursor.execute('''
                    SELECT category, COUNT(*) 
                    FROM knowledge_base_templates 
                    WHERE is_active = 1 
                    GROUP BY category
                ''')
                category_stats = dict(cursor.fetchall())
                
                # Recent templates (last 30 days)
                cursor.execute('''
                    SELECT COUNT(*) FROM knowledge_base_templates 
                    WHERE is_active = 1 AND created_at >= datetime('now', '-30 days')
                ''')
                recent_templates = cursor.fetchone()[0]
                
                return {
                    "total_templates": total_templates,
                    "category_stats": category_stats,
                    "recent_templates": recent_templates,
                    "last_updated": datetime.now().isoformat()
                }
        except Exception as e:
            logger.error(f"Error getting knowledge base template stats from SQLite: {e}")
            return {
                "total_templates": 0,
                "category_stats": {},
                "recent_templates": 0,
                "last_updated": datetime.now().isoformat()
            }
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get database health status"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM knowledge_base_templates WHERE is_active = 1")
                count = cursor.fetchone()[0]
                
                return {
                    "status": "healthy",
                    "total_templates": count,
                    "last_updated": datetime.now().isoformat(),
                    "database_type": "SQLite",
                    "database_path": str(self.db_path)
                }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "database_type": "SQLite",
                "database_path": str(self.db_path)
            }
    
    def cleanup_duplicates(self):
        """Remove duplicate templates based on title and category"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Find duplicates based on title and category
                cursor.execute('''
                    SELECT title, category, COUNT(*) as count
                    FROM knowledge_base_templates
                    WHERE is_active = 1
                    GROUP BY title, category
                    HAVING COUNT(*) > 1
                ''')
                
                duplicates = cursor.fetchall()
                logger.info(f"Found {len(duplicates)} duplicate template groups")
                
                for title, category, count in duplicates:
                    # Keep the most recent one, delete others
                    cursor.execute('''
                        SELECT id, created_at
                        FROM knowledge_base_templates
                        WHERE title = ? AND category = ? AND is_active = 1
                        ORDER BY created_at DESC
                    ''', (title, category))
                    
                    templates = cursor.fetchall()
                    # Keep the first (most recent), mark others as inactive
                    for i, (template_id, created_at) in enumerate(templates):
                        if i > 0:  # Skip the first one
                            cursor.execute('''
                                UPDATE knowledge_base_templates
                                SET is_active = 0, updated_at = ?
                                WHERE id = ?
                            ''', (datetime.now().isoformat(), template_id))
                            logger.info(f"Marked duplicate template '{title}' (ID: {template_id[:8]}...) as inactive")
                
                conn.commit()
                return len(duplicates)
        except Exception as e:
            logger.error(f"Error cleaning up duplicates: {e}")
            return 0
    
    def reset_database(self):
        """Reset database by removing all templates"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM knowledge_base_templates")
                conn.commit()
                logger.info("Database reset successfully")
                return True
        except Exception as e:
            logger.error(f"Error resetting database: {e}")
            return False

# Global knowledge base database manager instance
kb_db = KnowledgeBaseDB()
