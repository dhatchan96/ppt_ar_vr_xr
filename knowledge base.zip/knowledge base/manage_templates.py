#!/usr/bin/env python3
"""
Knowledge Base Template Management Script
Allows you to view, delete, and manage templates
"""

import sys
from knowledge_base_manager import KnowledgeBaseManager

def list_templates():
    """List all active templates"""
    kb_manager = KnowledgeBaseManager()
    templates = kb_manager.get_all_templates()
    
    if not templates:
        print("No templates found in Knowledge Base.")
        return []
    
    print(f"\nKnowledge Base Templates ({len(templates)} total):")
    print("=" * 80)
    
    for i, template in enumerate(templates, 1):
        title = template.get('title', 'Unknown')
        category = template.get('category', 'Unknown')
        content_type = template.get('content_type', 'Unknown')
        created = template.get('created_at', 'Unknown')[:10]  # Just the date part
        template_id = template.get('id', 'Unknown')
        
        print(f"{i:2d}. {title}")
        print(f"    Category: {category} | Type: {content_type} | Created: {created}")
        print(f"    ID: {template_id[:8]}...")
        print()
    
    return templates

def delete_template_by_id(template_id):
    """Delete template by ID"""
    kb_manager = KnowledgeBaseManager()
    
    # Get template details first
    template = kb_manager.get_template_by_id(template_id)
    if not template:
        print(f"ERROR: Template with ID {template_id} not found.")
        return False
    
    print(f"Template Details:")
    print(f"   Title: {template.get('title', 'Unknown')}")
    print(f"   Category: {template.get('category', 'Unknown')}")
    print(f"   Type: {template.get('content_type', 'Unknown')}")
    print(f"   Created: {template.get('created_at', 'Unknown')[:10]}")
    
    # Confirm deletion
    confirm = input(f"\nWARNING: Are you sure you want to DELETE this template? (yes/no): ")
    if confirm.lower() in ['yes', 'y']:
        try:
            # Mark as inactive instead of hard delete
            kb_manager.db.update_template(template_id, {'is_active': False})
            print(f"SUCCESS: Successfully deleted template: {template.get('title', 'Unknown')}")
            return True
        except Exception as e:
            print(f"ERROR: Error deleting template: {e}")
            return False
    else:
        print("CANCELLED: Deletion cancelled.")
        return False

def delete_template_by_number(templates, template_number):
    """Delete template by list number"""
    if template_number < 1 or template_number > len(templates):
        print(f"ERROR: Invalid template number. Please choose 1-{len(templates)}")
        return False
    
    template = templates[template_number - 1]
    template_id = template.get('id')
    
    return delete_template_by_id(template_id)

def main_menu():
    """Main menu for template management"""
    while True:
        print("\n" + "="*60)
        print("Knowledge Base Template Manager")
        print("="*60)
        print("1. List all templates")
        print("2. Delete template by number")
        print("3. Delete template by ID")
        print("4. Exit")
        
        choice = input("\nSelect an option (1-4): ").strip()
        
        if choice == '1':
            list_templates()
        
        elif choice == '2':
            templates = list_templates()
            if templates:
                try:
                    template_num = int(input(f"\nEnter template number to delete (1-{len(templates)}): "))
                    delete_template_by_number(templates, template_num)
                except ValueError:
                    print("ERROR: Invalid number.")
        
        elif choice == '3':
            template_id = input("\nEnter template ID to delete: ").strip()
            if template_id:
                delete_template_by_id(template_id)
        
        elif choice == '4':
            print("Goodbye!")
            break
        
        else:
            print("ERROR: Invalid choice. Please select 1-4.")

def main():
    """Main function with command line support"""
    if len(sys.argv) > 1:
        # Command line mode
        command = sys.argv[1].lower()
        
        if command == 'list':
            list_templates()
        
        elif command == 'delete':
            if len(sys.argv) > 2:
                template_id = sys.argv[2]
                delete_template_by_id(template_id)
            else:
                print("ERROR: Please provide template ID: python manage_templates.py delete <template_id>")
        
        elif command == 'help':
            print("Knowledge Base Template Manager")
            print("\nUsage:")
            print("  python manage_templates.py                    # Interactive mode")
            print("  python manage_templates.py list               # List all templates")
            print("  python manage_templates.py delete <id>        # Delete template by ID")
            print("  python manage_templates.py help               # Show this help")
        
        else:
            print(f"ERROR: Unknown command: {command}")
            print("Run 'python manage_templates.py help' for usage information.")
    
    else:
        # Interactive mode
        main_menu()

if __name__ == "__main__":
    main()