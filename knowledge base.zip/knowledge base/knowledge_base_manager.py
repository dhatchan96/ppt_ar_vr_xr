import json
import uuid
import requests
import pandas as pd
import io
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import logging

from knowledge_base_db import KnowledgeBaseDB

logger = logging.getLogger(__name__)

@dataclass
class KnowledgeTemplate:
    id: str
    title: str
    description: str
    category: str
    content_type: str
    content: str
    ai_copilot_prompt: str
    remediation_template: str
    created_at: str
    updated_at: str
    created_by: str
    tags: List[str] = field(default_factory=list)
    severity_levels: List[str] = field(default_factory=list)
    applicable_languages: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_active: bool = True
    version: int = 1

class KnowledgeBaseManager:
    def __init__(self):
        self.db = KnowledgeBaseDB()
        self.templates = {}
        self.load_templates()
    
    def load_templates(self):
        """Load templates from database"""
        try:
            templates_data = self.db.get_all_templates()
            if not templates_data:
                logger.info("No templates found in database, creating default templates")
                self._create_default_templates()
            else:
                logger.info(f"Loaded {len(templates_data)} templates from database")
                for template_data in templates_data:
                    try:
                        template = KnowledgeTemplate(**template_data)
                        self.templates[template.id] = template
                    except Exception as e:
                        logger.error(f"Error loading template {template_data.get('id', 'unknown')}: {e}")
        except Exception as e:
            logger.error(f"Error loading templates from database: {e}")
            self._create_default_templates()
    
    def save_template_to_db(self, template: KnowledgeTemplate):
        """Save template to database"""
        try:
            template_dict = {
                'id': template.id,
                'title': template.title,
                'description': template.description,
                'category': template.category,
                'content_type': template.content_type,
                'content': template.content,
                'ai_copilot_prompt': template.ai_copilot_prompt,
                'remediation_template': template.remediation_template,
                'created_at': template.created_at,
                'updated_at': template.updated_at,
                'created_by': template.created_by,
                'tags': json.dumps(template.tags),
                'severity_levels': json.dumps(template.severity_levels),
                'applicable_languages': json.dumps(template.applicable_languages),
                'metadata': json.dumps(template.metadata),
                'is_active': template.is_active,
                'version': template.version
            }
            self.db.save_template(template_dict)
            logger.info(f"Saved template {template.id} to database")
        except Exception as e:
            logger.error(f"Error saving template to database: {e}")
    
    def _create_default_templates(self):
        """Create default remediation templates"""
        # Check if default templates already exist to prevent duplicates
        existing_templates = self.db.get_all_templates()
        if existing_templates:
            logger.info(f"Found {len(existing_templates)} existing templates, skipping default template creation")
            return
        
        logger.info("Creating default templates")
        default_templates = [
            {
                "id": str(uuid.uuid4()),
                "title": "SQL Injection Remediation",
                "description": "Comprehensive guide for fixing SQL injection vulnerabilities",
                "category": "application",
                "content_type": "template",
                "content": "SQL injection template content",
                "ai_copilot_prompt": self._generate_sql_injection_copilot_prompt(),
                "remediation_template": self._generate_sql_injection_remediation_template(),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": "system",
                "tags": ["sql", "injection", "database", "security"],
                "severity_levels": ["CRITICAL_BOMB", "HIGH_RISK"],
                "applicable_languages": ["python", "javascript", "java", "php", "csharp"],
                "metadata": {"confidence": 0.95, "source": "system_template"},
                "is_active": True,
                "version": 1
            },
            {
                "id": str(uuid.uuid4()),
                "title": "Root Cause Explorer - Jira Data Analysis",
                "description": "AI-powered root cause analysis template for analyzing Jira tickets, comments, and historical data to identify patterns and provide remediation suggestions",
                "category": "data-analysis",
                "content_type": "template",
                "content": "Root cause analysis template for Jira data",
                "ai_copilot_prompt": self._generate_root_cause_explorer_copilot_prompt(),
                "remediation_template": self._generate_root_cause_explorer_remediation_template(),
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": "system",
                "tags": ["root-cause", "jira", "analysis", "remediation", "ai-powered", "historical-data"],
                "severity_levels": ["HIGH_RISK", "MEDIUM_RISK", "LOW_RISK"],
                "applicable_languages": ["python", "javascript", "sql", "json"],
                "metadata": {"confidence": 0.98, "source": "system_template", "supports_excel_upload": True},
                "is_active": True,
                "version": 1
            }
        ]
        
        for template_data in default_templates:
            template = KnowledgeTemplate(**template_data)
            self.templates[template.id] = template
            self.save_template_to_db(template)
    
    def _check_duplicate_template(self, title: str, category: str) -> bool:
        """Check if a template with the same title and category already exists"""
        try:
            existing_templates = self.db.get_all_templates({'category': category})
            for template in existing_templates:
                if template['title'].lower() == title.lower():
                    return True
            return False
        except Exception as e:
            logger.error(f"Error checking for duplicate template: {e}")
            return False
    
    def _generate_copilot_prompt_from_content(self, content: str, title: str, category: str) -> str:
        """Generate AI Copilot prompt from content"""
        return f"""# AI Copilot Prompt: {title}

## CONTEXT:
You are analyzing content related to {category} issues.

## CONTENT:
{content[:1000]}{'...' if len(content) > 1000 else ''}

## YOUR TASK:
Provide remediation suggestions and analysis for this {category} issue.

## EXPECTED OUTPUT:
Provide specific, actionable solutions with step-by-step instructions."""
    
    def _generate_remediation_template_from_content(self, content: str, title: str, category: str) -> str:
        """Generate remediation template from content"""
        return f"""# {title} - Remediation Template

## Overview
This template provides remediation guidance for {category} issues.

## Content Analysis
{content[:500]}{'...' if len(content) > 500 else ''}

## Remediation Steps
1. **Immediate Actions**
   - Analyze the issue based on the content above
   - Identify root causes
   - Implement quick fixes

2. **Long-term Solutions**
   - Prevent similar issues
   - Implement monitoring
   - Update processes

## Best Practices
- Follow security guidelines
- Test solutions in non-production first
- Document changes"""
    
    def _extract_tags_from_content(self, content: str) -> List[str]:
        """Extract tags from content"""
        tags = []
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['security', 'vulnerability', 'auth']):
            tags.append('security')
        if any(word in content_lower for word in ['performance', 'slow', 'timeout']):
            tags.append('performance')
        if any(word in content_lower for word in ['database', 'sql', 'query']):
            tags.append('database')
        if any(word in content_lower for word in ['api', 'endpoint', 'service']):
            tags.append('api')
        
        return tags[:5]  # Limit to 5 tags
    
    def _determine_severity_from_content(self, content: str) -> List[str]:
        """Determine severity from content"""
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['critical', 'urgent', 'emergency']):
            return ["CRITICAL_BOMB"]
        elif any(word in content_lower for word in ['high', 'important', 'security']):
            return ["HIGH_RISK"]
        elif any(word in content_lower for word in ['medium', 'moderate']):
            return ["MEDIUM_RISK"]
        else:
            return ["LOW_RISK"]
    
    def _detect_languages_from_content(self, content: str) -> List[str]:
        """Detect programming languages from content"""
        languages = []
        content_lower = content.lower()
        
        if any(word in content_lower for word in ['python', 'py']):
            languages.append('python')
        if any(word in content_lower for word in ['javascript', 'js', 'node']):
            languages.append('javascript')
        if any(word in content_lower for word in ['java', 'jvm']):
            languages.append('java')
        if any(word in content_lower for word in ['sql', 'database']):
            languages.append('sql')
        
        return languages[:3]  # Limit to 3 languages
    
    def add_template_from_excel(self, title: str, description: str, excel_file_content: bytes) -> Optional[str]:
        """Add template from Excel file with Jira data"""
        try:
            # Check for duplicates first
            if self._check_duplicate_template(title, "data-analysis"):
                logger.warning(f"Template '{title}' already exists in data-analysis category")
                return None
            
            # Parse Excel file
            df = pd.read_excel(io.BytesIO(excel_file_content))
            
            # Validate required columns
            required_columns = ['Jira ID', 'Jira Title', 'Jira Comments']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Process Jira data
            jira_data = self._process_jira_data(df)
            
            # Generate template
            template_id = str(uuid.uuid4())
            ai_copilot_prompt = self._generate_jira_analysis_copilot_prompt(jira_data)
            remediation_template = self._generate_jira_remediation_template(jira_data)
            
            template = KnowledgeTemplate(
                id=template_id,
                title=title,
                description=description,
                category="data-analysis",
                content_type="excel",
                content=json.dumps(jira_data, indent=2),
                ai_copilot_prompt=ai_copilot_prompt,
                remediation_template=remediation_template,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="user",
                tags=self._extract_tags_from_jira_data(jira_data),
                severity_levels=self._analyze_jira_severity(jira_data),
                applicable_languages=["python", "javascript", "sql", "json"],
                metadata={
                    "excel_rows": len(df),
                    "jira_tickets": len(jira_data['tickets']),
                    "analysis_date": datetime.now().isoformat(),
                    "confidence": 0.95
                }
            )
            
            self.templates[template_id] = template
            self.save_template_to_db(template)
            
            return template_id
            
        except Exception as e:
            logger.error(f"Error adding template from Excel: {e}")
            return None
    
    def add_template_from_file(self, title: str, description: str, category: str, file_content: str, filename: str) -> Optional[str]:
        """Add template from file content"""
        try:
            # Check for duplicates first
            if self._check_duplicate_template(title, category):
                logger.warning(f"Template '{title}' already exists in {category} category")
                return None
            
            # Generate template
            template_id = str(uuid.uuid4())
            ai_copilot_prompt = self._generate_copilot_prompt_from_content(file_content, title, category)
            remediation_template = self._generate_remediation_template_from_content(file_content, title, category)
            
            template = KnowledgeTemplate(
                id=template_id,
                title=title,
                description=description,
                category=category,
                content_type="file",
                content=file_content,
                ai_copilot_prompt=ai_copilot_prompt,
                remediation_template=remediation_template,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
                created_by="user",
                tags=self._extract_tags_from_content(file_content),
                severity_levels=self._determine_severity_from_content(file_content),
                applicable_languages=self._detect_languages_from_content(file_content),
                metadata={"filename": filename, "file_size": len(file_content)}
            )
            
            self.templates[template_id] = template
            self.save_template_to_db(template)
            
            return template_id
            
        except Exception as e:
            logger.error(f"Error adding template from file: {e}")
            return None
    
    def _process_jira_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Process Jira data from Excel DataFrame"""
        tickets = []
        
        for _, row in df.iterrows():
            ticket = {
                "jira_id": str(row['Jira ID']),
                "title": str(row['Jira Title']),
                "comments": str(row['Jira Comments']),
                "analysis": {
                    "keywords": self._extract_keywords_from_text(str(row['Jira Comments'])),
                    "sentiment": self._analyze_sentiment(str(row['Jira Comments'])),
                    "category": self._categorize_issue(str(row['Jira Title']), str(row['Jira Comments']))
                }
            }
            tickets.append(ticket)
        
        return {
            "total_tickets": len(tickets),
            "tickets": tickets,
            "summary": {
                "categories": self._get_category_summary(tickets),
                "common_keywords": self._get_common_keywords(tickets),
                "sentiment_distribution": self._get_sentiment_distribution(tickets)
            }
        }
    
    def _extract_keywords_from_text(self, text: str) -> List[str]:
        """Extract keywords from text"""
        # Simple keyword extraction - can be enhanced with NLP
        keywords = []
        common_technical_terms = [
            'bug', 'error', 'issue', 'problem', 'fix', 'solution', 'update', 'patch',
            'security', 'performance', 'database', 'api', 'frontend', 'backend',
            'authentication', 'authorization', 'validation', 'exception', 'timeout'
        ]
        
        text_lower = text.lower()
        for term in common_technical_terms:
            if term in text_lower:
                keywords.append(term)
        
        return keywords[:10]  # Limit to top 10
    
    def _analyze_sentiment(self, text: str) -> str:
        """Simple sentiment analysis"""
        positive_words = ['fixed', 'resolved', 'working', 'good', 'improved', 'success']
        negative_words = ['broken', 'failed', 'error', 'issue', 'problem', 'bug', 'critical']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"
    
    def _categorize_issue(self, title: str, comments: str) -> str:
        """Categorize issue based on title and comments"""
        text = (title + " " + comments).lower()
        
        if any(word in text for word in ['security', 'vulnerability', 'auth', 'permission']):
            return "security"
        elif any(word in text for word in ['performance', 'slow', 'timeout', 'memory']):
            return "performance"
        elif any(word in text for word in ['ui', 'frontend', 'display', 'interface']):
            return "ui"
        elif any(word in text for word in ['database', 'sql', 'query', 'data']):
            return "database"
        elif any(word in text for word in ['api', 'endpoint', 'service', 'integration']):
            return "api"
        else:
            return "general"
    
    def _get_category_summary(self, tickets: List[Dict]) -> Dict[str, int]:
        """Get summary of issue categories"""
        categories = {}
        for ticket in tickets:
            category = ticket['analysis']['category']
            categories[category] = categories.get(category, 0) + 1
        return categories
    
    def _get_common_keywords(self, tickets: List[Dict]) -> List[str]:
        """Get most common keywords across all tickets"""
        all_keywords = []
        for ticket in tickets:
            all_keywords.extend(ticket['analysis']['keywords'])
        
        keyword_counts = {}
        for keyword in all_keywords:
            keyword_counts[keyword] = keyword_counts.get(keyword, 0) + 1
        
        # Sort by frequency and return top 10
        sorted_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)
        return [keyword for keyword, count in sorted_keywords[:10]]
    
    def _get_sentiment_distribution(self, tickets: List[Dict]) -> Dict[str, int]:
        """Get sentiment distribution"""
        sentiments = {}
        for ticket in tickets:
            sentiment = ticket['analysis']['sentiment']
            sentiments[sentiment] = sentiments.get(sentiment, 0) + 1
        return sentiments
    
    def _extract_tags_from_jira_data(self, jira_data: Dict) -> List[str]:
        """Extract tags from Jira data analysis"""
        tags = ["jira-analysis", "root-cause", "data-driven"]
        
        # Add category tags
        for category in jira_data['summary']['categories'].keys():
            tags.append(f"category-{category}")
        
        # Add keyword tags
        for keyword in jira_data['summary']['common_keywords'][:5]:
            tags.append(f"keyword-{keyword}")
        
        return tags
    
    def _analyze_jira_severity(self, jira_data: Dict) -> List[str]:
        """Analyze severity levels based on Jira data"""
        severities = ["MEDIUM_RISK"]  # Default
        
        # Add HIGH_RISK if there are many security or critical issues
        security_count = jira_data['summary']['categories'].get('security', 0)
        if security_count > 0:
            severities.append("HIGH_RISK")
        
        # Add LOW_RISK if most issues are minor
        total_tickets = jira_data['total_tickets']
        if total_tickets > 50:  # Large dataset
            severities.append("LOW_RISK")
        
        return severities
    
    def _create_matching_tickets_section(self, tickets: List[Dict]) -> str:
        """Create the matching JIRA tickets section for the prompt"""
        tickets_section = ""
        
        for i, ticket in enumerate(tickets, 1):
            # Extract key information from comments
            comments = ticket['comments']
            title = ticket['title']
            jira_id = ticket['jira_id']
            
            # Try to extract resolution information from comments
            resolution_info = self._extract_resolution_info(comments)
            
            tickets_section += f"""
{i}. **{jira_id}: {title}**
   - **Comments:** {comments[:200]}{'...' if len(comments) > 200 else ''}
   - **RCA:** {resolution_info['rca']}
   - **Solution:** {resolution_info['solution']}
"""
        
        return tickets_section
    
    def _extract_resolution_info(self, comments: str) -> Dict[str, str]:
        """Extract resolution information from Jira comments"""
        comments_lower = comments.lower()
        
        # Try to identify RCA and solution patterns
        rca_patterns = [
            'rca:', 'root cause:', 'root cause analysis:', 'cause:', 'reason:'
        ]
        solution_patterns = [
            'solution:', 'fix:', 'resolved:', 'workaround:', 'action taken:'
        ]
        
        rca = "Not specified"
        solution = "Not specified"
        
        # Look for RCA patterns
        for pattern in rca_patterns:
            if pattern in comments_lower:
                # Try to extract text after the pattern
                start_idx = comments_lower.find(pattern) + len(pattern)
                end_idx = min(start_idx + 100, len(comments))
                rca = comments[start_idx:end_idx].strip()
                if len(comments) > start_idx + 100:
                    rca += "..."
                break
        
        # Look for solution patterns
        for pattern in solution_patterns:
            if pattern in comments_lower:
                # Try to extract text after the pattern
                start_idx = comments_lower.find(pattern) + len(pattern)
                end_idx = min(start_idx + 100, len(comments))
                solution = comments[start_idx:end_idx].strip()
                if len(comments) > start_idx + 100:
                    solution += "..."
                break
        
        # If no specific patterns found, use the first part of comments
        if rca == "Not specified" and solution == "Not specified":
            # Try to infer from common resolution keywords
            if any(word in comments_lower for word in ['restart', 'reboot', 'bounce']):
                solution = "System restart/reboot required"
            elif any(word in comments_lower for word in ['patch', 'update', 'upgrade']):
                solution = "Application patch or update"
            elif any(word in comments_lower for word in ['config', 'configuration']):
                solution = "Configuration change required"
            elif any(word in comments_lower for word in ['memory', 'oom', 'out of memory']):
                rca = "Memory/resource exhaustion"
                solution = "Increase memory allocation or restart services"
        
        return {
            'rca': rca,
            'solution': solution
        }
    
    def _create_historical_tickets_reference(self, tickets: List[Dict]) -> str:
        """Create historical tickets reference for the remediation template"""
        reference_section = ""
        
        for ticket in tickets:
            jira_id = ticket['jira_id']
            title = ticket['title']
            category = ticket['analysis']['category']
            keywords = ', '.join(ticket['analysis']['keywords'][:3])
            
            reference_section += f"""
- **{jira_id}**: {title} (Category: {category}, Keywords: {keywords})"""
        
        return reference_section
    
    def _generate_jira_analysis_copilot_prompt(self, jira_data: Dict) -> str:
        """Generate AI Copilot prompt for Jira data analysis"""
        
        # Create the matching JIRA tickets section
        matching_tickets_section = self._create_matching_tickets_section(jira_data['tickets'])
        
        return f"""# AI Copilot Prompt: Root Cause Analysis for Jira Data

## CONTEXT:
You are analyzing {jira_data['total_tickets']} Jira tickets to identify root causes and provide remediation suggestions.

## DATA SUMMARY:
- **Total Tickets**: {jira_data['total_tickets']}
- **Issue Categories**: {jira_data['summary']['categories']}
- **Common Keywords**: {jira_data['summary']['common_keywords'][:10]}
- **Sentiment Distribution**: {jira_data['summary']['sentiment_distribution']}

## MATCHING JIRA TICKETS:
{matching_tickets_section}

## YOUR TASK:
1. **Pattern Recognition**: Identify recurring patterns in the ticket data above
2. **Root Cause Analysis**: Determine underlying causes of issues based on historical tickets
3. **Prioritization**: Rank issues by impact and frequency
4. **Remediation Suggestions**: Provide specific, actionable solutions based on successful resolutions

## ANALYSIS FRAMEWORK:
- **Frequency Analysis**: Which issues occur most often in the historical data?
- **Category Clustering**: Group similar issues together based on the tickets above
- **Success Patterns**: What solutions worked for similar issues?
- **Impact Assessment**: Which issues have the highest business impact?

## EXPECTED OUTPUT FORMAT:
When a user reports a new issue, provide:

### Matching JIRA Tickets:
[List relevant historical tickets from the data above]

### Proposed Solution:
1. **Immediate Actions:**
   - [Specific actions based on successful historical resolutions]
2. **Monitoring:**
   - [What to monitor based on past issues]
3. **Preventive Measures:**
   - [How to prevent similar issues based on historical data]

## INSTRUCTIONS:
- Always reference specific JIRA ticket IDs when providing solutions
- Use successful resolution patterns from historical data
- Provide context-aware recommendations based on similar past issues
- Include root cause analysis (RCA) insights from historical tickets

Focus on actionable insights that leverage the historical ticket data to provide immediate, context-aware solutions."""

    def _generate_jira_remediation_template(self, jira_data: Dict) -> str:
        """Generate remediation template for Jira data"""
        
        # Create the historical tickets reference
        historical_tickets_section = self._create_historical_tickets_reference(jira_data['tickets'])
        
        return f"""# Root Cause Explorer - Remediation Template

## Executive Summary
Based on analysis of {jira_data['total_tickets']} Jira tickets, this template provides a systematic approach to addressing root causes and preventing recurring issues.

## Historical Data Reference
{historical_tickets_section}

## Issue Categories Identified
{chr(10).join([f"- **{category}**: {count} tickets" for category, count in jira_data['summary']['categories'].items()])}

## Common Patterns
{chr(10).join([f"- {keyword}" for keyword in jira_data['summary']['common_keywords'][:10]])}

## Remediation Strategy

### Phase 1: Immediate Actions (Week 1-2)
1. **High-Frequency Issues**
   - Identify top 3 most common issues from historical data
   - Implement quick fixes for critical paths (reference similar tickets above)
   - Add monitoring for early detection

2. **Security Issues**
   - Review and patch security vulnerabilities (see security tickets above)
   - Implement additional security checks
   - Update authentication mechanisms

### Phase 2: Systematic Improvements (Week 3-6)
1. **Code Quality**
   - Implement automated testing for common failure points
   - Add code review checklists based on historical issues
   - Enhance error handling

2. **Infrastructure**
   - Optimize performance bottlenecks (reference performance tickets)
   - Implement proper logging and monitoring
   - Add health checks and alerts

### Phase 3: Long-term Prevention (Month 2-3)
1. **Process Improvements**
   - Establish incident response procedures
   - Create knowledge base for common issues (using historical data above)
   - Implement regular health assessments

2. **Monitoring & Alerting**
   - Set up proactive monitoring
   - Create escalation procedures
   - Implement predictive analytics

## Success Metrics
- 50% reduction in recurring issues within 30 days
- 75% faster resolution time for known issues
- 90% reduction in critical incidents

## Template Usage
This template can be customized based on:
- Specific issue categories in your data
- Business priorities and constraints
- Available resources and timeline
- Technology stack and architecture

## AI Copilot Integration
Use the generated AI prompts to:
- Query specific issue patterns from historical data
- Get remediation suggestions for new tickets (reference similar tickets above)
- Analyze trends and predict future issues
- Generate automated reports and insights

## How to Use This Template
1. When a new issue is reported, search the historical tickets above for similar issues
2. Reference the RCA and Solution from matching tickets
3. Apply proven solutions from historical data
4. Update this template with new resolution patterns"""
    
    def _generate_root_cause_explorer_copilot_prompt(self) -> str:
        """Generate AI Copilot prompt for Root Cause Explorer"""
        return """# AI Copilot Prompt: Root Cause Explorer

## CONTEXT:
You are a Root Cause Explorer AI assistant designed to analyze historical ticket data, identify patterns, and provide actionable remediation suggestions.

## CAPABILITIES:
- **Historical Analysis**: Process large datasets of tickets and comments
- **Pattern Recognition**: Identify recurring issues and root causes
- **Smart Recommendations**: Provide context-aware remediation suggestions
- **Automated Insights**: Generate reports and trend analysis

## WORKFLOW:
1. **Data Ingestion**: Accept Excel files with Jira data (ID, Title, Comments)
2. **Pattern Analysis**: Identify common issues, keywords, and categories
3. **Root Cause Identification**: Determine underlying causes
4. **Remediation Generation**: Create specific, actionable solutions
5. **Knowledge Base Creation**: Build searchable repository of solutions

## QUERY TYPES SUPPORTED:
- "Show me all security-related issues from the last 30 days"
- "What are the most common performance problems?"
- "Generate remediation steps for authentication failures"
- "Analyze trends in database connectivity issues"
- "Create a prevention strategy for UI bugs"

## EXPECTED RESPONSES:
- **Immediate**: Direct answers with specific solutions
- **Comprehensive**: Detailed analysis with multiple approaches
- **Actionable**: Step-by-step remediation instructions
- **Contextual**: Tailored to your specific technology stack

## SAMPLE INTERACTION:
```
User: "I'm seeing repeated authentication failures in our system"
AI: "Based on your historical data, authentication failures occur in 3 main patterns:
1. Token expiration (40% of cases) - Solution: Implement refresh token logic
2. Invalid credentials (35% of cases) - Solution: Add credential validation
3. Network timeouts (25% of cases) - Solution: Implement retry mechanisms
[Detailed remediation steps follow]"
```

## DATA REQUIREMENTS:
- Jira ID, Title, and Comments (minimum)
- Additional metadata (priority, assignee, dates) preferred
- Historical data for better pattern recognition

## BENEFITS:
- **Time Savings**: Reduce manual analysis from hours to minutes
- **Accuracy**: AI-powered insights reduce human error
- **Scalability**: Handle large volumes of data effortlessly
- **Consistency**: Standardized analysis across all tickets

Use this template to transform your ticket data into actionable intelligence!"""

    def _generate_root_cause_explorer_remediation_template(self) -> str:
        """Generate remediation template for Root Cause Explorer"""
        return """# Root Cause Explorer - Implementation Guide

## Overview
The Root Cause Explorer automates ticket analysis, saving significant time and cost by reducing manual effort from hours to minutes. It improves accuracy and provides actionable insights, enabling teams to quickly resolve recurring issues.

## Implementation Steps

### 1. Data Preparation
- Export Jira data to Excel with columns: Jira ID, Jira Title, Jira Comments
- Include additional metadata if available (Priority, Assignee, Created Date)
- Ensure data is clean and properly formatted

### 2. Knowledge Base Creation
- Upload Excel file through the Knowledge Base interface
- System automatically processes and categorizes data
- AI analyzes patterns and creates searchable repository

### 3. Query Interface Setup
- Use natural language queries to search historical data
- Ask questions like:
  - "What are the most common issues in the last quarter?"
  - "Show me all authentication-related problems"
  - "Generate remediation steps for performance issues"

### 4. Automated Analysis
- **Pattern Recognition**: Identify recurring issues and root causes
- **Trend Analysis**: Track issue frequency and impact over time
- **Categorization**: Automatically classify issues by type and severity
- **Sentiment Analysis**: Understand resolution success rates

## Benefits for Different Teams

### Developers
- Quick access to similar past issues and solutions
- Automated code suggestions based on historical fixes
- Pattern recognition to prevent recurring bugs

### Testers
- Identify test coverage gaps based on historical issues
- Generate test cases for common failure scenarios
- Prioritize testing based on issue frequency

### Support Teams
- Faster issue resolution with historical context
- Automated escalation based on issue patterns
- Knowledge base for common troubleshooting steps

## Success Metrics
- **Time Reduction**: 75% faster issue resolution
- **Accuracy Improvement**: 90% reduction in repeated triages
- **Productivity Gain**: Teams focus on higher-value tasks
- **Knowledge Retention**: Preserve institutional knowledge

## Advanced Features
- **Predictive Analysis**: Forecast potential issues
- **Automated Reports**: Generate regular insights
- **Integration**: Connect with existing tools and workflows
- **Customization**: Tailor analysis to specific business needs

## Best Practices
1. **Regular Updates**: Keep knowledge base current with new tickets
2. **Quality Data**: Ensure clean, comprehensive ticket data
3. **Team Training**: Educate teams on effective query techniques
4. **Continuous Improvement**: Refine analysis based on feedback

## Getting Started
1. Upload your Excel file with Jira data
2. Review the generated analysis and insights
3. Start querying with natural language questions
4. Implement suggested remediations
5. Track improvements and iterate

Transform your historical ticket data into a powerful root cause analysis engine!"""
    
    def _generate_sql_injection_copilot_prompt(self) -> str:
        """Generate AI Copilot prompt for SQL injection remediation"""
        return """# AI Copilot Prompt: SQL Injection Remediation

## CONTEXT:
You are fixing SQL injection vulnerabilities in code. SQL injection occurs when user input is directly concatenated into SQL queries without proper sanitization.

## VULNERABILITY PATTERN:
```python
# VULNERABLE CODE:
query = f"SELECT * FROM users WHERE id = {user_id}"
cursor.execute(query)
```

## YOUR TASK:
1. Identify SQL injection vulnerabilities
2. Replace with parameterized queries
3. Add input validation
4. Implement proper error handling
5. Add security logging

## SECURE PATTERNS:
```python
# SECURE: Parameterized queries
query = "SELECT * FROM users WHERE id = %s"
cursor.execute(query, (user_id,))

# SECURE: Input validation
if not user_id.isdigit():
    raise ValueError("Invalid user ID")
```

## EXPECTED OUTPUT:
Provide secure, production-ready code with proper error handling and validation."""
    
    def _generate_sql_injection_remediation_template(self) -> str:
        """Generate SQL injection remediation template"""
        return """# SQL Injection Remediation Template

## Overview
SQL injection vulnerabilities occur when user input is directly concatenated into SQL queries without proper sanitization.

## Common Vulnerable Patterns
```python
# VULNERABLE
query = f"SELECT * FROM users WHERE id = {user_id}"
cursor.execute(query)

# VULNERABLE
query = "SELECT * FROM users WHERE name = '" + username + "'"
cursor.execute(query)
```

## Secure Implementation
```python
# SECURE: Parameterized queries
query = "SELECT * FROM users WHERE id = %s"
cursor.execute(query, (user_id,))

# SECURE: Input validation
def validate_user_id(user_id):
    if not user_id.isdigit():
        raise ValueError("Invalid user ID")
    return int(user_id)

# SECURE: Error handling
try:
    user_id = validate_user_id(user_id)
    query = "SELECT * FROM users WHERE id = %s"
    cursor.execute(query, (user_id,))
    result = cursor.fetchone()
except ValueError as e:
    logger.error(f"Validation error: {e}")
    return None
except Exception as e:
    logger.error(f"Database error: {e}")
    return None
```

## Prevention Strategies
1. **Always use parameterized queries**
2. **Validate and sanitize all inputs**
3. **Implement least privilege database access**
4. **Use stored procedures when possible**
5. **Add comprehensive logging and monitoring**

## Testing
```python
def test_sql_injection_prevention():
    # Test malicious input
    malicious_input = "1; DROP TABLE users; --"
    result = get_user_by_id(malicious_input)
    assert result is None  # Should be handled gracefully
```

## Monitoring
- Log all database queries
- Monitor for unusual query patterns
- Set up alerts for potential injection attempts
- Regular security audits

This template provides a comprehensive approach to preventing and fixing SQL injection vulnerabilities."""
    
    def get_all_templates(self) -> List[Dict]:
        """Get all templates"""
        try:
            templates_data = self.db.get_all_templates()
            return templates_data
        except Exception as e:
            logger.error(f"Error getting all templates: {e}")
            return []
    
    def get_template_by_id(self, template_id: str) -> Optional[Dict]:
        """Get template by ID"""
        try:
            template_data = self.db.get_template(template_id)
            return template_data
        except Exception as e:
            logger.error(f"Error getting template by ID: {e}")
            return None
    
    def get_templates_by_category(self, category: str) -> List[Dict]:
        """Get templates by category"""
        try:
            templates_data = self.db.get_templates_by_category(category)
            return templates_data
        except Exception as e:
            logger.error(f"Error getting templates by category: {e}")
            return []
    
    def search_templates(self, query: str) -> List[Dict]:
        """Search templates by query"""
        try:
            templates_data = self.db.search_templates(query)
            return templates_data
        except Exception as e:
            logger.error(f"Error searching templates: {e}")
            return []

# Global instance
knowledge_base_manager = KnowledgeBaseManager()
