#!/usr/bin/env python3
"""
Asynchronous Repository Scanner Worker
"""

import threading
import time
import tempfile
import subprocess
import shutil
import os
import re
from pathlib import Path
from typing import Dict, List
import logging
from job_manager import job_manager, JobStatus

logger = logging.getLogger(__name__)

class AsyncRepoScanner:
    """Asynchronous repository scanner worker"""
    
    def __init__(self):
        self.active_jobs = {}
        self.worker_threads = {}
    
    def start_scan_job(self, job_id: str, scan_data: Dict):
        """Start a repository scan job in a background thread"""
        if job_id in self.active_jobs:
            logger.warning(f"Job {job_id} is already running")
            return
        
        # Mark job as active
        self.active_jobs[job_id] = scan_data
        
        # Start worker thread
        worker_thread = threading.Thread(
            target=self._scan_repository_worker,
            args=(job_id, scan_data),
            daemon=True
        )
        worker_thread.start()
        
        self.worker_threads[job_id] = worker_thread
        logger.info(f"Started async scan job {job_id}")
    
    def _scan_repository_worker(self, job_id: str, scan_data: Dict):
        """Worker function that performs the actual repository scanning"""
        try:
            # Update status to running
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Starting repository scan...")
            
            repo_url = scan_data.get('repo_url')
            repo_token = scan_data.get('repo_token')
            scan_id = scan_data.get('scan_id')
            project_id = scan_data.get('project_id')
            project_name = scan_data.get('project_name')
            ait_tag = scan_data.get('ait_tag')
            spk_tag = scan_data.get('spk_tag')
            repo_name = scan_data.get('repo_name')
            
            # Extract repository information
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Analyzing repository URL...")
            
            repo_type, owner, repo, server_url = self._parse_repo_url(repo_url)
            logger.info(f"Parsed repository URL: type={repo_type}, owner={owner}, repo={repo}, server={server_url}")
            
            if not repo_type:
                raise ValueError("Invalid repository URL format")
            
            # Clone repository
            job_manager.update_job_status(job_id, JobStatus.RUNNING, "Cloning repository...")
            
            # Use job_id in temp directory name to avoid conflicts
            temp_dir = tempfile.mkdtemp(prefix=f"repo_scan_{job_id}_")
            repo_path = os.path.join(temp_dir, repo)
            
            try:
                # Clone the repository
                clone_url, clone_cmd = self._get_clone_command(repo_type, owner, repo, repo_token, server_url)
                
                # Change to temp directory and clone there
                original_cwd = os.getcwd()
                os.chdir(temp_dir)
                
                result = subprocess.run(clone_cmd, capture_output=True, text=True, timeout=300)
                
                # Change back to original directory
                os.chdir(original_cwd)
                
                if result.returncode != 0:
                    error_msg = result.stderr.strip()
                    raise Exception(f"Failed to clone repository: {error_msg}")
                
                # Process repository files
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Processing repository files...")
                
                base_upload_dir = Path('uploaded_projects') / scan_id / 'original'
                base_upload_dir.mkdir(parents=True, exist_ok=True)
                
                file_paths = []
                uploaded_files_for_prompts = []
                
                # Walk through repository and collect files
                supported_extensions = {
                    '.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.c', '.cpp', '.h', '.hpp',
                    '.cs', '.php', '.rb', '.go', '.rs', '.swift', '.kt', '.scala', '.clj',
                    '.html', '.htm', '.css', '.scss', '.sass', '.less', '.xml', '.json',
                    '.yaml', '.yml', '.toml', '.ini', '.cfg', '.conf', '.sh', '.bash',
                    '.ps1', '.bat', '.cmd', '.sql', '.md', '.txt', '.log', '.config',
                    '.properties', '.env', '.dockerfile', '.dockerignore', '.gitignore',
                    '.gitattributes', '.editorconfig', '.eslintrc', '.prettierrc',
                    '.babelrc', '.webpack.config.js', '.rollup.config.js', '.vite.config.js',
                    '.jest.config.js', '.karma.conf.js', '.protractor.conf.js',
                    '.angular.json', '.package.json', '.composer.json', '.pom.xml',
                    '.build.gradle', '.gradle.properties', '.sbt', '.mix.exs',
                    '.Gemfile', '.Rakefile', '.Procfile', '.app.json', '.app.yaml',
                    '.requirements.txt', '.setup.py', '.pyproject.toml', '.Cargo.toml',
                    '.go.mod', '.go.sum', '.package-lock.json', '.yarn.lock', '.pnpm-lock.yaml'
                }
                
                total_files = 0
                processed_files = 0
                skipped_files = 0
                max_files_to_process = 1000  # Limit to prevent very long scans
                
                for root, dirs, files in os.walk(repo_path):
                    # Skip common directories that don't contain source code
                    dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules', '.venv', 'venv', '__pycache__', 
                                                           '.pytest_cache', '.mypy_cache', '.coverage', 'dist', 
                                                           'build', 'target', 'bin', 'obj', '.vs', '.idea', 
                                                           '.vscode', 'coverage', '.nyc_output', '.next', 
                                                           '.nuxt', '.output', '.cache', '.parcel-cache'}]
                    
                    for file in files:
                        total_files += 1
                        file_path = os.path.join(root, file)
                        relative_path = os.path.relpath(file_path, repo_path)
                        
                        # Check file extension
                        file_ext = os.path.splitext(file)[1].lower()
                        if file_ext not in supported_extensions:
                            skipped_files += 1
                            continue
                        
                        # Skip files that are likely binary or too large
                        try:
                            file_size = os.path.getsize(file_path)
                            if file_size > 1024 * 1024:  # Skip files > 1MB
                                skipped_files += 1
                                continue
                            
                            # Try to read file content
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                            
                            # Skip files that are mostly binary (high ratio of null bytes or control characters)
                            if len(content) > 0:
                                binary_ratio = sum(1 for c in content if ord(c) < 32 and c not in '\n\r\t') / len(content)
                                if binary_ratio > 0.1:  # More than 10% control characters
                                    skipped_files += 1
                                    continue
                            
                            # Save file
                            target_path = base_upload_dir / relative_path
                            target_path.parent.mkdir(parents=True, exist_ok=True)
                            
                            with open(target_path, 'w', encoding='utf-8') as f:
                                f.write(content)
                            
                            file_paths.append({
                                'id': f"file_{len(file_paths)}",
                                'name': relative_path,
                                'path': str(target_path),
                                'type': self._get_file_language(relative_path)
                            })
                            
                            uploaded_files_for_prompts.append({
                                'file_path': str(target_path),
                                'content': content,
                                'file_name': relative_path
                            })
                            
                            processed_files += 1
                            
                            # Stop processing if we've reached the limit
                            if processed_files >= max_files_to_process:
                                logger.info(f"Reached file processing limit of {max_files_to_process} files")
                                break
                            
                        except (UnicodeDecodeError, PermissionError, OSError) as e:
                            skipped_files += 1
                            logger.debug(f"Skipped file {relative_path}: {e}")
                            continue
                    
                    # Break out of the outer loop if we've reached the limit
                    if processed_files >= max_files_to_process:
                        break
                
                logger.info(f"Repository processing complete: {processed_files} files processed, {skipped_files} files skipped out of {total_files} total files")
                
                if not file_paths:
                    raise Exception(f"No readable files found in repository. Total files: {total_files}, Processed: {processed_files}, Skipped: {skipped_files}")
                
                # Perform threat analysis
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Analyzing files for security threats...")
                
                # Import here to avoid circular imports
                from dashboard_api_enhanced import perform_enhanced_file_scan, generate_vscode_copilot_prompts
                
                # Add timeout to prevent hanging using threading
                import concurrent.futures
                
                def run_scan():
                    return perform_enhanced_file_scan(
                        scan_id=scan_id,
                        project_id=project_id,
                        project_name=project_name,
                        file_paths=file_paths,
                        scan_type='repository',
                        ait_tag=ait_tag,
                        spk_tag=spk_tag,
                        repo_name=repo_name
                    )
                
                # Run scan with timeout (5 minutes)
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(run_scan)
                    try:
                        scan_result = future.result(timeout=300)  # 5 minutes timeout
                    except concurrent.futures.TimeoutError:
                        raise TimeoutError("File analysis timed out after 5 minutes")
                
                # Add repository-specific information
                scan_result['repo_info'] = {
                    'repo_type': repo_type,
                    'owner': owner,
                    'repo': repo,
                    'url': repo_url,
                    'files_count': len(file_paths),
                    'is_private': bool(repo_token),
                    'auth_used': bool(repo_token),
                    'server_url': server_url if repo_type == 'bitbucket_server' else None
                }
                
                # Generate VS Code Copilot prompts
                job_manager.update_job_status(job_id, JobStatus.RUNNING, "Generating remediation prompts...")
                
                try:
                    prompts_data = generate_vscode_copilot_prompts(scan_id, uploaded_files_for_prompts)
                    scan_result['prompts_generated'] = True
                    scan_result['prompts_data'] = prompts_data
                except Exception as e:
                    logger.error(f"Error generating prompts: {e}")
                    scan_result['prompts_generated'] = False
                    scan_result['prompts_error'] = str(e)
                
                # Mark job as completed
                # Get the correct threat count from the summary
                threat_count = scan_result.get('summary', {}).get('total_issues', 0)
                
                # Debug logging to track threat count consistency
                logger.info(f"Job {job_id} - Scan result summary: {scan_result.get('summary', {})}")
                logger.info(f"Job {job_id} - Threat count from summary: {threat_count}")
                logger.info(f"Job {job_id} - Files scanned: {len(file_paths)}")
                
                job_manager.update_job_status(
                    job_id, 
                    JobStatus.COMPLETED, 
                    f"Scan completed successfully. Found {threat_count} threats in {len(file_paths)} files.",
                    result_data=scan_result
                )
                
                logger.info(f"Job {job_id} completed successfully")
                
            finally:
                # Clean up temporary directory
                try:
                    shutil.rmtree(temp_dir)
                except Exception as e:
                    logger.warning(f"Failed to clean up temp directory: {e}")
                
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Job {job_id} failed: {error_msg}")
            
            job_manager.update_job_status(
                job_id, 
                JobStatus.FAILED, 
                f"Scan failed: {error_msg}",
                error_message=error_msg
            )
        
        finally:
            # Clean up
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            if job_id in self.worker_threads:
                del self.worker_threads[job_id]
    
    def _parse_repo_url(self, repo_url: str) -> tuple:
        """Parse repository URL and return (repo_type, owner, repo, server_url)"""
        # GitHub patterns
        github_pattern = r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'
        github_match = re.match(github_pattern, repo_url.strip())
        
        # Bitbucket patterns
        bitbucket_cloud_pattern = r'https://bitbucket\.org/([^/]+)/([^/]+?)(?:\.git)?/?$'
        bitbucket_server_pattern = r'https://([^/]+)/scm/([^/]+)/([^/]+?)(?:\.git)?/?$'
        
        bitbucket_cloud_match = re.match(bitbucket_cloud_pattern, repo_url.strip())
        bitbucket_server_match = re.match(bitbucket_server_pattern, repo_url.strip())
        
        if github_match:
            return 'github', github_match.group(1), github_match.group(2), None
        elif bitbucket_cloud_match:
            return 'bitbucket_cloud', bitbucket_cloud_match.group(1), bitbucket_cloud_match.group(2), None
        elif bitbucket_server_match:
            return 'bitbucket_server', bitbucket_server_match.group(2), bitbucket_server_match.group(3), bitbucket_server_match.group(1)
        
        return None, None, None, None
    
    def _get_clone_command(self, repo_type: str, owner: str, repo: str, repo_token: str, server_url: str = None) -> tuple:
        """Get git clone command for repository type"""
        if repo_type == 'github':
            if repo_token:
                clone_url = f"https://{repo_token}@github.com/{owner}/{repo}.git"
            else:
                clone_url = f"https://github.com/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
            
        elif repo_type == 'bitbucket_cloud':
            if repo_token:
                clone_url = f"https://{repo_token}@bitbucket.org/{owner}/{repo}.git"
            else:
                clone_url = f"https://bitbucket.org/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
            
        elif repo_type == 'bitbucket_server':
            if repo_token:
                clone_url = f"https://{repo_token}@{server_url}/scm/{owner}/{repo}.git"
            else:
                clone_url = f"https://{server_url}/scm/{owner}/{repo}.git"
            return clone_url, ['git', 'clone', clone_url]
        
        raise ValueError(f"Unsupported repository type: {repo_type}")
    
    def _get_file_language(self, filename: str) -> str:
        """Determine file language based on extension"""
        ext = filename.lower().split('.')[-1] if '.' in filename else ''
        
        language_map = {
            'py': 'python', 'js': 'javascript', 'ts': 'typescript', 'jsx': 'javascript',
            'tsx': 'typescript', 'java': 'java', 'cpp': 'cpp', 'c': 'c', 'cs': 'csharp',
            'php': 'php', 'rb': 'ruby', 'go': 'go', 'rs': 'rust', 'swift': 'swift',
            'kt': 'kotlin', 'scala': 'scala', 'html': 'html', 'css': 'css', 'scss': 'scss',
            'sass': 'sass', 'less': 'less', 'json': 'json', 'xml': 'xml', 'yaml': 'yaml',
            'yml': 'yaml', 'toml': 'toml', 'ini': 'ini', 'cfg': 'ini', 'conf': 'ini',
            'sh': 'bash', 'bash': 'bash', 'zsh': 'bash', 'fish': 'bash', 'ps1': 'powershell',
            'bat': 'batch', 'cmd': 'batch', 'sql': 'sql', 'md': 'markdown', 'txt': 'text',
            'log': 'text'
        }
        
        return language_map.get(ext, 'text')
    
    def get_active_jobs_count(self) -> int:
        """Get number of active jobs"""
        return len(self.active_jobs)
    
    def cancel_job(self, job_id: str) -> bool:
        """Cancel a running job"""
        # Check if job is active in our list
        if job_id in self.active_jobs:
            job_manager.update_job_status(job_id, JobStatus.CANCELLED, "Job cancelled by user")
            
            # Clean up
            if job_id in self.active_jobs:
                del self.active_jobs[job_id]
            if job_id in self.worker_threads:
                del self.worker_threads[job_id]
            
            return True
        
        # If not in active jobs, check if it exists in job manager and is still running
        try:
            job_status = job_manager.get_job_status(job_id)
            if job_status and job_status.get('status') == JobStatus.RUNNING:
                job_manager.update_job_status(job_id, JobStatus.CANCELLED, "Job cancelled by user")
                return True
        except:
            pass
        
        return False

# Global async scanner instance
async_repo_scanner = AsyncRepoScanner()
