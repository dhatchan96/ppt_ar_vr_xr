# ThreatGuard Pro - Security Scanning System

A comprehensive security scanning system with AI-powered threat detection, automated remediation, and VSCode integration.

## 🏗️ System Architecture

ThreatGuard Pro consists of three main components:

- **Backend API** (Python Flask) - Core scanning engine and data management
- **Frontend Dashboard** (React) - Web-based user interface
- **VSCode Extension** (TypeScript) - IDE integration for real-time scanning

## 📋 Prerequisites

Before setting up ThreatGuard Pro, ensure you have the following installed:

### System Requirements
- **Python 3.8+**
- **Node.js 16+** and npm
- **Git**
- **VSCode** (for extension development/testing)

### Python Dependencies
- Flask
- Flask-CORS
- requests
- json5
- pathlib

### Node.js Dependencies
- React 18+
- Axios
- Bootstrap 5
- react-icons

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd dashboard_api_enhanced
```

### 2. Backend Setup

#### Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install flask flask-cors requests json5
```

#### Start the Backend Server

```bash
# Navigate to backend directory
cd dashboard_api_enhanced

# Start the Flask server
python dashboard_api_enhanced.py
```

The backend will start on `http://localhost:5000` by default.

**Backend Features:**
- RESTful API endpoints for scanning
- Threat detection and analysis
- Scan history management
- AI-powered remediation suggestions
- Data persistence with JSON storage

### 3. Frontend Setup

#### Install Dependencies

```bash
# Navigate to frontend directory
cd security_scanner_dashboard_react_GC_TS

# Install Node.js dependencies
npm install
```

#### Start the Frontend Development Server

```bash
# Start the React development server
npm start
```

The frontend will start on `http://localhost:3000` by default.

**Frontend Features:**
- Real-time dashboard with security metrics
- Scan history visualization
- Threat analysis and reporting
- VSCode scan integration
- Responsive design with Bootstrap

### 4. VSCode Extension Setup

#### Install Dependencies

```bash
# Navigate to VSCode extension directory
cd vscode-extension

# Install TypeScript dependencies
npm install

# Install VSCode extension development tools
npm install -g @vscode/vsce
```

#### Compile the Extension

```bash
# Compile TypeScript to JavaScript
npm run compile

# Package the extension (optional)
vsce package
```

#### Install the Extension

1. **For Development:**
   ```bash
   # Press F5 in VSCode to run the extension in a new Extension Development Host window
   ```

2. **For Production:**
   - Package the extension: `vsce package`
   - Install the generated `.vsix` file in VSCode

**Extension Features:**
- Real-time workspace scanning
- Threat detection in VSCode
- Scan history in sidebar
- Quick threat remediation
- File-level security analysis

## 🔧 Configuration

### Backend Configuration

The backend uses several configuration files:

- `scan_history.json` - Stores scan results
- `threats.json` - Stores detected threats
- `uploaded_projects/` - Directory for VSCode scan data

### Frontend Configuration

Update API endpoints in `src/api/api.js`:

```javascript
const API_BASE_URL = 'http://localhost:5000';
```

### VSCode Extension Configuration

The extension automatically connects to the backend API. Ensure the backend is running on the expected port.

## 📖 API Endpoints

### Core Endpoints

- `GET /api/health` - Health check
- `POST /api/scan` - Perform security scan
- `GET /api/threats` - Get detected threats
- `GET /api/scan-history` - Get scan history
- `GET /api/metrics` - Get system metrics

### VSCode Extension Endpoints

- `POST /api/vscode-agent/save-scan-data` - Save VSCode scan data
- `GET /api/scan-history` - Get combined scan history

## 🧪 Testing

### Backend Testing

```bash
# Run backend tests
python test_backend_scan_response.py
```

### Frontend Testing

```bash
# Run frontend tests
npm test
```

### VSCode Extension Testing

1. Open the extension in VSCode
2. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS)
3. Run "ThreatGuard: Scan Workspace" or "ThreatGuard: Scan File"

## 🔍 Usage Guide

### 1. Backend Usage

Start the backend server and it will be ready to accept scan requests:

```bash
python dashboard_api_enhanced.py
```

### 2. Frontend Usage

1. Open `http://localhost:3000` in your browser
2. Navigate through different sections:
   - **Dashboard** - Overview of security metrics
   - **Scan History** - View all scan results
   - **VSCode Scans** - View VSCode extension scans
   - **Threat Issues** - Detailed threat analysis

### 3. VSCode Extension Usage

1. **Scan Workspace:**
   - Open Command Palette (`Ctrl+Shift+P`)
   - Run "ThreatGuard: Scan Workspace"
   - View results in the Threats sidebar

2. **Scan Individual File:**
   - Right-click on a file in Explorer
   - Select "ThreatGuard: Scan File"
   - View results in the Threats sidebar

3. **View Scan History:**
   - Open the Scans sidebar
   - Browse through previous scan results
   - Click on scans for detailed information

## 🛠️ Development

### Backend Development

```bash
# Enable debug mode
export FLASK_ENV=development
export FLASK_DEBUG=1

# Run with auto-reload
python dashboard_api_enhanced.py
```

### Frontend Development

```bash
# Start development server with hot reload
npm start

# Build for production
npm run build
```

### VSCode Extension Development

```bash
# Watch for changes and recompile
npm run watch

# Package for distribution
vsce package
```

## 📁 Project Structure

```
dashboard_api_enhanced/
├── dashboard_api_enhanced.py          # Main backend API
├── scan_history.json                  # Scan data storage
├── threats.json                       # Threat data storage
├── uploaded_projects/                 # VSCode scan data
├── security_scanner_dashboard_react_GC_TS/  # Frontend React app
│   ├── src/
│   │   ├── components/               # React components
│   │   ├── api/                      # API client
│   │   └── App.js                    # Main app component
│   └── package.json
└── vscode-extension/                 # VSCode extension
    ├── src/
    │   ├── extension.ts              # Main extension file
    │   ├── providers/                # Tree view providers
    │   └── api/                      # API client
    └── package.json
```

## 🔒 Security Features

- **Threat Detection:** Identifies security vulnerabilities and malicious code
- **Logic Bomb Detection:** Detects potentially harmful code patterns
- **AI-Powered Analysis:** Uses advanced algorithms for threat assessment
- **Real-time Scanning:** Continuous monitoring in VSCode
- **Automated Remediation:** Suggests fixes for detected issues

## 🐛 Troubleshooting

### Common Issues

1. **Backend Connection Failed:**
   - Ensure backend is running on port 5000
   - Check firewall settings
   - Verify CORS configuration

2. **Frontend Not Loading:**
   - Check if React dev server is running
   - Verify API endpoint configuration
   - Check browser console for errors

3. **VSCode Extension Not Working:**
   - Ensure extension is compiled (`npm run compile`)
   - Check VSCode developer console for errors
   - Verify backend is accessible from extension

4. **Scan Data Not Showing:**
   - Check backend logs for errors
   - Verify data files are writable
   - Ensure proper file permissions

### Debug Mode

Enable debug logging by setting environment variables:

```bash
export THREATGUARD_DEBUG=1
```

## 📞 Support

For issues and questions:

1. Check the troubleshooting section above
2. Review the console logs for error messages
3. Ensure all prerequisites are met
4. Verify network connectivity between components

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

---

**ThreatGuard Pro** - Protecting your code, one scan at a time! 🔒

