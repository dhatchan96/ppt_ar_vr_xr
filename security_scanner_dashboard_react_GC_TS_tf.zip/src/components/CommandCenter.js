import React, { useState, useEffect } from "react";
import ThreatGuardDashboard from "./ThreatGuardDashboard";
import VSCodeScans from "./VSCodeScans";
import {
  FaCloud,
  FaDesktop,
  FaServer
} from "react-icons/fa";

const CommandCenter = () => {
  const [activeTab, setActiveTab] = useState("remote");

  // Render Remote Self Service Tab - Use existing ThreatGuardDashboard
  const renderRemoteTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-primary text-white">
          <h5 className="mb-0">
            <FaCloud className="me-2" />
            Self Service (Remote) - File Upload & GitHub Scanning
          </h5>
        </div>
        <div className="card-body">
          <ThreatGuardDashboard />
        </div>
      </div>
    </div>
  );

  // Render Local IDE Tab - Use existing VSCodeScans
  const renderLocalIDETab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-success text-white">
          <h5 className="mb-0">
            <FaDesktop className="me-2" />
            Self Service (Local-IDE) - VSCode Extension Scans
          </h5>
        </div>
        <div className="card-body">
          <VSCodeScans />
        </div>
      </div>
    </div>
  );

  // Render CI/CD Pipeline Tab - Use existing ThreatGuardDashboard without file upload
  const renderCICDTab = () => (
    <div>
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-info text-white">
          <h5 className="mb-0">
            <FaServer className="me-2" />
            CI/CD Pipeline - Security Monitoring
          </h5>
        </div>
        <div className="card-body">
          <ThreatGuardDashboard hideFileUpload={true} />
        </div>
      </div>
    </div>
  );

  return (
    <div className="container-fluid">
      {/* Tab Navigation */}
      <div className="row mb-4">
        <div className="col-12">
          <ul className="nav nav-tabs" id="commandCenterTabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'remote' ? 'active' : ''}`}
                onClick={() => setActiveTab('remote')}
                type="button"
                role="tab"
              >
                <FaCloud className="me-2" />
                Self Service (Remote)
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'local' ? 'active' : ''}`}
                onClick={() => setActiveTab('local')}
                type="button"
                role="tab"
              >
                <FaDesktop className="me-2" />
                Self Service (Local-IDE)
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'cicd' ? 'active' : ''}`}
                onClick={() => setActiveTab('cicd')}
                type="button"
                role="tab"
              >
                <FaServer className="me-2" />
                CI/CD Pipeline
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Tab Content */}
      <div className="tab-content" id="commandCenterTabContent">
        {activeTab === 'remote' && renderRemoteTab()}
        {activeTab === 'local' && renderLocalIDETab()}
        {activeTab === 'cicd' && renderCICDTab()}
      </div>
    </div>
  );
};

export default CommandCenter;
