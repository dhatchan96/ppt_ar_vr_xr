import React from "react";
import { NavLink } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import {
  FaShieldAlt,
  FaExclamationTriangle,
  FaEye,
  FaBrain,
  FaHeartbeat,
  FaChartBar,
  FaCogs,
  FaTools,
  FaRobot,
  FaCode,
  FaBug,
  FaLayerGroup
} from "react-icons/fa";
import PropTypes from "prop-types";

const sidebarItems = [
  {
    to: "/",
    icon: <FaEye className="me-1" />,
    label: "Command Center"
  },
  {
    to: "/threats",
    icon: <FaExclamationTriangle className="me-1" />,
    label: "Action Hub"
  },
  {
    to: "/copilot-remediation",
    icon: <FaRobot className="me-1" />,
    label: "Copilot Remediation"
  },
  // {
  //   to: "/enhanced-vulnerabilities",
  //   icon: <FaBug className="me-1" />,
  //   label: "Enhanced Vulnerabilities"
  // },
  // {
  //   to: "/vscode-scans",
  //   icon: <FaCode className="me-1" />,
  //   label: "VSCode Scans"
  // },
  {
    to: "/rules",
    icon: <FaCogs className="me-1" />,
    label: "Security Rules"
  },
  // {
  //   to: "/security-tech-debt",
  //   icon: <FaTools className="me-1" />,
  //   label: "Tech Debt"
  // },
  {
    to: "/threat-shields",
    icon: <FaShieldAlt className="me-1" />,
    label: "Threat Shields"
  },
  {
    to: "/threat-intelligence",
    icon: <FaBrain className="me-1" />,
    label: "Threat Intelligence"
  },
  {
    to: "/admin-data",
    icon: <FaCogs className="me-1" />,
    label: "Admin Data"
  },
  {
    to: "/metrics",
    icon: <FaChartBar className="me-1" />,
    label: "Metrics"
  },
  {
    to: "/health",
    icon: <FaHeartbeat className="me-1" />,
    label: "System Health"
  }
];

function getSidebarLabel(label, sidebarCollapsed) {
  return !sidebarCollapsed ? label : null;
}

export default function Sidebar({ sidebarCollapsed }) {
  return (
    <ul className={`nav flex-column ${sidebarCollapsed ? "mt-4" : "mt-3"}`}>
      {sidebarItems.map((item, idx) => (
        <li className="nav-item" key={item.to}>
          <NavLink
            to={item.to}
            className={({ isActive }) => `nav-link mb-2 ${isActive ? "active" : ""}`}
            style={({ isActive }) => ({
              color: isActive ? "#0d6efd" : "#fff",
              background: isActive ? "#e9f3ff" : "transparent",
              borderRadius: "5px",
              fontWeight: isActive ? "bold" : "normal",
            })}
          >
            {item.icon} {getSidebarLabel(item.label, sidebarCollapsed)}
          </NavLink>
        </li>
      ))}
    </ul>
  );
}
Sidebar.propTypes = {
  sidebarCollapsed: PropTypes.bool.isRequired,
};


 