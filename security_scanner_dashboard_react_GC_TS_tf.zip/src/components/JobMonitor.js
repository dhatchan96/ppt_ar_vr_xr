import React, { useState, useEffect } from 'react';
import { FaSpinner, FaCheck, FaTimes, FaEye, FaTrash, FaPlay, FaPause } from 'react-icons/fa';
import API from '../api';

const JobMonitor = ({ onJobComplete }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [cleanupInProgress, setCleanupInProgress] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);

  useEffect(() => {
    loadJobs();
    // Poll for job updates every 5 seconds
    const interval = setInterval(loadJobs, 5000);
    setPollingInterval(interval);
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      setLoading(true);
      console.log('🔄 Loading jobs...');
      
      // Add cache-busting parameter to ensure fresh data
      const timestamp = Date.now();
      const response = await API.get(`/api/jobs?limit=20&_t=${timestamp}`);
      const jobsData = response.data.jobs || [];
      console.log(`📋 Loaded ${jobsData.length} jobs:`, jobsData.map(job => ({ id: job.job_id, status: job.status })));
      setJobs(jobsData);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <FaPause className="text-warning" />;
      case 'running':
        return <FaSpinner className="text-primary fa-spin" />;
      case 'completed':
        return <FaCheck className="text-success" />;
      case 'failed':
        return <FaTimes className="text-danger" />;
      case 'cancelled':
        return <FaTimes className="text-secondary" />;
      default:
        return <FaEye className="text-muted" />;
    }
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      pending: 'badge bg-warning text-dark',
      running: 'badge bg-primary',
      completed: 'badge bg-success',
      failed: 'badge bg-danger',
      cancelled: 'badge bg-secondary'
    };
    return statusClasses[status] || 'badge bg-secondary';
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString();
  };

  const getDuration = (startedAt, completedAt) => {
    if (!startedAt) return 'N/A';
    const start = new Date(startedAt);
    const end = completedAt ? new Date(completedAt) : new Date();
    const duration = Math.round((end - start) / 1000);
    return `${duration}s`;
  };

  const cancelJob = async (jobId) => {
    try {
      await API.post(`/api/jobs/${jobId}/cancel`);
      showToast('Job cancelled successfully', 'success');
      loadJobs();
    } catch (error) {
      showToast('Failed to cancel job', 'error');
    }
  };

  const showJobDetails = (job) => {
    setSelectedJob(job);
    setShowDetails(true);
  };

  const showToast = (message, type = 'info') => {
    // Simple toast implementation - you can replace with your preferred toast library
    const toast = document.createElement('div');
    toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed`;
    toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => document.body.removeChild(toast), 3000);
  };

  const cleanupOldJobs = async (days = 7) => {
    // Determine cleanup message based on days
    let cleanupMessage = '';
    if (days === 0) {
      cleanupMessage = 'Are you sure you want to clean up ALL completed/failed jobs?\n\n' +
                      'This will permanently delete ALL jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    } else if (days === 1) {
      cleanupMessage = 'Are you sure you want to clean up completed/failed jobs from the last 24 hours?\n\n' +
                      'This will permanently delete jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    } else {
      cleanupMessage = `Are you sure you want to clean up completed/failed jobs older than ${days} days?\n\n` +
                      'This will permanently delete jobs that are completed, failed, or cancelled.\n\n' +
                      'This action cannot be undone.';
    }
    
    // Add confirmation dialog
    const confirmed = window.confirm(cleanupMessage);
    
    if (!confirmed) {
      return;
    }
    
    try {
      setCleanupInProgress(true);
      
      // Temporarily pause polling to avoid race conditions
      if (pollingInterval) {
        clearInterval(pollingInterval);
        console.log('🔍 Paused polling during cleanup');
      }
      
      console.log('🧹 Starting cleanup with days:', days);
      const response = await API.post(`/api/jobs/cleanup?days=${days}`);
      const data = response.data;
      
      console.log('✅ Cleanup response:', data);
      
      if (data.deleted_count > 0) {
        showToast(`Successfully cleaned up ${data.deleted_count} old jobs`, 'success');
      } else {
        showToast('No old jobs found to clean up', 'info');
      }
      
      // Force reload jobs immediately after cleanup
      console.log('🔄 Reloading jobs after cleanup...');
      await loadJobs();
      
      // Wait a moment and reload again to ensure we have the latest data
      setTimeout(async () => {
        console.log('🔄 Second reload after cleanup...');
        await loadJobs();
      }, 1000);
      
      // Restart polling after cleanup
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
      console.log('🔄 Restarted polling after cleanup');
      
    } catch (error) {
      console.error('Cleanup error:', error);
      const errorMessage = error.response?.data?.error || 'Failed to cleanup jobs';
      showToast(errorMessage, 'error');
      
      // Restart polling even if cleanup failed
      const newInterval = setInterval(loadJobs, 5000);
      setPollingInterval(newInterval);
    } finally {
      setCleanupInProgress(false);
    }
  };

  return (
    <div className="card">
      <div className="card-header d-flex justify-content-between align-items-center">
        <h5 className="mb-0">
          <FaSpinner className="me-2" />
          Repository Scan Jobs
        </h5>
                 <div>
           <button 
             className="btn btn-sm btn-outline-secondary me-2" 
             onClick={loadJobs}
             disabled={loading}
           >
             {loading ? <FaSpinner className="fa-spin" /> : 'Refresh'}
           </button>
           <div className="btn-group btn-group-sm">
             <button 
               className="btn btn-outline-warning dropdown-toggle" 
               data-bs-toggle="dropdown"
               aria-expanded="false"
               disabled={cleanupInProgress}
             >
               {cleanupInProgress ? (
                 <>
                   <FaSpinner className="fa-spin me-1" />
                   Cleaning...
                 </>
               ) : (
                 <>
                   <FaTrash className="me-1" />
                   Cleanup
                 </>
               )}
             </button>
             <ul className="dropdown-menu">
               <li><button className="dropdown-item" onClick={() => cleanupOldJobs(1)} disabled={cleanupInProgress}>Last 24 hours</button></li>
               <li><button className="dropdown-item" onClick={() => cleanupOldJobs(3)} disabled={cleanupInProgress}>Last 3 days</button></li>
               <li><button className="dropdown-item" onClick={() => cleanupOldJobs(7)} disabled={cleanupInProgress}>Last 7 days</button></li>
               <li><button className="dropdown-item" onClick={() => cleanupOldJobs(30)} disabled={cleanupInProgress}>Last 30 days</button></li>
               <li><hr className="dropdown-divider" /></li>
               <li><button className="dropdown-item text-danger" onClick={() => cleanupOldJobs(0)} disabled={cleanupInProgress}>All completed jobs</button></li>
             </ul>
           </div>
         </div>
      </div>
      <div className="card-body">
        {cleanupInProgress && (
          <div className="alert alert-info text-center mb-3">
            <FaSpinner className="fa-spin me-2" />
            Cleaning up old jobs... Please wait.
          </div>
        )}
        
        {jobs.length === 0 ? (
          <div className="text-center text-muted py-4">
            <FaEye className="mb-3" style={{ fontSize: '3rem' }} />
            <p>No scan jobs found</p>
            <small>Repository scans will appear here</small>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>Status</th>
                  <th>Repository</th>
                  <th>Progress</th>
                  <th>Created</th>
                  <th>Duration</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {jobs.map((job) => (
                  <tr key={job.job_id}>
                    <td>
                      <div className="d-flex align-items-center">
                        {getStatusIcon(job.status)}
                        <span className={`ms-2 ${getStatusBadge(job.status)}`}>
                          {job.status}
                        </span>
                      </div>
                    </td>
                    <td>
                      <div>
                        <strong>{job.repo_url?.split('/').pop() || 'Unknown'}</strong>
                        <br />
                        <small className="text-muted">{job.repo_url}</small>
                      </div>
                    </td>
                    <td>
                      <div className="progress" style={{ height: '20px' }}>
                        <div 
                          className={`progress-bar ${
                            job.status === 'completed' ? 'bg-success' :
                            job.status === 'failed' ? 'bg-danger' :
                            job.status === 'running' ? 'bg-primary' :
                            'bg-secondary'
                          }`}
                          style={{ 
                            width: job.status === 'completed' ? '100%' :
                                   job.status === 'failed' ? '100%' :
                                   job.status === 'running' ? '50%' : '0%'
                          }}
                        >
                          {job.progress}
                        </div>
                      </div>
                    </td>
                    <td>
                      <small>{formatDate(job.created_at)}</small>
                    </td>
                    <td>
                      <small>{getDuration(job.started_at, job.completed_at)}</small>
                    </td>
                    <td>
                      <div className="btn-group btn-group-sm">
                        <button
                          className="btn btn-outline-primary"
                          onClick={() => showJobDetails(job)}
                          title="View Details"
                        >
                          <FaEye />
                        </button>
                        {job.status === 'running' && (
                          <button
                            className="btn btn-outline-warning"
                            onClick={() => cancelJob(job.job_id)}
                            title="Cancel Job"
                          >
                            <FaTimes />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Job Details Modal */}
      {showDetails && selectedJob && (
        <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
          <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Job Details</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowDetails(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="row">
                  <div className="col-md-6">
                    <h6>Job Information</h6>
                    <table className="table table-sm">
                      <tbody>
                        <tr>
                          <td><strong>Job ID:</strong></td>
                          <td><code>{selectedJob.job_id}</code></td>
                        </tr>
                        <tr>
                          <td><strong>Status:</strong></td>
                          <td>
                            <span className={getStatusBadge(selectedJob.status)}>
                              {selectedJob.status}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <td><strong>Repository:</strong></td>
                          <td>{selectedJob.repo_url}</td>
                        </tr>
                        <tr>
                          <td><strong>Type:</strong></td>
                          <td>{selectedJob.repo_type}</td>
                        </tr>
                        <tr>
                          <td><strong>Created:</strong></td>
                          <td>{formatDate(selectedJob.created_at)}</td>
                        </tr>
                        <tr>
                          <td><strong>Started:</strong></td>
                          <td>{formatDate(selectedJob.started_at)}</td>
                        </tr>
                        <tr>
                          <td><strong>Completed:</strong></td>
                          <td>{formatDate(selectedJob.completed_at)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="col-md-6">
                    <h6>Progress & Results</h6>
                    <div className="mb-3">
                      <strong>Progress:</strong>
                      <p className="text-muted">{selectedJob.progress}</p>
                    </div>
                    {selectedJob.error_message && (
                      <div className="mb-3">
                        <strong>Error:</strong>
                        <div className="alert alert-danger">
                          {selectedJob.error_message}
                        </div>
                      </div>
                    )}
                    {selectedJob.result_data && (
                      <div className="mb-3">
                        <strong>Results:</strong>
                        <div className="alert alert-success">
                          <p><strong>Files Scanned:</strong> {selectedJob.result_data.files_scanned || 'N/A'}</p>
                          <p><strong>Threats Found:</strong> {selectedJob.result_data.summary?.total_issues || 0}</p>
                          <p><strong>Risk Score:</strong> {selectedJob.result_data.summary?.logic_bomb_risk_score || 0}/100</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowDetails(false)}
                >
                  Close
                </button>
                {selectedJob.status === 'completed' && selectedJob.result_data && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => {
                      console.log('🔍 View Results clicked for job:', selectedJob.job_id);
                      console.log('🔍 Result data structure:', {
                        hasFileResults: !!selectedJob.result_data.file_results,
                        fileResultsLength: selectedJob.result_data.file_results?.length || 0,
                        hasSummary: !!selectedJob.result_data.summary,
                        summary: selectedJob.result_data.summary,
                        hasIssues: !!selectedJob.result_data.issues,
                        issuesLength: selectedJob.result_data.issues?.length || 0
                      });
                      
                      // Extract issues for debugging
                      const allIssues = [];
                      if (selectedJob.result_data.file_results && Array.isArray(selectedJob.result_data.file_results)) {
                        selectedJob.result_data.file_results.forEach(fileResult => {
                          if (fileResult.issues && Array.isArray(fileResult.issues)) {
                            allIssues.push(...fileResult.issues);
                          }
                        });
                      }
                      console.log('🔍 Issues extracted from file_results:', allIssues.length);
                      
                      onJobComplete(selectedJob.result_data);
                      setShowDetails(false);
                    }}
                  >
                    View Results
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
        </div>
      )}
    </div>
  );
};

export default JobMonitor;
