"""
ThreatGuard Pro - Health Monitoring and Metrics Collection
Comprehensive system health monitoring, metrics collection, and alerting
"""

import logging
import time
import threading
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import json
import psutil
import os
from pathlib import Path

from config import settings
import logging
from database import db_manager

logger = logging.getLogger(__name__)

# ============================================================================
# System Metrics Collection
# ============================================================================

@dataclass
class SystemMetrics:
    """System performance and resource metrics"""
    timestamp: str
    cpu_percent: float
    memory_percent: float
    disk_usage_percent: float
    network_io: Dict[str, float]
    process_count: int
    uptime_seconds: float
    load_average: List[float]

@dataclass
class ApplicationMetrics:
    """Application-specific metrics"""
    timestamp: str
    active_connections: int
    request_count: int
    error_count: int
    response_time_avg: float
    database_connections: int
    terraform_executions: int
    vulnerability_scans: int

@dataclass
class SecurityMetrics:
    """Security and threat metrics"""
    timestamp: str
    total_vulnerabilities: int
    critical_vulnerabilities: int
    high_risk_vulnerabilities: int
    remediated_vulnerabilities: int
    active_threats: int
    security_score: float
    compliance_status: str

class MetricsCollector:
    """Collects system, application, and security metrics"""
    
    def __init__(self):
        self.metrics_dir = Path("metrics_data")
        self.metrics_dir.mkdir(exist_ok=True)
        self.collection_interval = 60  # seconds
        self.retention_days = 30
        self._stop_collection = False
        self._collection_thread = None
        self._start_collection()
    
    def _start_collection(self):
        """Start metrics collection in background thread"""
        self._collection_thread = threading.Thread(target=self._collect_metrics_loop, daemon=True)
        self._collection_thread.start()
        logger.info("Metrics collection started")
    
    def _collect_metrics_loop(self):
        """Main metrics collection loop"""
        while not self._stop_collection:
            try:
                self._collect_all_metrics()
                time.sleep(self.collection_interval)
            except Exception as e:
                logger.error(f"Metrics collection error: {e}")
                time.sleep(self.collection_interval)
    
    def _collect_all_metrics(self):
        """Collect all types of metrics"""
        try:
            timestamp = datetime.utcnow().isoformat()
            
            # Collect system metrics
            system_metrics = self._collect_system_metrics(timestamp)
            self._save_metrics("system", system_metrics)
            
            # Collect application metrics
            app_metrics = self._collect_application_metrics(timestamp)
            self._save_metrics("application", app_metrics)
            
            # Collect security metrics
            security_metrics = self._collect_security_metrics(timestamp)
            self._save_metrics("security", security_metrics)
            
            # Cleanup old metrics
            self._cleanup_old_metrics()
            
        except Exception as e:
            logger.error(f"Failed to collect metrics: {e}")
    
    def _collect_system_metrics(self, timestamp: str) -> SystemMetrics:
        """Collect system performance metrics"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_usage_percent = disk.percent
            
            # Network I/O
            network = psutil.net_io_counters()
            network_io = {
                'bytes_sent': network.bytes_sent,
                'bytes_recv': network.bytes_recv,
                'packets_sent': network.packets_sent,
                'packets_recv': network.packets_recv
            }
            
            # Process count
            process_count = len(psutil.pids())
            
            # Uptime
            uptime_seconds = time.time() - psutil.boot_time()
            
            # Load average (Linux only)
            try:
                load_average = psutil.getloadavg()
            except AttributeError:
                load_average = [0.0, 0.0, 0.0]
            
            return SystemMetrics(
                timestamp=timestamp,
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                disk_usage_percent=disk_usage_percent,
                network_io=network_io,
                process_count=process_count,
                uptime_seconds=uptime_seconds,
                load_average=list(load_average)
            )
            
        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
            return SystemMetrics(
                timestamp=timestamp,
                cpu_percent=0.0,
                memory_percent=0.0,
                disk_usage_percent=0.0,
                network_io={},
                process_count=0,
                uptime_seconds=0.0,
                load_average=[0.0, 0.0, 0.0]
            )
    
    def _collect_application_metrics(self, timestamp: str) -> ApplicationMetrics:
        """Collect application-specific metrics"""
        try:
            # These would typically come from application monitoring
            # For now, we'll collect basic metrics
            
            # Database connections
            db_health = robust_db_manager.get_health_status()
            db_connections = 0
            if db_health.get("connection_pool", {}).get("status") == "healthy":
                db_connections = 10  # Default pool size
            
            # Terraform executions (placeholder)
            terraform_executions = 0
            
            # Vulnerability scans (placeholder)
            vulnerability_scans = 0
            
            return ApplicationMetrics(
                timestamp=timestamp,
                active_connections=0,  # Would come from web server
                request_count=0,       # Would come from request tracking
                error_count=0,         # Would come from error tracking
                response_time_avg=0.0, # Would come from performance monitoring
                database_connections=db_connections,
                terraform_executions=terraform_executions,
                vulnerability_scans=vulnerability_scans
            )
            
        except Exception as e:
            logger.error(f"Failed to collect application metrics: {e}")
            return ApplicationMetrics(
                timestamp=timestamp,
                active_connections=0,
                request_count=0,
                error_count=0,
                response_time_avg=0.0,
                database_connections=0,
                terraform_executions=0,
                vulnerability_scans=0
            )
    
    def _collect_security_metrics(self, timestamp: str) -> SecurityMetrics:
        """Collect security and threat metrics"""
        try:
            # Get vulnerability data
            vulnerabilities = robust_db_manager.get_vulnerabilities()
            
            total_vulnerabilities = len(vulnerabilities)
            critical_vulnerabilities = len([v for v in vulnerabilities if v.get('severity') == 'CRITICAL_BOMB'])
            high_risk_vulnerabilities = len([v for v in vulnerabilities if v.get('severity') == 'HIGH_RISK'])
            remediated_vulnerabilities = len([v for v in vulnerabilities if v.get('status') == 'RESOLVED'])
            active_threats = len([v for v in vulnerabilities if v.get('status') == 'ACTIVE_THREAT'])
            
            # Calculate security score (0-100)
            if total_vulnerabilities > 0:
                critical_weight = critical_vulnerabilities * 0.5
                high_weight = high_risk_vulnerabilities * 0.3
                medium_weight = len([v for v in vulnerabilities if v.get('severity') == 'MEDIUM_RISK']) * 0.2
                security_score = max(0, 100 - (critical_weight + high_weight + medium_weight))
            else:
                security_score = 100.0
            
            # Determine compliance status
            if security_score >= 90:
                compliance_status = "COMPLIANT"
            elif security_score >= 70:
                compliance_status = "PARTIALLY_COMPLIANT"
            else:
                compliance_status = "NON_COMPLIANT"
            
            return SecurityMetrics(
                timestamp=timestamp,
                total_vulnerabilities=total_vulnerabilities,
                critical_vulnerabilities=critical_vulnerabilities,
                high_risk_vulnerabilities=high_risk_vulnerabilities,
                remediated_vulnerabilities=remediated_vulnerabilities,
                active_threats=active_threats,
                security_score=security_score,
                compliance_status=compliance_status
            )
            
        except Exception as e:
            logger.error(f"Failed to collect security metrics: {e}")
            return SecurityMetrics(
                timestamp=timestamp,
                total_vulnerabilities=0,
                critical_vulnerabilities=0,
                high_risk_vulnerabilities=0,
                remediated_vulnerabilities=0,
                active_threats=0,
                security_score=0.0,
                compliance_status="UNKNOWN"
            )
    
    def _save_metrics(self, metric_type: str, metrics: Any):
        """Save metrics to file"""
        try:
            metrics_file = self.metrics_dir / f"{metric_type}_metrics.json"
            
            # Load existing metrics
            if metrics_file.exists():
                with open(metrics_file, 'r') as f:
                    existing_metrics = json.load(f)
            else:
                existing_metrics = []
            
            # Add new metrics
            existing_metrics.append(asdict(metrics))
            
            # Save back to file
            with open(metrics_file, 'w') as f:
                json.dump(existing_metrics, f, indent=2, default=str)
                
        except Exception as e:
            logger.error(f"Failed to save {metric_type} metrics: {e}")
    
    def _cleanup_old_metrics(self):
        """Remove metrics older than retention period"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(days=self.retention_days)
            
            for metric_file in self.metrics_dir.glob("*_metrics.json"):
                try:
                    with open(metric_file, 'r') as f:
                        metrics = json.load(f)
                    
                    # Filter out old metrics
                    filtered_metrics = []
                    for metric in metrics:
                        metric_time = datetime.fromisoformat(metric.get('timestamp', ''))
                        if metric_time > cutoff_time:
                            filtered_metrics.append(metric)
                    
                    # Save filtered metrics
                    with open(metric_file, 'w') as f:
                        json.dump(filtered_metrics, f, indent=2, default=str)
                        
                except Exception as e:
                    logger.error(f"Failed to cleanup {metric_file}: {e}")
                    
        except Exception as e:
            logger.error(f"Failed to cleanup old metrics: {e}")
    
    def get_metrics_summary(self, hours: int = 24) -> Dict[str, Any]:
        """Get metrics summary for the last N hours"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            summary = {
                'system': {},
                'application': {},
                'security': {},
                'summary_period_hours': hours
            }
            
            # Load and filter metrics
            for metric_type in ['system', 'application', 'security']:
                metrics_file = self.metrics_dir / f"{metric_type}_metrics.json"
                if metrics_file.exists():
                    with open(metrics_file, 'r') as f:
                        metrics = json.load(f)
                    
                    # Filter by time
                    recent_metrics = []
                    for metric in metrics:
                        metric_time = datetime.fromisoformat(metric.get('timestamp', ''))
                        if metric_time > cutoff_time:
                            recent_metrics.append(metric)
                    
                    if recent_metrics:
                        summary[metric_type] = self._calculate_metrics_summary(recent_metrics, metric_type)
            
            return summary
            
        except Exception as e:
            logger.error(f"Failed to get metrics summary: {e}")
            return {}
    
    def _calculate_metrics_summary(self, metrics: List[Dict], metric_type: str) -> Dict[str, Any]:
        """Calculate summary statistics for metrics"""
        try:
            if not metrics:
                return {}
            
            if metric_type == 'system':
                return {
                    'cpu_avg': sum(m.get('cpu_percent', 0) for m in metrics) / len(metrics),
                    'memory_avg': sum(m.get('memory_percent', 0) for m in metrics) / len(metrics),
                    'disk_avg': sum(m.get('disk_usage_percent', 0) for m in metrics) / len(metrics),
                    'process_count_avg': sum(m.get('process_count', 0) for m in metrics) / len(metrics),
                    'sample_count': len(metrics)
                }
            
            elif metric_type == 'security':
                return {
                    'security_score_avg': sum(m.get('security_score', 0) for m in metrics) / len(metrics),
                    'total_vulnerabilities_avg': sum(m.get('total_vulnerabilities', 0) for m in metrics) / len(metrics),
                    'critical_vulnerabilities_avg': sum(m.get('critical_vulnerabilities', 0) for m in metrics) / len(metrics),
                    'compliance_status': metrics[-1].get('compliance_status', 'UNKNOWN'),
                    'sample_count': len(metrics)
                }
            
            else:  # application
                return {
                    'database_connections_avg': sum(m.get('database_connections', 0) for m in metrics) / len(metrics),
                    'terraform_executions_total': sum(m.get('terraform_executions', 0) for m in metrics),
                    'vulnerability_scans_total': sum(m.get('vulnerability_scans', 0) for m in metrics),
                    'sample_count': len(metrics)
                }
                
        except Exception as e:
            logger.error(f"Failed to calculate {metric_type} metrics summary: {e}")
            return {}
    
    def stop_collection(self):
        """Stop metrics collection"""
        self._stop_collection = True
        if self._collection_thread:
            self._collection_thread.join(timeout=5)
        logger.info("Metrics collection stopped")

# ============================================================================
# Health Monitoring Dashboard
# ============================================================================

class HealthMonitor:
    """Comprehensive health monitoring for the ThreatGuard Pro system"""
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.health_checks = {}
        self.alert_thresholds = {
            'cpu_percent': 80.0,
            'memory_percent': 85.0,
            'disk_usage_percent': 90.0,
            'security_score': 70.0,
            'database_health': 'unhealthy',
            'response_time': 5.0  # seconds
        }
        self._register_health_checks()
    
    def _register_health_checks(self):
        """Register all health check functions"""
        self.register_health_check("system_resources", self._check_system_resources)
        self.register_health_check("database_connectivity", self._check_database_connectivity)
        self.register_health_check("application_health", self._check_application_health)
        self.register_health_check("security_status", self._check_security_status)
        self.register_health_check("terraform_health", self._check_terraform_health)
        self.register_health_check("file_system", self._check_file_system)
    
    def register_health_check(self, name: str, check_function: Callable):
        """Register a new health check"""
        self.health_checks[name] = check_function
    
    def _check_system_resources(self) -> Dict[str, Any]:
        """Check system resource usage"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Check thresholds
            cpu_status = "healthy" if cpu_percent < self.alert_thresholds['cpu_percent'] else "warning"
            memory_status = "healthy" if memory.percent < self.alert_thresholds['memory_percent'] else "warning"
            disk_status = "healthy" if disk.percent < self.alert_thresholds['disk_usage_percent'] else "warning"
            
            overall_status = "healthy"
            if any(status == "warning" for status in [cpu_status, memory_status, disk_status]):
                overall_status = "warning"
            
            return {
                "status": overall_status,
                "checks": {
                    "cpu": {
                        "status": cpu_status,
                        "value": cpu_percent,
                        "threshold": self.alert_thresholds['cpu_percent'],
                        "unit": "%"
                    },
                    "memory": {
                        "status": memory_status,
                        "value": memory.percent,
                        "threshold": self.alert_thresholds['memory_percent'],
                        "unit": "%"
                    },
                    "disk": {
                        "status": disk_status,
                        "value": disk.percent,
                        "threshold": self.alert_thresholds['disk_usage_percent'],
                        "unit": "%"
                    }
                }
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def _check_database_connectivity(self) -> Dict[str, Any]:
        """Check database connectivity and health"""
        try:
            db_health = robust_db_manager.get_health_status()
            return db_health
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def _check_application_health(self) -> Dict[str, Any]:
        """Check application health and performance"""
        try:
            # Check if key files exist
            key_files = [
                "dashboard_api_enhanced.py",
                "robust_error_handling.py",
                "robust_database.py",
                "robust_terraform.py"
            ]
            
            missing_files = []
            for file_name in key_files:
                if not Path(file_name).exists():
                    missing_files.append(file_name)
            
            if missing_files:
                return {
                    "status": "unhealthy",
                    "error": f"Missing key files: {', '.join(missing_files)}"
                }
            
            # Check if metrics collection is running
            metrics_running = not self.metrics_collector._stop_collection
            
            return {
                "status": "healthy" if metrics_running else "warning",
                "metrics_collection": "running" if metrics_running else "stopped",
                "key_files_present": len(key_files) - len(missing_files),
                "total_key_files": len(key_files)
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def _check_security_status(self) -> Dict[str, Any]:
        """Check security status and compliance"""
        try:
            # Get recent security metrics
            security_metrics = self.metrics_collector._collect_security_metrics(
                datetime.utcnow().isoformat()
            )
            
            # Check security score threshold
            security_status = "healthy"
            if security_metrics.security_score < self.alert_thresholds['security_score']:
                security_status = "warning"
            
            return {
                "status": security_status,
                "security_score": security_metrics.security_score,
                "compliance_status": security_metrics.compliance_status,
                "total_vulnerabilities": security_metrics.total_vulnerabilities,
                "critical_vulnerabilities": security_metrics.critical_vulnerabilities,
                "active_threats": security_metrics.active_threats
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def _check_terraform_health(self) -> Dict[str, Any]:
        """Check Terraform integration health"""
        try:
            # Check if Terraform binary exists
            terraform_binary = Path(settings.TERRAFORM_BINARY_PATH)
            terraform_exists = terraform_binary.exists()
            
            # Check workspace directory
            workspace_path = Path(settings.TERRAFORM_WORKSPACE_PATH)
            workspace_exists = workspace_path.exists()
            
            if not terraform_exists:
                return {
                    "status": "unhealthy",
                    "error": "Terraform binary not found"
                }
            
            if not workspace_exists:
                return {
                    "status": "warning",
                    "message": "Terraform workspace directory not found"
                }
            
            return {
                "status": "healthy",
                "terraform_binary": str(terraform_binary),
                "workspace_path": str(workspace_path),
                "binary_exists": terraform_exists,
                "workspace_exists": workspace_exists
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def _check_file_system(self) -> Dict[str, Any]:
        """Check file system health and permissions"""
        try:
            # Check key directories
            key_dirs = [
                "threatguard_data",
                "metrics_data",
                "terraform_backups"
            ]
            
            dir_status = {}
            for dir_name in key_dirs:
                dir_path = Path(dir_name)
                if dir_path.exists():
                    # Test write permissions
                    try:
                        test_file = dir_path / ".health_check"
                        with open(test_file, 'w') as f:
                            f.write("health_check")
                        test_file.unlink()
                        dir_status[dir_name] = "healthy"
                    except Exception:
                        dir_status[dir_name] = "warning"
                else:
                    dir_status[dir_name] = "missing"
            
            # Determine overall status
            if all(status == "healthy" for status in dir_status.values()):
                overall_status = "healthy"
            elif any(status == "missing" for status in dir_status.values()):
                overall_status = "warning"
            else:
                overall_status = "healthy"
            
            return {
                "status": overall_status,
                "directories": dir_status
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def get_overall_health(self) -> Dict[str, Any]:
        """Get overall system health status"""
        try:
            health_results = {}
            overall_status = "healthy"
            
            # Run all health checks
            for check_name, check_function in self.health_checks.items():
                try:
                    result = check_function()
                    health_results[check_name] = result
                    
                    # Determine overall status
                    check_status = result.get("status", "unknown")
                    if check_status == "unhealthy":
                        overall_status = "unhealthy"
                    elif check_status == "warning" and overall_status == "healthy":
                        overall_status = "warning"
                        
                except Exception as e:
                    health_results[check_name] = {
                        "status": "unhealthy",
                        "error": f"Check failed: {str(e)}"
                    }
                    overall_status = "unhealthy"
            
            # Add metrics summary
            try:
                metrics_summary = self.metrics_collector.get_metrics_summary(hours=1)
                health_results['metrics_summary'] = metrics_summary
            except Exception as e:
                health_results['metrics_summary'] = {
                    "error": f"Failed to get metrics: {str(e)}"
                }
            
            return {
                "overall_status": overall_status,
                "timestamp": datetime.utcnow().isoformat(),
                "health_checks": health_results,
                "alert_thresholds": self.alert_thresholds
            }
            
        except Exception as e:
            return {
                "overall_status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def get_health_alerts(self) -> List[Dict[str, Any]]:
        """Get current health alerts based on thresholds"""
        try:
            alerts = []
            overall_health = self.get_overall_health()
            
            for check_name, check_result in overall_health.get('health_checks', {}).items():
                if check_result.get('status') == 'unhealthy':
                    alerts.append({
                        'level': 'CRITICAL',
                        'check': check_name,
                        'message': f"Health check {check_name} is unhealthy",
                        'details': check_result,
                        'timestamp': datetime.utcnow().isoformat()
                    })
                elif check_result.get('status') == 'warning':
                    alerts.append({
                        'level': 'WARNING',
                        'check': check_name,
                        'message': f"Health check {check_name} shows warning",
                        'details': check_result,
                        'timestamp': datetime.utcnow().isoformat()
                    })
            
            return alerts
            
        except Exception as e:
            logger.error(f"Failed to get health alerts: {e}")
            return []

# Global health monitor instance
health_monitor = HealthMonitor()
