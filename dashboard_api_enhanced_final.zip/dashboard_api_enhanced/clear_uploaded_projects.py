#!/usr/bin/env python3
"""
Script to clear uploaded_projects directory
This will clean up the data showing in VS Code scans and Copilot remediation pages
"""

import shutil
import os
from pathlib import Path

def clear_uploaded_projects():
    """Clear the uploaded_projects directory"""
    uploaded_projects_dir = Path('uploaded_projects')
    
    if uploaded_projects_dir.exists():
        print(f"Found uploaded_projects directory with {len(list(uploaded_projects_dir.iterdir()))} items")
        
        # Remove all contents
        for item in uploaded_projects_dir.iterdir():
            if item.is_dir():
                shutil.rmtree(item)
                print(f"Removed directory: {item.name}")
            else:
                item.unlink()
                print(f"Removed file: {item.name}")
        
        print("Successfully cleared uploaded_projects directory")
    else:
        print("uploaded_projects directory does not exist")

if __name__ == "__main__":
    clear_uploaded_projects()



