import React from 'react';

export default function Results({ results }) {
  if (!results || results.length === 0) return null;

  return (
    <div className="mt-4">
      <h5>📊 Scan Results</h5>
      {results.map((file, idx) => (
        <div className="card my-3" key={idx}>
          <div className="card-body">
            <h6 className="card-title">{file.filename}</h6>
            <p>
              <strong>Risk Level:</strong> <span className={`badge bg-${file.risk_level === 'HIGH' ? 'danger' : file.risk_level === 'MEDIUM' ? 'warning' : 'success'}`}>{file.risk_level}</span><br />
              <strong>Patterns Detected:</strong> {file.total_patterns}
            </p>
            {file.patterns.map((p, i) => (
              <div className="border rounded p-2 mb-2" key={i}>
                <strong>{p.pattern_type}</strong> <span className="text-muted">(Line {p.line_number})</span><br />
                <small>{p.description}</small><br />
                <code>{p.code_snippet}</code>
              </div>
            ))}
            {file.error && <div className="alert alert-danger mt-2">{file.error}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}
