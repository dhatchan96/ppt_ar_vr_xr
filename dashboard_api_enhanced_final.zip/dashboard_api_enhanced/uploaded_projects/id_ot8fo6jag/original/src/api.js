import axios from 'axios';

const BASE_URL = 'http://localhost:5000/api'; // Update if Flask is hosted elsewhere

export const analyzeFile = async (formData) => {
  return axios.post(`${BASE_URL}/analyze`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
};

export const analyzeText = async (code, filename = "code.py") => {
  return axios.post(`${BASE_URL}/analyze/text`, { code, filename });
};

export const healthCheck = async () => {
  return axios.get(`${BASE_URL}/health`);
};
