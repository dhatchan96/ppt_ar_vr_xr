import React, { useState } from 'react';
import { analyzeText } from './api';
import Results from './Results';

export default function TextAnalyzer() {
  const [code, setCode] = useState("");
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await analyzeText(code);
      setResults([res.data]);
    } catch (err) {
      setError("Analysis failed: " + err.message);
    }
  };

  return (
    <div>
      <h4>✍️ Paste Python Code</h4>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <textarea
            className="form-control"
            rows="8"
            placeholder="Paste your Python code here"
            value={code}
            onChange={e => setCode(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-success">Analyze</button>
      </form>
      {error && <div className="alert alert-danger mt-3">{error}</div>}
      <Results results={results} />
    </div>
  );
}
