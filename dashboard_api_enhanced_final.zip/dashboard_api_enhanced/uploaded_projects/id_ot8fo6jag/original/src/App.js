import React, { useState } from 'react';
import UploadForm from './UploadForm';
import TextAnalyzer from './TextAnalyzer';

function App() {
  const [activeTab, setActiveTab] = useState('upload');

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">🛡️ Logic Bomb Detection Tool</h1>

      <ul className="nav nav-tabs mb-3">
        <li className="nav-item">
          <button className={`nav-link ${activeTab === 'upload' ? 'active' : ''}`}
            onClick={() => setActiveTab('upload')}>
            📂 File Upload
          </button>
        </li>
        <li className="nav-item">
          <button className={`nav-link ${activeTab === 'text' ? 'active' : ''}`}
            onClick={() => setActiveTab('text')}>
            ✍️ Code Text
          </button>
        </li>
      </ul>

      <div className="tab-content">
        {activeTab === 'upload' && (
          <div className="tab-pane active show">
            <div className="card p-3">
              <UploadForm />
            </div>
          </div>
        )}

        {activeTab === 'text' && (
          <div className="tab-pane active show">
            <div className="card p-3">
              <TextAnalyzer />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
