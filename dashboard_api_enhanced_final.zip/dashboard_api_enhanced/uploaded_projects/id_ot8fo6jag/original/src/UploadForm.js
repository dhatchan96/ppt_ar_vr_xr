import React, { useState } from 'react';
import { analyzeFile } from './api';
import Results from './Results';

export default function UploadForm() {
  const [files, setFiles] = useState([]);
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  const handleFileChange = (e) => setFiles(e.target.files);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const formData = new FormData();
    for (let file of files) {
      formData.append('files', file);
    }
    try {
      const res = await analyzeFile(formData);
      setResults(res.data);
    } catch (err) {
      setError("Upload failed: " + err.message);
    }
  };

  return (
    <div>
      <h4>📂 Upload Python or ZIP Files</h4>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <input type="file" className="form-control" multiple onChange={handleFileChange} />
        </div>
        <button type="submit" className="btn btn-primary">Analyze</button>
      </form>
      {error && <div className="alert alert-danger mt-3">{error}</div>}
      <Results results={results} />
    </div>
  );
}
