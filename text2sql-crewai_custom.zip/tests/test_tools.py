"""Unit tests for tools."""
import pytest
import json
from src.tools import (
    SchemaRetrievalTool,
    QueryValidationTool,
    SQLGenerationTool,
    SQLExecutionTool,
    SchemaTableMatchingTool
)


class TestSchemaRetrievalTool:
    """Tests for SchemaRetrievalTool."""
    
    def test_schema_retrieval_database_level(self):
        """Test database-level schema retrieval."""
        tool = SchemaRetrievalTool()
        result = tool._run(database="test_db", level="database")
        
        data = json.loads(result)
        assert "database" in data
        assert "tables" in data
        assert isinstance(data["tables"], list)
    
    def test_schema_retrieval_table_level(self):
        """Test table-level schema retrieval."""
        tool = SchemaRetrievalTool()
        result = tool._run(database="test_db", tables=["customers"], level="table")
        
        data = json.loads(result)
        assert "tables" in data
        assert "customers" in data["tables"]
    
    def test_schema_retrieval_column_level(self):
        """Test column-level schema retrieval."""
        tool = SchemaRetrievalTool()
        result = tool._run(database="test_db", tables=["customers"], level="column")
        
        data = json.loads(result)
        assert "tables" in data
        assert "customers" in data["tables"]
        assert "columns" in data["tables"]["customers"]


class TestQueryValidationTool:
    """Tests for QueryValidationTool."""
    
    def test_valid_query(self):
        """Test validation of valid query."""
        tool = QueryValidationTool()
        schema = {
            "tables": {
                "customers": {
                    "columns": [
                        {"name": "id", "type": "INT"},
                        {"name": "name", "type": "STRING"},
                        {"name": "email", "type": "STRING"}
                    ]
                }
            }
        }
        
        result = tool._run(query="Show me all customers", schema=schema)
        data = json.loads(result)
        
        assert "valid" in data
        assert isinstance(data["valid"], bool)
    
    def test_query_with_aggregation(self):
        """Test query with aggregation detection."""
        tool = QueryValidationTool()
        schema = {"tables": {"orders": {"columns": [{"name": "amount", "type": "DECIMAL"}]}}}
        
        result = tool._run(query="Count total orders", schema=schema)
        data = json.loads(result)
        
        assert "has_aggregation" in data


class TestSQLGenerationTool:
    """Tests for SQLGenerationTool."""
    
    def test_basic_sql_generation(self):
        """Test basic SQL generation."""
        tool = SQLGenerationTool()
        query_plan = {
            "query_type": "SELECT",
            "entities": ["customers"],
            "conditions": [],
            "aggregations": []
        }
        schema = {
            "tables": {
                "customers": {
                    "columns": [
                        {"name": "id", "type": "INT"},
                        {"name": "name", "type": "STRING"}
                    ]
                }
            }
        }
        
        result = tool._run(query_plan=query_plan, schema=schema, dialect="impala")
        data = json.loads(result)
        
        assert "sql" in data
        assert "SELECT" in data["sql"].upper()
    
    def test_sql_with_limit(self):
        """Test SQL generation with LIMIT clause."""
        tool = SQLGenerationTool()
        query_plan = {
            "query_type": "SELECT",
            "entities": ["customers"],
            "limit": 10
        }
        schema = {"tables": {"customers": {"columns": [{"name": "id", "type": "INT"}]}}}
        
        result = tool._run(query_plan=query_plan, schema=schema)
        data = json.loads(result)
        
        assert "LIMIT" in data["sql"]


class TestSQLExecutionTool:
    """Tests for SQLExecutionTool."""
    
    def test_sql_execution(self):
        """Test SQL execution (mock)."""
        tool = SQLExecutionTool()
        result = tool._run(sql="SELECT * FROM customers LIMIT 10")
        
        data = json.loads(result)
        assert "status" in data
        assert "results" in data
        assert "row_count" in data
    
    def test_execution_with_limit(self):
        """Test SQL execution with limit."""
        tool = SQLExecutionTool()
        result = tool._run(sql="SELECT * FROM customers", limit=5)
        
        data = json.loads(result)
        assert data["status"] == "success"
        assert data["row_count"] <= 5


class TestSchemaTableMatchingTool:
    """Tests for SchemaTableMatchingTool."""
    
    def test_table_matching(self):
        """Test table matching."""
        tool = SchemaTableMatchingTool()
        result = tool._run(query="Show me customer orders", database="test_db", top_k=3)
        
        data = json.loads(result)
        assert "tables" in data
        assert len(data["tables"]) <= 3
    
    def test_relevance_scores(self):
        """Test that relevance scores are calculated."""
        tool = SchemaTableMatchingTool()
        result = tool._run(query="customer information", database="test_db")
        
        data = json.loads(result)
        if data["tables"]:
            assert "relevance_score" in data["tables"][0]
            assert 0 <= data["tables"][0]["relevance_score"] <= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

