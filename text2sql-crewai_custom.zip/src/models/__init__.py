"""Data models for Text-to-SQL system."""
from .query_request import QueryRequest, UserContext
from .query_response import QueryResponse, QueryResult, ValidationResult, SchemaInfo

__all__ = [
    "QueryRequest",
    "UserContext",
    "QueryResponse",
    "QueryResult",
    "ValidationResult",
    "SchemaInfo"
]

