"""Settings management for Text-to-SQL system."""
import os
from pathlib import Path
from typing import Optional
import yaml
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load environment variables from .env file (for ORCHESTRA_API_KEY if needed)
# Try loading from project root (parent of src directory)
project_root = Path(__file__).parent.parent.parent
env_file = project_root / ".env"

# Also try current working directory
cwd_env = Path.cwd() / ".env"

# Load .env file if it exists
if env_file.exists():
    load_dotenv(dotenv_path=env_file, override=True)
    print(f"Loaded .env file from: {env_file}")
elif cwd_env.exists():
    load_dotenv(dotenv_path=cwd_env, override=True)
    print(f"Loaded .env file from: {cwd_env}")
else:
    # Fallback: load_dotenv() searches current directory and parent directories
    load_dotenv(override=True)


class DatabaseConfig(BaseModel):
    """Database configuration."""
    type: str = "sqlite"  # sqlite, impala, postgresql, mysql
    path: Optional[str] = "data/text2sql.db"  # For SQLite
    host: str = "localhost"  # For Impala/PostgreSQL/MySQL
    port: int = 21050
    database: str = "default"
    auth_mechanism: str = "PLAIN"
    user: Optional[str] = None
    password: Optional[str] = None


class AgentConfig(BaseModel):
    """Agent configuration."""
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.0
    max_iterations: int = 5
    cache_ttl: int = 3600
    max_timeout: int = 60
    default_limit: int = 100
    format_instructions: Optional[str] = None


class OrchestraConfig(BaseModel):
    """Orchestra API gateway configuration."""
    api_key: str = Field(default_factory=lambda: os.getenv("ORCHESTRA_API_KEY", ""))
    base_url: str = "https://api-gateway.example.com/api/v1/chat"
    model: str = "gpt-4.1-2025-04-14"
    temperature: float = 0.0
    verify_ssl: bool = True
    ca_bundle_path: Optional[str] = Field(default_factory=lambda: os.getenv("ORCHESTRA_CA_BUNDLE", None))
    
    def __init__(self, **data):
        # If api_key is provided in data and is not empty, use it (hardcoded value)
        # Otherwise, try environment variable
        if "api_key" not in data or not data.get("api_key") or data.get("api_key") == "${ORCHESTRA_API_KEY}":
            env_key = os.getenv("ORCHESTRA_API_KEY", "")
            if env_key:
                data["api_key"] = env_key
            elif "api_key" in data and data["api_key"] == "${ORCHESTRA_API_KEY}":
                # If it's still the placeholder and no env var, keep empty
                data["api_key"] = ""
        super().__init__(**data)


class CustomLLMConfig(BaseModel):
    """Custom LLM provider configuration (OpenAI-compatible API)."""
    api_key: str = Field(default_factory=lambda: os.getenv("CUSTOM_LLM_API_KEY", ""))
    base_url: str = Field(..., description="Base URL for the custom LLM API (e.g., https://api.example.com/v1)")
    model: str = "gpt-4"
    temperature: float = 0.0
    verify_ssl: bool = True
    ca_bundle_path: Optional[str] = Field(default_factory=lambda: os.getenv("CUSTOM_LLM_CA_BUNDLE", None))
    api_key_env_var: Optional[str] = None  # Optional: name of env var to use for API key
    # Custom response format handling
    response_format: Optional[str] = None  # Optional: "openai" (default) or "custom" - for future use
    
    def __init__(self, **data):
        # Handle API key from environment variable if specified
        if "api_key_env_var" in data and data["api_key_env_var"]:
            env_var_name = data.pop("api_key_env_var")
            env_key = os.getenv(env_var_name, "")
            if env_key:
                data["api_key"] = env_key
            elif "api_key" not in data or not data.get("api_key"):
                data["api_key"] = ""
        # If api_key is a placeholder like ${CUSTOM_LLM_API_KEY}, try to resolve it
        elif "api_key" in data and isinstance(data.get("api_key"), str) and data["api_key"].startswith("${"):
            env_var_name = data["api_key"][2:-1]  # Remove ${ and }
            env_key = os.getenv(env_var_name, "")
            if env_key:
                data["api_key"] = env_key
            elif not data.get("api_key"):
                data["api_key"] = ""
        # If api_key is not provided, try default env var
        elif "api_key" not in data or not data.get("api_key"):
            env_key = os.getenv("CUSTOM_LLM_API_KEY", "")
            if env_key:
                data["api_key"] = env_key
            else:
                data["api_key"] = ""
        super().__init__(**data)


class LLMConfig(BaseModel):
    """LLM provider configuration - supports Orchestra or Custom LLM."""
    orchestra: Optional[OrchestraConfig] = None
    custom: Optional[CustomLLMConfig] = None


class RedisConfig(BaseModel):
    """Redis configuration."""
    enabled: bool = True
    host: str = "localhost"
    port: int = 6379
    db: int = 0


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file: str = "text2sql.log"


class Settings(BaseModel):
    """Main settings class."""
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)
    llm: Optional[LLMConfig] = None
    redis: RedisConfig = Field(default_factory=RedisConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @classmethod
    def load_from_yaml(cls, config_path: Optional[Path] = None) -> "Settings":
        """Load settings from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent / "config.yaml"
        
        if not config_path.exists():
            return cls()
        
        with open(config_path, 'r') as f:
            config_data = yaml.safe_load(f)
        
        # Process environment variables in config
        config_str = yaml.dump(config_data)
        for key, value in os.environ.items():
            config_str = config_str.replace(f"${{{key}}}", value)
        config_data = yaml.safe_load(config_str)
        
        # Handle LLM config (Custom or Orchestra)
        if "llm" in config_data:
            # Handle Custom LLM config
            if "custom" in config_data["llm"]:
                custom_config = config_data["llm"]["custom"]
                api_key = custom_config.get("api_key", "")
                # If it's a placeholder or empty, try environment variable
                if not api_key or (isinstance(api_key, str) and api_key.startswith("${")):
                    env_var_name = "CUSTOM_LLM_API_KEY"
                    if isinstance(api_key, str) and api_key.startswith("${"):
                        env_var_name = api_key[2:-1]  # Extract env var name from ${VAR}
                    env_key = os.getenv(env_var_name, "")
                    if env_key:
                        custom_config["api_key"] = env_key
                        print(f"Using Custom LLM API key from environment {env_var_name} (last 4: {env_key[-4:]})")
                    else:
                        print(f"Warning: Custom LLM API key not set in config.yaml or {env_var_name} environment variable")
                else:
                    print(f"Using Custom LLM API key from config.yaml (last 4: {api_key[-4:] if len(api_key) > 4 else 'N/A'})")
            
            # Handle Orchestra LLM config
            if "orchestra" in config_data["llm"]:
                orchestra_config = config_data["llm"]["orchestra"]
                api_key = orchestra_config.get("api_key", "")
                # If it's a placeholder or empty, try environment variable
                if not api_key or (isinstance(api_key, str) and api_key.startswith("${")):
                    env_key = os.getenv("ORCHESTRA_API_KEY", "")
                    if env_key:
                        orchestra_config["api_key"] = env_key
                        print(f"Using Orchestra API key from environment (last 4: {env_key[-4:]})")
                    else:
                        print("Warning: Orchestra API key not set in config.yaml or environment")
                else:
                    print(f"Using Orchestra API key from config.yaml (last 4: {api_key[-4:] if len(api_key) > 4 else 'N/A'})")
        
        return cls(**config_data)


# Global settings instance
settings = Settings.load_from_yaml()

