"""LLM factory for creating LLM instances using Orchestra or Custom LLM."""
import logging
import httpx
from langchain_openai import ChatOpenAI
from ..config.settings import Settings
from .custom_llm_adapter import CustomLLMAdapter

logger = logging.getLogger(__name__)


def get_llm(settings: Settings, model: str = None, temperature: float = None):
    """
    Get LLM instance using configured provider (Orchestra or Custom).
    
    Args:
        settings: Settings instance with LLM configuration
        model: Optional model name override
        temperature: Optional temperature override
        
    Returns:
        LLM instance configured for the selected LLM provider
    """
    if not settings.llm:
        raise ValueError("LLM config not found. Please configure llm in config.yaml")
    
    # Determine which provider to use (prefer custom over orchestra)
    config = None
    provider_name = None
    use_custom_adapter = False
    
    if settings.llm.custom:
        config = settings.llm.custom
        provider_name = "Custom LLM"
        # Check if custom adapter is needed (if response_format is "langchain" or "custom")
        use_custom_adapter = getattr(config, 'response_format', None) in ['langchain', 'custom']
        logger.info(f"Creating {provider_name} with base_url: {config.base_url}, response_format: {getattr(config, 'response_format', 'openai')}")
    elif settings.llm.orchestra:
        config = settings.llm.orchestra
        provider_name = "Orchestra"
        logger.info(f"Creating {provider_name} with base_url: {config.base_url}")
    else:
        raise ValueError("No LLM provider configured. Please configure llm.custom or llm.orchestra in config.yaml")
    
    if not config.api_key:
        raise ValueError(f"{provider_name} API key not set. Please set api_key in config.yaml or environment variable")
    
    # Configure HTTP client with SSL settings if needed
    http_client = None
    if hasattr(config, 'verify_ssl') and not config.verify_ssl:
        # Disable SSL verification for development
        http_client = httpx.Client(verify=False)
        logger.warning(f"SSL verification disabled for {provider_name}")
    elif hasattr(config, 'ca_bundle_path') and config.ca_bundle_path:
        # Use custom CA bundle
        http_client = httpx.Client(verify=config.ca_bundle_path)
        logger.info(f"Using custom CA bundle: {config.ca_bundle_path}")
    
    # ALWAYS use CustomLLMAdapter for custom base_urls to prevent CrewAI from wrapping ChatOpenAI
    # CrewAI detects ChatOpenAI and wraps it in its own OpenAI provider, ignoring our base_url
    # CustomLLMAdapter extends BaseChatModel directly, so CrewAI won't wrap it
    llm = CustomLLMAdapter(
        model=model or config.model,
        temperature=temperature if temperature is not None else config.temperature,
        api_key=config.api_key,
        base_url=config.base_url,
        http_client=http_client
    )
    logger.info(f"Created CustomLLMAdapter: base_url={config.base_url}, model={model or config.model}, response_format={getattr(config, 'response_format', 'openai')}")
    return llm

