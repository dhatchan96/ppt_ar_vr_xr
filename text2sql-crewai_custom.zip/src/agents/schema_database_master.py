"""Schema Database Master agent for detailed schema information."""
from crewai import Agent, Task
from ..config import settings
from ..utils.llm_factory import get_llm
from ..tools import SchemaRetrievalTool


def create_schema_database_master_agent() -> Agent:
    """
    Create the Schema Database Master Agent.
    
    This agent provides detailed column-level schema information.
    """
    config = settings.agents.get("schema_database_master", {})
    
    return Agent(
        role="Schema Database Specialist",
        goal="Provide detailed column-level schema information",
        backstory="""You are a database schema expert who knows every detail 
        about table structures, column types, constraints, and relationships. You 
        provide comprehensive schema information including column names, data types, 
        descriptions, example values, primary/foreign keys, and constraints. You 
        help other agents understand the database structure deeply.""",
        llm=get_llm(
            settings,
            model=config.model if hasattr(config, 'model') else "gpt-3.5-turbo",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[SchemaRetrievalTool()],
        allow_delegation=False
    )


def create_schema_detail_task(agent: Agent, database: str, selected_tables: list[str]) -> Task:
    """Create schema detail task for the schema database master agent."""
    return Task(
        description=f"""
        Retrieve detailed schema for these tables: {selected_tables}
        
        Database: {database}
        
        For each table, provide:
        1. All column names and data types
        2. Column descriptions
        3. Example values (if available)
        4. Primary/foreign keys
        5. Constraints
        
        Use the schema_retrieval tool with level='column'
        
        Format as:
        ## Table Name: table_name
        
        ### Columns:
        - `column1` (type): description [example: value]
        - `column2` (type): description
        
        ### Relationships:
        - Foreign key to other_table.column
        """,
        agent=agent,
        expected_output="Detailed schema for all selected tables"
    )

