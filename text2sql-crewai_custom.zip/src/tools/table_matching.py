"""Table matching tool for semantic table discovery."""
import json
import logging
from typing import Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class TableMatchingInput(BaseModel):
    """Input schema for SchemaTableMatchingTool."""
    query: str = Field(..., description="Natural language query")
    database: str = Field(..., description="Database name")
    top_k: int = Field(default=5, description="Number of top tables to return")


class SchemaTableMatchingTool(BaseTool):
    """
    Finds relevant tables for query using semantic search.
    """
    name: str = "table_matcher"
    description: str = """
    Identifies relevant tables using semantic search and keyword matching.
    Input should be a JSON string with keys:
    - query (str): The natural language query
    - database (str): Database name to search
    - top_k (int, optional): Number of top tables to return (default: 5)
    
    Returns: JSON with:
    - tables (list): List of relevant tables with relevance scores and descriptions
    
    Example input:
    {"query": "Show me customer orders", "database": "sales_db", "top_k": 5}
    """

    def _run(self, query: str, database: str, top_k: int = 5) -> str:
        """
        Find relevant tables for query.
        
        Args:
            query: Natural language query
            database: Database name
            top_k: Number of top tables to return
            
        Returns:
            JSON string with relevant tables
        """
        try:
            logger.info(f"Finding tables for query in database={database}, top_k={top_k}")
            
            result = self._match_tables(query, database, top_k)
            
            return json.dumps(result, indent=2)
        
        except Exception as e:
            logger.error(f"Error matching tables: {str(e)}")
            return json.dumps({
                "tables": [],
                "error": str(e)
            })

    def _match_tables(self, query: str, database: str, top_k: int) -> dict[str, Any]:
        """
        Match tables to query using semantic similarity.
        
        This is a simplified implementation using keyword matching.
        In production, this would use embeddings and vector search.
        """
        query_lower = query.lower()
        
        # Get table catalog from SQLite database
        table_catalog = self._get_table_catalog_from_db()
        
        # If database query failed, use fallback catalog
        if not table_catalog:
            table_catalog = {
                "customers": {
                    "description": "Customer information including demographics and contact details",
                    "keywords": ["customer", "client", "user", "buyer", "contact", "person"],
                    "row_count": 0
                },
                "orders": {
                    "description": "Order transactions and purchase details",
                    "keywords": ["order", "purchase", "transaction", "buy", "sale"],
                    "row_count": 0
                },
                "products": {
                    "description": "Product catalog with pricing and inventory",
                    "keywords": ["product", "item", "goods", "merchandise", "inventory", "stock"],
                    "row_count": 0
                },
                "sales": {
                    "description": "Sales transactions by region and salesperson",
                    "keywords": ["sales", "revenue", "income", "earnings", "region", "territory"],
                    "row_count": 0
                },
                "employees": {
                    "description": "Employee information and organizational structure",
                    "keywords": ["employee", "staff", "worker", "personnel", "team", "salesperson"],
                    "row_count": 0
                },
                "departments": {
                    "description": "Department hierarchy and organizational units",
                    "keywords": ["department", "division", "unit", "team", "organization"],
                    "row_count": 0
                },
                "regions": {
                    "description": "Geographic regions and territories",
                    "keywords": ["region", "territory", "geography", "location", "area"],
                    "row_count": 0
                }
            }
        
        # Calculate relevance scores
        scored_tables = []
        for table_name, table_info in table_catalog.items():
            score = self._calculate_relevance_score(query_lower, table_name, table_info)
            if score > 0:
                scored_tables.append({
                    "name": table_name,
                    "relevance_score": round(score, 3),
                    "description": table_info["description"],
                    "reason": self._generate_reason(query_lower, table_name, table_info)
                })
        
        # Sort by relevance score
        scored_tables.sort(key=lambda x: x["relevance_score"], reverse=True)
        
        # Return top K
        return {
            "tables": scored_tables[:top_k],
            "total_matches": len(scored_tables),
            "database": database
        }

    def _calculate_relevance_score(self, query: str, table_name: str, table_info: dict) -> float:
        """
        Calculate relevance score for a table.
        
        In production, this would use embeddings and cosine similarity.
        This implementation uses simple keyword matching.
        """
        score = 0.0
        
        # Direct table name match
        if table_name in query:
            score += 1.0
        
        # Keyword matches
        keywords = table_info.get("keywords", [])
        for keyword in keywords:
            if keyword in query:
                score += 0.5
        
        # Description similarity (simple word overlap)
        description = table_info.get("description", "").lower()
        query_words = set(query.split())
        description_words = set(description.split())
        overlap = len(query_words & description_words)
        score += overlap * 0.1
        
        # Normalize score to 0-1 range
        return min(score, 1.0)

    def _generate_reason(self, query: str, table_name: str, table_info: dict) -> str:
        """Generate human-readable reason for table selection."""
        reasons = []
        
        if table_name in query:
            reasons.append(f"table name '{table_name}' directly mentioned in query")
        
        keywords = table_info.get("keywords", [])
        matched_keywords = [kw for kw in keywords if kw in query]
        if matched_keywords:
            reasons.append(f"keywords matched: {', '.join(matched_keywords)}")
        
        if not reasons:
            reasons.append("general relevance to query context")
        
        return "; ".join(reasons)

    def _get_table_catalog_from_db(self) -> dict[str, Any]:
        """Get table catalog from SQLite database."""
        try:
            import sqlite3
            from pathlib import Path
            from ..config import settings
            
            db_path = settings.database.path or "data/text2sql.db"
            if not Path(db_path).is_absolute():
                # table_matching.py is in src/tools/, so go up 3 levels to project root
                project_root = Path(__file__).parent.parent.parent
                db_path = project_root / db_path
            
            if not Path(db_path).exists():
                logger.warning(f"Database not found at {db_path}, using fallback catalog")
                return {}
            
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                ORDER BY name
            """)
            tables = [row[0] for row in cursor.fetchall()]
            
            # Keyword mapping for tables
            keyword_map = {
                "customers": ["customer", "client", "user", "buyer", "contact", "person"],
                "orders": ["order", "purchase", "transaction", "buy", "sale"],
                "products": ["product", "item", "goods", "merchandise", "inventory", "stock"],
                "sales": ["sales", "revenue", "income", "earnings", "region", "territory"],
                "employees": ["employee", "staff", "worker", "personnel", "team", "salesperson"],
                "departments": ["department", "division", "unit", "team", "organization"],
                "regions": ["region", "territory", "geography", "location", "area"]
            }
            
            table_catalog = {}
            for table_name in tables:
                # Get row count
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                row_count = cursor.fetchone()[0]
                
                # Generate description from table name
                description = f"{table_name.replace('_', ' ').title()} table"
                
                # Get keywords for this table
                keywords = keyword_map.get(table_name, [table_name.lower()])
                
                table_catalog[table_name] = {
                    "description": description,
                    "keywords": keywords,
                    "row_count": row_count
                }
            
            conn.close()
            return table_catalog
        
        except Exception as e:
            logger.error(f"Error getting table catalog from database: {str(e)}")
            return {}
    
    def _get_embeddings(self, text: str) -> list[float]:
        """
        Get embeddings for text.
        
        This is a placeholder for actual embedding generation.
        In production, use OpenAI embeddings or similar service.
        """
        # from openai import OpenAI
        # client = OpenAI()
        # response = client.embeddings.create(
        #     model="text-embedding-ada-002",
        #     input=text
        # )
        # return response.data[0].embedding
        pass

