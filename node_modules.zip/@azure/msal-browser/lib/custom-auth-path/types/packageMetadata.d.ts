export declare const name = "@azure/msal-browser";
export declare const version = "4.26.2";
//# sourceMappingURL=packageMetadata.d.ts.map