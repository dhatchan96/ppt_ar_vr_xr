export declare const contentError = "ContentError";
export declare const pageException = "PageException";
export declare const userSwitch = "user_switch";
//# sourceMappingURL=NativeAuthErrorCodes.d.ts.map