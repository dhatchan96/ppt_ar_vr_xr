export declare const storageNotSupported = "storage_not_supported";
export declare const stubbedPublicClientApplicationCalled = "stubbed_public_client_application_called";
export declare const inMemRedirectUnavailable = "in_mem_redirect_unavailable";
//# sourceMappingURL=BrowserConfigurationAuthErrorCodes.d.ts.map