import { CustomAuthError } from "./CustomAuthError.js";
export declare class NoCachedAccountFoundError extends CustomAuthError {
    constructor(correlationId?: string);
}
//# sourceMappingURL=NoCachedAccountFoundError.d.ts.map