export declare const InvalidUrl = "invalid_url";
//# sourceMappingURL=ParsedUrlErrorCodes.d.ts.map