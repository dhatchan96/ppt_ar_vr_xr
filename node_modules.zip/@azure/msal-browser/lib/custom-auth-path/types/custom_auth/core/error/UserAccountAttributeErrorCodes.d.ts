export declare const InvalidAttributeErrorCode = "invalid_attribute";
//# sourceMappingURL=UserAccountAttributeErrorCodes.d.ts.map