1. need to highlight - command center by default
2. need to have close button in the alert
3. AIT  full form needs to be corrected ( Application inventory Tool) 
4. same for SPK ( software product key)
5. need to change values for drop down
6. Need to change lite color
7. Need to disable selected project text