#!/usr/bin/env python3
"""
Safe test file with no malicious patterns
This file should not trigger any threat detection
"""

import os
import json
import datetime

def safe_function():
    """A completely safe function"""
    print("This is a safe function")
    return True

def calculate_sum(a, b):
    """Safe mathematical operation"""
    return a + b

def read_file_safely(filename):
    """Safe file reading"""
    try:
        with open(filename, 'r') as f:
            return f.read()
    except FileNotFoundError:
        return None

def write_file_safely(filename, content):
    """Safe file writing"""
    try:
        with open(filename, 'w') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error writing file: {e}")
        return False

def get_current_time():
    """Safe time operation"""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def process_data(data):
    """Safe data processing"""
    if isinstance(data, list):
        return sum(data)
    elif isinstance(data, dict):
        return len(data)
    else:
        return 0

def validate_input(user_input):
    """Safe input validation"""
    if not user_input:
        return False
    
    # Simple validation
    if len(user_input) > 100:
        return False
    
    return True

def create_backup(filename):
    """Safe backup creation"""
    backup_name = f"{filename}.backup"
    try:
        with open(filename, 'r') as source:
            with open(backup_name, 'w') as backup:
                backup.write(source.read())
        return True
    except Exception as e:
        print(f"Backup failed: {e}")
        return False

def log_activity(message):
    """Safe logging"""
    timestamp = get_current_time()
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)
    return log_entry

def main():
    """Main function with safe operations"""
    print("Starting safe operations...")
    
    # Safe operations
    safe_function()
    result = calculate_sum(5, 3)
    print(f"Sum: {result}")
    
    current_time = get_current_time()
    print(f"Current time: {current_time}")
    
    # Safe file operations
    write_file_safely("test_output.txt", "This is safe content")
    content = read_file_safely("test_output.txt")
    print(f"File content: {content}")
    
    # Safe data processing
    data = [1, 2, 3, 4, 5]
    total = process_data(data)
    print(f"Data total: {total}")
    
    # Safe validation
    is_valid = validate_input("safe input")
    print(f"Input valid: {is_valid}")
    
    # Safe logging
    log_activity("Safe operation completed")
    
    print("All operations completed safely!")

if __name__ == "__main__":
    main() 