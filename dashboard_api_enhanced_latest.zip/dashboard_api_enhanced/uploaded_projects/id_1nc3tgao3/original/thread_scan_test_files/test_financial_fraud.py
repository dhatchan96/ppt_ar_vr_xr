#!/usr/bin/env python3
"""
Test file with FINANCIAL_FRAUD patterns
This file contains financial fraud and cryptocurrency theft patterns
"""

import requests
import json

# FINANCIAL_FRAUD - Bitcoin address redirection
def redirect_payments():
    # Malicious bitcoin address
    bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    
    # Redirect payments to attacker's wallet
    payment_data = {
        "amount": 1000,
        "currency": "USD",
        "destination": bitcoin_address,
        "description": "System maintenance fee"
    }
    
    print(f"Payment redirected to: {bitcoin_address}")

# FINANCIAL_FRAUD - PayPal redirection
def paypal_fraud():
    # Malicious PayPal.me link
    paypal_link = "https://paypal.me/attacker123"
    
    # Redirect user payments
    redirect_url = paypal_link
    print(f"Payment redirected to: {redirect_url}")

# FINANCIAL_FRAUD - Cryptocurrency wallet theft
def crypto_theft():
    # Ethereum wallet address
    eth_wallet = "0x742d35Cc6634C0532925a3b8D4C9db96C4b4d8b6"
    
    # Transfer funds to attacker
    transfer_data = {
        "from": "user_wallet",
        "to": eth_wallet,
        "amount": "10.5 ETH",
        "gas": "21000"
    }
    
    print(f"Funds transferred to: {eth_wallet}")

# FINANCIAL_FRAUD - Unauthorized money transfer
def unauthorized_transfer():
    # Transfer money to personal account
    personal_account = "1234567890"
    
    transfer_info = {
        "source": "company_account",
        "destination": personal_account,
        "amount": 50000,
        "reason": "Personal development fee"
    }
    
    print(f"Unauthorized transfer to: {personal_account}")

# FINANCIAL_FRAUD - Payment redirection
def payment_redirection():
    # Redirect legitimate payments
    original_payment = "https://legitimate-company.com/pay"
    malicious_payment = "https://attacker-site.com/collect"
    
    # Intercept and redirect
    if "payment" in original_payment:
        redirect_to = malicious_payment
        print(f"Payment redirected to: {redirect_to}")

# FINANCIAL_FRAUD - Crypto mining redirect
def mining_redirect():
    # Redirect to mining pool
    mining_pool = "stratum+tcp://pool.minexmr.com:3333"
    
    # Start mining for attacker
    mining_config = {
        "pool": mining_pool,
        "wallet": "attacker_wallet_address",
        "worker": "victim_machine"
    }
    
    print(f"Mining redirected to: {mining_pool}")

# Normal function
def safe_payment():
    # Safe payment processing
    payment = {
        "amount": 100,
        "currency": "USD",
        "merchant": "legitimate_merchant",
        "secure": True
    }
    print("Safe payment processed")

if __name__ == "__main__":
    # These would be fraudulent if executed
    # redirect_payments()
    # paypal_fraud()
    # crypto_theft()
    # unauthorized_transfer()
    # payment_redirection()
    # mining_redirect()
    
    # Only run safe operation
    safe_payment() 