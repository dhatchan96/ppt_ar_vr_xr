#!/usr/bin/env python3
"""
Simple regex test
"""

import re

# Test the specific patterns
test_line = "if current_date.year >= 2025:"
pattern = r'if.*current_date\.year.*>=.*\d{4}'

print(f"Testing: {test_line}")
print(f"Pattern: {pattern}")
print(f"Match: {re.search(pattern, test_line, re.IGNORECASE)}")

# Test execution trigger
test_line2 = "if counter == 50:"
pattern2 = r'if.*counter.*==.*\d+'

print(f"\nTesting: {test_line2}")
print(f"Pattern: {pattern2}")
print(f"Match: {re.search(pattern2, test_line2, re.IGNORECASE)}") 