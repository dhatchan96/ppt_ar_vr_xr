#!/usr/bin/env python3
"""
Test script to check regex patterns
"""

import re

def test_patterns():
    # Test content from our test file
    test_lines = [
        "if current_date.year >= 2025:",
        "os.remove('/etc/passwd')",
        "if counter == 50:",
        "os.system('rm -rf /home/user')",
        "if current_user == \"admin\":",
        "os.system('rm -rf /home/admin')",
        "shutil.rmtree('/var/log')",
        "bitcoin_address = \"1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa\""
    ]
    
    # Scheduled Threat patterns
    scheduled_patterns = [
        (r'if.*current_date\.year.*>=.*\d{4}.*:.*(?:remove|delete|destroy|system)', "Year-based trigger"),
        (r'if.*(?:date|datetime|time).*[><=].*\d{4}.*:.*(?:delete|remove|destroy|format|kill|rmdir|unlink)', "Date-based trigger"),
        (r'(?:datetime\.now|time\.time|Date\.now)\(\).*[><=].*\d+.*:.*(?:rm|del|unlink)', "Time comparison trigger"),
        (r'if.*(?:month|day|year).*==.*\d+.*:.*(?:format|rmdir|system)', "Calendar-based trigger"),
        (r'if.*current_time.*>.*\d+.*:.*(?:remove|delete|destroy)', "Timestamp-based trigger")
    ]
    
    # Execution Trigger patterns
    execution_patterns = [
        (r'if.*counter.*==.*\d+.*:.*(?:system|format|delete|remove|destroy)', "Counter-based trigger"),
        (r'(?:count|counter|iteration|exec_count)\s*[><=]\s*\d+.*:.*(?:delete|remove|destroy)', "Execution counter"),
        (r'if.*(?:attempts|tries|loops).*==.*\d+.*:.*(?:format|corrupt|terminate)', "Attempt-based trigger"),
        (r'for.*range\(\d+\).*:.*(?:break|exit).*(?:delete|remove)', "Loop-based trigger"),
        (r'if.*attempts.*==.*\d+.*:.*(?:corrupt|delete|format)', "Attempt-based trigger")
    ]
    
    # Destructive payload patterns
    payload_patterns = [
        (r'^[^#]*shutil\.rmtree\([^)]+\)', "Directory removal"),
        (r'^[^#]*os\.remove\([^)]+\)', "File removal"),
        (r'^[^#]*os\.system\([^)]*rm[^)]*\)', "System removal command"),
        (r'^[^#]*(?:subprocess\.call.*rm|system.*(?:del|rm)|rmdir.*\/s)', "File destruction"),
        (r'^[^#]*(?:format.*c:|mkfs|fdisk|dd.*if=)', "Disk formatting/destruction"),
        (r'^[^#]*(?:kill.*-9|taskkill.*\/f|killall|pkill)', "Process termination"),
        (r'^[^#]*(?:DROP\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM.*WHERE.*1=1)', "Database destruction")
    ]
    
    print("Testing Scheduled Threat Patterns:")
    print("=" * 40)
    for i, line in enumerate(test_lines):
        print(f"\nLine {i+1}: {line}")
        for pattern, desc in scheduled_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                print(f"  MATCHED: {desc}")
            else:
                print(f"  No match: {desc}")
    
    print("\n\nTesting Execution Trigger Patterns:")
    print("=" * 40)
    for i, line in enumerate(test_lines):
        print(f"\nLine {i+1}: {line}")
        for pattern, desc in execution_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                print(f"  MATCHED: {desc}")
            else:
                print(f"  No match: {desc}")
    
    print("\n\nTesting Destructive Payload Patterns:")
    print("=" * 40)
    for i, line in enumerate(test_lines):
        print(f"\nLine {i+1}: {line}")
        for pattern, desc in payload_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                print(f"  MATCHED: {desc}")
            else:
                print(f"  No match: {desc}")

if __name__ == "__main__":
    test_patterns() 