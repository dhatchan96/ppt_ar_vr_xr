#!/usr/bin/env python3
"""
Debug test file with obvious threat patterns
"""

import datetime
import os

# SCHEDULED_THREAT - This should be detected
def scheduled_threat():
    current_date = datetime.datetime.now()
    if current_date.year >= 2025:
        os.remove('/etc/passwd')  # This should trigger scheduled threat detection

# TARGETED_ATTACK - This should be detected  
def targeted_attack():
    import getpass
    current_user = getpass.getuser()
    if current_user == "admin":
        os.system('rm -rf /home/admin')  # This should trigger targeted attack detection

# EXECUTION_TRIGGER - This should be detected
def execution_trigger():
    counter = 0
    for i in range(100):
        counter += 1
        if counter == 50:
            os.system('format c: /q')  # This should trigger execution trigger detection

# DESTRUCTIVE_PAYLOAD - This should be detected
def destructive_payload():
    import shutil
    shutil.rmtree('/var/log')  # This should trigger destructive payload detection

# FINANCIAL_FRAUD - This should be detected
def financial_fraud():
    bitcoin_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"
    print(f"Payment to: {bitcoin_address}")  # This should trigger financial fraud detection

if __name__ == "__main__":
    scheduled_threat()
    targeted_attack()
    execution_trigger()
    destructive_payload()
    financial_fraud() 