#!/usr/bin/env python3
"""
Test script to check what data the frontend is receiving
"""

import requests
import json

def test_frontend_data():
    """Test what data the frontend is receiving"""
    base_url = "http://localhost:5000"
    
    print("🔍 Testing Frontend Data...")
    print("=" * 50)
    
    # Test command center metrics endpoint
    print("\n1. Testing /api/command-center/metrics")
    try:
        response = requests.get(f"{base_url}/api/command-center/metrics")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Command center metrics returned")
            
            # Check the exact structure
            print(f"\n📊 Full Response Structure:")
            print(json.dumps(data, indent=2))
            
            # Check logic_bomb_metrics specifically
            logic_bomb_metrics = data.get('logic_bomb_metrics', {})
            print(f"\n📊 Logic Bomb Metrics:")
            print(json.dumps(logic_bomb_metrics, indent=2))
            
            # Check specific values that frontend expects
            print(f"\n📊 Frontend Expected Values:")
            print(f"✅ trigger_complexity_score: {logic_bomb_metrics.get('trigger_complexity_score', 'NOT_FOUND')}")
            print(f"✅ payload_severity_score: {logic_bomb_metrics.get('payload_severity_score', 'NOT_FOUND')}")
            print(f"✅ detection_confidence_avg: {logic_bomb_metrics.get('detection_confidence_avg', 'NOT_FOUND')}")
            print(f"✅ threat_density: {logic_bomb_metrics.get('threat_density', 'NOT_FOUND')}")
            
            # Check if values are 0 or null
            print(f"\n📊 Value Analysis:")
            print(f"✅ trigger_complexity_score is 0: {logic_bomb_metrics.get('trigger_complexity_score') == 0}")
            print(f"✅ payload_severity_score is 0: {logic_bomb_metrics.get('payload_severity_score') == 0}")
            print(f"✅ detection_confidence_avg is 0: {logic_bomb_metrics.get('detection_confidence_avg') == 0}")
            print(f"✅ threat_density is 0: {logic_bomb_metrics.get('threat_density') == 0}")
            
        else:
            print(f"❌ Error: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Exception: {e}")

if __name__ == "__main__":
    print("🚀 Starting Frontend Data Test...")
    test_frontend_data()
    print("\n✅ Frontend data test completed!") 