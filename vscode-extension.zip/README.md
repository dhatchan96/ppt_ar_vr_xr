# ThreatGuard Pro VS Code Extension

Advanced security threat detection and remediation for Visual Studio Code.

## 🚀 Features

### Core Functionality
- **Real-time Threat Detection**: Scan files and workspaces for security threats
- **Logic Bomb Detection**: Identify time-based, user-targeted, and execution-triggered malicious code
- **Destructive Payload Analysis**: Detect potentially harmful operations
- **Security Tech Debt Tracking**: Monitor security-related technical debt
- **Automated Remediation**: Fix security issues with AI-powered suggestions

### VS Code Integration
- **Status Bar**: Real-time threat count and connection status
- **Tree Views**: Organized threat and scan history display
- **Diagnostics**: Inline threat markers in the Problems panel
- **Webview Dashboard**: Rich dashboard with metrics and controls
- **Context Menus**: Right-click actions for scanning and remediation
- **Keyboard Shortcuts**: Quick access to scanning commands

### Advanced Features
- **Multi-language Support**: Python, JavaScript, TypeScript, Java, C#, C++, Rust, Go, PHP, Ruby
- **Hierarchical Organization**: AIT → SPK → Repo → Scan tagging system
- **Threat Intelligence**: Risk scoring and threat analysis
- **GitHub Integration**: Scan repositories directly from VS Code
- **Auto-scan**: Automatic scanning on file save (configurable)

## 📋 Prerequisites

### Backend Requirements
- Python 3.8+
- Flask server running on `http://localhost:5000`
- ThreatGuard Pro backend API (see main project)

### Development Requirements
- Node.js 16+
- TypeScript 4.8+
- VS Code Extension Development Tools

## 🛠️ Installation & Setup

### 1. Install Dependencies

```bash
cd vscode-extension
npm install
```

### 2. Build the Extension

```bash
npm run compile
```

### 3. Start the Backend Server

```bash
# In the main project directory
python dashboard_api_enhanced.py
```

### 4. Install the Extension

#### Development Mode
```bash
# Press F5 in VS Code to launch extension host
# Or use the extension development host
```

#### Production Installation
```bash
# Package the extension
npm run package

# Install the .vsix file
code --install-extension threatguard-pro-1.0.0.vsix
```

## 🔧 Configuration

### Extension Settings

Open VS Code settings and configure:

```json
{
  "threatguard.apiUrl": "http://localhost:5000",
  "threatguard.autoScan": false,
  "threatguard.severityLevel": "MEDIUM",
  "threatguard.enableNotifications": true
}
```

### Settings Description

| Setting | Description | Default |
|---------|-------------|---------|
| `apiUrl` | ThreatGuard API server URL | `http://localhost:5000` |
| `autoScan` | Automatically scan files on save | `false` |
| `severityLevel` | Minimum severity to display | `MEDIUM` |
| `enableNotifications` | Show notifications for threats | `true` |

## 🎯 Usage

### Commands

#### Available Commands
- `ThreatGuard: Scan Current File` - Scan the active file for threats
- `ThreatGuard: Scan Workspace` - Scan the entire workspace
- `ThreatGuard: Show Dashboard` - Open the dashboard webview
- `ThreatGuard: Remediate Current File` - Fix security issues in the current file
- `ThreatGuard: Show Threats` - Display all detected threats
- `ThreatGuard: Configure` - Open extension settings

#### Keyboard Shortcuts
- `Ctrl+Shift+T` (Windows/Linux) or `Cmd+Shift+T` (Mac) - Scan current file

### Views

#### ThreatGuard Sidebar
- **Dashboard**: Security metrics and overview
- **Threats**: Organized threat display by category
- **Scans**: Scan history and results

#### Status Bar
- Shows connection status and threat count
- Click to open dashboard or configure settings

### Context Menus

Right-click in the editor to access:
- Scan current file
- Remediate current file

## 🏗️ Architecture

### File Structure
```
vscode-extension/
├── src/
│   ├── extension.ts              # Main extension entry point
│   ├── api/
│   │   └── threatguard-api.ts   # API client for backend communication
│   ├── providers/
│   │   ├── threat-provider.ts   # Threat tree view provider
│   │   ├── dashboard-provider.ts # Dashboard metrics provider
│   │   └── scan-provider.ts     # Scan history provider
│   ├── status/
│   │   └── threatguard-statusbar.ts # Status bar component
│   ├── diagnostics/
│   │   └── threatguard-diagnostics.ts # Problems panel integration
│   └── webview/
│       └── threatguard-webview.ts # Dashboard webview
├── package.json                  # Extension manifest
├── tsconfig.json                # TypeScript configuration
└── README.md                    # This file
```

### Key Components

#### 1. API Client (`threatguard-api.ts`)
- Handles all communication with the ThreatGuard backend
- Provides type-safe interfaces for threats, scans, and metrics
- Includes error handling and request/response interceptors

#### 2. Tree View Providers
- **ThreatProvider**: Displays threats organized by category and severity
- **DashboardProvider**: Shows security metrics and system status
- **ScanProvider**: Lists scan history with detailed results

#### 3. Status Bar (`threatguard-statusbar.ts`)
- Real-time connection status
- Threat count display
- Quick access to main functions

#### 4. Diagnostics (`threatguard-diagnostics.ts`)
- Integrates with VS Code Problems panel
- Shows threat locations in code
- Provides detailed threat information

#### 5. Webview (`threatguard-webview.ts`)
- Rich HTML dashboard
- Interactive threat management
- Real-time metrics display

## 🔌 API Integration

### Backend Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/health` | GET | Check server status |
| `/api/scan/files` | POST | Scan individual files |
| `/api/scan` | POST | Scan entire workspace |
| `/api/threats` | GET | Fetch all threats |
| `/api/command-center/metrics` | GET | Get dashboard metrics |
| `/api/scan-history` | GET | Get scan history |
| `/api/vscode-agent/remediate` | POST | Remediate file |
| `/api/threats/{id}/neutralize` | POST | Neutralize specific threat |

### Data Models

#### Threat Interface
```typescript
interface Threat {
    id: string;
    rule_id: string;
    file_path: string;
    line_number: number;
    column: number;
    message: string;
    severity: string;
    type: string;
    status: string;
    code_snippet: string;
    suggested_fix: string;
    threat_level: string;
    trigger_analysis: string;
    payload_analysis: string;
    // ... additional fields
}
```

## 🚀 Development

### Building
```bash
npm run compile
```

### Watching for Changes
```bash
npm run watch
```

### Testing
```bash
npm run test
```

### Linting
```bash
npm run lint
```

### Packaging
```bash
npm run package
```

## 🔍 Debugging

### Extension Development
1. Open the extension folder in VS Code
2. Press `F5` to launch the extension development host
3. Use the new VS Code window to test the extension

### Backend Integration
1. Ensure the ThreatGuard backend is running on `http://localhost:5000`
2. Check the extension's output channel for API communication logs
3. Use the Developer Tools to inspect webview content

### Common Issues

#### Connection Issues
- Verify the backend server is running
- Check the API URL in settings
- Review the extension's output channel for error messages

#### Scan Failures
- Ensure the file is saved before scanning
- Check file permissions
- Verify the backend can access the file path

#### Performance Issues
- Disable auto-scan for large workspaces
- Increase the API timeout in settings
- Use workspace-specific scanning instead of full workspace scans

## 🎨 Customization

### Adding New Commands
1. Add command to `package.json` contributes section
2. Register command in `extension.ts`
3. Implement command handler

### Customizing Views
1. Modify the respective provider class
2. Update the tree item rendering
3. Add new data sources as needed

### Styling
- Webview styles use VS Code theme variables
- Tree view icons use VS Code's built-in icon set
- Status bar colors follow VS Code's color scheme

## 📦 Distribution

### Publishing to VS Code Marketplace
1. Create a publisher account on https://marketplace.visualstudio.com/
2. Package the extension: `npm run package`
3. Use `vsce` to publish: `vsce publish`

### Private Distribution
1. Package the extension: `npm run package`
2. Share the `.vsix` file
3. Install with: `code --install-extension threatguard-pro-1.0.0.vsix`

## 🤝 Contributing

### Development Workflow
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

### Code Style
- Follow TypeScript best practices
- Use VS Code's extension API patterns
- Maintain consistent error handling
- Add appropriate logging

## 📄 License

This extension is part of the ThreatGuard Pro project. See the main project for licensing information.

## 🆘 Support

### Getting Help
- Check the extension's output channel for error messages
- Review the backend server logs
- Consult the main ThreatGuard Pro documentation

### Reporting Issues
- Include VS Code version and OS
- Provide steps to reproduce
- Include relevant error messages
- Attach sample files if applicable

## 🔮 Future Enhancements

### Planned Features
- **Real-time Collaboration**: Share threat findings with team members
- **Advanced Filtering**: Filter threats by multiple criteria
- **Custom Rules**: Create and manage custom detection rules
- **Integration APIs**: Connect with other security tools
- **Performance Optimization**: Faster scanning for large codebases
- **Offline Mode**: Basic threat detection without backend

### Extension Points
- **Custom Threat Detectors**: Plugin system for custom detection logic
- **Third-party Integrations**: Connect with external security services
- **Custom Dashboards**: User-defined dashboard layouts
- **Advanced Reporting**: Generate detailed security reports

---

**ThreatGuard Pro VS Code Extension** - Making security threat detection accessible and integrated into your development workflow.

