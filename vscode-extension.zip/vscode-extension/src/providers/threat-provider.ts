import * as vscode from 'vscode';
import { ThreatGuardAPI, Threat } from '../api/threatguard-api';

export class ThreatProvider implements vscode.TreeDataProvider<ThreatItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<ThreatItem | undefined | null | void> = new vscode.EventEmitter<ThreatItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<ThreatItem | undefined | null | void> = this._onDidChangeTreeData.event;
    private currentThreats: Threat[] = [];

    constructor(private api: ThreatGuardAPI) {}

    updateThreats(threats: Threat[]): void {
        console.log(`ThreatProvider: Updating with ${threats.length} threats`);
        console.log('ThreatProvider: Sample threats:', threats.slice(0, 3).map(t => ({
            id: t.id,
            file_name: t.file_name,
            file_path: t.file_path,
            line_number: t.line_number,
            type: t.type,
            severity: t.severity
        })));
        this.currentThreats = threats;
        this.refresh();
    }

    clearThreats(): void {
        console.log('ThreatProvider: Clearing current threats');
        this.currentThreats = [];
        this.refresh();
    }

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: ThreatItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: ThreatItem): Promise<ThreatItem[]> {
        if (!element) {
            // Root level - show threat categories
            try {
                // Only use current threats - don't fall back to all threats from API
                const threats = this.currentThreats;
                
                console.log(`ThreatProvider: Root level - Showing ${threats.length} threats`);
                console.log(`ThreatProvider: currentThreats.length = ${this.currentThreats.length}`);
                
                // If we have current threats (from a recent scan), use only those
                // Otherwise, show a message to run a scan
                if (this.currentThreats.length > 0) {
                    console.log('ThreatProvider: Using current threats from recent scan');
                } else {
                    console.log('ThreatProvider: No current threats, showing message to run scan');
                    return [new ThreatItem('Run a scan to see threats', 'info', vscode.TreeItemCollapsibleState.None)];
                }
                
                if (threats.length === 0) {
                    console.log('ThreatProvider: No threats found, showing "No threats detected" message');
                    return [new ThreatItem('No threats detected', 'info', vscode.TreeItemCollapsibleState.None)];
                }
                
                const categories = this.groupThreatsByCategory(threats);
                console.log(`ThreatProvider: Created ${categories.length} categories:`, categories.map(c => c.label));
                return categories;
            } catch (error) {
                console.error('Failed to fetch threats:', error);
                return [new ThreatItem('Error loading threats', 'error', vscode.TreeItemCollapsibleState.None)];
            }
        }

        if (element.contextValue === 'category') {
            // Category level - show threats in this category
            const threats = this.currentThreats;
            console.log(`ThreatProvider: Category "${element.label}" - filtering ${threats.length} threats`);
            
            // Debug: Log all threats to see their structure
            console.log('All threats:', threats.map(t => ({
                id: t.id,
                type: t.type,
                severity: t.severity,
                file_name: t.file_name,
                file_path: t.file_path,
                line_number: t.line_number,
                message: t.message
            })));
            
            const categoryThreats = threats.filter(t => {
                const category = this.getThreatCategory(t);
                // Extract the base category name without the count in parentheses
                const baseCategory = element.label.replace(/\s*\(\d+\)$/, '');
                const matches = category === baseCategory;
                console.log(`Threat ${t.id}: type="${t.type}", severity="${t.severity}", category="${category}", baseCategory="${baseCategory}", matches="${element.label}" = ${matches}`);
                return matches;
            });
            
            console.log(`ThreatProvider: Found ${categoryThreats.length} threats for category "${element.label}"`);
            
            return categoryThreats.map(threat => {
                // Create a better label that shows filename and line number clearly
                const fileName = threat.file_name || threat.file_path?.split(/[\\/]/).pop() || 'unknown';
                const lineNumber = threat.line_number || 1;
                const shortMessage = threat.message?.length > 50 ? threat.message.substring(0, 50) + '...' : threat.message;
                
                return new ThreatItem(
                    `${fileName}:${lineNumber} - ${shortMessage}`,
                    'threat',
                    vscode.TreeItemCollapsibleState.None,
                    threat
                );
            });
        }

        return [];
    }

    private groupThreatsByCategory(threats: Threat[]): ThreatItem[] {
        const categories = new Map<string, Threat[]>();
        
        console.log(`ThreatProvider: Grouping ${threats.length} threats by category`);
        
        threats.forEach(threat => {
            const category = this.getThreatCategory(threat);
            if (!categories.has(category)) {
                categories.set(category, []);
            }
            categories.get(category)!.push(threat);
        });

        const result = Array.from(categories.entries()).map(([category, categoryThreats]) => {
            const severity = this.getHighestSeverity(categoryThreats);
            console.log(`ThreatProvider: Category "${category}" has ${categoryThreats.length} threats with severity ${severity}`);
            return new ThreatItem(
                `${category} (${categoryThreats.length})`,
                'category',
                vscode.TreeItemCollapsibleState.Collapsed,
                undefined,
                severity
            );
        });
        
        console.log(`ThreatProvider: Created ${result.length} category items`);
        return result;
    }

    private getThreatCategory(threat: Threat): string {
        console.log(`ThreatProvider: Categorizing threat ${threat.id} with type="${threat.type}" severity="${threat.severity}"`);
        // Match the actual threat types from the backend
        if (threat.type === 'SCHEDULED_THREAT') return 'Scheduled Threats';
        if (threat.type === 'TARGETED_ATTACK') return 'Targeted Attacks';
        if (threat.type === 'EXECUTION_TRIGGER') return 'Execution Triggers';
        if (threat.type === 'DESTRUCTIVE_PAYLOAD') return 'Destructive Payloads';
        if (threat.type === 'SECURITY_TECH_DEBT') return 'Security Tech Debt';
        if (threat.type === 'LOGIC_BOMB') return 'Logic Bombs';
        if (threat.type === 'FINANCIAL_FRAUD') return 'Financial Fraud';
        if (threat.type === 'VULNERABILITY') return 'Vulnerabilities';
        
        // Fallback to severity-based categorization
        if (threat.severity === 'CRITICAL_BOMB') return 'Critical Threats';
        if (threat.severity === 'HIGH_RISK') return 'High Risk Threats';
        if (threat.severity === 'MEDIUM_RISK') return 'Medium Risk Threats';
        if (threat.severity === 'LOW_RISK') return 'Low Risk Threats';
        if (threat.severity === 'CRITICAL') return 'Critical Threats';
        
        // If no type or severity, categorize as unknown
        console.log(`Warning: Threat ${threat.id} has no type or severity:`, threat);
        return 'Other Threats';
    }

    private getHighestSeverity(threats: Threat[]): string {
        const severityOrder = ['CRITICAL_BOMB', 'HIGH_RISK', 'MEDIUM_RISK', 'LOW_RISK'];
        for (const severity of severityOrder) {
            if (threats.some(t => t.severity === severity)) {
                return severity;
            }
        }
        return 'UNKNOWN';
    }
}

export class ThreatItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly contextValue: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly threat?: Threat,
        public readonly severity?: string
    ) {
        super(label, collapsibleState);

        if (contextValue === 'threat' && threat) {
            const fileName = threat.file_name || threat.file_path?.split(/[\\/]/).pop() || 'unknown';
            this.tooltip = `${threat.file_path}:${threat.line_number}\n${threat.message}\n\nSeverity: ${threat.severity}\nType: ${threat.type}`;
            this.description = `${threat.severity} - ${threat.type}`;
            this.iconPath = this.getSeverityIcon(threat.severity);
            this.command = {
                command: 'threatguard.showThreatDetails',
                title: 'Show Threat Details',
                arguments: [threat]
            };
        } else if (contextValue === 'category') {
            this.iconPath = this.getCategoryIcon(severity || 'UNKNOWN');
        } else if (contextValue === 'error') {
            this.iconPath = new vscode.ThemeIcon('error');
        }
    }

    private getSeverityIcon(severity: string): vscode.ThemeIcon {
        switch (severity) {
            case 'CRITICAL_BOMB':
                return new vscode.ThemeIcon('error', new vscode.ThemeColor('errorForeground'));
            case 'HIGH_RISK':
                return new vscode.ThemeIcon('warning', new vscode.ThemeColor('warningForeground'));
            case 'MEDIUM_RISK':
                return new vscode.ThemeIcon('info', new vscode.ThemeColor('infoForeground'));
            case 'LOW_RISK':
                return new vscode.ThemeIcon('info');
            default:
                return new vscode.ThemeIcon('question');
        }
    }

    private getCategoryIcon(severity: string): vscode.ThemeIcon {
        switch (severity) {
            case 'CRITICAL_BOMB':
                return new vscode.ThemeIcon('shield', new vscode.ThemeColor('errorForeground'));
            case 'HIGH_RISK':
                return new vscode.ThemeIcon('shield', new vscode.ThemeColor('warningForeground'));
            case 'MEDIUM_RISK':
                return new vscode.ThemeIcon('shield', new vscode.ThemeColor('infoForeground'));
            case 'LOW_RISK':
                return new vscode.ThemeIcon('shield');
            default:
                return new vscode.ThemeIcon('shield');
        }
    }
}

