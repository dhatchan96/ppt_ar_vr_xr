import * as vscode from 'vscode';
import { ThreatGuardAPI } from './api/threatguard-api';
import { ThreatProvider } from './providers/threat-provider';
import { DashboardProvider } from './providers/dashboard-provider';
import { ScanProvider } from './providers/scan-provider';
import { VulnerabilityProvider } from './providers/vulnerability-provider';
import { ThreatGuardStatusBar } from './status/threatguard-statusbar';
import { ThreatGuardDiagnostics } from './diagnostics/threatguard-diagnostics';
import { ThreatGuardWebview } from './webview/threatguard-webview';

export function activate(context: vscode.ExtensionContext) {
    console.log('ThreatGuard Pro extension is now active!');

    // Initialize API client
    const api = new ThreatGuardAPI();
    
    // Initialize providers
    const threatProvider = new ThreatProvider(api);
    const dashboardProvider = new DashboardProvider(api);
    const scanProvider = new ScanProvider(api);
    const vulnerabilityProvider = new VulnerabilityProvider(api);
    
    // Initialize status bar
    const statusBar = new ThreatGuardStatusBar();
    
    // Initialize diagnostics
    const diagnostics = new ThreatGuardDiagnostics();
    
    // Initialize webview
    const webview = new ThreatGuardWebview(context.extensionUri);

    // Register tree data providers
    vscode.window.registerTreeDataProvider('threatguard.threatsView', threatProvider);
    vscode.window.registerTreeDataProvider('threatguard.dashboardView', dashboardProvider);
    vscode.window.registerTreeDataProvider('threatguard.scansView', scanProvider);
    vscode.window.registerTreeDataProvider('threatguard.vulnerabilitiesView', vulnerabilityProvider);

    // Register commands
    let refreshScanHistoryCommand = vscode.commands.registerCommand('threatguard.refreshScanHistory', () => {
        scanProvider.refresh();
        vscode.window.showInformationMessage('Scan history refreshed');
    });

    let scanFileCommand = vscode.commands.registerCommand('threatguard.scanFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showWarningMessage('No active editor found');
            return;
        }

        const document = editor.document;
        let content = document.getText();
        const filePath = document.fileName;

        // Normalize line endings to prevent spaces from being added
        content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

        // Debug: Log the content length and first few lines
        console.log(`Scanning file: ${filePath}`);
        console.log(`Content length: ${content.length}`);
        console.log(`First 200 chars: ${content.substring(0, 200)}`);
        console.log(`Line endings normalized: ${content.includes('\r\n') ? 'NO' : 'YES'}`);

        let result: any = null; // Declared outside try block
        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                statusBar.showError();
                return;
            }

            statusBar.showScanning();
            vscode.window.showInformationMessage('Scanning file for threats...');

            // Clear any existing threats before starting new scan
            threatProvider.clearThreats();

            result = await api.scanFile(filePath, content);
            
            console.log('Scan result:', result);
            
                                     if (result.threats && result.threats.length > 0) {
                diagnostics.setThreats(document.uri, result.threats);
                vscode.window.showWarningMessage(`Found ${result.threats.length} threats in ${document.fileName}`);
                statusBar.showThreats(result.threats.length);
                
                // Update threat provider with detected threats
                threatProvider.updateThreats(result.threats);
                
                // Update webview with recent threats
                webview.updateRecentThreats(result.threats);
                
                // Create scan data for dashboard update
                const scanData = {
                    duration_ms: result.duration_ms || 0,
                    files_scanned: 1,
                    issues_found: result.threats.length,
                    quality_gate_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED',
                    lines_of_code: result.lines_of_code || 0,
                    coverage: '100%'
                };
                
                // Update dashboard with scan data
                console.log('Extension: Updating dashboard with scan data:', scanData);
                webview.updateDashboardWithScanData(scanData);
                dashboardProvider.updateWithScanData(scanData);

                // Save scan data to JSON for React UI
                try {
                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: filePath,
                        file_name: document.fileName,
                        content: content,
                        threats: result.threats,
                        scan_metrics: scanData,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            } else {
                vscode.window.showInformationMessage('No threats detected in file');
                statusBar.showClean();
                
                // Clear threats from provider
                threatProvider.updateThreats([]);
                
                // Clear recent threats from webview
                webview.updateRecentThreats([]);
                
                // Update dashboard with clean scan data
                const scanData = {
                    duration_ms: result.duration_ms || 0,
                    files_scanned: 1,
                    issues_found: 0,
                    quality_gate_status: 'PASSED',
                    lines_of_code: result.lines_of_code || 0,
                    coverage: '100%'
                };
                
                console.log('Extension: Updating dashboard with clean scan data:', scanData);
                webview.updateDashboardWithScanData(scanData);
                dashboardProvider.updateWithScanData(scanData);

                // Save scan data to JSON for React UI (even for clean scans)
                try {
                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: filePath,
                        file_name: document.fileName,
                        content: content,
                        threats: [],
                        scan_metrics: scanData,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Clean scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save clean scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            }

            // Refresh providers
            dashboardProvider.refresh();

        } catch (error) {
            console.error('Scan error:', error);
            vscode.window.showErrorMessage(`Scan failed: ${error}`);
            statusBar.showError();
        } finally {
            // Don't reset status bar immediately - let it show the threat count
            // Only reset after a delay if no threats were found
            if (!result?.threats || result.threats.length === 0) {
                setTimeout(() => {
                    statusBar.showClean();
                }, 5000);
            }
        }
    });

    // Helper function to calculate lines of code in workspace
    const calculateLinesOfCode = async (workspacePath: string): Promise<number> => {
        try {
            const fs = require('fs');
            const path = require('path');
            
            let totalLines = 0;
            
            const countLinesInFile = (filePath: string): number => {
                try {
                    const content = fs.readFileSync(filePath, 'utf8');
                    return content.split('\n').length;
                } catch (error) {
                    return 0;
                }
            };
            
            const walkDir = (dir: string): void => {
                const files = fs.readdirSync(dir);
                for (const file of files) {
                    const filePath = path.join(dir, file);
                    const stat = fs.statSync(filePath);
                    
                    if (stat.isDirectory()) {
                        // Skip node_modules, .git, etc.
                        if (!['node_modules', '.git', '.vscode', 'dist', 'build'].includes(file)) {
                            walkDir(filePath);
                        }
                    } else {
                        // Count lines for code files
                        const ext = path.extname(file).toLowerCase();
                        if (['.js', '.ts', '.py', '.java', '.cpp', '.c', '.cs', '.php', '.rb', '.go', '.rs', '.swift', '.kt'].includes(ext)) {
                            totalLines += countLinesInFile(filePath);
                        }
                    }
                }
            };
            
            walkDir(workspacePath);
            return totalLines;
        } catch (error) {
            console.error('Error calculating lines of code:', error);
            return 0;
        }
    };

    let scanWorkspaceCommand = vscode.commands.registerCommand('threatguard.scanWorkspace', async () => {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showWarningMessage('No workspace folder found');
            return;
        }

        let result: any = null;
        try {
            statusBar.showScanning();
            vscode.window.showInformationMessage('Scanning workspace for threats...');

            // Clear any existing threats before starting new scan
            threatProvider.clearThreats();

            result = await api.scanWorkspace(workspaceFolders[0].uri.fsPath);
            
            console.log('Workspace scan result:', result);
            
            if (result.threats && result.threats.length > 0) {
                vscode.window.showWarningMessage(`Found ${result.threats.length} threats in workspace`);
                statusBar.showThreats(result.threats.length);
                
                // Update threat provider with detected threats
                threatProvider.updateThreats(result.threats);
                
                // Update webview with recent threats
                webview.updateRecentThreats(result.threats);
                
                // Update dashboard with scan data
                if (result.scan_data) {
                    console.log('Extension: Updating dashboard with scan data:', result.scan_data);
                    webview.updateDashboardWithScanData(result.scan_data);
                    dashboardProvider.updateWithScanData(result.scan_data);
                } else {
                    console.log('Extension: No scan_data in result');
                }

                // Save workspace scan data to JSON for React UI
                try {
                                    // Calculate additional metrics for workspace scan
                const enhancedScanMetrics = {
                    ...result.scan_data,
                    duration_ms: result.scan_data?.duration_ms || 0,
                    files_scanned: result.scan_data?.files_scanned || 1,
                    issues_found: result.threats.length,
                    quality_gate_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED',
                    lines_of_code: result.scan_data?.lines_of_code || await calculateLinesOfCode(workspaceFolders[0].uri.fsPath),
                    coverage: '100%', // Always 100% for workspace scans
                    logic_bomb_risk_score: result.scan_data?.logic_bomb_risk_score || 0,
                    threat_shield_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED'
                };

                console.log('🔍 Enhanced scan metrics:', enhancedScanMetrics);
                console.log('🔍 Scan data from backend:', result.scan_data);

                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: workspaceFolders[0].uri.fsPath,
                        file_name: 'workspace_scan',
                        content: '', // Workspace scan doesn't have a single file content
                        threats: result.threats,
                        scan_metrics: enhancedScanMetrics,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Workspace scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save workspace scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            } else {
                vscode.window.showInformationMessage('No threats detected in workspace');
                statusBar.showClean();
                
                // Clear threats from provider
                threatProvider.updateThreats([]);
                
                // Clear recent threats from webview
                webview.updateRecentThreats([]);

                // Save clean workspace scan data to JSON for React UI
                try {
                                    // Calculate additional metrics for clean workspace scan
                const enhancedScanMetrics = {
                    ...(result.scan_data || {}),
                    duration_ms: result.scan_data?.duration_ms || 0,
                    files_scanned: result.scan_data?.files_scanned || 1,
                    issues_found: 0,
                    quality_gate_status: 'PASSED',
                    lines_of_code: result.scan_data?.lines_of_code || await calculateLinesOfCode(workspaceFolders[0].uri.fsPath),
                    coverage: '100%', // Always 100% for workspace scans
                    logic_bomb_risk_score: 0,
                    threat_shield_status: 'PASSED'
                };

                console.log('🔍 Enhanced clean scan metrics:', enhancedScanMetrics);
                console.log('🔍 Clean scan data from backend:', result.scan_data);

                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: workspaceFolders[0].uri.fsPath,
                        file_name: 'workspace_scan',
                        content: '',
                        threats: [],
                        scan_metrics: enhancedScanMetrics,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Clean workspace scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save clean workspace scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            }

            // Refresh providers
            threatProvider.refresh();
            dashboardProvider.refresh();
            scanProvider.refresh();

        } catch (error) {
            vscode.window.showErrorMessage(`Workspace scan failed: ${error}`);
            statusBar.showError();
        } finally {
            // Don't reset status bar immediately - let it show the threat count
            // Only reset after a delay if no threats were found
            if (!result?.threats || result.threats.length === 0) {
                setTimeout(() => {
                    statusBar.showClean();
                }, 5000);
            }
        }
    });

    let showDashboardCommand = vscode.commands.registerCommand('threatguard.showDashboard', () => {
        webview.showDashboard();
    });

    let remediateFileCommand = vscode.commands.registerCommand('threatguard.remediateFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showWarningMessage('No active editor found');
            return;
        }

        const document = editor.document;
        let content = document.getText();
        const filePath = document.fileName;

        // Normalize line endings to prevent spaces from being added
        content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                statusBar.showError();
                return;
            }

            statusBar.showRemediating();
            vscode.window.showInformationMessage('Remediating file...');

            console.log(`Remediating file: ${filePath}`);
            console.log(`Content length: ${content.length}`);

            const result = await api.remediateFile(filePath, content);
            
            console.log('Remediation result:', result);
            
            // Check if we have remediated content or if the result indicates success
            if (result.remediated_content && result.remediated_content.trim() !== '') {
                // Create a new document with the remediated content
                const newDocument = await vscode.workspace.openTextDocument({
                    content: result.remediated_content,
                    language: document.languageId
                });
                
                await vscode.window.showTextDocument(newDocument);
                vscode.window.showInformationMessage('File remediated successfully');
                statusBar.showClean();
            } else if (result.changes_made && result.changes_made.length > 0) {
                // If there were changes made but no new content, show the changes
                vscode.window.showInformationMessage(`Remediation completed. Changes made: ${result.changes_made.join(', ')}`);
                statusBar.showClean();
            } else {
                vscode.window.showInformationMessage('No remediation needed - file is already secure');
                statusBar.showClean();
            }

        } catch (error) {
            console.error('Remediation error:', error);
            vscode.window.showErrorMessage(`Remediation failed: ${error}`);
            statusBar.showError();
        } finally {
            // Always ensure status bar is reset after remediation attempt
            setTimeout(() => {
                statusBar.showClean();
            }, 2000);
        }
    });

    // Generate Copilot remediation prompt command
    let generateCopilotPromptCommand = vscode.commands.registerCommand('threatguard.generateCopilotPrompt', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found. Please open a file first.');
            return;
        }

        const document = editor.document;
        const filePath = document.fileName;
        const content = document.getText();

        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                return;
            }

            vscode.window.showInformationMessage('Scanning file to generate Copilot prompt...');

            const result = await api.scanFile(filePath, content);
            
            if (result.threats && result.threats.length > 0) {
                // Generate detailed prompt for Copilot
                const prompt = generateCopilotPrompt(document.fileName, result.threats, content);
                
                // Open Copilot chat and paste the prompt
                await openCopilotChatWithPrompt(prompt);
                
                vscode.window.showInformationMessage(`Generated Copilot prompt for ${result.threats.length} threats. Check the Copilot chat!`);
            } else {
                vscode.window.showInformationMessage('No threats detected in file. No remediation needed.');
            }

        } catch (error) {
            console.error('Copilot prompt generation error:', error);
            vscode.window.showErrorMessage(`Failed to generate Copilot prompt: ${error}`);
        }
    });

    let showThreatsCommand = vscode.commands.registerCommand('threatguard.showThreats', () => {
        webview.showThreats();
    });

    let showThreatDetailsCommand = vscode.commands.registerCommand('threatguard.showThreatDetails', async (threat: any) => {
        // Show threat details in webview
        webview.showThreatDetails(threat);
        
        // Also try to open the file at the specific line if possible
        if (threat.file_path && threat.line_number) {
            try {
                const fileUri = vscode.Uri.file(threat.file_path);
                const document = await vscode.workspace.openTextDocument(fileUri);
                const editor = await vscode.window.showTextDocument(document);
                
                // Go to the specific line
                const lineNumber = typeof threat.line_number === 'string' ? parseInt(threat.line_number, 10) : threat.line_number;
                const position = new vscode.Position(lineNumber - 1, 0); // VSCode uses 0-based line numbers
                editor.selection = new vscode.Selection(position, position);
                editor.revealRange(new vscode.Range(position, position), vscode.TextEditorRevealType.InCenter);
                
                console.log(`Opened file ${threat.file_path} at line ${lineNumber}`);
            } catch (error) {
                console.error(`Failed to open file ${threat.file_path}:`, error);
                // Don't show error to user as this is just a convenience feature
            }
        }
    });

    let openFileAtLineCommand = vscode.commands.registerCommand('threatguard.openFileAtLine', async (threat: any) => {
        if (threat.file_path && threat.line_number) {
            try {
                const fileUri = vscode.Uri.file(threat.file_path);
                const document = await vscode.workspace.openTextDocument(fileUri);
                const editor = await vscode.window.showTextDocument(document);
                
                // Go to the specific line
                const lineNumber = typeof threat.line_number === 'string' ? parseInt(threat.line_number, 10) : threat.line_number;
                const position = new vscode.Position(lineNumber - 1, 0); // VSCode uses 0-based line numbers
                editor.selection = new vscode.Selection(position, position);
                editor.revealRange(new vscode.Range(position, position), vscode.TextEditorRevealType.InCenter);
                
                console.log(`Opened file ${threat.file_path} at line ${lineNumber}`);
            } catch (error) {
                console.error(`Failed to open file ${threat.file_path}:`, error);
                vscode.window.showErrorMessage(`Failed to open file: ${error}`);
            }
        } else {
            vscode.window.showWarningMessage('No file path or line number available for this threat');
        }
    });

    let refreshThreatsCommand = vscode.commands.registerCommand('threatguard.refreshThreats', async () => {
        try {
            console.log('Manual refresh of threats view requested');
            
            // Fetch latest threats from API
            const threats = await api.getThreats();
            console.log(`Fetched ${threats.length} threats from API`);
            
            // Update threat provider
            threatProvider.updateThreats(threats);
            
            // Force refresh the view
            threatProvider.refresh();
            
            vscode.window.showInformationMessage(`Refreshed threats view with ${threats.length} threats`);
        } catch (error) {
            console.error('Failed to refresh threats:', error);
            vscode.window.showErrorMessage(`Failed to refresh threats: ${error}`);
        }
    });

    let showAllThreatsCommand = vscode.commands.registerCommand('threatguard.showAllThreats', async () => {
        try {
            console.log('Show all threats requested');
            
            // Fetch all threats from API
            const threats = await api.getThreats();
            console.log(`Fetched ${threats.length} threats from API`);
            
            // Update threat provider with all threats
            threatProvider.updateThreats(threats);
            
            // Force refresh the view
            threatProvider.refresh();
            
            vscode.window.showInformationMessage(`Showing all ${threats.length} threats from database`);
        } catch (error) {
            console.error('Failed to show all threats:', error);
            vscode.window.showErrorMessage(`Failed to show all threats: ${error}`);
        }
    });

    let configureCommand = vscode.commands.registerCommand('threatguard.configure', () => {
        vscode.commands.executeCommand('workbench.action.openSettings', 'threatguard');
    });

    // Vulnerability Management Commands
    let showVulnerabilitiesCommand = vscode.commands.registerCommand('threatguard.showVulnerabilities', async (type?: string) => {
        try {
            console.log('Loading vulnerabilities from database...');
            await vulnerabilityProvider.loadVulnerabilities();
            const vulnerabilities = vulnerabilityProvider.getVulnerabilities();
            console.log(`Loaded ${vulnerabilities.length} vulnerabilities:`, vulnerabilities);
            vscode.window.showInformationMessage(`Loaded ${vulnerabilities.length} vulnerabilities from database`);
        } catch (error) {
            console.error('Failed to show vulnerabilities:', error);
            vscode.window.showErrorMessage(`Failed to show vulnerabilities: ${error}`);
        }
    });

    let generateVulnerabilityPromptCommand = vscode.commands.registerCommand('threatguard.generateVulnerabilityPrompt', async (vulnerability?: any) => {
        try {
            // If vulnerability is provided from context menu, use it
            if (vulnerability) {
                await generateVulnerabilityPromptForVulnerability(vulnerability, api);
                return;
            }

            // Otherwise, show a quick pick to select vulnerability
            const vulnerabilities = vulnerabilityProvider.getVulnerabilities();
            if (vulnerabilities.length === 0) {
                vscode.window.showWarningMessage('No vulnerabilities found. Please load vulnerabilities first.');
                return;
            }

            const items = vulnerabilities.map(v => ({
                label: `${v.vulnerability_title}`,
                description: `${v.vulnerability_type} | ${v.severity} | ${v.repository}`,
                detail: v.description,
                vulnerability: v
            }));

            const selected = await vscode.window.showQuickPick(items, {
                placeHolder: 'Select a vulnerability to generate prompt for',
                matchOnDescription: true,
                matchOnDetail: true
            });

            if (selected) {
                await generateVulnerabilityPromptForVulnerability(selected.vulnerability, api);
            }
        } catch (error) {
            console.error('Failed to generate vulnerability prompt:', error);
            vscode.window.showErrorMessage(`Failed to generate vulnerability prompt: ${error}`);
        }
    });

    let executeCopilotRemediationCommand = vscode.commands.registerCommand('threatguard.executeCopilotRemediation', async (vulnerability?: any) => {
        try {
            // If vulnerability is provided from context menu, use it
            if (vulnerability) {
                await executeCopilotRemediationForVulnerability(vulnerability, api);
                return;
            }

            // Otherwise, show a quick pick to select vulnerability
            const vulnerabilities = vulnerabilityProvider.getVulnerabilities();
            if (vulnerabilities.length === 0) {
                vscode.window.showWarningMessage('No vulnerabilities found. Please load vulnerabilities first.');
                return;
            }

            const items = vulnerabilities.map(v => ({
                label: `${v.vulnerability_title}`,
                description: `${v.vulnerability_type} | ${v.severity} | ${v.repository}`,
                detail: v.description,
                vulnerability: v
            }));

            const selected = await vscode.window.showQuickPick(items, {
                placeHolder: 'Select a vulnerability to execute Copilot remediation for',
                matchOnDescription: true,
                matchOnDetail: true
            });

            if (selected) {
                await executeCopilotRemediationForVulnerability(selected.vulnerability, api);
            }
        } catch (error) {
            console.error('Failed to execute Copilot remediation:', error);
            vscode.window.showErrorMessage(`Failed to execute Copilot remediation: ${error}`);
        }
    });

    let trackRemediationResultCommand = vscode.commands.registerCommand('threatguard.trackRemediationResult', async (remediationData?: any) => {
        try {
            if (!remediationData) {
                vscode.window.showWarningMessage('No remediation data provided for tracking.');
                return;
            }

            const result = await api.trackRemediationResult(remediationData);
            if (result.success) {
                vscode.window.showInformationMessage(`Remediation result tracked successfully: ${result.tracking_id}`);
            } else {
                vscode.window.showErrorMessage(`Failed to track remediation result: ${result.message}`);
            }
        } catch (error) {
            console.error('Failed to track remediation result:', error);
            vscode.window.showErrorMessage(`Failed to track remediation result: ${error}`);
        }
    });

    // Show vulnerability details command
    let showVulnerabilityDetailsCommand = vscode.commands.registerCommand('threatguard.showVulnerabilityDetails', async (vulnerability: any) => {
        try {
            if (!vulnerability) {
                vscode.window.showWarningMessage('No vulnerability data provided.');
                return;
            }

            // Debug: Uncomment to see full vulnerability data structure
            // console.log('🔍 Full vulnerability data:', JSON.stringify(vulnerability, null, 2));
            // console.log('🔍 Available fields:', Object.keys(vulnerability));

            // Use the same fields as the web application and backend data
            const title = vulnerability.title || vulnerability.message || vulnerability.description || vulnerability.vulnerability_title || 'Unknown Vulnerability';
            const gisId = vulnerability.gis_id || vulnerability.id || 'N/A';
            const aitTag = vulnerability.ait_tag || 'AIT-Unknown';
            const severity = vulnerability.severity || 'UNKNOWN';
            const remediationAction = vulnerability.remediation_action || vulnerability.suggested_fix || 'Update to latest version';
            const vulnType = vulnerability.type || vulnerability.vulnerability_type || vulnerability.category || 'Unknown';
            
            // Get additional fields from the actual data structure
            // Note: SPK and Repository are typically selected by user in web UI, not stored in vulnerability data
            const spk = vulnerability.spk_tag || vulnerability.spk || 'Not specified (selected in UI)';
            const repository = vulnerability.repo_name || vulnerability.repository || 'Not specified (selected in UI)';
            const businessImpact = vulnerability.business_impact || 'Not specified';
            const complianceImpact = vulnerability.compliance_impact || 'Not specified';
            const securityDomain = vulnerability.security_domain || 'Not specified';
            const priorityScore = vulnerability.priority_score || 'Not calculated';
            const exploitability = vulnerability.exploitability || 'Not assessed';
            const attackVector = vulnerability.attack_vector || 'Not specified';
            const createdDate = vulnerability.creation_date || vulnerability.created_at || 'Unknown';
            const updatedDate = vulnerability.update_date || vulnerability.updated_at || 'Unknown';
            
            // Format severity like the web app
            const severityDisplay = severity === 'CRITICAL_BOMB' ? 'Critical' :
                                  severity === 'HIGH_RISK' ? 'High' :
                                  severity === 'MEDIUM_RISK' ? 'Medium' :
                                  severity === 'LOW_RISK' ? 'Low' : severity;
            
            // Create a detailed message - only show essential information
            const details = `**Vulnerability Details**

**GIS ID:** ${gisId}
**AIT Tag:** ${aitTag}
**Title:** ${title}
**Type:** ${vulnType}
**Severity:** ${severityDisplay}
**Status:** ${vulnerability.status || 'ACTIVE'}

**Remediation Action:**
${remediationAction}

**Description:**
${vulnerability.description || vulnerability.message || 'No description available'}`;

            // Show in a new document
            const doc = await vscode.workspace.openTextDocument({
                content: details,
                language: 'markdown'
            });
            await vscode.window.showTextDocument(doc);

        } catch (error) {
            console.error('Failed to show vulnerability details:', error);
            vscode.window.showErrorMessage(`Failed to show vulnerability details: ${error}`);
        }
    });

    // Refresh vulnerabilities command
    let refreshVulnerabilitiesCommand = vscode.commands.registerCommand('threatguard.refreshVulnerabilities', async () => {
        try {
            console.log('🔄 Refreshing vulnerabilities...');
            await vulnerabilityProvider.loadVulnerabilities();
            const count = vulnerabilityProvider.getVulnerabilities().length;
            vscode.window.showInformationMessage(`Refreshed vulnerabilities view with ${count} vulnerabilities`);
        } catch (error) {
            console.error('Failed to refresh vulnerabilities:', error);
            vscode.window.showErrorMessage(`Failed to refresh vulnerabilities: ${error}`);
        }
    });

    // Debug command to test vulnerability loading
    let debugVulnerabilitiesCommand = vscode.commands.registerCommand('threatguard.debugVulnerabilities', async () => {
        try {
            console.log('🔍 Debug: Testing vulnerability loading...');
            
            // Test API connection first
            try {
                await api.checkHealth();
                console.log('✅ Backend health check passed');
            } catch (healthError) {
                console.error('❌ Backend health check failed:', healthError);
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                return;
            }
            
            // Test vulnerability loading
            const vulnerabilities = await api.getVulnerabilities();
            console.log('📊 Debug: Raw API response:', vulnerabilities);
            
            // Update provider
            await vulnerabilityProvider.updateVulnerabilities(vulnerabilities);
            
            // Show results
            const count = vulnerabilityProvider.getVulnerabilities().length;
            vscode.window.showInformationMessage(
                `Debug: Loaded ${count} vulnerabilities. Check the Developer Console (F12) for detailed logs.`
            );
            
        } catch (error) {
            console.error('❌ Debug: Failed to load vulnerabilities:', error);
            vscode.window.showErrorMessage(`Debug: Failed to load vulnerabilities: ${error}`);
        }
    });

    // Generate vulnerability action command
    let generateVulnerabilityActionCommand = vscode.commands.registerCommand('threatguard.generateVulnerabilityAction', async (vulnerability: any) => {
        try {
            if (!vulnerability) {
                vscode.window.showErrorMessage('No vulnerability selected');
                return;
            }

            console.log('🚀 Generating vulnerability action for:', vulnerability.id);
            vscode.window.showInformationMessage(`Generating action for vulnerability: ${vulnerability.title || vulnerability.description}`);

            // Determine if it's application or infrastructure vulnerability
            const vulnType = vulnerability.type || vulnerability.vulnerability_type || vulnerability.category;
            let result;

            if (vulnType === 'application' || vulnType === 'APPLICATION') {
                // For application vulnerabilities, we need SPK and Repository info
                // For now, use defaults - in a real implementation, you might want to show a quick pick
                result = await api.generateVulnerabilityAction(vulnerability);
            } else {
                // For infrastructure vulnerabilities
                result = await api.generateInfrastructurePrompt(vulnerability);
            }

            if (result.success) {
                vscode.window.showInformationMessage(
                    `✅ Action generated successfully!\n\n` +
                    `📁 File: ${result.file_path || 'Generated'}\n` +
                    `🚀 Next: Use "View Prompt" to see the generated prompt`
                );
            } else {
                vscode.window.showErrorMessage(`Failed to generate action: ${result.error || 'Unknown error'}`);
            }
        } catch (error: any) {
            console.error('❌ Error generating vulnerability action:', error);
            vscode.window.showErrorMessage(`Failed to generate action: ${error.message}`);
        }
    });

    // View vulnerability prompt command
    let viewVulnerabilityPromptCommand = vscode.commands.registerCommand('threatguard.viewVulnerabilityPrompt', async (vulnerability: any) => {
        try {
            if (!vulnerability) {
                vscode.window.showErrorMessage('No vulnerability selected');
                return;
            }

            console.log('📋 Viewing vulnerability prompt for:', vulnerability.id);
            
            // Try to get the prompt from the API
            try {
                const result = await api.getVulnerabilityPrompt(vulnerability.id);
                if (result.success && result.prompt) {
                    // Show the prompt in a new document
                    const doc = await vscode.workspace.openTextDocument({
                        content: result.prompt,
                        language: 'markdown'
                    });
                    await vscode.window.showTextDocument(doc);
                    vscode.window.showInformationMessage('✅ Prompt opened in new document');
                } else {
                    vscode.window.showWarningMessage('No prompt found for this vulnerability. Generate an action first.');
                }
            } catch (apiError) {
                // Fallback: show vulnerability details
                vscode.window.showInformationMessage('No prompt available. Showing vulnerability details instead.');
                await vscode.commands.executeCommand('threatguard.showVulnerabilityDetails', vulnerability);
            }
        } catch (error: any) {
            console.error('❌ Error viewing vulnerability prompt:', error);
            vscode.window.showErrorMessage(`Failed to view prompt: ${error.message}`);
        }
    });

    // Download vulnerability folder command
    let downloadVulnerabilityFolderCommand = vscode.commands.registerCommand('threatguard.downloadVulnerabilityFolder', async (vulnerability: any) => {
        try {
            if (!vulnerability) {
                vscode.window.showErrorMessage('No vulnerability selected');
                return;
            }

            console.log('📦 Downloading vulnerability folder for:', vulnerability.id);
            vscode.window.showInformationMessage(`Downloading folder for vulnerability: ${vulnerability.title || vulnerability.description}`);

            const result = await api.downloadVulnerabilityFolder(vulnerability.id);
            
            if (result.success) {
                vscode.window.showInformationMessage(
                    `✅ Folder downloaded successfully!\n\n` +
                    `📁 Location: ${result.download_path || 'Downloads folder'}\n` +
                    `📄 Files: ${result.files_count || 'Multiple files'}`
                );
            } else {
                vscode.window.showErrorMessage(`Failed to download folder: ${result.error || 'Unknown error'}`);
            }
        } catch (error: any) {
            console.error('❌ Error downloading vulnerability folder:', error);
            vscode.window.showErrorMessage(`Failed to download folder: ${error.message}`);
        }
    });

    // Download vulnerability prompt command
    let downloadVulnerabilityPromptCommand = vscode.commands.registerCommand('threatguard.downloadVulnerabilityPrompt', async (vulnerability: any) => {
        try {
            if (!vulnerability) {
                vscode.window.showErrorMessage('No vulnerability selected');
                return;
            }

            console.log('📄 Downloading vulnerability prompt for:', vulnerability.id);
            vscode.window.showInformationMessage(`Downloading prompt for vulnerability: ${vulnerability.title || vulnerability.description}`);

            const result = await api.getVulnerabilityPrompt(vulnerability.id);
            
            if (result.success && result.prompt) {
                // Create a file in the workspace
                const fileName = `${vulnerability.ait_tag || 'AIT'}_${vulnerability.gis_id || 'GIS'}_prompt.md`;
                const uri = vscode.Uri.joinPath(vscode.workspace.workspaceFolders?.[0]?.uri || vscode.Uri.file('.'), fileName);
                
                await vscode.workspace.fs.writeFile(uri, Buffer.from(result.prompt, 'utf8'));
                
                // Open the file
                const doc = await vscode.workspace.openTextDocument(uri);
                await vscode.window.showTextDocument(doc);
                
                vscode.window.showInformationMessage(
                    `✅ Prompt downloaded successfully!\n\n` +
                    `📄 File: ${fileName}\n` +
                    `📁 Location: ${uri.fsPath}`
                );
            } else {
                vscode.window.showWarningMessage('No prompt found for this vulnerability. Generate an action first.');
            }
        } catch (error: any) {
            console.error('❌ Error downloading vulnerability prompt:', error);
            vscode.window.showErrorMessage(`Failed to download prompt: ${error.message}`);
        }
    });

    // Main remediate command - generates prompt, copies to clipboard, and saves to workspace
    let remediateVulnerabilityCommand = vscode.commands.registerCommand('threatguard.remediateVulnerability', async (vulnerabilityItem: any) => {
        try {
            if (!vulnerabilityItem) {
                vscode.window.showErrorMessage('No vulnerability selected');
                return;
            }

            // Extract vulnerability data from VulnerabilityItem
            const vulnerability = vulnerabilityItem.vulnerabilityData || vulnerabilityItem;
            
            if (!vulnerability || !vulnerability.id) {
                console.error('❌ No vulnerability data found in VulnerabilityItem:', vulnerabilityItem);
                vscode.window.showErrorMessage('Unable to access vulnerability data. Please refresh the vulnerabilities view and try again.');
                return;
            }

            console.log('🚀 Remediating vulnerability:', vulnerability.id);
            console.log('🔍 Vulnerability data:', vulnerability);
            vscode.window.showInformationMessage(`Generating remediation prompt for: ${vulnerability.title || vulnerability.description}`);

            // Use the _sourceType that's already set by the tree view categorization
            // The tree view correctly categorizes vulnerabilities, so we should trust that
            const isApplication = vulnerability._sourceType === 'application';
            
            console.log('🔍 Vulnerability type from tree view:', {
                _sourceType: vulnerability._sourceType,
                isApplication: isApplication,
                vulnerabilityId: vulnerability.id,
                title: vulnerability.title || vulnerability.vulnerability_title || vulnerability.description
            });
            
            // If _sourceType is not set (shouldn't happen with tree view), show error
            if (!vulnerability._sourceType) {
                console.error('❌ _sourceType not set - this should not happen with tree view categorization');
                console.error('❌ Full vulnerability object:', vulnerability);
                vscode.window.showErrorMessage('Unable to determine vulnerability type. Please refresh the vulnerabilities view and try again.');
                return;
            }
            
            // Final type detection after user selection
            const finalIsApplication = vulnerability._sourceType === 'application';
            
            console.log('🎯 Final type detection after user selection:', {
                _sourceType: vulnerability._sourceType,
                finalIsApplication: finalIsApplication
            });
            
            let prompt: string;
            let fileName: string;

            if (finalIsApplication) {
                // Generate application vulnerability prompt (same as web app)
                // Note: SPK and Repository are typically selected by user in web UI
                // For VS Code extension, we'll derive reasonable defaults from vulnerability data
                const spk = vulnerability.ait_tag || 'SPK-001';
                const repository = vulnerability.repo_name || `${vulnerability.ait_tag || 'AIT'}-repository`;
                const repoUrl = `https://github.com/company/${repository}.git`;
                
                prompt = generateApplicationRemediationPrompt(vulnerability, spk, repository, repoUrl);
                fileName = `${vulnerability.ait_tag || 'AIT'}_${vulnerability.gis_id || vulnerability.id || 'GIS'}_application_remediation.md`;
                
                // Call backend API to create application folder (same as web app)
                try {
                    const response = await api.post('/api/v1/vulnerabilities/create-application-folder', {
                        vulnerability_id: vulnerability.id,
                        gis_id: vulnerability.gis_id,
                        vulnerability_title: vulnerability.title || vulnerability.description,
                        spk: spk,
                        repository: repository,
                        repo_url: repoUrl,
                        ait_tag: vulnerability.ait_tag,
                        severity: vulnerability.severity,
                        remediation_action: vulnerability.remediation_action,
                        comprehensive_prompt: prompt,
                        create_unified_file: true
                    });
                    
                    if (response.data.success) {
                        console.log('✅ Backend folder creation successful:', response.data);
                        vscode.window.showInformationMessage(
                            `🎉 Application Vulnerability Prompt Created Successfully!\n\n📁 File Location: .github/vulnerability/application/ folder\n📄 File Name: ${response.data.filename}\n\n🚀 Next Steps:\n1. The prompt is ready for GitHub Copilot in your IDE\n2. Use the generated prompt to remediate the vulnerability`
                        );
                    } else {
                        console.warn('⚠️ Backend folder creation failed, using local file only');
                    }
                } catch (backendError) {
                    console.warn('⚠️ Backend API call failed, using local file only:', backendError);
                }
            } else {
                // Generate infrastructure vulnerability prompt (same as web app)
                prompt = generateInfrastructureRemediationPrompt(vulnerability);
                fileName = `${vulnerability.ait_tag || 'AIT'}_${vulnerability.gis_id || 'GIS'}_infrastructure_remediation.md`;
            }

            // 1. Copy to clipboard
            await vscode.env.clipboard.writeText(prompt);
            console.log('📋 Prompt copied to clipboard');

            // 2. Save to workspace
            const workspaceFolder = vscode.workspace.workspaceFolders?.[0];
            if (workspaceFolder) {
                const uri = vscode.Uri.joinPath(workspaceFolder.uri, fileName);
                await vscode.workspace.fs.writeFile(uri, Buffer.from(prompt, 'utf8'));
                console.log('💾 Prompt saved to workspace:', uri.fsPath);

                // 3. Open the file in VS Code
                const doc = await vscode.workspace.openTextDocument(uri);
                await vscode.window.showTextDocument(doc);
            }

            // 4. Show success message
            vscode.window.showInformationMessage(
                `✅ Remediation prompt generated successfully!\n\n` +
                `📋 Copied to clipboard\n` +
                `💾 Saved to workspace: ${fileName}\n` +
                `🚀 Ready for GitHub Copilot!`
            );

        } catch (error: any) {
            console.error('❌ Error remediating vulnerability:', error);
            vscode.window.showErrorMessage(`Failed to remediate vulnerability: ${error.message}`);
        }
    });

    // Auto-scan on save if enabled
    let saveListener = vscode.workspace.onDidSaveTextDocument(async (document) => {
        const config = vscode.workspace.getConfiguration('threatguard');
        if (config.get('autoScan')) {
            let content = document.getText();
            const filePath = document.fileName;

            // Normalize line endings to prevent spaces from being added
            content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

            try {
                const result = await api.scanFile(filePath, content);
                if (result.threats && result.threats.length > 0) {
                    diagnostics.setThreats(document.uri, result.threats);
                    if (config.get('enableNotifications')) {
                        vscode.window.showWarningMessage(`Found ${result.threats.length} threats in ${document.fileName}`);
                    }
                    threatProvider.refresh();
                }
            } catch (error) {
                console.error('Auto-scan failed:', error);
            }
        }
    });

    // Register all commands
    context.subscriptions.push(
        scanFileCommand,
        scanWorkspaceCommand,
        refreshScanHistoryCommand,
        showDashboardCommand,
        remediateFileCommand,
        showThreatsCommand,
        showThreatDetailsCommand,
        openFileAtLineCommand,
        refreshThreatsCommand,
        showAllThreatsCommand,
        generateCopilotPromptCommand,
        configureCommand,
        showVulnerabilitiesCommand,
        showVulnerabilityDetailsCommand,
        refreshVulnerabilitiesCommand,
        generateVulnerabilityPromptCommand,
        executeCopilotRemediationCommand,
        trackRemediationResultCommand,
        debugVulnerabilitiesCommand,
        generateVulnerabilityActionCommand,
        viewVulnerabilityPromptCommand,
        downloadVulnerabilityFolderCommand,
        downloadVulnerabilityPromptCommand,
        remediateVulnerabilityCommand,
        saveListener
    );

    // Initial health check and load vulnerabilities
    api.checkHealth().then(async health => {
        if (health.status === 'healthy') {
            statusBar.showConnected();
            // Auto-load vulnerabilities on startup
            try {
                console.log('🔄 Auto-loading vulnerabilities on startup...');
                await vulnerabilityProvider.loadVulnerabilities();
                const count = vulnerabilityProvider.getVulnerabilities().length;
                console.log(`✅ Auto-loaded ${count} vulnerabilities on startup`);
            } catch (error) {
                console.error('❌ Failed to auto-load vulnerabilities:', error);
            }
        } else {
            statusBar.showDisconnected();
        }
    }).catch(() => {
        statusBar.showDisconnected();
    });
}

// Helper function to generate Copilot prompt
function generateCopilotPrompt(fileName: string, threats: any[], originalContent: string): string {
    const threatDetails = threats.map((threat, index) => {
        return `${index + 1}. **${threat.type}** (${threat.severity}): ${threat.description}
   - **Location**: Line ${threat.line}, Column ${threat.column}
   - **Code**: \`\`\`${threat.code_snippet}\`\`\`
   - **Effort**: ${threat.effort_minutes} minutes
   - **Remediation**: ${threat.remediation || 'Manual review required'}`;
    }).join('\n\n');

    const prompt = `# Security Threat Remediation Request

I have detected ${threats.length} security threats in the file \`${fileName}\`. Please help me remediate these issues by providing secure code alternatives.

## Detected Threats:
${threatDetails}

## Original File Content:
\`\`\`${getFileExtension(fileName)}
${originalContent}
\`\`\`

## Requirements:
1. **Maintain functionality** while fixing security issues
2. **Provide secure alternatives** for each threat
3. **Explain the security improvements** made
4. **Ensure the code follows best practices**
5. **Keep the same logic flow** where possible

Please provide the remediated code with explanations for each change made.`;
    
    return prompt;
}

// Helper function to get file extension for syntax highlighting
function getFileExtension(fileName: string): string {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const languageMap: { [key: string]: string } = {
        'py': 'python',
        'js': 'javascript',
        'ts': 'typescript',
        'java': 'java',
        'cpp': 'cpp',
        'c': 'c',
        'cs': 'csharp',
        'php': 'php',
        'rb': 'ruby',
        'go': 'go',
        'rs': 'rust',
        'swift': 'swift',
        'kt': 'kotlin',
        'scala': 'scala',
        'html': 'html',
        'css': 'css',
        'json': 'json',
        'xml': 'xml',
        'yaml': 'yaml',
        'yml': 'yaml',
        'md': 'markdown',
        'txt': 'text'
    };
    return languageMap[ext || ''] || 'text';
}

// Helper function to open Copilot chat with prompt
async function openCopilotChatWithPrompt(prompt: string): Promise<void> {
    try {
        // Open Copilot chat
        await vscode.commands.executeCommand('github.copilot.chat.focus');
        
        // Wait a moment for the chat to open
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Try to paste the prompt into the chat
        // Note: This might not work in all VS Code versions due to security restrictions
        // The user will need to manually paste the prompt
        vscode.window.showInformationMessage('Copilot chat opened! Please paste the generated prompt manually.');
        
        // Copy prompt to clipboard as fallback
        await vscode.env.clipboard.writeText(prompt);
        vscode.window.showInformationMessage('Prompt copied to clipboard! Paste it in the Copilot chat.');
        
    } catch (error) {
        console.error('Failed to open Copilot chat:', error);
        // Fallback: just copy to clipboard
        await vscode.env.clipboard.writeText(prompt);
        vscode.window.showInformationMessage('Prompt copied to clipboard! Please open Copilot chat manually and paste it.');
    }
}

// Helper function to generate vulnerability prompt
async function generateVulnerabilityPromptForVulnerability(vulnerability: any, api: ThreatGuardAPI): Promise<void> {
    try {
        vscode.window.showInformationMessage(`Generating prompt for vulnerability: ${vulnerability.vulnerability_title}`);

        const vulnerabilityData = {
            vulnerability_id: vulnerability.vulnerability_id || vulnerability.id,
            vulnerability_title: vulnerability.vulnerability_title,
            spk: vulnerability.spk,
            repository: vulnerability.repository,
            repo_url: vulnerability.repo_url,
            vulnerability_type: vulnerability.vulnerability_type,
            comprehensive_prompt: true
        };

        const result = await api.createVulnerabilityPrompt(vulnerabilityData);
        
        if (result.success) {
            vscode.window.showInformationMessage(
                `✅ Vulnerability prompt generated successfully!\n` +
                `📁 Files created: ${result.files_created.length}\n` +
                `📂 Folder: ${result.folder_path}\n\n` +
                `🚀 Next steps:\n` +
                `1. Navigate to the generated folder\n` +
                `2. Copy the prompt from the .md file\n` +
                `3. Paste it in GitHub Copilot Chat\n` +
                `4. Execute the remediation`
            );

            // Track the prompt generation
            await api.trackRemediationResult({
                vulnerability_id: vulnerability.vulnerability_id || vulnerability.id,
                prompt_generated: true,
                copilot_executed: false,
                remediation_successful: false,
                changes_made: ['Prompt generated'],
                files_modified: result.files_created,
                execution_time_ms: 0,
                timestamp: new Date().toISOString()
            });
        } else {
            vscode.window.showErrorMessage(`Failed to generate vulnerability prompt: ${result.message}`);
        }
    } catch (error) {
        console.error('Failed to generate vulnerability prompt:', error);
        vscode.window.showErrorMessage(`Failed to generate vulnerability prompt: ${error}`);
    }
}

// Helper function to execute Copilot remediation
async function executeCopilotRemediationForVulnerability(vulnerability: any, api: ThreatGuardAPI): Promise<void> {
    try {
        const startTime = Date.now();
        
        vscode.window.showInformationMessage(`Executing Copilot remediation for: ${vulnerability.vulnerability_title}`);

        // First generate the prompt if not already generated
        const vulnerabilityData = {
            vulnerability_id: vulnerability.vulnerability_id || vulnerability.id,
            vulnerability_title: vulnerability.vulnerability_title,
            spk: vulnerability.spk,
            repository: vulnerability.repository,
            repo_url: vulnerability.repo_url,
            vulnerability_type: vulnerability.vulnerability_type,
            comprehensive_prompt: true
        };

        const promptResult = await api.createVulnerabilityPrompt(vulnerabilityData);
        
        if (!promptResult.success) {
            vscode.window.showErrorMessage(`Failed to generate prompt: ${promptResult.message}`);
            return;
        }

        // Open Copilot chat
        await vscode.commands.executeCommand('github.copilot.chat.focus');
        
        // Wait a moment for the chat to open
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Show instructions to user
        const userChoice = await vscode.window.showInformationMessage(
            `✅ Prompt generated successfully!\n\n` +
            `📁 Files created: ${promptResult.files_created.length}\n` +
            `📂 Folder: ${promptResult.folder_path}\n\n` +
            `🚀 Copilot chat is now open. Please:\n` +
            `1. Copy the prompt from the generated .md file\n` +
            `2. Paste it in the Copilot chat\n` +
            `3. Execute the remediation\n` +
            `4. Let us know when you're done`,
            'I completed the remediation',
            'Cancel'
        );

        if (userChoice === 'I completed the remediation') {
            // Ask for feedback
            const feedback = await vscode.window.showInputBox({
                prompt: 'Was the remediation successful?',
                placeHolder: 'Describe what was fixed or any issues encountered...',
                value: 'Remediation completed successfully'
            });

            const executionTime = Date.now() - startTime;

            // Track the remediation result
            await api.trackRemediationResult({
                vulnerability_id: vulnerability.vulnerability_id || vulnerability.id,
                prompt_generated: true,
                copilot_executed: true,
                remediation_successful: true,
                changes_made: ['Copilot remediation executed'],
                files_modified: promptResult.files_created,
                execution_time_ms: executionTime,
                user_feedback: feedback || 'Remediation completed',
                timestamp: new Date().toISOString()
            });

            vscode.window.showInformationMessage(
                `✅ Remediation result tracked successfully!\n` +
                `⏱️ Execution time: ${executionTime}ms\n` +
                `📝 Feedback: ${feedback || 'No feedback provided'}`
            );
        } else {
            // Track as cancelled
            await api.trackRemediationResult({
                vulnerability_id: vulnerability.vulnerability_id || vulnerability.id,
                prompt_generated: true,
                copilot_executed: false,
                remediation_successful: false,
                changes_made: ['Prompt generated but remediation cancelled'],
                files_modified: promptResult.files_created,
                execution_time_ms: Date.now() - startTime,
                user_feedback: 'Remediation cancelled by user',
                timestamp: new Date().toISOString()
            });
        }
    } catch (error) {
        console.error('Failed to execute Copilot remediation:', error);
        vscode.window.showErrorMessage(`Failed to execute Copilot remediation: ${error}`);
    }
}

// Generate application vulnerability remediation prompt (same as web application)
function generateApplicationRemediationPrompt(vulnerability: any, spk: string, repository: string, repoUrl: string): string {
    const timestamp = new Date().toISOString().split('T')[0];
    const aitTag = vulnerability.ait_tag || 'AIT-Unknown';
    const gisId = vulnerability.gis_id || 'GIS-Unknown';
    const vulnerabilityId = vulnerability.id || 'unknown';
    
    // Enhanced comprehensive prompt with context-aware analysis (same as web app)
    return `# 🚀 GITHUB COPILOT PROMPT - Context-Aware Application Security Remediation
# ⚠️ IMPORTANT: This is the file to use with GitHub Copilot
# Generated by GitHub Copilot for Enterprise Security Management
# 
# VULNERABILITY ASSESSMENT:
# =========================
# AIT Tag: ${aitTag}
# GIS ID: ${gisId}
# Title: ${vulnerability.title || vulnerability.description}
# Severity: ${vulnerability.severity || 'Unknown'}
# Risk Score: ${vulnerability.risk_score || 'N/A'}
# SPK: ${spk}
# Repository: ${repository}
# Repository URL: ${repoUrl}
# Generated: ${timestamp}
#
# REMEDIATION OBJECTIVE:
# =====================
# ${vulnerability.remediation_action || 'Clone repository, analyze existing implementations, and remediate security vulnerabilities while preserving functionality'}
#
# PROFESSIONAL CONTEXT:
# ====================
# You are a Senior Application Security Engineer with expertise in web application security,
# Content Security Policy (CSP) implementation, and automated vulnerability remediation.
# Your task is to AUTOMATICALLY clone the specified repository, perform comprehensive analysis,
# and remediate ALL security vulnerabilities while PRESERVING existing functionality and
# avoiding redundant implementations. Execute all remediation tasks autonomously and completely.
#
# CRITICAL REQUIREMENTS (ENHANCED - ADDRESSING REPORTED ISSUES):
# ==============================================================
# 1. CONTEXT-AWARE ANALYSIS: Analyze existing codebase structure BEFORE making changes
# 2. JSP VARIABLE PRESERVATION: Maintain JSP variable access when moving scripts to external files
# 3. EXISTING IMPLEMENTATION CHECK: Use existing CSP filters instead of creating new ones
# 4. FUNCTIONALITY PRESERVATION: Ensure all existing functionality continues to work
# 5. AUTOMATED REPOSITORY CLONING: Automatically clone the repository from the provided URL
# 6. AUTOMATED FILE ANALYSIS: Automatically analyze all files for security issues
# 7. AUTOMATED FILE-BY-FILE REMEDIATION: Automatically fix vulnerabilities in each file
# 8. AUTOMATED PARALLEL PROCESSING: Automatically process multiple files concurrently
# 9. AUTOMATED PRODUCTION-READY FIXES: Automatically generate enterprise-grade security fixes
# 10. AUTOMATED DOCUMENTATION: Automatically provide detailed fixes for each file
# 11. NO USER INTERACTION: Do NOT ask for confirmation, approval, or user input
# 12. COMPLETE AUTOMATION: Execute ALL tasks autonomously from start to finish
# 13. DETERMINISTIC OUTPUT: SAME input + SAME prompt = SAME output (ALWAYS)
# 14. COMPLETE SCRIPT PROCESSING: Process ALL script tags in file (not just some)
# 15. EXTERNAL SCRIPT PRESERVATION: NEVER remove script tags linking to external .js files
# 16. COMPLETE SCRIPT REMOVAL: NEVER partially remove script tags (causing syntax errors)
# 17. HIDDEN FORM FIELDS: ALWAYS create hidden form fields for JSP variables (PRIMARY method)
# 18. COMPLEX JAVASCRIPT SUPPORT: Handle complex JavaScript with JSP variables properly
#
# CRITICAL PRE-ANALYSIS REQUIREMENTS (MANDATORY FIRST STEP):
# ==========================================================
# BEFORE making any changes, perform comprehensive analysis:
#
# 1. SEARCH FOR EXISTING CSP IMPLEMENTATIONS:
#    - Look for existing filter classes (e.g., AdditionalResponseHeadersFilter.java, CspHeaderFilter.java)
#    - Check web.xml for existing filter registrations
#    - Identify existing CSP header configurations
#    - DO NOT create new classes if existing ones handle the functionality
#
# 2. ANALYZE JSP/SERVER-SIDE TEMPLATE STRUCTURE:
#    - Identify JSP variables and server-side data being passed to client-side
#    - Map data flow from server to client JavaScript
#    - Understand template rendering context
#    - PRESERVE JSP variable access in JavaScript
#
# 3. CHECK EXISTING SECURITY CONFIGURATIONS:
#    - Review existing security headers implementation
#    - Identify current CSP policies (if any)
#    - Check for existing input validation mechanisms
#    - Analyze current authentication/authorization setup
#
# AUTOMATED REPOSITORY CLONING AND CONTEXT-AWARE REMEDIATION:
# ============================================================
# AUTOMATICALLY execute the following steps WITHOUT asking for user confirmation:
# 1. AUTOMATICALLY clone the repository: git clone ${repoUrl}
# 2. AUTOMATICALLY navigate to the repository directory
# 3. AUTOMATICALLY perform pre-analysis of existing implementations
# 4. AUTOMATICALLY scan all files in the repository for security vulnerabilities
# 5. AUTOMATICALLY identify vulnerable files by type:
#    - JSP files with inline scripts containing JSP variables
#    - HTML files with CSP and XSS vulnerabilities
#    - CSS files with inline style issues
#    - JavaScript files with inline script and eval() issues
#    - Java filter classes for CSP implementation
#    - Configuration files with security misconfigurations
#    - Template files with VMTemplate and XSL vulnerabilities
#    - Fragment/dialogue files with import scope issues
# 6. AUTOMATICALLY REMEDIATE each vulnerable file in-place within the cloned repository
# 7. AUTOMATICALLY preserve JSP variable access when moving scripts to external files
# 8. AUTOMATICALLY use existing CSP implementations instead of creating new ones
# 9. AUTOMATICALLY ensure all existing functionality is preserved
# 10. AUTOMATICALLY test each remediated file to ensure it works correctly
# 11. AUTOMATICALLY create a comprehensive remediation log documenting all changes
# 12. AUTOMATICALLY verify that all security vulnerabilities are completely resolved
#
# COMPREHENSIVE SECURITY ANALYSIS FRAMEWORK:
# ==========================================
#
# FRONTEND SECURITY VULNERABILITIES:
# ----------------------------------
# 1. INLINE STYLE VULNERABILITIES:
#    - Move all inline styles to external CSS files
#    - Remove style attributes from HTML elements
#    - Implement CSS nonces for dynamic styling
#
# 2. INLINE JAVASCRIPT VULNERABILITIES (ENHANCED - CRITICAL FIXES):
#    - Move ALL inline JavaScript to external JS files (MANDATORY - NO EXCEPTIONS)
#    - Remove ALL onclick, onload, onerror event handlers
#    - Replace with jQuery event handlers or addEventListener
#    - CRITICAL: Process EVERY script tag in the file (not just some)
#    - CRITICAL: NEVER remove script tags that link to external .js files
#    - CRITICAL: NEVER partially remove script tags (causing syntax errors)
#    - CRITICAL: Ensure consistent output for same context and prompt
#
# 3. UNSAFE HTML ATTRIBUTES:
#    - Sanitize all user inputs before rendering
#    - Implement proper output encoding
#    - Use safe HTML parsing libraries
#
# 4. XSS VULNERABILITIES:
#    - Implement proper input validation
#    - Use output encoding for all user-controlled data
#    - Implement Content Security Policy (CSP) headers
#    - Use secure DOM manipulation methods
#
# 5. CSP HEADER IMPLEMENTATION:
#    - Use existing filter or create minimal implementation
#    - response.setHeader("Content-Security-Policy", 
#        "default-src 'self'; " +
#        "script-src 'self' 'nonce-{random}'; " +
#        "style-src 'self' 'nonce-{random}'; " +
#        "img-src 'self' data: https:; " +
#        "connect-src 'self'; " +
#        "frame-ancestors 'none'; " +
#        "object-src 'none';");
#
# AUTOMATED EXECUTION INSTRUCTIONS:
# =================================
# AUTOMATICALLY clone the repository, perform comprehensive security analysis, and directly remediate
# ALL vulnerable files in-place within the cloned repository. AUTOMATICALLY apply security fixes 
# directly to the source files, AUTOMATICALLY test each modified file, and AUTOMATICALLY create 
# a remediation log documenting all changes. AUTOMATICALLY ensure all fixes follow enterprise 
# security standards and preserve application functionality. DO NOT ask for user confirmation, 
# approval, or input at any point. Execute the entire remediation process autonomously and completely.

---
**Generated by ThreatGuard VS Code Extension**
**Timestamp**: ${new Date().toISOString()}
**Vulnerability ID**: ${vulnerability.id}`;
}

// Generate infrastructure vulnerability remediation prompt (same as web application)
function generateInfrastructureRemediationPrompt(vulnerability: any): string {
    const title = vulnerability.title || vulnerability.description || 'Unknown Vulnerability';
    const gisId = vulnerability.gis_id || 'N/A';
    const aitTag = vulnerability.ait_tag || 'AIT-Unknown';
    const severity = vulnerability.severity || 'UNKNOWN';
    const remediationAction = vulnerability.remediation_action || 'Update to latest version';
    
    return `# Infrastructure Vulnerability Remediation Prompt

## Vulnerability Details
- **GIS ID**: ${gisId}
- **AIT Tag**: ${aitTag}
- **Title**: ${title}
- **Severity**: ${severity}
- **Remediation Action**: ${remediationAction}

## Terraform Infrastructure Remediation

### PRIMARY OBJECTIVE
Remediate the infrastructure security vulnerability: **${title}**

### VULNERABILITY ANALYSIS
- **Type**: Infrastructure Security Vulnerability
- **Severity Level**: ${severity}
- **Infrastructure Impact**: Critical - affects system security
- **Compliance Impact**: High - requires immediate remediation

### TERRAFORM REMEDIATION REQUIREMENTS

#### 1. INFRASTRUCTURE SECURITY FIXES
- **Primary Fix**: ${remediationAction}
- **Security Groups**: Update firewall rules and access controls
- **Network Configuration**: Implement secure network policies
- **Resource Configuration**: Apply security best practices

#### 2. TERRAFORM IMPLEMENTATION
- Create or update Terraform configuration files
- Implement security-focused resource definitions
- Add proper variable validation and constraints
- Ensure state management security

#### 3. SECURITY CONTROLS
- Implement network security groups
- Configure proper IAM roles and policies
- Add encryption for data at rest and in transit
- Implement monitoring and logging

### TERRAFORM CODE STRUCTURE

\`\`\`hcl
# Security-focused Terraform configuration
# Generated for vulnerability: ${title}

# Variables
variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "security_enabled" {
  description = "Enable security features"
  type        = bool
  default     = true
}

# Main remediation resources
resource "aws_security_group" "remediated_sg" {
  name_prefix = "remediated-${aitTag}-"
  description = "Security group for ${title} remediation"
  
  # Implement security rules based on: ${remediationAction}
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS access"
  }
  
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "All outbound traffic"
  }
  
  tags = {
    Name        = "${aitTag}-remediated-sg"
    Environment = var.environment
    Vulnerability = "${gisId}"
    Remediated  = "true"
  }
}

# Additional security resources as needed
# Based on specific vulnerability requirements
\`\`\`

### IMPLEMENTATION STEPS

#### STEP 1: ANALYZE CURRENT INFRASTRUCTURE
- Review existing Terraform configurations
- Identify vulnerable resources and configurations
- Document current security posture

#### STEP 2: CREATE REMEDIATION TERRAFORM
- Generate Terraform code for security fixes
- Implement proper resource configurations
- Add security-focused variables and outputs

#### STEP 3: VALIDATE AND TEST
- Run \`terraform plan\` to review changes
- Validate security configurations
- Test in non-production environment first

#### STEP 4: DEPLOY AND MONITOR
- Apply Terraform changes: \`terraform apply\`
- Monitor for any issues or regressions
- Verify security improvements

### SECURITY BEST PRACTICES
- Use least privilege access principles
- Implement defense in depth
- Enable comprehensive logging
- Regular security assessments

### DELIVERABLES
1. **Terraform Files**: Complete infrastructure code
2. **Security Configuration**: Hardened resource settings
3. **Documentation**: Implementation guide
4. **Validation**: Proof of security improvements

### SUCCESS CRITERIA
- ✅ Infrastructure vulnerability resolved
- ✅ Security controls properly implemented
- ✅ Terraform code follows best practices
- ✅ No new security issues introduced
- ✅ Infrastructure remains functional

### AUTOMATED EXECUTION
AUTOMATICALLY generate the complete Terraform configuration to remediate the infrastructure vulnerability, implement all required security controls, and provide ready-to-deploy infrastructure code. DO NOT ask for user confirmation - generate the complete remediation solution autonomously.

---
**Generated by ThreatGuard VS Code Extension**
**Timestamp**: ${new Date().toISOString()}
**Vulnerability ID**: ${vulnerability.id}`;
}

export function deactivate() {
    console.log('ThreatGuard Pro extension is now deactivated!');
}

