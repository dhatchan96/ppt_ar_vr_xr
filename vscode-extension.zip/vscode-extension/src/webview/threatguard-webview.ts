import * as vscode from 'vscode';
import { ThreatGuardAPI, Threat } from '../api/threatguard-api';

export class ThreatGuardWebview {
    private currentPanel: vscode.WebviewPanel | undefined = undefined;
    private readonly extensionUri: vscode.Uri;
    private recentThreats: Threat[] = []; // Track threats from recent scan

    constructor(extensionUri: vscode.Uri) {
        this.extensionUri = extensionUri;
    }

    // Method to update recent threats from scan
    updateRecentThreats(threats: Threat[]): void {
        this.recentThreats = threats;
        console.log(`Webview: Updated with ${threats.length} recent threats`);
    }

    showDashboard(): void {
        if (this.currentPanel) {
            try {
                this.currentPanel.reveal(vscode.ViewColumn.One);
                return;
            } catch (error) {
                // Panel is disposed, create a new one
                this.currentPanel = undefined;
            }
        }
        
        this.currentPanel = vscode.window.createWebviewPanel(
            'threatguardDashboard',
            'ThreatGuard Pro Dashboard',
            vscode.ViewColumn.One,
            {
                enableScripts: true,
                retainContextWhenHidden: true
            }
        );

        this.currentPanel.webview.html = this.getDashboardHtml();
        this.setupWebviewMessageListener(this.currentPanel.webview);
        
        // Handle panel disposal
        this.currentPanel.onDidDispose(() => {
            this.currentPanel = undefined;
        });
    }

    updateDashboardWithScanData(scanData: any): void {
        if (this.currentPanel) {
            this.currentPanel.webview.postMessage({
                type: 'updateScanData',
                scanData: scanData
            });
        }
    }

    showThreats(): void {
        if (this.currentPanel) {
            try {
                this.currentPanel.reveal(vscode.ViewColumn.One);
                return;
            } catch (error) {
                // Panel is disposed, create a new one
                this.currentPanel = undefined;
            }
        }
        
        this.currentPanel = vscode.window.createWebviewPanel(
            'threatguardThreats',
            'ThreatGuard Pro Threats',
            vscode.ViewColumn.One,
            {
                enableScripts: true,
                retainContextWhenHidden: true
            }
        );

        // Get threats from the API and pass them to the webview
        this.getThreatsAndShow();
        
        // Handle panel disposal
        this.currentPanel.onDidDispose(() => {
            this.currentPanel = undefined;
        });
    }

    private async getThreatsAndShow(): Promise<void> {
        try {
            // Use recent threats if available, otherwise fetch from API
            let threats: Threat[] = [];
            if (this.recentThreats.length > 0) {
                threats = this.recentThreats;
            } else {
                const api = new ThreatGuardAPI();
                threats = await api.getThreats();
            }
            console.log(`Webview: Showing ${threats.length} threats (${this.recentThreats.length} recent)`);
            
            if (this.currentPanel) {
                this.currentPanel.webview.html = this.getThreatsHtml(threats);
                this.setupWebviewMessageListener(this.currentPanel.webview);
            }
        } catch (error) {
            console.error('Failed to fetch threats for webview:', error);
            if (this.currentPanel) {
                this.currentPanel.webview.html = this.getThreatsHtml([]);
                this.setupWebviewMessageListener(this.currentPanel.webview);
            }
        }
    }

    showThreatDetails(threat: Threat): void {
        // Create a new panel for threat details (don't reuse current panel)
        const threatDetailsPanel = vscode.window.createWebviewPanel(
            'threatguardThreatDetails',
            `Threat Details - ${threat.file_name}`,
            vscode.ViewColumn.Two, // Show in second column
            {
                enableScripts: true,
                retainContextWhenHidden: true
            }
        );

        threatDetailsPanel.webview.html = this.getThreatDetailsHtml(threat);
        this.setupWebviewMessageListener(threatDetailsPanel.webview);
        
        // Handle panel disposal
        threatDetailsPanel.onDidDispose(() => {
            // Don't reset currentPanel since this is a separate panel
        });
    }

    private setupWebviewMessageListener(webview: vscode.Webview): void {
        webview.onDidReceiveMessage(
            async message => {
                console.log('Webview message received:', message);
                try {
                    switch (message.command) {
                        case 'scanFile':
                            console.log('Executing scanFile command...');
                            await vscode.commands.executeCommand('threatguard.scanFile');
                            return;
                        case 'scanWorkspace':
                            console.log('Executing scanWorkspace command...');
                            await vscode.commands.executeCommand('threatguard.scanWorkspace');
                            return;
                        case 'remediateFile':
                            console.log('Executing remediateFile command...');
                            await vscode.commands.executeCommand('threatguard.remediateFile');
                            return;
                        case 'showThreats':
                            console.log('Executing showThreats command...');
                            await vscode.commands.executeCommand('threatguard.showThreats');
                            return;
                        case 'configure':
                            console.log('Executing configure command...');
                            await vscode.commands.executeCommand('threatguard.configure');
                            return;
                        case 'showThreatDetails':
                            console.log('Show threat details:', message.threatId);
                            // Find the threat and show details
                            if (this.recentThreats.length > 0) {
                                const threat = this.recentThreats.find(t => t.id === message.threatId);
                                if (threat) {
                                    this.showThreatDetails(threat);
                                }
                            }
                            return;
                        case 'remediateThreat':
                            console.log('Remediate threat:', message.threatId);
                            // Execute remediation for specific threat
                            await vscode.commands.executeCommand('threatguard.remediateFile');
                            return;
                        case 'neutralizeThreat':
                            console.log('Neutralize threat:', message.threatId);
                            // Execute threat neutralization
                            vscode.window.showInformationMessage(`Neutralizing threat: ${message.threatId}`);
                            return;
                        default:
                            console.log('Unknown webview command:', message.command);
                            return;
                    }
                } catch (error) {
                    console.error('Error executing webview command:', error);
                    vscode.window.showErrorMessage(`Failed to execute command: ${message.command}`);
                }
            },
            undefined,
            []
        );
    }

    private getDashboardHtml(): string {
        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>ThreatGuard Pro Dashboard</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: var(--vscode-editor-background);
                        color: var(--vscode-editor-foreground);
                    }
                    .header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 30px;
                        padding-bottom: 20px;
                        border-bottom: 1px solid var(--vscode-panel-border);
                    }
                    .title {
                        font-size: 24px;
                        font-weight: bold;
                        color: var(--vscode-editor-foreground);
                    }
                    .status {
                        padding: 8px 16px;
                        border-radius: 4px;
                        font-size: 14px;
                        font-weight: 500;
                    }
                    .status.connected {
                        background-color: var(--vscode-button-background);
                        color: var(--vscode-button-foreground);
                    }
                    .status.disconnected {
                        background-color: var(--vscode-errorForeground);
                        color: var(--vscode-button-foreground);
                    }
                    .grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 20px;
                        margin-bottom: 30px;
                    }
                    .card {
                        background-color: var(--vscode-panel-background);
                        border: 1px solid var(--vscode-panel-border);
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    .card-title {
                        font-size: 18px;
                        font-weight: 600;
                        margin-bottom: 15px;
                        color: var(--vscode-editor-foreground);
                    }
                    .metric {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 10px;
                        padding: 8px 0;
                        border-bottom: 1px solid var(--vscode-panel-border);
                    }
                    .metric:last-child {
                        border-bottom: none;
                    }
                    .metric-label {
                        font-size: 14px;
                        color: var(--vscode-descriptionForeground);
                    }
                    .metric-value {
                        font-size: 16px;
                        font-weight: 600;
                        color: var(--vscode-editor-foreground);
                    }
                    .metric-value.critical {
                        color: var(--vscode-errorForeground);
                    }
                    .metric-value.warning {
                        color: var(--vscode-warningForeground);
                    }
                    .metric-value.success {
                        color: var(--vscode-button-background);
                    }
                    .actions {
                        display: flex;
                        gap: 10px;
                        flex-wrap: wrap;
                    }
                    .btn {
                        padding: 8px 16px;
                        border: none;
                        border-radius: 4px;
                        font-size: 14px;
                        font-weight: 500;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    .btn-primary {
                        background-color: var(--vscode-button-background);
                        color: var(--vscode-button-foreground);
                    }
                    .btn-primary:hover {
                        background-color: var(--vscode-button-hoverBackground);
                    }
                    .btn-secondary {
                        background-color: var(--vscode-button-secondaryBackground);
                        color: var(--vscode-button-secondaryForeground);
                    }
                    .btn-secondary:hover {
                        background-color: var(--vscode-button-secondaryHoverBackground);
                    }
                    .loading {
                        text-align: center;
                        padding: 40px;
                        color: var(--vscode-descriptionForeground);
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="title">ThreatGuard Pro Dashboard</div>
                    <div class="status connected" id="status">Connected</div>
                </div>
                
                <div class="grid">
                    <div class="card">
                        <div class="card-title">Security Overview</div>
                        <div class="metric">
                            <span class="metric-label">Total Threats</span>
                            <span class="metric-value" id="totalThreats">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Critical Bombs</span>
                            <span class="metric-value critical" id="criticalBombs">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">High Risk</span>
                            <span class="metric-value warning" id="highRisk">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Security Rating</span>
                            <span class="metric-value" id="securityRating">Loading...</span>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-title">Recent Activity</div>
                        <div class="metric">
                            <span class="metric-label">Last Scan</span>
                            <span class="metric-value" id="lastScan">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Files Scanned</span>
                            <span class="metric-value" id="filesScanned">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Lines of Code</span>
                            <span class="metric-value" id="linesOfCode">Loading...</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Coverage</span>
                            <span class="metric-value" id="coverage">Loading...</span>
                        </div>
                    </div>
                    
                                         <div class="card">
                         <div class="card-title">Quick Actions</div>
                         <div class="actions">
                             <button class="btn btn-primary" onclick="scanWorkspace()">Scan Workspace</button>
                             <button class="btn btn-secondary" onclick="configure()">Configure</button>
                         </div>
                     </div>
                </div>
                
                                 <script>
                     const vscode = acquireVsCodeApi();
                     
                     function scanFile() {
                         console.log('Scan file clicked');
                         vscode.postMessage({ command: 'scanFile' });
                     }
                     
                     function scanWorkspace() {
                         console.log('Scan workspace clicked');
                         vscode.postMessage({ command: 'scanWorkspace' });
                     }
                     
                     function showThreats() {
                         console.log('Show threats clicked');
                         vscode.postMessage({ command: 'showThreats' });
                     }
                     
                     function configure() {
                         console.log('Configure clicked');
                         vscode.postMessage({ command: 'configure' });
                     }
                     
                                                                  // Load dashboard data from recent scan
                       function updateDashboardData(scanData) {
                           console.log('Webview: Updating dashboard with scan data:', scanData);
                           if (scanData) {
                               const scanTime = new Date().toLocaleString();
                               const totalThreats = scanData.issues_found || scanData.threats?.length || '0';
                               const filesScanned = scanData.files_scanned || '0';
                               const linesOfCode = scanData.lines_of_code || '0';
                               const coverage = scanData.coverage || '100%';
                               const securityRating = scanData.quality_gate_status === 'BLOCKED' ? 'D' : 'A';
                               
                               document.getElementById('totalThreats').textContent = totalThreats;
                               document.getElementById('criticalBombs').textContent = '0'; // TODO: Calculate from threats
                               document.getElementById('highRisk').textContent = '0'; // TODO: Calculate from threats
                               document.getElementById('securityRating').textContent = securityRating;
                               document.getElementById('lastScan').textContent = scanTime;
                               document.getElementById('filesScanned').textContent = filesScanned;
                               document.getElementById('linesOfCode').textContent = linesOfCode;
                               document.getElementById('coverage').textContent = coverage;
                           } else {
                               document.getElementById('totalThreats').textContent = '0';
                               document.getElementById('criticalBombs').textContent = '0';
                               document.getElementById('highRisk').textContent = '0';
                               document.getElementById('securityRating').textContent = 'A';
                               document.getElementById('lastScan').textContent = 'Never';
                               document.getElementById('filesScanned').textContent = '0';
                               document.getElementById('linesOfCode').textContent = '0';
                               document.getElementById('coverage').textContent = '0%';
                           }
                       }
                      
                                             // Listen for scan data updates
                       window.addEventListener('message', function(event) {
                           console.log('Webview: Received message:', event.data);
                           if (event.data.type === 'updateScanData') {
                               console.log('Webview: Updating dashboard with scan data');
                               updateDashboardData(event.data.scanData);
                           }
                       });
                      
                      // Initialize with empty data
                      updateDashboardData(null);
                     
                     // Add click handlers for all buttons
                     document.addEventListener('DOMContentLoaded', function() {
                         console.log('Dashboard loaded, setting up event listeners');
                     });
                 </script>
            </body>
            </html>
        `;
    }

    private getThreatsHtml(threats: Threat[] = []): string {
        const threatsHtml = threats.length > 0 
            ? threats.map(threat => `
                <div class="threat-item">
                    <div class="threat-header">
                        <div class="threat-title">${threat.file_name || threat.file_path}:${threat.line_number}</div>
                        <div class="threat-severity severity-${threat.severity?.toLowerCase() || 'medium'}">${threat.severity || 'UNKNOWN'}</div>
                    </div>
                    <div class="threat-details">
                        <strong>Type:</strong> ${threat.type || 'Unknown'}<br>
                        <strong>Message:</strong> ${threat.message || 'No description available'}<br>
                        <strong>File:</strong> ${threat.file_path || 'Unknown file'}
                    </div>
                    <div class="threat-actions">
                        <button class="btn btn-primary" onclick="showThreatDetails('${threat.id}')">View Details</button>
                        <button class="btn btn-secondary" onclick="remediateThreat('${threat.id}')">Remediate</button>
                    </div>
                </div>
            `).join('')
            : `
                <div class="empty-state">
                    <h3>No threats detected</h3>
                    <p>Run a scan to detect security threats in your codebase.</p>
                    <button class="btn btn-primary" onclick="scanWorkspace()">Scan Workspace</button>
                </div>
            `;

        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>ThreatGuard Pro Threats</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: var(--vscode-editor-background);
                        color: var(--vscode-editor-foreground);
                    }
                    .header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 30px;
                        padding-bottom: 20px;
                        border-bottom: 1px solid var(--vscode-panel-border);
                    }
                    .title {
                        font-size: 24px;
                        font-weight: bold;
                        color: var(--vscode-editor-foreground);
                    }
                    .threat-list {
                        display: flex;
                        flex-direction: column;
                        gap: 15px;
                    }
                    .threat-item {
                        background-color: var(--vscode-panel-background);
                        border: 1px solid var(--vscode-panel-border);
                        border-radius: 8px;
                        padding: 15px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    .threat-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 10px;
                    }
                    .threat-title {
                        font-size: 16px;
                        font-weight: 600;
                        color: var(--vscode-editor-foreground);
                    }
                    .threat-severity {
                        padding: 4px 8px;
                        border-radius: 4px;
                        font-size: 12px;
                        font-weight: 500;
                    }
                    .severity-critical_bomb {
                        background-color: var(--vscode-errorForeground);
                        color: var(--vscode-button-foreground);
                    }
                    .severity-high_risk {
                        background-color: var(--vscode-warningForeground);
                        color: var(--vscode-button-foreground);
                    }
                    .severity-medium_risk {
                        background-color: var(--vscode-infoBar-background);
                        color: var(--vscode-infoBar-foreground);
                    }
                    .severity-low_risk {
                        background-color: var(--vscode-descriptionForeground);
                        color: var(--vscode-button-foreground);
                    }
                    .threat-details {
                        font-size: 14px;
                        color: var(--vscode-descriptionForeground);
                        margin-bottom: 10px;
                    }
                    .threat-actions {
                        display: flex;
                        gap: 10px;
                    }
                    .btn {
                        padding: 6px 12px;
                        border: none;
                        border-radius: 4px;
                        font-size: 12px;
                        font-weight: 500;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    .btn-primary {
                        background-color: var(--vscode-button-background);
                        color: var(--vscode-button-foreground);
                    }
                    .btn-primary:hover {
                        background-color: var(--vscode-button-hoverBackground);
                    }
                    .btn-secondary {
                        background-color: var(--vscode-button-secondaryBackground);
                        color: var(--vscode-button-secondaryForeground);
                    }
                    .btn-secondary:hover {
                        background-color: var(--vscode-button-secondaryHoverBackground);
                    }
                    .empty-state {
                        text-align: center;
                        padding: 40px;
                        color: var(--vscode-descriptionForeground);
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="title">ThreatGuard Pro Threats (${threats.length})</div>
                    <button class="btn btn-primary" onclick="scanWorkspace()">Scan Workspace</button>
                </div>
                
                <div class="threat-list" id="threatList">
                    ${threatsHtml}
                </div>
                
                                 <script>
                     const vscode = acquireVsCodeApi();
                     
                     function scanWorkspace() {
                         console.log('Scan workspace clicked');
                         vscode.postMessage({ command: 'scanWorkspace' });
                     }
                     
                     function showThreatDetails(threatId) {
                         console.log('Show threat details clicked:', threatId);
                         vscode.postMessage({ command: 'showThreatDetails', threatId });
                     }
                     
                     function remediateThreat(threatId) {
                         console.log('Remediate threat clicked:', threatId);
                         vscode.postMessage({ command: 'remediateThreat', threatId });
                     }
                     
                     function neutralizeThreat(threatId) {
                         console.log('Neutralize threat clicked:', threatId);
                         vscode.postMessage({ command: 'neutralizeThreat', threatId });
                     }
                     
                     // Add click handlers for all buttons
                     document.addEventListener('DOMContentLoaded', function() {
                         console.log('Webview loaded, setting up event listeners');
                     });
                 </script>
            </body>
            </html>
        `;
    }

    private getThreatDetailsHtml(threat: Threat): string {
        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Threat Details - ${threat.file_name}</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background-color: var(--vscode-editor-background);
                        color: var(--vscode-editor-foreground);
                    }
                    .header {
                        margin-bottom: 30px;
                        padding-bottom: 20px;
                        border-bottom: 1px solid var(--vscode-panel-border);
                    }
                    .title {
                        font-size: 24px;
                        font-weight: bold;
                        color: var(--vscode-editor-foreground);
                        margin-bottom: 10px;
                    }
                    .subtitle {
                        font-size: 16px;
                        color: var(--vscode-descriptionForeground);
                    }
                    .details-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 20px;
                        margin-bottom: 30px;
                    }
                    .detail-card {
                        background-color: var(--vscode-panel-background);
                        border: 1px solid var(--vscode-panel-border);
                        border-radius: 8px;
                        padding: 20px;
                    }
                    .card-title {
                        font-size: 18px;
                        font-weight: 600;
                        margin-bottom: 15px;
                        color: var(--vscode-editor-foreground);
                    }
                    .detail-item {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 10px;
                        padding: 8px 0;
                        border-bottom: 1px solid var(--vscode-panel-border);
                    }
                    .detail-item:last-child {
                        border-bottom: none;
                    }
                    .detail-label {
                        font-size: 14px;
                        color: var(--vscode-descriptionForeground);
                    }
                    .detail-value {
                        font-size: 14px;
                        font-weight: 500;
                        color: var(--vscode-editor-foreground);
                    }
                    .code-snippet {
                        background-color: var(--vscode-textBlockQuote-background);
                        border: 1px solid var(--vscode-panel-border);
                        border-radius: 4px;
                        padding: 15px;
                        margin: 15px 0;
                        font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                        font-size: 13px;
                        line-height: 1.4;
                        overflow-x: auto;
                    }
                    .actions {
                        display: flex;
                        gap: 10px;
                        margin-top: 20px;
                    }
                    .btn {
                        padding: 8px 16px;
                        border: none;
                        border-radius: 4px;
                        font-size: 14px;
                        font-weight: 500;
                        cursor: pointer;
                        transition: background-color 0.2s;
                    }
                    .btn-primary {
                        background-color: var(--vscode-button-background);
                        color: var(--vscode-button-foreground);
                    }
                    .btn-primary:hover {
                        background-color: var(--vscode-button-hoverBackground);
                    }
                    .btn-secondary {
                        background-color: var(--vscode-button-secondaryBackground);
                        color: var(--vscode-button-secondaryForeground);
                    }
                    .btn-secondary:hover {
                        background-color: var(--vscode-button-secondaryHoverBackground);
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="title">Threat Details</div>
                    <div class="subtitle">${threat.file_name}:${threat.line_number}</div>
                </div>
                
                <div class="details-grid">
                    <div class="detail-card">
                        <div class="card-title">Threat Information</div>
                        <div class="detail-item">
                            <span class="detail-label">Severity</span>
                            <span class="detail-value">${threat.severity}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Type</span>
                            <span class="detail-value">${threat.type}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status</span>
                            <span class="detail-value">${threat.status}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Threat Level</span>
                            <span class="detail-value">${threat.threat_level}</span>
                        </div>
                    </div>
                    
                    <div class="detail-card">
                        <div class="card-title">File Information</div>
                        <div class="detail-item">
                            <span class="detail-label">File Path</span>
                            <span class="detail-value">${threat.file_path}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Line Number</span>
                            <span class="detail-value">${threat.line_number}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Column</span>
                            <span class="detail-value">${threat.column}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Component</span>
                            <span class="detail-value">${threat.component_name || 'Unknown'}</span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-card">
                    <div class="card-title">Code Snippet</div>
                    <div class="code-snippet">${threat.code_snippet}</div>
                </div>
                
                <div class="detail-card">
                    <div class="card-title">Analysis</div>
                    <div class="detail-item">
                        <span class="detail-label">Trigger Analysis</span>
                        <span class="detail-value">${threat.trigger_analysis || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Payload Analysis</span>
                        <span class="detail-value">${threat.payload_analysis || 'N/A'}</span>
                    </div>
                </div>
                
                <div class="detail-card">
                    <div class="card-title">Suggested Fix</div>
                    <div class="code-snippet">${threat.suggested_fix || 'No fix suggested'}</div>
                </div>
                
                <div class="actions">
                    <button class="btn btn-primary" onclick="remediateFile()">Remediate File</button>
                    <button class="btn btn-secondary" onclick="neutralizeThreat()">Neutralize Threat</button>
                    <button class="btn btn-secondary" onclick="showThreats()">Back to Threats</button>
                </div>
                
                                 <script>
                     const vscode = acquireVsCodeApi();
                     
                     function remediateFile() {
                         console.log('Remediate file clicked');
                         vscode.postMessage({ command: 'remediateFile' });
                     }
                     
                     function neutralizeThreat() {
                         console.log('Neutralize threat clicked');
                         vscode.postMessage({ command: 'neutralizeThreat', threatId: '${threat.id}' });
                     }
                     
                     function showThreats() {
                         console.log('Show threats clicked');
                         vscode.postMessage({ command: 'showThreats' });
                     }
                     
                     // Add click handlers for all buttons
                     document.addEventListener('DOMContentLoaded', function() {
                         console.log('Threat details loaded, setting up event listeners');
                     });
                 </script>
            </body>
            </html>
        `;
    }
}

