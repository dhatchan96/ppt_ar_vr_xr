// Test file to check threat data structure
const axios = require('axios');

async function testThreatData() {
    try {
        const response = await axios.get('http://localhost:5000/api/threats');
        console.log('Threat data structure:');
        console.log(JSON.stringify(response.data, null, 2));
        
        if (response.data && response.data.length > 0) {
            console.log('\nFirst threat details:');
            console.log('ID:', response.data[0].id);
            console.log('Type:', response.data[0].type);
            console.log('Severity:', response.data[0].severity);
            console.log('File:', response.data[0].file_name || response.data[0].file_path);
            console.log('Line:', response.data[0].line_number);
            console.log('Message:', response.data[0].message);
        }
    } catch (error) {
        console.error('Error fetching threats:', error.message);
    }
}

testThreatData();
