# ThreatGuard Pro Extension - Installation & Distribution Guide

This guide explains how to bundle, package, and install the ThreatGuard Pro VSCode extension for testing and distribution.

## 📦 Prerequisites

Before packaging the extension, ensure you have:

1. **Node.js** (v16 or higher) installed
2. **npm** (comes with Node.js)
3. **VS Code** installed (for testing)
4. **Backend API** running (required for extension to function)

## 🔨 Step 1: Install Dependencies

Navigate to the extension directory and install all dependencies:

```bash
cd vscode-extension
npm install
```

This will install:
- TypeScript and compilation tools
- VS Code extension dependencies
- `@vscode/vsce` (Visual Studio Code Extension packaging tool)

## 🔧 Step 2: Build the Extension

Compile TypeScript to JavaScript:

```bash
npm run compile
```

This will:
- Transpile TypeScript files to JavaScript
- Output files to the `out/` directory
- Check for compilation errors

**Verify build:** Check that `out/extension.js` exists and is populated.

## 📦 Step 3: Package the Extension

Create a `.vsix` file (VS Code extension package):

```bash
npm run package
```

This will:
- Compile the extension (if not already done)
- Create a `.vsix` file named `threatguard-pro-1.0.0.vsix`
- Include all necessary files (JavaScript, package.json, README, etc.)

**Output:** You'll see `threatguard-pro-1.0.0.vsix` in the `vscode-extension` directory.

## 📋 Manual Packaging (Alternative)

If you need more control, use `vsce` directly:

```bash
# Install vsce globally (optional)
npm install -g @vscode/vsce

# Package the extension
vsce package

# Or specify output name
vsce package -o threatguard-pro-1.0.0.vsix
```

## 🚀 Step 4: Install on Another User's System

### Option A: Install from `.vsix` File (Recommended)

1. **Copy the `.vsix` file** to the target system
   - Transfer `threatguard-pro-1.0.0.vsix` via:
     - USB drive
     - Email attachment
     - Network share
     - Cloud storage (Google Drive, Dropbox, etc.)

2. **Install via Command Line:**
   ```bash
   code --install-extension threatguard-pro-1.0.0.vsix
   ```

3. **Or Install via VS Code UI:**
   - Open VS Code
   - Press `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)
   - Type: `Extensions: Install from VSIX...`
   - Select the `threatguard-pro-1.0.0.vsix` file
   - Click "Install"

4. **Reload VS Code:**
   - VS Code will prompt to reload
   - Or press `Ctrl+Shift+P` → `Developer: Reload Window`

### Option B: Install from Local Folder (Development)

For development/testing on the same machine:

1. **Open Extension Development Host:**
   ```bash
   code vscode-extension
   ```

2. **Press F5** to launch Extension Development Host
   - This opens a new VS Code window with your extension loaded
   - Check the Output panel for extension logs

## ✅ Step 5: Verify Installation

1. **Check Extension is Installed:**
   - Open VS Code
   - Go to Extensions view (`Ctrl+Shift+X`)
   - Search for "ThreatGuard Pro"
   - Should show as installed

2. **Verify Extension Works:**
   - Check status bar for ThreatGuard icon
   - Look for "ThreatGuard Pro" in Activity Bar (left sidebar)
   - Try commands:
     - `Ctrl+Shift+P` → "ThreatGuard: Show Dashboard"
     - `Ctrl+Shift+T` → Scan current file

3. **Check Connection:**
   - Ensure backend API is running on `http://localhost:5000`
   - Status bar should show "Connected" (green indicator)

## ⚙️ Step 6: Configure Extension

The user needs to configure the extension:

1. **Open Settings:**
   - Press `Ctrl+,` (Windows/Linux) or `Cmd+,` (Mac)
   - Search for "ThreatGuard"

2. **Configure API URL:**
   ```json
   {
     "threatguard.apiUrl": "http://localhost:5000"
   }
   ```

3. **Other Settings:**
   - `threatguard.autoScan`: Enable/disable auto-scan on save
   - `threatguard.severityLevel`: Minimum severity to display
   - `threatguard.enableNotifications`: Show notifications

## 🔍 Troubleshooting

### Extension Not Appearing

**Problem:** Extension doesn't show in Extensions view

**Solutions:**
- Check VS Code version (requires 1.74.0+)
- Verify `.vsix` file is valid: `code --install-extension threatguard-pro-1.0.0.vsix --force`
- Check Output panel for errors

### Extension Installed But Not Working

**Problem:** Extension installed but features don't work

**Solutions:**
1. **Check Backend Connection:**
   - Ensure `dashboard_api_enhanced.py` is running
   - Test: `curl http://localhost:5000/api/health`

2. **Check Extension Logs:**
   - Open Output panel (`Ctrl+Shift+U`)
   - Select "ThreatGuard Pro" from dropdown
   - Look for errors

3. **Verify Configuration:**
   - Check `threatguard.apiUrl` setting
   - Should match backend URL

### Build Errors

**Problem:** `npm run compile` fails

**Solutions:**
- Check TypeScript version: `npm list typescript`
- Update dependencies: `npm update`
- Clear and rebuild: `rm -rf out node_modules && npm install && npm run compile`

### Packaging Errors

**Problem:** `npm run package` fails

**Solutions:**
- Ensure `out/extension.js` exists
- Check `package.json` is valid JSON
- Verify `vsce` is installed: `npm list @vscode/vsce`
- Try manual packaging: `npx @vscode/vsce package`

## 📤 Distribution Checklist

Before distributing the extension:

- [ ] Extension compiles without errors
- [ ] All features tested in Extension Development Host
- [ ] `.vsix` file created successfully
- [ ] README.md is up to date
- [ ] Version number updated in `package.json`
- [ ] Backend API is documented for users
- [ ] Installation instructions included

## 🔄 Updating the Extension

To update an installed extension:

1. **Build new version:**
   ```bash
   npm run compile
   npm run package
   ```

2. **Update version in package.json:**
   ```json
   "version": "1.0.1"
   ```

3. **Package new version:**
   ```bash
   npm run package
   ```

4. **Reinstall:**
   ```bash
   code --install-extension threatguard-pro-1.0.1.vsix --force
   ```

## 📝 Quick Reference

```bash
# Complete workflow
cd vscode-extension
npm install              # Install dependencies
npm run compile          # Build extension
npm run package          # Create .vsix file

# Install on target system
code --install-extension threatguard-pro-1.0.0.vsix

# Check installed extensions
code --list-extensions | grep threatguard

# Uninstall extension
code --uninstall-extension threatguard-pro
```

## 🌐 Network Installation (Advanced)

If backend is on a different machine:

1. **Update API URL in settings:**
   ```json
   {
     "threatguard.apiUrl": "http://192.168.1.100:5000"
   }
   ```

2. **Ensure backend allows external connections:**
   - In `dashboard_api_enhanced.py`, change:
     ```python
     app.run(host='0.0.0.0', port=5000)  # Allows external access
     ```

3. **Check firewall settings** on backend machine

## 📞 Support

For issues or questions:
1. Check extension logs in Output panel
2. Check backend logs
3. Verify network connectivity
4. Review configuration settings

---

**Note:** The extension requires the ThreatGuard Pro backend API to be running. Make sure users have access to or can run the backend server.

