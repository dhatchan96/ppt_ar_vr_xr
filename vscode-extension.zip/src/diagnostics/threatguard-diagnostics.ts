import * as vscode from 'vscode';
import { Threat } from '../api/threatguard-api';

export class ThreatGuardDiagnostics {
    private diagnosticCollection: vscode.DiagnosticCollection;

    constructor() {
        this.diagnosticCollection = vscode.languages.createDiagnosticCollection('threatguard');
    }

    setThreats(uri: vscode.Uri, threats: Threat[]): void {
        const diagnostics: vscode.Diagnostic[] = threats.map(threat => {
            const range = new vscode.Range(
                threat.line_number - 1, 
                threat.column - 1, 
                threat.line_number - 1, 
                threat.column + (threat.code_snippet?.length || 0)
            );

            const diagnostic = new vscode.Diagnostic(
                range,
                threat.message,
                this.getSeverity(threat.severity)
            );

            diagnostic.source = 'ThreatGuard Pro';
            diagnostic.code = threat.rule_id;
            diagnostic.relatedInformation = [
                new vscode.DiagnosticRelatedInformation(
                    new vscode.Location(uri, range),
                    `Type: ${threat.type} | Level: ${threat.threat_level}`
                )
            ];

            // Add additional information to the diagnostic
            if (threat.suggested_fix) {
                diagnostic.message += `\n\nSuggested Fix:\n${threat.suggested_fix}`;
            }

            if (threat.trigger_analysis) {
                diagnostic.message += `\n\nTrigger Analysis:\n${threat.trigger_analysis}`;
            }

            if (threat.payload_analysis) {
                diagnostic.message += `\n\nPayload Analysis:\n${threat.payload_analysis}`;
            }

            return diagnostic;
        });

        this.diagnosticCollection.set(uri, diagnostics);
    }

    clearThreats(uri: vscode.Uri): void {
        this.diagnosticCollection.delete(uri);
    }

    clearAllThreats(): void {
        this.diagnosticCollection.clear();
    }

    private getSeverity(severity: string): vscode.DiagnosticSeverity {
        switch (severity) {
            case 'CRITICAL_BOMB':
                return vscode.DiagnosticSeverity.Error;
            case 'HIGH_RISK':
                return vscode.DiagnosticSeverity.Error;
            case 'MEDIUM_RISK':
                return vscode.DiagnosticSeverity.Warning;
            case 'LOW_RISK':
                return vscode.DiagnosticSeverity.Information;
            default:
                return vscode.DiagnosticSeverity.Warning;
        }
    }

    dispose(): void {
        this.diagnosticCollection.dispose();
    }
}

