import * as vscode from 'vscode';
import { ThreatGuardAPI } from './api/threatguard-api';
import { ThreatProvider } from './providers/threat-provider';
import { DashboardProvider } from './providers/dashboard-provider';
import { ScanProvider } from './providers/scan-provider';
import { ThreatGuardStatusBar } from './status/threatguard-statusbar';
import { ThreatGuardDiagnostics } from './diagnostics/threatguard-diagnostics';
import { ThreatGuardWebview } from './webview/threatguard-webview';

export function activate(context: vscode.ExtensionContext) {
    console.log('ThreatGuard Pro extension is now active!');

    // Initialize API client
    const api = new ThreatGuardAPI();
    
    // Initialize providers
    const threatProvider = new ThreatProvider(api);
    const dashboardProvider = new DashboardProvider(api);
    const scanProvider = new ScanProvider(api);
    
    // Initialize status bar
    const statusBar = new ThreatGuardStatusBar();
    
    // Initialize diagnostics
    const diagnostics = new ThreatGuardDiagnostics();
    
    // Initialize webview
    const webview = new ThreatGuardWebview(context.extensionUri);

    // Register tree data providers
    vscode.window.registerTreeDataProvider('threatguard.threatsView', threatProvider);
    vscode.window.registerTreeDataProvider('threatguard.dashboardView', dashboardProvider);
    vscode.window.registerTreeDataProvider('threatguard.scansView', scanProvider);

    // Register commands
    let refreshScanHistoryCommand = vscode.commands.registerCommand('threatguard.refreshScanHistory', () => {
        scanProvider.refresh();
        vscode.window.showInformationMessage('Scan history refreshed');
    });

    let scanFileCommand = vscode.commands.registerCommand('threatguard.scanFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showWarningMessage('No active editor found');
            return;
        }

        const document = editor.document;
        let content = document.getText();
        const filePath = document.fileName;

        // Normalize line endings to prevent spaces from being added
        content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

        // Debug: Log the content length and first few lines
        console.log(`Scanning file: ${filePath}`);
        console.log(`Content length: ${content.length}`);
        console.log(`First 200 chars: ${content.substring(0, 200)}`);
        console.log(`Line endings normalized: ${content.includes('\r\n') ? 'NO' : 'YES'}`);

        let result: any = null; // Declared outside try block
        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                statusBar.showError();
                return;
            }

            statusBar.showScanning();
            vscode.window.showInformationMessage('Scanning file for threats...');

            // Clear any existing threats before starting new scan
            threatProvider.clearThreats();

            result = await api.scanFile(filePath, content);
            
            console.log('Scan result:', result);
            
                                     if (result.threats && result.threats.length > 0) {
                diagnostics.setThreats(document.uri, result.threats);
                vscode.window.showWarningMessage(`Found ${result.threats.length} threats in ${document.fileName}`);
                statusBar.showThreats(result.threats.length);
                
                // Update threat provider with detected threats
                threatProvider.updateThreats(result.threats);
                
                // Update webview with recent threats
                webview.updateRecentThreats(result.threats);
                
                // Create scan data for dashboard update
                const scanData = {
                    duration_ms: result.duration_ms || 0,
                    files_scanned: 1,
                    issues_found: result.threats.length,
                    quality_gate_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED',
                    lines_of_code: result.lines_of_code || 0,
                    coverage: '100%'
                };
                
                // Update dashboard with scan data
                console.log('Extension: Updating dashboard with scan data:', scanData);
                webview.updateDashboardWithScanData(scanData);
                dashboardProvider.updateWithScanData(scanData);

                // Save scan data to JSON for React UI
                try {
                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: filePath,
                        file_name: document.fileName,
                        content: content,
                        threats: result.threats,
                        scan_metrics: scanData,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            } else {
                vscode.window.showInformationMessage('No threats detected in file');
                statusBar.showClean();
                
                // Clear threats from provider
                threatProvider.updateThreats([]);
                
                // Clear recent threats from webview
                webview.updateRecentThreats([]);
                
                // Update dashboard with clean scan data
                const scanData = {
                    duration_ms: result.duration_ms || 0,
                    files_scanned: 1,
                    issues_found: 0,
                    quality_gate_status: 'PASSED',
                    lines_of_code: result.lines_of_code || 0,
                    coverage: '100%'
                };
                
                console.log('Extension: Updating dashboard with clean scan data:', scanData);
                webview.updateDashboardWithScanData(scanData);
                dashboardProvider.updateWithScanData(scanData);

                // Save scan data to JSON for React UI (even for clean scans)
                try {
                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: filePath,
                        file_name: document.fileName,
                        content: content,
                        threats: [],
                        scan_metrics: scanData,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Clean scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save clean scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            }

            // Refresh providers
            dashboardProvider.refresh();

        } catch (error) {
            console.error('Scan error:', error);
            vscode.window.showErrorMessage(`Scan failed: ${error}`);
            statusBar.showError();
        } finally {
            // Don't reset status bar immediately - let it show the threat count
            // Only reset after a delay if no threats were found
            if (!result?.threats || result.threats.length === 0) {
                setTimeout(() => {
                    statusBar.showClean();
                }, 5000);
            }
        }
    });

    // Helper function to calculate lines of code in workspace
    const calculateLinesOfCode = async (workspacePath: string): Promise<number> => {
        try {
            const fs = require('fs');
            const path = require('path');
            
            let totalLines = 0;
            
            const countLinesInFile = (filePath: string): number => {
                try {
                    const content = fs.readFileSync(filePath, 'utf8');
                    return content.split('\n').length;
                } catch (error) {
                    return 0;
                }
            };
            
            const walkDir = (dir: string): void => {
                const files = fs.readdirSync(dir);
                for (const file of files) {
                    const filePath = path.join(dir, file);
                    const stat = fs.statSync(filePath);
                    
                    if (stat.isDirectory()) {
                        // Skip node_modules, .git, etc.
                        if (!['node_modules', '.git', '.vscode', 'dist', 'build'].includes(file)) {
                            walkDir(filePath);
                        }
                    } else {
                        // Count lines for code files
                        const ext = path.extname(file).toLowerCase();
                        if (['.js', '.ts', '.py', '.java', '.cpp', '.c', '.cs', '.php', '.rb', '.go', '.rs', '.swift', '.kt'].includes(ext)) {
                            totalLines += countLinesInFile(filePath);
                        }
                    }
                }
            };
            
            walkDir(workspacePath);
            return totalLines;
        } catch (error) {
            console.error('Error calculating lines of code:', error);
            return 0;
        }
    };

    let scanWorkspaceCommand = vscode.commands.registerCommand('threatguard.scanWorkspace', async () => {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showWarningMessage('No workspace folder found');
            return;
        }

        let result: any = null;
        try {
            statusBar.showScanning();
            vscode.window.showInformationMessage('Scanning workspace for threats...');

            // Clear any existing threats before starting new scan
            threatProvider.clearThreats();

            result = await api.scanWorkspace(workspaceFolders[0].uri.fsPath);
            
            console.log('Workspace scan result:', result);
            
            if (result.threats && result.threats.length > 0) {
                vscode.window.showWarningMessage(`Found ${result.threats.length} threats in workspace`);
                statusBar.showThreats(result.threats.length);
                
                // Update threat provider with detected threats
                threatProvider.updateThreats(result.threats);
                
                // Update webview with recent threats
                webview.updateRecentThreats(result.threats);
                
                // Update dashboard with scan data
                if (result.scan_data) {
                    console.log('Extension: Updating dashboard with scan data:', result.scan_data);
                    webview.updateDashboardWithScanData(result.scan_data);
                    dashboardProvider.updateWithScanData(result.scan_data);
                } else {
                    console.log('Extension: No scan_data in result');
                }

                // Save workspace scan data to JSON for React UI
                try {
                                    // Calculate additional metrics for workspace scan
                const enhancedScanMetrics = {
                    ...result.scan_data,
                    duration_ms: result.scan_data?.duration_ms || 0,
                    files_scanned: result.scan_data?.files_scanned || 1,
                    issues_found: result.threats.length,
                    quality_gate_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED',
                    lines_of_code: result.scan_data?.lines_of_code || await calculateLinesOfCode(workspaceFolders[0].uri.fsPath),
                    coverage: '100%', // Always 100% for workspace scans
                    logic_bomb_risk_score: result.scan_data?.logic_bomb_risk_score || 0,
                    threat_shield_status: result.threats.length > 0 ? 'BLOCKED' : 'PASSED'
                };

                console.log('🔍 Enhanced scan metrics:', enhancedScanMetrics);
                console.log('🔍 Scan data from backend:', result.scan_data);

                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: workspaceFolders[0].uri.fsPath,
                        file_name: 'workspace_scan',
                        content: '', // Workspace scan doesn't have a single file content
                        threats: result.threats,
                        scan_metrics: enhancedScanMetrics,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Workspace scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save workspace scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            } else {
                vscode.window.showInformationMessage('No threats detected in workspace');
                statusBar.showClean();
                
                // Clear threats from provider
                threatProvider.updateThreats([]);
                
                // Clear recent threats from webview
                webview.updateRecentThreats([]);

                // Save clean workspace scan data to JSON for React UI
                try {
                                    // Calculate additional metrics for clean workspace scan
                const enhancedScanMetrics = {
                    ...(result.scan_data || {}),
                    duration_ms: result.scan_data?.duration_ms || 0,
                    files_scanned: result.scan_data?.files_scanned || 1,
                    issues_found: 0,
                    quality_gate_status: 'PASSED',
                    lines_of_code: result.scan_data?.lines_of_code || await calculateLinesOfCode(workspaceFolders[0].uri.fsPath),
                    coverage: '100%', // Always 100% for workspace scans
                    logic_bomb_risk_score: 0,
                    threat_shield_status: 'PASSED'
                };

                console.log('🔍 Enhanced clean scan metrics:', enhancedScanMetrics);
                console.log('🔍 Clean scan data from backend:', result.scan_data);

                    const saveResult = await api.saveScanData({
                        scan_id: result.scan_id,
                        file_path: workspaceFolders[0].uri.fsPath,
                        file_name: 'workspace_scan',
                        content: '',
                        threats: [],
                        scan_metrics: enhancedScanMetrics,
                        timestamp: new Date().toISOString()
                    });
                    console.log('💾 Clean workspace scan data saved:', saveResult.message);
                } catch (saveError) {
                    console.error('❌ Failed to save clean workspace scan data:', saveError);
                    // Don't show error to user as this is a background operation
                }
            }

            // Refresh providers
            threatProvider.refresh();
            dashboardProvider.refresh();
            scanProvider.refresh();

        } catch (error) {
            vscode.window.showErrorMessage(`Workspace scan failed: ${error}`);
            statusBar.showError();
        } finally {
            // Don't reset status bar immediately - let it show the threat count
            // Only reset after a delay if no threats were found
            if (!result?.threats || result.threats.length === 0) {
                setTimeout(() => {
                    statusBar.showClean();
                }, 5000);
            }
        }
    });

    let showDashboardCommand = vscode.commands.registerCommand('threatguard.showDashboard', () => {
        webview.showDashboard();
    });

    let remediateFileCommand = vscode.commands.registerCommand('threatguard.remediateFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showWarningMessage('No active editor found');
            return;
        }

        const document = editor.document;
        let content = document.getText();
        const filePath = document.fileName;

        // Normalize line endings to prevent spaces from being added
        content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                statusBar.showError();
                return;
            }

            statusBar.showRemediating();
            vscode.window.showInformationMessage('Remediating file...');

            console.log(`Remediating file: ${filePath}`);
            console.log(`Content length: ${content.length}`);

            const result = await api.remediateFile(filePath, content);
            
            console.log('Remediation result:', result);
            
            // Check if we have remediated content or if the result indicates success
            if (result.remediated_content && result.remediated_content.trim() !== '') {
                // Create a new document with the remediated content
                const newDocument = await vscode.workspace.openTextDocument({
                    content: result.remediated_content,
                    language: document.languageId
                });
                
                await vscode.window.showTextDocument(newDocument);
                vscode.window.showInformationMessage('File remediated successfully');
                statusBar.showClean();
            } else if (result.changes_made && result.changes_made.length > 0) {
                // If there were changes made but no new content, show the changes
                vscode.window.showInformationMessage(`Remediation completed. Changes made: ${result.changes_made.join(', ')}`);
                statusBar.showClean();
            } else {
                vscode.window.showInformationMessage('No remediation needed - file is already secure');
                statusBar.showClean();
            }

        } catch (error) {
            console.error('Remediation error:', error);
            vscode.window.showErrorMessage(`Remediation failed: ${error}`);
            statusBar.showError();
        } finally {
            // Always ensure status bar is reset after remediation attempt
            setTimeout(() => {
                statusBar.showClean();
            }, 2000);
        }
    });

    // Generate Copilot remediation prompt command
    let generateCopilotPromptCommand = vscode.commands.registerCommand('threatguard.generateCopilotPrompt', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active editor found. Please open a file first.');
            return;
        }

        const document = editor.document;
        const filePath = document.fileName;
        const content = document.getText();

        try {
            // First check if backend is running
            try {
                await api.checkHealth();
            } catch (healthError) {
                vscode.window.showErrorMessage('Backend server is not running. Please start the ThreatGuard backend server first.');
                return;
            }

            vscode.window.showInformationMessage('Scanning file to generate Copilot prompt...');

            const result = await api.scanFile(filePath, content);
            
            if (result.threats && result.threats.length > 0) {
                // Generate detailed prompt for Copilot
                const prompt = generateCopilotPrompt(document.fileName, result.threats, content);
                
                // Open Copilot chat and paste the prompt
                await openCopilotChatWithPrompt(prompt);
                
                vscode.window.showInformationMessage(`Generated Copilot prompt for ${result.threats.length} threats. Check the Copilot chat!`);
            } else {
                vscode.window.showInformationMessage('No threats detected in file. No remediation needed.');
            }

        } catch (error) {
            console.error('Copilot prompt generation error:', error);
            vscode.window.showErrorMessage(`Failed to generate Copilot prompt: ${error}`);
        }
    });

    let showThreatsCommand = vscode.commands.registerCommand('threatguard.showThreats', () => {
        webview.showThreats();
    });

    let showThreatDetailsCommand = vscode.commands.registerCommand('threatguard.showThreatDetails', async (threat: any) => {
        // Show threat details in webview
        webview.showThreatDetails(threat);
        
        // Also try to open the file at the specific line if possible
        if (threat.file_path && threat.line_number) {
            try {
                const fileUri = vscode.Uri.file(threat.file_path);
                const document = await vscode.workspace.openTextDocument(fileUri);
                const editor = await vscode.window.showTextDocument(document);
                
                // Go to the specific line
                const lineNumber = typeof threat.line_number === 'string' ? parseInt(threat.line_number, 10) : threat.line_number;
                const position = new vscode.Position(lineNumber - 1, 0); // VSCode uses 0-based line numbers
                editor.selection = new vscode.Selection(position, position);
                editor.revealRange(new vscode.Range(position, position), vscode.TextEditorRevealType.InCenter);
                
                console.log(`Opened file ${threat.file_path} at line ${lineNumber}`);
            } catch (error) {
                console.error(`Failed to open file ${threat.file_path}:`, error);
                // Don't show error to user as this is just a convenience feature
            }
        }
    });

    let openFileAtLineCommand = vscode.commands.registerCommand('threatguard.openFileAtLine', async (threat: any) => {
        if (threat.file_path && threat.line_number) {
            try {
                const fileUri = vscode.Uri.file(threat.file_path);
                const document = await vscode.workspace.openTextDocument(fileUri);
                const editor = await vscode.window.showTextDocument(document);
                
                // Go to the specific line
                const lineNumber = typeof threat.line_number === 'string' ? parseInt(threat.line_number, 10) : threat.line_number;
                const position = new vscode.Position(lineNumber - 1, 0); // VSCode uses 0-based line numbers
                editor.selection = new vscode.Selection(position, position);
                editor.revealRange(new vscode.Range(position, position), vscode.TextEditorRevealType.InCenter);
                
                console.log(`Opened file ${threat.file_path} at line ${lineNumber}`);
            } catch (error) {
                console.error(`Failed to open file ${threat.file_path}:`, error);
                vscode.window.showErrorMessage(`Failed to open file: ${error}`);
            }
        } else {
            vscode.window.showWarningMessage('No file path or line number available for this threat');
        }
    });

    let refreshThreatsCommand = vscode.commands.registerCommand('threatguard.refreshThreats', async () => {
        try {
            console.log('Manual refresh of threats view requested');
            
            // Fetch latest threats from API
            const threats = await api.getThreats();
            console.log(`Fetched ${threats.length} threats from API`);
            
            // Update threat provider
            threatProvider.updateThreats(threats);
            
            // Force refresh the view
            threatProvider.refresh();
            
            vscode.window.showInformationMessage(`Refreshed threats view with ${threats.length} threats`);
        } catch (error) {
            console.error('Failed to refresh threats:', error);
            vscode.window.showErrorMessage(`Failed to refresh threats: ${error}`);
        }
    });

    let showAllThreatsCommand = vscode.commands.registerCommand('threatguard.showAllThreats', async () => {
        try {
            console.log('Show all threats requested');
            
            // Fetch all threats from API
            const threats = await api.getThreats();
            console.log(`Fetched ${threats.length} threats from API`);
            
            // Update threat provider with all threats
            threatProvider.updateThreats(threats);
            
            // Force refresh the view
            threatProvider.refresh();
            
            vscode.window.showInformationMessage(`Showing all ${threats.length} threats from database`);
        } catch (error) {
            console.error('Failed to show all threats:', error);
            vscode.window.showErrorMessage(`Failed to show all threats: ${error}`);
        }
    });

    let configureCommand = vscode.commands.registerCommand('threatguard.configure', () => {
        vscode.commands.executeCommand('workbench.action.openSettings', 'threatguard');
    });

    // Auto-scan on save if enabled
    let saveListener = vscode.workspace.onDidSaveTextDocument(async (document) => {
        const config = vscode.workspace.getConfiguration('threatguard');
        if (config.get('autoScan')) {
            let content = document.getText();
            const filePath = document.fileName;

            // Normalize line endings to prevent spaces from being added
            content = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

            try {
                const result = await api.scanFile(filePath, content);
                if (result.threats && result.threats.length > 0) {
                    diagnostics.setThreats(document.uri, result.threats);
                    if (config.get('enableNotifications')) {
                        vscode.window.showWarningMessage(`Found ${result.threats.length} threats in ${document.fileName}`);
                    }
                    threatProvider.refresh();
                }
            } catch (error) {
                console.error('Auto-scan failed:', error);
            }
        }
    });

    // Register all commands
    context.subscriptions.push(
        scanFileCommand,
        scanWorkspaceCommand,
        refreshScanHistoryCommand,
        showDashboardCommand,
        remediateFileCommand,
        showThreatsCommand,
        showThreatDetailsCommand,
        openFileAtLineCommand,
        refreshThreatsCommand,
        showAllThreatsCommand,
        generateCopilotPromptCommand,
        configureCommand,
        saveListener
    );

    // Initial health check
    api.checkHealth().then(health => {
        if (health.status === 'healthy') {
            statusBar.showConnected();
        } else {
            statusBar.showDisconnected();
        }
    }).catch(() => {
        statusBar.showDisconnected();
    });
}

// Helper function to generate Copilot prompt
function generateCopilotPrompt(fileName: string, threats: any[], originalContent: string): string {
    const threatDetails = threats.map((threat, index) => {
        return `${index + 1}. **${threat.type}** (${threat.severity}): ${threat.description}
   - **Location**: Line ${threat.line}, Column ${threat.column}
   - **Code**: \`\`\`${threat.code_snippet}\`\`\`
   - **Effort**: ${threat.effort_minutes} minutes
   - **Remediation**: ${threat.remediation || 'Manual review required'}`;
    }).join('\n\n');

    const prompt = `# Security Threat Remediation Request

I have detected ${threats.length} security threats in the file \`${fileName}\`. Please help me remediate these issues by providing secure code alternatives.

## Detected Threats:
${threatDetails}

## Original File Content:
\`\`\`${getFileExtension(fileName)}
${originalContent}
\`\`\`

## Requirements:
1. **Maintain functionality** while fixing security issues
2. **Provide secure alternatives** for each threat
3. **Explain the security improvements** made
4. **Ensure the code follows best practices**
5. **Keep the same logic flow** where possible

Please provide the remediated code with explanations for each change made.`;
    
    return prompt;
}

// Helper function to get file extension for syntax highlighting
function getFileExtension(fileName: string): string {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const languageMap: { [key: string]: string } = {
        'py': 'python',
        'js': 'javascript',
        'ts': 'typescript',
        'java': 'java',
        'cpp': 'cpp',
        'c': 'c',
        'cs': 'csharp',
        'php': 'php',
        'rb': 'ruby',
        'go': 'go',
        'rs': 'rust',
        'swift': 'swift',
        'kt': 'kotlin',
        'scala': 'scala',
        'html': 'html',
        'css': 'css',
        'json': 'json',
        'xml': 'xml',
        'yaml': 'yaml',
        'yml': 'yaml',
        'md': 'markdown',
        'txt': 'text'
    };
    return languageMap[ext || ''] || 'text';
}

// Helper function to open Copilot chat with prompt
async function openCopilotChatWithPrompt(prompt: string): Promise<void> {
    try {
        // Open Copilot chat
        await vscode.commands.executeCommand('github.copilot.chat.focus');
        
        // Wait a moment for the chat to open
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Try to paste the prompt into the chat
        // Note: This might not work in all VS Code versions due to security restrictions
        // The user will need to manually paste the prompt
        vscode.window.showInformationMessage('Copilot chat opened! Please paste the generated prompt manually.');
        
        // Copy prompt to clipboard as fallback
        await vscode.env.clipboard.writeText(prompt);
        vscode.window.showInformationMessage('Prompt copied to clipboard! Paste it in the Copilot chat.');
        
    } catch (error) {
        console.error('Failed to open Copilot chat:', error);
        // Fallback: just copy to clipboard
        await vscode.env.clipboard.writeText(prompt);
        vscode.window.showInformationMessage('Prompt copied to clipboard! Please open Copilot chat manually and paste it.');
    }
}

export function deactivate() {
    console.log('ThreatGuard Pro extension is now deactivated!');
}

