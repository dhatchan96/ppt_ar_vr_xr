import * as vscode from 'vscode';

export class Remediation360StatusBar {
    private statusBarItem: vscode.StatusBarItem;
    private threatCount: number = 0;

    constructor() {
        this.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
        this.statusBarItem.name = 'Remediation360 Status';
        this.statusBarItem.show();
        this.showDisconnected();
    }

    showConnected(): void {
        this.statusBarItem.text = '$(shield) Remediation360 Connected';
        this.statusBarItem.tooltip = 'Remediation360 is connected and ready';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.prominentBackground');
        this.statusBarItem.command = 'remediation360.showDashboard';
    }

    showDisconnected(): void {
        this.statusBarItem.text = '$(shield) Remediation360 Disconnected';
        this.statusBarItem.tooltip = 'Remediation360 is not connected';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'remediation360.configure';
    }

    showScanning(): void {
        this.statusBarItem.text = '$(sync~spin) Remediation360 Scanning...';
        this.statusBarItem.tooltip = 'Remediation360 is scanning for threats';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.command = undefined;
    }

    showRemediating(): void {
        this.statusBarItem.text = '$(sync~spin) Remediation360 Remediating...';
        this.statusBarItem.tooltip = 'Remediation360 is remediating threats';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.command = undefined;
    }

    showThreats(count: number): void {
        this.threatCount = count;
        this.statusBarItem.text = `$(shield) ${count} Threats`;
        this.statusBarItem.tooltip = `Remediation360 detected ${count} threats`;
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'remediation360.showThreats';
    }

    showClean(): void {
        this.threatCount = 0;
        this.statusBarItem.text = '$(shield) Clean';
        this.statusBarItem.tooltip = 'No threats detected';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.prominentBackground');
        this.statusBarItem.command = 'remediation360.showDashboard';
    }

    showError(): void {
        this.statusBarItem.text = '$(shield) Remediation360 Error';
        this.statusBarItem.tooltip = 'Remediation360 encountered an error';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'remediation360.configure';
    }

    updateThreatCount(count: number): void {
        if (count > 0) {
            this.showThreats(count);
        } else {
            this.showClean();
        }
    }

    getThreatCount(): number {
        return this.threatCount;
    }

    dispose(): void {
        this.statusBarItem.dispose();
    }
}

