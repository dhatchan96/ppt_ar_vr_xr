import * as vscode from 'vscode';

export class ThreatGuardStatusBar {
    private statusBarItem: vscode.StatusBarItem;
    private threatCount: number = 0;

    constructor() {
        this.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
        this.statusBarItem.name = 'ThreatGuard Status';
        this.statusBarItem.show();
        this.showDisconnected();
    }

    showConnected(): void {
        this.statusBarItem.text = '$(shield) ThreatGuard Connected';
        this.statusBarItem.tooltip = 'ThreatGuard Pro is connected and ready';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.prominentBackground');
        this.statusBarItem.command = 'threatguard.showDashboard';
    }

    showDisconnected(): void {
        this.statusBarItem.text = '$(shield) ThreatGuard Disconnected';
        this.statusBarItem.tooltip = 'ThreatGuard Pro is not connected';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'threatguard.configure';
    }

    showScanning(): void {
        this.statusBarItem.text = '$(sync~spin) ThreatGuard Scanning...';
        this.statusBarItem.tooltip = 'ThreatGuard Pro is scanning for threats';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.command = undefined;
    }

    showRemediating(): void {
        this.statusBarItem.text = '$(sync~spin) ThreatGuard Remediating...';
        this.statusBarItem.tooltip = 'ThreatGuard Pro is remediating threats';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        this.statusBarItem.command = undefined;
    }

    showThreats(count: number): void {
        this.threatCount = count;
        this.statusBarItem.text = `$(shield) ${count} Threats`;
        this.statusBarItem.tooltip = `ThreatGuard Pro detected ${count} threats`;
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'threatguard.showThreats';
    }

    showClean(): void {
        this.threatCount = 0;
        this.statusBarItem.text = '$(shield) Clean';
        this.statusBarItem.tooltip = 'No threats detected';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.prominentBackground');
        this.statusBarItem.command = 'threatguard.showDashboard';
    }

    showError(): void {
        this.statusBarItem.text = '$(shield) ThreatGuard Error';
        this.statusBarItem.tooltip = 'ThreatGuard Pro encountered an error';
        this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        this.statusBarItem.command = 'threatguard.configure';
    }

    updateThreatCount(count: number): void {
        if (count > 0) {
            this.showThreats(count);
        } else {
            this.showClean();
        }
    }

    getThreatCount(): number {
        return this.threatCount;
    }

    dispose(): void {
        this.statusBarItem.dispose();
    }
}

