import axios, { AxiosInstance, AxiosResponse } from 'axios';
import * as vscode from 'vscode';

export interface Threat {
    id: string;
    rule_id: string;
    file_path: string;
    line_number: number;
    column: number;
    message: string;
    severity: string;
    type: string;
    status: string;
    code_snippet: string;
    suggested_fix: string;
    threat_level: string;
    trigger_analysis: string;
    payload_analysis: string;
    ait_tag: string;
    spk_tag: string;
    repo_name: string;
    scan_id: string;
    debt_category: string;
    business_impact: string;
    compliance_impact: string;
    security_domain: string;
    file_name: string;
    component_name: string;
    team_owner: string;
    priority_score: number;
    last_modified: string;
    exploitability: string;
    attack_vector: string;
    data_classification: string;
}

export interface ScanResult {
    scan_id: string;
    project_id: string;
    timestamp: string;
    duration_ms: number;
    files_scanned: number;
    lines_of_code?: number;
    issues?: Threat[];
    coverage?: number | string;
    duplications?: number;
    maintainability_rating?: string;
    reliability_rating?: string;
    security_rating?: string;
    threat_shield_status?: string;
    logic_bomb_risk_score?: number;
    threat_intelligence?: any;
    ait_tag?: string;
    spk_tag?: string;
    repo_name?: string;
    // VSCode extension specific fields
    source?: string;
    issues_found?: number;
    total_threats?: number;
    quality_gate_status?: string;
    file_name?: string;
    file_path?: string;
}

export interface HealthStatus {
    status: string;
    timestamp: string;
    version: string;
    uptime: number;
    api_endpoints: string[];
}

export interface RemediationResult {
    remediated_content: string;
    original_file: string;
    scan_id: string;
    timestamp: string;
    changes_made: string[];
}

export class ThreatGuardAPI {
    private client: AxiosInstance;
    private config: vscode.WorkspaceConfiguration;

    constructor() {
        this.config = vscode.workspace.getConfiguration('threatguard');
        const apiUrl = this.config.get('apiUrl', 'http://localhost:5000');
        
        this.client = axios.create({
            baseURL: apiUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
                'X-ThreatGuard-Client': 'ThreatGuard-VSCode-Extension',
                'X-Client-Version': '1.0.0'
            }
        });

        // Add request interceptor
        this.client.interceptors.request.use(
            (config) => {
                console.log(`🔍 ThreatGuard API Request: ${config.method?.toUpperCase()} ${config.url}`);
                return config;
            },
            (error) => {
                console.error('❌ ThreatGuard API Request Error:', error);
                return Promise.reject(error);
            }
        );

        // Add response interceptor
        this.client.interceptors.response.use(
            (response) => {
                console.log(`✅ ThreatGuard API Response: ${response.status}`);
                return response;
            },
            (error) => {
                console.error('❌ ThreatGuard API Response Error:', error.response?.data || error.message);
                return Promise.reject(error);
            }
        );
    }

    async checkHealth(): Promise<HealthStatus> {
        try {
            const response: AxiosResponse<HealthStatus> = await this.client.get('/api/health');
            return response.data;
        } catch (error) {
            throw new Error(`Health check failed: ${error}`);
        }
    }

    async post<T = any>(url: string, data?: any): Promise<AxiosResponse<T>> {
        try {
            return await this.client.post(url, data);
        } catch (error) {
            throw new Error(`POST request failed: ${error}`);
        }
    }

    async scanFile(filePath: string, content: string): Promise<{ threats: Threat[]; scan_id: string }> {
        try {
            // Normalize line endings to prevent spaces from being added
            const normalizedContent = this.normalizeLineEndings(content);
            
            console.log(`Sending scan request for: ${filePath}`);
            console.log(`Content length: ${normalizedContent.length}`);
            
            const requestData = {
                file_contents: [{
                    id: `file-${Date.now()}`,
                    name: filePath.split('/').pop() || filePath.split('\\').pop() || 'unknown',
                    content: normalizedContent,
                    path: filePath,
                    type: this.getFileType(filePath)
                }],
                scan_type: 'quick',
                project_id: `vscode-scan-${Date.now()}`,
                project_name: 'VS Code File Scan',
                source: 'vscode-extension' // Add source identifier for filtering
            };
            
            console.log('Request data:', JSON.stringify(requestData, null, 2));
            
            const response = await this.client.post('/api/scan/files', requestData);
            
            console.log('Response status:', response.status);
            console.log('Response data:', response.data);

            // Extract threats from file_results
            const threats: Threat[] = [];
            if (response.data.file_results && Array.isArray(response.data.file_results)) {
                console.log(`Found ${response.data.file_results.length} file results`);
                for (const fileResult of response.data.file_results) {
                    console.log(`File: ${fileResult.file_name}, Issues: ${fileResult.issues_count}`);
                    if (fileResult.issues && Array.isArray(fileResult.issues)) {
                        console.log(`Adding ${fileResult.issues.length} threats from ${fileResult.file_name}`);
                        threats.push(...fileResult.issues);
                    }
                }
            }

            console.log(`Total threats extracted: ${threats.length}`);
            if (threats.length > 0) {
                console.log('First threat:', threats[0]);
            }

            return {
                threats: threats,
                scan_id: response.data.scan_id || `scan-${Date.now()}`
            };
        } catch (error: any) {
            console.error('API Error details:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            throw new Error(`File scan failed: ${error.message || error}`);
        }
    }

    private getFileType(filePath: string): string {
        const extension = filePath.split('.').pop()?.toLowerCase();
        switch (extension) {
            case 'py': return 'python';
            case 'js': return 'javascript';
            case 'ts': return 'typescript';
            case 'java': return 'java';
            case 'cs': return 'csharp';
            case 'cpp': case 'cc': case 'cxx': return 'cpp';
            case 'rs': return 'rust';
            case 'go': return 'go';
            case 'php': return 'php';
            case 'rb': return 'ruby';
            case 'html': case 'htm': return 'html';
            case 'json': return 'json';
            default: return 'text';
        }
    }

    private normalizeLineEndings(content: string): string {
        // Convert Windows line endings (\r\n) and old Mac line endings (\r) to Unix line endings (\n)
        return content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    }

    async scanWorkspace(workspacePath: string): Promise<{ threats: Threat[]; scan_id: string; scan_data?: any }> {
        try {
            console.log(`🔍 ThreatGuard API Request: POST /api/scan`);
            console.log(`Workspace path: ${workspacePath}`);

            const response = await this.client.post('/api/scan', {
                project_path: workspacePath,
                project_id: `vscode-workspace-${Date.now()}`,
                scan_type: 'comprehensive',
                source: 'vscode-extension' // Add source identifier for filtering
            }, {
                timeout: 120000 // Increase timeout to 2 minutes for workspace scans
            });

            console.log(`✅ ThreatGuard API Response: ${response.status}`);
            console.log('Workspace scan response:', response.data);

            // Extract threats directly from the scan response
            let threats: Threat[] = [];
            
            console.log('Extracting threats from scan response...');
            console.log('Scan response keys:', Object.keys(response.data));
            
            // Try to extract threats from scan response first
            if (response.data.issues && Array.isArray(response.data.issues)) {
                threats = response.data.issues;
                console.log(`✅ Using ${threats.length} threats from scan response issues`);
            } else if (response.data.file_results && Array.isArray(response.data.file_results)) {
                // Extract threats from file_results
                console.log(`Found ${response.data.file_results.length} file results`);
                for (const fileResult of response.data.file_results) {
                    if (fileResult.issues && Array.isArray(fileResult.issues)) {
                        threats.push(...fileResult.issues);
                    }
                }
                console.log(`✅ Extracted ${threats.length} threats from file_results`);
            } else if (response.data.threats && Array.isArray(response.data.threats)) {
                threats = response.data.threats;
                console.log(`✅ Using ${threats.length} threats from scan response threats`);
            } else {
                console.warn('⚠️ No threats found in scan response, creating empty array');
                threats = [];
            }

            // Ensure all threats have proper file information
            threats = threats.map(threat => {
                // Ensure file_name is set if not present
                if (!threat.file_name && threat.file_path) {
                    threat.file_name = threat.file_path.split(/[\\/]/).pop() || 'unknown';
                }
                
                // Ensure line_number is a number
                if (typeof threat.line_number === 'string') {
                    threat.line_number = parseInt(threat.line_number, 10) || 1;
                }
                
                // Ensure column is a number
                if (typeof threat.column === 'string') {
                    threat.column = parseInt(threat.column, 10) || 1;
                }
                
                return threat;
            });

            console.log(`Total threats for workspace scan: ${threats.length}`);
            
            // Debug: Log first few threats to verify structure
            if (threats.length > 0) {
                console.log('Sample threats:', threats.slice(0, 3).map(t => ({
                    id: t.id,
                    file_name: t.file_name,
                    file_path: t.file_path,
                    line_number: t.line_number,
                    message: t.message?.substring(0, 50)
                })));
            }

            return {
                threats: threats,
                scan_id: response.data.scan_id || `workspace-scan-${Date.now()}`,
                scan_data: response.data // Include full scan data for dashboard
            };
        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            if (error.code === 'ETIMEDOUT') {
                throw new Error('Workspace scan timed out. The scan is taking too long. Try scanning individual files instead.');
            }
            throw new Error(`Workspace scan failed: ${error.message || error}`);
        }
    }

    async remediateFile(filePath: string, content: string): Promise<RemediationResult> {
        try {
            // Normalize line endings to prevent spaces from being added
            const normalizedContent = this.normalizeLineEndings(content);
            
            console.log(`🔍 ThreatGuard API Request: POST /api/vscode-agent/remediate`);
            console.log(`File path: ${filePath}`);
            console.log(`Content length: ${normalizedContent.length}`);

            const response = await this.client.post('/api/vscode-agent/remediate', {
                file_path: filePath,
                content: normalizedContent,
                params: {
                    scan_id: `vscode-remediate-${Date.now()}`,
                    severity: 'MEDIUM',
                    type: 'GENERAL'
                }
            });

            console.log(`✅ ThreatGuard API Response: ${response.status}`);
            console.log('Remediation response:', response.data);
            
            // If remediation was successful, get the remediated content
            if (response.data && response.data.success && response.data.remediated_file) {
                try {
                    // Get the remediated content from the backend
                    const contentResponse = await this.client.get(`/api/vscode-agent/remediate-content`, {
                        params: {
                            remediated_file: response.data.remediated_file
                        }
                    });
                    
                    console.log('✅ Got remediated content from backend');
                    return {
                        ...response.data,
                        remediated_content: contentResponse.data.content || contentResponse.data
                    };
                } catch (contentError) {
                    console.warn('⚠️ Could not fetch remediated content, using original:', contentError);
                    return {
                        ...response.data,
                        remediated_content: content // Fallback to original content
                    };
                }
            }
            
            // Handle different response formats
            if (response.data && typeof response.data === 'object') {
                return response.data;
            } else {
                // If response is not in expected format, create a default result
                return {
                    remediated_content: response.data || content,
                    original_file: filePath,
                    scan_id: `vscode-remediate-${Date.now()}`,
                    timestamp: new Date().toISOString(),
                    changes_made: ['Content processed']
                };
            }
        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            if (error.code === 'ETIMEDOUT') {
                throw new Error('Request timed out. The backend server is not responding. Please check if the server is running.');
            }
            throw new Error(`Remediation failed: ${error.message || error}`);
        }
    }

    async saveScanData(scanData: {
        scan_id?: string;
        file_path: string;
        file_name: string;
        content: string;
        threats: Threat[];
        scan_metrics?: any;
        timestamp?: string;
        username?: string;
    }): Promise<{ success: boolean; scan_id: string; message: string }> {
        try {
            console.log('💾 ThreatGuard API Request: POST /api/vscode-agent/save-scan-data');
            
            const response = await this.client.post('/api/vscode-agent/save-scan-data', scanData, {
                timeout: 30000,
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            console.log('✅ ThreatGuard API Response:', response.status);
            console.log('Response data:', response.data);

            return {
                success: response.data.success,
                scan_id: response.data.scan_id,
                message: response.data.message
            };

        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Backend server is not running. Please start the ThreatGuard backend server.');
            } else if (error.code === 'ETIMEDOUT') {
                throw new Error('Save scan data request timed out. Please try again.');
            }
            throw new Error(`Failed to save scan data: ${error.response?.data?.error || error.message}`);
        }
    }

    async getThreats(): Promise<Threat[]> {
        try {
            const response = await this.client.get('/api/threats');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch threats: ${error}`);
        }
    }

    async getThreatById(threatId: string): Promise<Threat> {
        try {
            const response = await this.client.get(`/api/threats/${threatId}`);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch threat: ${error}`);
        }
    }

    async updateThreatStatus(threatId: string, status: string): Promise<void> {
        try {
            await this.client.put(`/api/threats/${threatId}/status`, { status });
        } catch (error) {
            throw new Error(`Failed to update threat status: ${error}`);
        }
    }

    async neutralizeThreat(threatId: string): Promise<void> {
        try {
            await this.client.post(`/api/threats/${threatId}/neutralize`);
        } catch (error) {
            throw new Error(`Failed to neutralize threat: ${error}`);
        }
    }

    async getMetrics(): Promise<any> {
        try {
            const response = await this.client.get('/api/command-center/metrics');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch metrics: ${error}`);
        }
    }

    async getScanHistory(): Promise<{ scan_history: ScanResult[]; total_scans: number; threats_neutralized: number; avg_risk_score: number; shield_effectiveness: number }> {
        try {
            const response = await this.client.get('/api/scan-history');
            return response.data || { scan_history: [], total_scans: 0, threats_neutralized: 0, avg_risk_score: 0, shield_effectiveness: 0 };
        } catch (error) {
            throw new Error(`Failed to fetch scan history: ${error}`);
        }
    }

    async getThreatIntelligence(): Promise<any> {
        try {
            const response = await this.client.get('/api/threat-intelligence');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch threat intelligence: ${error}`);
        }
    }

    async getRules(): Promise<any[]> {
        try {
            const response = await this.client.get('/api/rules');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch rules: ${error}`);
        }
    }

    async createRule(rule: any): Promise<any> {
        try {
            const response = await this.client.post('/api/rules', rule);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to create rule: ${error}`);
        }
    }

    async updateRule(ruleId: string, updates: any): Promise<any> {
        try {
            const response = await this.client.put(`/api/rules/${ruleId}`, updates);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to update rule: ${error}`);
        }
    }

    async deleteRule(ruleId: string): Promise<void> {
        try {
            await this.client.delete(`/api/rules/${ruleId}`);
        } catch (error) {
            throw new Error(`Failed to delete rule: ${error}`);
        }
    }

    async getThreatShields(): Promise<any[]> {
        try {
            const response = await this.client.get('/api/threat-shields');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch threat shields: ${error}`);
        }
    }

    async createThreatShield(shield: any): Promise<any> {
        try {
            const response = await this.client.post('/api/threat-shields', shield);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to create threat shield: ${error}`);
        }
    }

    async updateThreatShield(shieldId: string, updates: any): Promise<any> {
        try {
            const response = await this.client.put(`/api/threat-shields/${shieldId}`, updates);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to update threat shield: ${error}`);
        }
    }

    async deleteThreatShield(shieldId: string): Promise<void> {
        try {
            await this.client.delete(`/api/threat-shields/${shieldId}`);
        } catch (error) {
            throw new Error(`Failed to delete threat shield: ${error}`);
        }
    }

    async exportData(): Promise<any> {
        try {
            const response = await this.client.get('/api/export');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to export data: ${error}`);
        }
    }

    async scanGitHubRepository(repoUrl: string, token?: string): Promise<any> {
        try {
            const response = await this.client.post('/api/scan/github', {
                repository_url: repoUrl,
                github_token: token
            });
            return response.data;
        } catch (error) {
            throw new Error(`GitHub scan failed: ${error}`);
        }
    }

    // Vulnerability Management APIs - Updated to match web application
    async getVulnerabilities(): Promise<any[]> {
        try {
            console.log('🔍 ThreatGuard API Request: Loading vulnerabilities like web application...');
            
            // Load application vulnerabilities (same as web app)
            const applicationVulns = await this.getApplicationVulnerabilities();
            console.log(`✅ Loaded ${applicationVulns.length} application vulnerabilities`);
            
            // Load infrastructure vulnerabilities (same as web app)
            const infrastructureVulns = await this.getInfrastructureVulnerabilities();
            console.log(`✅ Loaded ${infrastructureVulns.length} infrastructure vulnerabilities`);
            
            // Combine both types
            const allVulnerabilities = [...applicationVulns, ...infrastructureVulns];
            console.log(`✅ Total vulnerabilities loaded: ${allVulnerabilities.length}`);
            
            return allVulnerabilities;
        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Backend server is not running. Please start the ThreatGuard backend server.');
            }
            throw new Error(`Failed to fetch vulnerabilities: ${error.response?.data?.error || error.message}`);
        }
    }

    async getApplicationVulnerabilities(): Promise<any[]> {
        try {
            console.log('🔍 Loading application vulnerabilities...');
            
            // Fetch from enhanced API (same as web app)
            const params = new URLSearchParams({
                severity: 'ALL',
                priority: 'ALL',
                wave_assignment: 'ALL',
                type: 'application',
                page: '1',
                per_page: '1000'
            });
            
            const response = await this.client.get(`/api/v1/vulnerabilities/enhanced?${params}`);
            let applicationVulnerabilities = [];
            
            if (response.data && response.data.success && response.data.vulnerabilities) {
                applicationVulnerabilities = response.data.vulnerabilities;
                console.log(`✅ Enhanced API: ${applicationVulnerabilities.length} application vulnerabilities`);
            }
            
            // Also fetch from Excel export API (same as web app)
            try {
                const excelResponse = await this.client.get('/api/v1/vulnerabilities/excel-export?type=application');
                let excelVulnerabilities = [];
                
                if (excelResponse.data && excelResponse.data.success && excelResponse.data.vulnerabilities) {
                    excelVulnerabilities = excelResponse.data.vulnerabilities;
                    console.log(`✅ Excel API: ${excelVulnerabilities.length} application vulnerabilities`);
                }
                
                // Merge and avoid duplicates (same logic as web app)
                const existingIds = new Set(applicationVulnerabilities.map((v: any) => v.id));
                const newExcelVulns = excelVulnerabilities.filter((v: any) => !existingIds.has(v.id));
                const mergedVulnerabilities = [...applicationVulnerabilities, ...newExcelVulns];
                
                console.log(`✅ Merged: ${applicationVulnerabilities.length} + ${newExcelVulns.length} = ${mergedVulnerabilities.length} application vulnerabilities`);
                return mergedVulnerabilities;
            } catch (excelError) {
                console.warn('Excel application vulnerabilities API not available, using enhanced API only:', excelError);
                return applicationVulnerabilities;
            }
        } catch (error: any) {
            console.error('❌ Error loading application vulnerabilities:', error);
            return [];
        }
    }

    async getInfrastructureVulnerabilities(): Promise<any[]> {
        try {
            console.log('🔍 Loading infrastructure vulnerabilities...');
            
            // Fetch from enhanced API (same as web app)
            const params = new URLSearchParams({
                severity: 'ALL',
                priority: 'ALL',
                wave_assignment: 'ALL',
                type: 'infrastructure',
                page: '1',
                per_page: '1000'
            });
            
            const response = await this.client.get(`/api/v1/vulnerabilities/enhanced?${params}`);
            let infrastructureVulnerabilities = [];
            
            if (response.data && response.data.success && response.data.vulnerabilities) {
                infrastructureVulnerabilities = response.data.vulnerabilities;
                console.log(`✅ Enhanced API: ${infrastructureVulnerabilities.length} infrastructure vulnerabilities`);
            }
            
            // Also fetch from Excel export API (same as web app)
            try {
                const excelResponse = await this.client.get('/api/v1/vulnerabilities/excel-export?type=infrastructure');
                let excelVulnerabilities = [];
                
                if (excelResponse.data && excelResponse.data.success && excelResponse.data.vulnerabilities) {
                    excelVulnerabilities = excelResponse.data.vulnerabilities;
                    console.log(`✅ Excel API: ${excelVulnerabilities.length} infrastructure vulnerabilities`);
                }
                
                // Merge and avoid duplicates (same logic as web app)
                const existingIds = new Set(infrastructureVulnerabilities.map((v: any) => v.id));
                const newExcelVulns = excelVulnerabilities.filter((v: any) => !existingIds.has(v.id));
                const mergedVulnerabilities = [...infrastructureVulnerabilities, ...newExcelVulns];
                
                console.log(`✅ Merged: ${infrastructureVulnerabilities.length} + ${newExcelVulns.length} = ${mergedVulnerabilities.length} infrastructure vulnerabilities`);
                return mergedVulnerabilities;
            } catch (excelError) {
                console.warn('Excel infrastructure vulnerabilities API not available, using enhanced API only:', excelError);
                return infrastructureVulnerabilities;
            }
        } catch (error: any) {
            console.error('❌ Error loading infrastructure vulnerabilities:', error);
            return [];
        }
    }

    async getVulnerabilityById(vulnerabilityId: string): Promise<any> {
        try {
            const response = await this.client.get(`/api/v1/vulnerabilities/${vulnerabilityId}`);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch vulnerability: ${error}`);
        }
    }

    async createVulnerabilityPrompt(vulnerabilityData: {
        vulnerability_id: string;
        vulnerability_title: string;
        spk: string;
        repository: string;
        repo_url: string;
        vulnerability_type: 'application' | 'infrastructure';
        comprehensive_prompt?: boolean;
    }): Promise<{ success: boolean; message: string; files_created: string[]; folder_path: string }> {
        try {
            console.log('🔍 ThreatGuard API Request: POST /api/v1/vulnerabilities/create-application-folder');
            
            const response = await this.client.post('/api/v1/vulnerabilities/create-application-folder', vulnerabilityData, {
                timeout: 30000,
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            console.log('✅ ThreatGuard API Response:', response.status);
            console.log('Response data:', response.data);

            return {
                success: response.data.success,
                message: response.data.message,
                files_created: response.data.files_created || [],
                folder_path: response.data.folder_path || ''
            };

        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Backend server is not running. Please start the ThreatGuard backend server.');
            } else if (error.code === 'ETIMEDOUT') {
                throw new Error('Create vulnerability prompt request timed out. Please try again.');
            }
            throw new Error(`Failed to create vulnerability prompt: ${error.response?.data?.error || error.message}`);
        }
    }

    async trackRemediationResult(remediationData: {
        vulnerability_id: string;
        prompt_generated: boolean;
        copilot_executed: boolean;
        remediation_successful: boolean;
        changes_made: string[];
        files_modified: string[];
        execution_time_ms: number;
        user_feedback?: string;
        timestamp: string;
    }): Promise<{ success: boolean; message: string; tracking_id: string }> {
        try {
            console.log('🔍 ThreatGuard API Request: POST /api/v1/vulnerabilities/track-remediation');
            
            const response = await this.client.post('/api/v1/vulnerabilities/track-remediation', remediationData, {
                timeout: 30000,
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            console.log('✅ ThreatGuard API Response:', response.status);
            console.log('Response data:', response.data);

            return {
                success: response.data.success,
                message: response.data.message,
                tracking_id: response.data.tracking_id || `track-${Date.now()}`
            };

        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Backend server is not running. Please start the ThreatGuard backend server.');
            } else if (error.code === 'ETIMEDOUT') {
                throw new Error('Track remediation result request timed out. Please try again.');
            }
            throw new Error(`Failed to track remediation result: ${error.response?.data?.error || error.message}`);
        }
    }

    async getRemediationHistory(vulnerabilityId?: string): Promise<any[]> {
        try {
            const url = vulnerabilityId 
                ? `/api/v1/vulnerabilities/${vulnerabilityId}/remediation-history`
                : '/api/v1/vulnerabilities/remediation-history';
            
            const response = await this.client.get(url);
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch remediation history: ${error}`);
        }
    }

    // Vulnerability Action APIs - Same as web application
    async generateVulnerabilityAction(vulnerability: any, spk?: string, repository?: string, repoUrl?: string): Promise<any> {
        try {
            console.log('🚀 Generating vulnerability action for:', vulnerability.id);
            
            const requestData = {
                vulnerability_id: vulnerability.id,
                gis_id: vulnerability.gis_id,
                vulnerability_title: vulnerability.title || vulnerability.description,
                spk: spk || 'Default',
                repository: repository || 'Default',
                repo_url: repoUrl || 'https://github.com/example/repo',
                ait_tag: vulnerability.ait_tag,
                severity: vulnerability.severity,
                remediation_action: vulnerability.remediation_action,
                create_unified_file: true
            };

            const response = await this.client.post('/api/v1/vulnerabilities/create-application-folder', requestData);
            return response.data;
        } catch (error: any) {
            throw new Error(`Failed to generate vulnerability action: ${error.response?.data?.error || error.message}`);
        }
    }

    async generateInfrastructurePrompt(vulnerability: any): Promise<any> {
        try {
            console.log('🚀 Generating infrastructure prompt for:', vulnerability.id);
            
            const requestData = {
                vulnerability_id: vulnerability.id,
                vulnerability_title: vulnerability.title || vulnerability.description,
                ait_tag: vulnerability.ait_tag,
                severity: vulnerability.severity,
                remediation_action: vulnerability.remediation_action
            };

            const response = await this.client.post('/api/v1/vulnerabilities/create-infrastructure-prompt', requestData);
            return response.data;
        } catch (error: any) {
            throw new Error(`Failed to generate infrastructure prompt: ${error.response?.data?.error || error.message}`);
        }
    }

    async downloadVulnerabilityFolder(vulnerabilityId: string): Promise<any> {
        try {
            console.log('📦 Downloading vulnerability folder for:', vulnerabilityId);
            const response = await this.client.get(`/api/v1/vulnerabilities/download-folder/${vulnerabilityId}`);
            return response.data;
        } catch (error: any) {
            throw new Error(`Failed to download vulnerability folder: ${error.response?.data?.error || error.message}`);
        }
    }

    async getVulnerabilityPrompt(vulnerabilityId: string): Promise<any> {
        try {
            console.log('📋 Getting vulnerability prompt for:', vulnerabilityId);
            const response = await this.client.get(`/api/v1/vulnerabilities/prompt/${vulnerabilityId}`);
            return response.data;
        } catch (error: any) {
            throw new Error(`Failed to get vulnerability prompt: ${error.response?.data?.error || error.message}`);
        }
    }

    // Knowledge Base APIs
    async getKnowledgeBaseTemplates(category?: string, search?: string): Promise<any[]> {
        try {
            console.log('📚 Fetching knowledge base templates...');
            const params: any = {};
            if (category && category !== 'all') {
                params.category = category;
            }
            if (search) {
                params.search = search;
            }
            
            const response = await this.client.get('/api/knowledge-base/templates', { params });
            return response.data?.templates || [];
        } catch (error: any) {
            console.error('Failed to fetch knowledge base templates:', error);
            throw new Error(`Failed to fetch knowledge base templates: ${error.response?.data?.error || error.message}`);
        }
    }

    async getKnowledgeBaseTemplate(templateId: string): Promise<any> {
        try {
            console.log('📚 Fetching knowledge base template:', templateId);
            const response = await this.client.get(`/api/knowledge-base/templates/${templateId}`);
            if (response.data?.success && response.data?.template) {
                const template = response.data.template;
                // Ensure tags is always an array (handle JSON string or already parsed array)
                if (template.tags) {
                    if (typeof template.tags === 'string') {
                        try {
                            template.tags = JSON.parse(template.tags);
                        } catch {
                            template.tags = [template.tags];
                        }
                    }
                    if (!Array.isArray(template.tags)) {
                        template.tags = [];
                    }
                } else {
                    template.tags = [];
                }
                return template;
            }
            return null;
        } catch (error: any) {
            console.error('Failed to fetch knowledge base template:', error);
            throw new Error(`Failed to fetch knowledge base template: ${error.response?.data?.error || error.message}`);
        }
    }

    async trackPromptUsage(templateId: string, username: string, templateTitle?: string, usageType: string = 'used', metadata?: any): Promise<{ success: boolean; message: string }> {
        try {
            console.log('📊 Tracking prompt usage:', { templateId, username, usageType });
            const response = await this.client.post('/api/knowledge-base/track-usage', {
                template_id: templateId,
                username: username,
                template_title: templateTitle,
                usage_type: usageType,
                metadata: metadata || {},
                source: 'vscode_extension'
            });
            return {
                success: response.data?.success || false,
                message: response.data?.message || 'Usage tracked'
            };
        } catch (error: any) {
            console.error('Failed to track prompt usage:', error);
            throw new Error(`Failed to track prompt usage: ${error.response?.data?.error || error.message}`);
        }
    }
}
