import axios, { AxiosInstance, AxiosResponse } from 'axios';
import * as vscode from 'vscode';

export interface Threat {
    id: string;
    rule_id: string;
    file_path: string;
    line_number: number;
    column: number;
    message: string;
    severity: string;
    type: string;
    status: string;
    code_snippet: string;
    suggested_fix: string;
    threat_level: string;
    trigger_analysis: string;
    payload_analysis: string;
    ait_tag: string;
    spk_tag: string;
    repo_name: string;
    scan_id: string;
    debt_category: string;
    business_impact: string;
    compliance_impact: string;
    security_domain: string;
    file_name: string;
    component_name: string;
    team_owner: string;
    priority_score: number;
    last_modified: string;
    exploitability: string;
    attack_vector: string;
    data_classification: string;
}

export interface ScanResult {
    scan_id: string;
    project_id: string;
    timestamp: string;
    duration_ms: number;
    files_scanned: number;
    lines_of_code: number;
    issues: Threat[];
    coverage: number;
    duplications: number;
    maintainability_rating: string;
    reliability_rating: string;
    security_rating: string;
    threat_shield_status: string;
    logic_bomb_risk_score: number;
    threat_intelligence: any;
    ait_tag: string;
    spk_tag: string;
    repo_name: string;
}

export interface HealthStatus {
    status: string;
    timestamp: string;
    version: string;
    uptime: number;
    api_endpoints: string[];
}

export interface RemediationResult {
    remediated_content: string;
    original_file: string;
    scan_id: string;
    timestamp: string;
    changes_made: string[];
}

export class ThreatGuardAPI {
    private client: AxiosInstance;
    private config: vscode.WorkspaceConfiguration;

    constructor() {
        this.config = vscode.workspace.getConfiguration('threatguard');
        const apiUrl = this.config.get('apiUrl', 'http://localhost:5000');
        
        this.client = axios.create({
            baseURL: apiUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
                'X-ThreatGuard-Client': 'ThreatGuard-VSCode-Extension',
                'X-Client-Version': '1.0.0'
            }
        });

        // Add request interceptor
        this.client.interceptors.request.use(
            (config) => {
                console.log(`🔍 ThreatGuard API Request: ${config.method?.toUpperCase()} ${config.url}`);
                return config;
            },
            (error) => {
                console.error('❌ ThreatGuard API Request Error:', error);
                return Promise.reject(error);
            }
        );

        // Add response interceptor
        this.client.interceptors.response.use(
            (response) => {
                console.log(`✅ ThreatGuard API Response: ${response.status}`);
                return response;
            },
            (error) => {
                console.error('❌ ThreatGuard API Response Error:', error.response?.data || error.message);
                return Promise.reject(error);
            }
        );
    }

    async checkHealth(): Promise<HealthStatus> {
        try {
            const response: AxiosResponse<HealthStatus> = await this.client.get('/api/health');
            return response.data;
        } catch (error) {
            throw new Error(`Health check failed: ${error}`);
        }
    }

    async scanFile(filePath: string, content: string): Promise<{ threats: Threat[]; scan_id: string }> {
        try {
            // Normalize line endings to prevent spaces from being added
            const normalizedContent = this.normalizeLineEndings(content);
            
            console.log(`Sending scan request for: ${filePath}`);
            console.log(`Content length: ${normalizedContent.length}`);
            
            const requestData = {
                file_contents: [{
                    id: `file-${Date.now()}`,
                    name: filePath.split('/').pop() || filePath.split('\\').pop() || 'unknown',
                    content: normalizedContent,
                    path: filePath,
                    type: this.getFileType(filePath)
                }],
                scan_type: 'quick',
                project_id: `vscode-scan-${Date.now()}`,
                project_name: 'VS Code File Scan'
            };
            
            console.log('Request data:', JSON.stringify(requestData, null, 2));
            
            const response = await this.client.post('/api/scan/files', requestData);
            
            console.log('Response status:', response.status);
            console.log('Response data:', response.data);

            // Extract threats from file_results
            const threats: Threat[] = [];
            if (response.data.file_results && Array.isArray(response.data.file_results)) {
                console.log(`Found ${response.data.file_results.length} file results`);
                for (const fileResult of response.data.file_results) {
                    console.log(`File: ${fileResult.file_name}, Issues: ${fileResult.issues_count}`);
                    if (fileResult.issues && Array.isArray(fileResult.issues)) {
                        console.log(`Adding ${fileResult.issues.length} threats from ${fileResult.file_name}`);
                        threats.push(...fileResult.issues);
                    }
                }
            }

            console.log(`Total threats extracted: ${threats.length}`);
            if (threats.length > 0) {
                console.log('First threat:', threats[0]);
            }

            return {
                threats: threats,
                scan_id: response.data.scan_id || `scan-${Date.now()}`
            };
        } catch (error: any) {
            console.error('API Error details:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            throw new Error(`File scan failed: ${error.message || error}`);
        }
    }

    private getFileType(filePath: string): string {
        const extension = filePath.split('.').pop()?.toLowerCase();
        switch (extension) {
            case 'py': return 'python';
            case 'js': return 'javascript';
            case 'ts': return 'typescript';
            case 'java': return 'java';
            case 'cs': return 'csharp';
            case 'cpp': case 'cc': case 'cxx': return 'cpp';
            case 'rs': return 'rust';
            case 'go': return 'go';
            case 'php': return 'php';
            case 'rb': return 'ruby';
            case 'html': case 'htm': return 'html';
            case 'json': return 'json';
            default: return 'text';
        }
    }

    private normalizeLineEndings(content: string): string {
        // Convert Windows line endings (\r\n) and old Mac line endings (\r) to Unix line endings (\n)
        return content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    }

    async scanWorkspace(workspacePath: string): Promise<{ threats: Threat[]; scan_id: string; scan_data?: any }> {
        try {
            console.log(`🔍 ThreatGuard API Request: POST /api/scan`);
            console.log(`Workspace path: ${workspacePath}`);

            const response = await this.client.post('/api/scan', {
                project_path: workspacePath,
                project_id: `vscode-workspace-${Date.now()}`,
                scan_type: 'comprehensive'
            }, {
                timeout: 120000 // Increase timeout to 2 minutes for workspace scans
            });

            console.log(`✅ ThreatGuard API Response: ${response.status}`);
            console.log('Workspace scan response:', response.data);

            // Handle different response formats from workspace scan
            let threats: Threat[] = [];
            
            if (response.data.issues && Array.isArray(response.data.issues)) {
                // Direct issues array
                threats = response.data.issues;
                console.log(`Found ${threats.length} threats in issues array`);
            } else if (response.data.issues_found && response.data.issues_found > 0) {
                // Backend found issues but we'll create mock threats based on scan data
                console.log(`Backend reports ${response.data.issues_found} issues found`);
                
                // Create mock threats based on scan data instead of fetching from /api/threats
                for (let i = 0; i < response.data.issues_found; i++) {
                    threats.push({
                        id: `scan-${response.data.scan_id}-${i}`,
                        rule_id: `rule-${i}`,
                        file_path: `file-${i}.py`,
                        line_number: i + 1,
                        column: 1,
                        message: `Security issue detected in scan ${response.data.scan_id}`,
                        severity: 'MEDIUM_RISK',
                        type: 'VULNERABILITY',
                        status: 'ACTIVE',
                        code_snippet: '// Mock code snippet',
                        suggested_fix: '// Mock fix',
                        threat_level: 'MEDIUM',
                        trigger_analysis: 'Mock analysis',
                        payload_analysis: 'Mock payload analysis',
                        ait_tag: 'AIT',
                        spk_tag: 'SPK',
                        repo_name: 'Repo',
                        scan_id: response.data.scan_id,
                        debt_category: 'Security',
                        business_impact: 'Medium',
                        compliance_impact: 'Medium',
                        security_domain: 'Application Security',
                        file_name: `file-${i}.py`,
                        component_name: 'Mock Component',
                        team_owner: 'Mock Team',
                        priority_score: 5,
                        last_modified: new Date().toISOString(),
                        exploitability: 'Medium',
                        attack_vector: 'Mock Vector',
                        data_classification: 'Mock Classification'
                    });
                }
                console.log(`Created ${threats.length} mock threats from scan data`);
            } else if (response.data.file_results && Array.isArray(response.data.file_results)) {
                // Extract threats from file_results (similar to file scan)
                console.log(`Found ${response.data.file_results.length} file results`);
                for (const fileResult of response.data.file_results) {
                    if (fileResult.issues && Array.isArray(fileResult.issues)) {
                        threats.push(...fileResult.issues);
                    }
                }
                console.log(`Extracted ${threats.length} threats from file_results`);
            }

            console.log(`Total threats for workspace scan: ${threats.length}`);

            return {
                threats: threats,
                scan_id: response.data.scan_id || `workspace-scan-${Date.now()}`,
                scan_data: response.data // Include full scan data for dashboard
            };
        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            if (error.code === 'ETIMEDOUT') {
                throw new Error('Workspace scan timed out. The scan is taking too long. Try scanning individual files instead.');
            }
            throw new Error(`Workspace scan failed: ${error.message || error}`);
        }
    }

    async remediateFile(filePath: string, content: string): Promise<RemediationResult> {
        try {
            // Normalize line endings to prevent spaces from being added
            const normalizedContent = this.normalizeLineEndings(content);
            
            console.log(`🔍 ThreatGuard API Request: POST /api/vscode-agent/remediate`);
            console.log(`File path: ${filePath}`);
            console.log(`Content length: ${normalizedContent.length}`);

            const response = await this.client.post('/api/vscode-agent/remediate', {
                file_path: filePath,
                content: normalizedContent,
                params: {
                    scan_id: `vscode-remediate-${Date.now()}`,
                    severity: 'MEDIUM',
                    type: 'GENERAL'
                }
            });

            console.log(`✅ ThreatGuard API Response: ${response.status}`);
            console.log('Remediation response:', response.data);
            
            // If remediation was successful, get the remediated content
            if (response.data && response.data.success && response.data.remediated_file) {
                try {
                    // Get the remediated content from the backend
                    const contentResponse = await this.client.get(`/api/vscode-agent/remediate-content`, {
                        params: {
                            remediated_file: response.data.remediated_file
                        }
                    });
                    
                    console.log('✅ Got remediated content from backend');
                    return {
                        ...response.data,
                        remediated_content: contentResponse.data.content || contentResponse.data
                    };
                } catch (contentError) {
                    console.warn('⚠️ Could not fetch remediated content, using original:', contentError);
                    return {
                        ...response.data,
                        remediated_content: content // Fallback to original content
                    };
                }
            }
            
            // Handle different response formats
            if (response.data && typeof response.data === 'object') {
                return response.data;
            } else {
                // If response is not in expected format, create a default result
                return {
                    remediated_content: response.data || content,
                    original_file: filePath,
                    scan_id: `vscode-remediate-${Date.now()}`,
                    timestamp: new Date().toISOString(),
                    changes_made: ['Content processed']
                };
            }
        } catch (error: any) {
            console.error('❌ ThreatGuard API Response Error:', error);
            if (error.code === 'ECONNREFUSED') {
                throw new Error('Connection refused. Please make sure the ThreatGuard backend server is running on http://localhost:5000');
            }
            if (error.code === 'ETIMEDOUT') {
                throw new Error('Request timed out. The backend server is not responding. Please check if the server is running.');
            }
            throw new Error(`Remediation failed: ${error.message || error}`);
        }
    }

    async getThreats(): Promise<Threat[]> {
        try {
            const response = await this.client.get('/api/threats');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch threats: ${error}`);
        }
    }

    async getThreatById(threatId: string): Promise<Threat> {
        try {
            const response = await this.client.get(`/api/threats/${threatId}`);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch threat: ${error}`);
        }
    }

    async updateThreatStatus(threatId: string, status: string): Promise<void> {
        try {
            await this.client.put(`/api/threats/${threatId}/status`, { status });
        } catch (error) {
            throw new Error(`Failed to update threat status: ${error}`);
        }
    }

    async neutralizeThreat(threatId: string): Promise<void> {
        try {
            await this.client.post(`/api/threats/${threatId}/neutralize`);
        } catch (error) {
            throw new Error(`Failed to neutralize threat: ${error}`);
        }
    }

    async getMetrics(): Promise<any> {
        try {
            const response = await this.client.get('/api/command-center/metrics');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch metrics: ${error}`);
        }
    }

    async getScanHistory(): Promise<{ scan_history: ScanResult[]; total_scans: number; threats_neutralized: number; avg_risk_score: number; shield_effectiveness: number }> {
        try {
            const response = await this.client.get('/api/scan-history');
            return response.data || { scan_history: [], total_scans: 0, threats_neutralized: 0, avg_risk_score: 0, shield_effectiveness: 0 };
        } catch (error) {
            throw new Error(`Failed to fetch scan history: ${error}`);
        }
    }

    async getThreatIntelligence(): Promise<any> {
        try {
            const response = await this.client.get('/api/threat-intelligence');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to fetch threat intelligence: ${error}`);
        }
    }

    async getRules(): Promise<any[]> {
        try {
            const response = await this.client.get('/api/rules');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch rules: ${error}`);
        }
    }

    async createRule(rule: any): Promise<any> {
        try {
            const response = await this.client.post('/api/rules', rule);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to create rule: ${error}`);
        }
    }

    async updateRule(ruleId: string, updates: any): Promise<any> {
        try {
            const response = await this.client.put(`/api/rules/${ruleId}`, updates);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to update rule: ${error}`);
        }
    }

    async deleteRule(ruleId: string): Promise<void> {
        try {
            await this.client.delete(`/api/rules/${ruleId}`);
        } catch (error) {
            throw new Error(`Failed to delete rule: ${error}`);
        }
    }

    async getThreatShields(): Promise<any[]> {
        try {
            const response = await this.client.get('/api/threat-shields');
            return response.data || [];
        } catch (error) {
            throw new Error(`Failed to fetch threat shields: ${error}`);
        }
    }

    async createThreatShield(shield: any): Promise<any> {
        try {
            const response = await this.client.post('/api/threat-shields', shield);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to create threat shield: ${error}`);
        }
    }

    async updateThreatShield(shieldId: string, updates: any): Promise<any> {
        try {
            const response = await this.client.put(`/api/threat-shields/${shieldId}`, updates);
            return response.data;
        } catch (error) {
            throw new Error(`Failed to update threat shield: ${error}`);
        }
    }

    async deleteThreatShield(shieldId: string): Promise<void> {
        try {
            await this.client.delete(`/api/threat-shields/${shieldId}`);
        } catch (error) {
            throw new Error(`Failed to delete threat shield: ${error}`);
        }
    }

    async exportData(): Promise<any> {
        try {
            const response = await this.client.get('/api/export');
            return response.data;
        } catch (error) {
            throw new Error(`Failed to export data: ${error}`);
        }
    }

    async scanGitHubRepository(repoUrl: string, token?: string): Promise<any> {
        try {
            const response = await this.client.post('/api/scan/github', {
                repository_url: repoUrl,
                github_token: token
            });
            return response.data;
        } catch (error) {
            throw new Error(`GitHub scan failed: ${error}`);
        }
    }
}
