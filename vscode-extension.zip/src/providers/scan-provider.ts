import * as vscode from 'vscode';
import { ThreatGuardAPI, ScanResult } from '../api/threatguard-api';

export class ScanProvider implements vscode.TreeDataProvider<ScanItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<ScanItem | undefined | null | void> = new vscode.EventEmitter<ScanItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<ScanItem | undefined | null | void> = this._onDidChangeTreeData.event;

    constructor(private api: ThreatGuardAPI) {}

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: ScanItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: ScanItem): Promise<ScanItem[]> {
        if (!element) {
            // Root level - show scan history
            try {
                const response = await this.api.getScanHistory();
                
                // The backend returns an object with scan_history property
                const scans = response.scan_history || [];

                if (scans.length === 0) {
                    return [new ScanItem('No scan history available', 'info', vscode.TreeItemCollapsibleState.None)];
                }

                return scans.map(scan => new ScanItem(
                    `${scan.project_id || 'Unknown Project'} - ${new Date(scan.timestamp).toLocaleDateString()}`,
                    'scan',
                    vscode.TreeItemCollapsibleState.Collapsed,
                    scan
                ));
            } catch (error) {
                console.error('Failed to fetch scan history:', error);
                return [new ScanItem('Error loading scans', 'error', vscode.TreeItemCollapsibleState.None)];
            }
        }

        if (element.contextValue === 'scan' && element.scan) {
            // Scan details level
            return this.getScanDetailsItems(element.scan);
        }

        return [];
    }

    private getScanDetailsItems(scan: ScanResult): ScanItem[] {
        return [
            new ScanItem(`Scan ID: ${scan.scan_id}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Project: ${scan.project_id}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Timestamp: ${new Date(scan.timestamp).toLocaleString()}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Duration: ${scan.duration_ms}ms`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Files Scanned: ${scan.files_scanned}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Lines of Code: ${scan.lines_of_code}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Issues Found: ${scan.issues?.length || 0}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Coverage: ${scan.coverage}%`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Security Rating: ${scan.security_rating}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Risk Score: ${scan.logic_bomb_risk_score}`, 'detail', vscode.TreeItemCollapsibleState.None),
            new ScanItem(`Shield Status: ${scan.threat_shield_status}`, 'detail', vscode.TreeItemCollapsibleState.None)
        ];
    }
}

export class ScanItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly contextValue: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly scan?: ScanResult
    ) {
        super(label, collapsibleState);

        if (contextValue === 'scan') {
            this.iconPath = new vscode.ThemeIcon('search');
            this.tooltip = `Scan completed on ${scan ? new Date(scan.timestamp).toLocaleString() : 'Unknown'}`;
            this.description = scan ? `${scan.issues?.length || 0} issues found` : '';
        } else if (contextValue === 'detail') {
            this.iconPath = new vscode.ThemeIcon('info');
        } else if (contextValue === 'error') {
            this.iconPath = new vscode.ThemeIcon('error');
        } else if (contextValue === 'info') {
            this.iconPath = new vscode.ThemeIcon('info');
        }
    }
}
