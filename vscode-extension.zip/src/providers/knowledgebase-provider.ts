import * as vscode from 'vscode';
import { Remediation360API } from '../api/remediation360-api';

export interface KnowledgeBaseTemplate {
    id: string;
    title: string;
    description: string;
    category: string;
    content_type: string;
    content: string;
    ai_copilot_prompt?: string;
    remediation_template?: string;
    tags?: string[];
    severity_levels?: string[];
    applicable_languages?: string[];
    created_at?: string;
    updated_at?: string;
}

export class KnowledgeBaseProvider implements vscode.TreeDataProvider<KnowledgeBaseItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<KnowledgeBaseItem | undefined | null | void> = new vscode.EventEmitter<KnowledgeBaseItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<KnowledgeBaseItem | undefined | null | void> = this._onDidChangeTreeData.event;

    private templates: KnowledgeBaseTemplate[] = [];
    private api: Remediation360API;

    constructor(api: Remediation360API) {
        this.api = api;
    }

    refresh(): void {
        console.log('KnowledgeBaseProvider.refresh() called');
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: KnowledgeBaseItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: KnowledgeBaseItem): Promise<KnowledgeBaseItem[]> {
        if (!element) {
            // Root level - show categories
            return this.getCategories();
        } else if (element.contextValue === 'category') {
            // Category level - show templates in this category
            return this.getTemplatesByCategory(element.id);
        } else {
            // Template level - no children
            return [];
        }
    }

    private getCategories(): KnowledgeBaseItem[] {
        const categories = new Set<string>();
        
        this.templates.forEach(template => {
            if (template.category) {
                categories.add(template.category);
            }
        });

        return Array.from(categories).map(category => {
            const count = this.templates.filter(t => t.category === category).length;
            return new KnowledgeBaseItem(
                `${category} (${count})`,
                category,
                'category',
                vscode.TreeItemCollapsibleState.Collapsed
            );
        });
    }

    private getTemplatesByCategory(category: string): KnowledgeBaseItem[] {
        const categoryTemplates = this.templates.filter(t => t.category === category);
        
        return categoryTemplates.map(template => {
            return new KnowledgeBaseItem(
                template.title,
                template.id,
                'template',
                vscode.TreeItemCollapsibleState.None,
                template
            );
        });
    }

    async loadTemplates(category?: string, search?: string): Promise<void> {
        try {
            console.log('Loading knowledge base templates...');
            this.templates = await this.api.getKnowledgeBaseTemplates(category, search);
            console.log(`Loaded ${this.templates.length} templates`);
            this.refresh();
        } catch (error) {
            console.error('Failed to load knowledge base templates:', error);
            this.templates = [];
            this.refresh();
        }
    }

    getTemplates(): KnowledgeBaseTemplate[] {
        return this.templates;
    }

    getTemplateById(id: string): KnowledgeBaseTemplate | undefined {
        return this.templates.find(t => t.id === id);
    }
}

export class KnowledgeBaseItem extends vscode.TreeItem {
    public readonly templateData?: KnowledgeBaseTemplate;

    constructor(
        public readonly label: string,
        public readonly id: string,
        public readonly contextValue: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        templateData?: KnowledgeBaseTemplate
    ) {
        super(label, collapsibleState);
        this.templateData = templateData;

        if (contextValue === 'category') {
            this.iconPath = new vscode.ThemeIcon('folder');
        } else if (contextValue === 'template') {
            this.iconPath = new vscode.ThemeIcon('file-text');
            this.tooltip = templateData?.description || 'Knowledge Base Template';
            this.command = {
                command: 'remediation360.showKnowledgeBaseTemplate',
                title: 'Show Template',
                arguments: [templateData]
            };
        }
    }
}

