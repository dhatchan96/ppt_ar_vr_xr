import * as vscode from 'vscode';
import { Remediation360API } from '../api/remediation360-api';

export class DashboardProvider implements vscode.TreeDataProvider<DashboardItem> {
    private _onDidChangeTreeData: vscode.EventEmitter<DashboardItem | undefined | null | void> = new vscode.EventEmitter<DashboardItem | undefined | null | void>();
    readonly onDidChangeTreeData: vscode.Event<DashboardItem | undefined | null | void> = this._onDidChangeTreeData.event;
    private recentScanData: any = null;

    constructor(private api: Remediation360API) {}

    updateWithScanData(scanData: any): void {
        console.log('DashboardProvider: Updating with scan data:', scanData);
        this.recentScanData = scanData;
        this.refresh();
    }

    refresh(): void {
        this._onDidChangeTreeData.fire();
    }

    getTreeItem(element: DashboardItem): vscode.TreeItem {
        return element;
    }

    async getChildren(element?: DashboardItem): Promise<DashboardItem[]> {
        if (!element) {
            // Root level - show dashboard sections
            return [
                new DashboardItem('Security Overview', 'section', vscode.TreeItemCollapsibleState.Collapsed),
                new DashboardItem('Recent Activity', 'section', vscode.TreeItemCollapsibleState.Collapsed),
                new DashboardItem('Threat Intelligence', 'section', vscode.TreeItemCollapsibleState.Collapsed),
                new DashboardItem('System Status', 'section', vscode.TreeItemCollapsibleState.Collapsed)
            ];
        }

        try {
            const metrics = await this.api.getMetrics();
            
            switch (element.label) {
                case 'Security Overview':
                    return this.getSecurityOverviewItems(metrics);
                case 'Recent Activity':
                    return this.getRecentActivityItems(metrics);
                case 'Threat Intelligence':
                    return this.getThreatIntelligenceItems(metrics);
                case 'System Status':
                    return this.getSystemStatusItems(metrics);
                default:
                    return [];
            }
        } catch (error) {
            console.error('Failed to fetch dashboard data:', error);
            return [new DashboardItem('Error loading data', 'error', vscode.TreeItemCollapsibleState.None)];
        }
    }

    private getSecurityOverviewItems(metrics: any): DashboardItem[] {
        const threats = metrics.threats || {};
        const ratings = metrics.threat_ratings || {};
        
        return [
            new DashboardItem(`Total Threats: ${threats.total || 0}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Critical Bombs: ${threats.critical_bombs || 0}`, 'metric', vscode.TreeItemCollapsibleState.None, 'critical'),
            new DashboardItem(`High Risk: ${threats.high_risk || 0}`, 'metric', vscode.TreeItemCollapsibleState.None, 'warning'),
            new DashboardItem(`Medium Risk: ${threats.medium_risk || 0}`, 'metric', vscode.TreeItemCollapsibleState.None, 'info'),
            new DashboardItem(`Security Rating: ${ratings.security_rating || 'Unknown'}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Risk Score: ${ratings.logic_bomb_risk_score || 0}`, 'metric', vscode.TreeItemCollapsibleState.None)
        ];
    }

    private getRecentActivityItems(metrics: any): DashboardItem[] {
        // Use recent scan data if available, otherwise fall back to metrics
        if (this.recentScanData) {
            console.log('DashboardProvider: Using recent scan data for Recent Activity');
            const scanTime = new Date().toLocaleString();
            const filesScanned = this.recentScanData.files_scanned || 0;
            const issuesFound = this.recentScanData.issues_found || 0;
            const duration = this.recentScanData.duration_ms || 0;
            const qualityGate = this.recentScanData.quality_gate_status || 'Unknown';
            const linesOfCode = this.recentScanData.lines_of_code || 0;
            const coverage = this.recentScanData.coverage || '100%';
            
            return [
                new DashboardItem(`Last Scan: ${scanTime}`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Files Scanned: ${filesScanned}`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Issues Found: ${issuesFound}`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Duration: ${duration}ms`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Lines of Code: ${linesOfCode}`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Coverage: ${coverage}`, 'metric', vscode.TreeItemCollapsibleState.None),
                new DashboardItem(`Quality Gate: ${qualityGate}`, 'metric', vscode.TreeItemCollapsibleState.None)
            ];
        }
        
        console.log('DashboardProvider: Using metrics data for Recent Activity (no recent scan data)');
        
        const scanInfo = metrics.scan_info || {};
        
        return [
            new DashboardItem(`Last Scan: ${scanInfo.last_scan || 'Never'}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Files Scanned: ${scanInfo.files_scanned || 0}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Lines of Code: ${scanInfo.lines_of_code || 0}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Coverage: ${scanInfo.coverage || 0}%`, 'metric', vscode.TreeItemCollapsibleState.None)
        ];
    }

    private getThreatIntelligenceItems(metrics: any): DashboardItem[] {
        const intelligence = metrics.threat_intelligence || {};
        
        return [
            new DashboardItem(`Threat Level: ${intelligence.threat_level || 'Unknown'}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Active Threats: ${intelligence.active_threats || 0}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Neutralized: ${intelligence.neutralized || 0}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Under Review: ${intelligence.under_review || 0}`, 'metric', vscode.TreeItemCollapsibleState.None)
        ];
    }

    private getSystemStatusItems(metrics: any): DashboardItem[] {
        const shield = metrics.threat_shield || {};
        
        return [
            new DashboardItem(`Shield Status: ${shield.status || 'Unknown'}`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`Protection Effectiveness: ${shield.protection_effectiveness || 0}%`, 'metric', vscode.TreeItemCollapsibleState.None),
            new DashboardItem(`API Status: Connected`, 'metric', vscode.TreeItemCollapsibleState.None, 'success'),
            new DashboardItem(`Extension Version: 1.0.0`, 'metric', vscode.TreeItemCollapsibleState.None)
        ];
    }
}

export class DashboardItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly contextValue: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly status?: string
    ) {
        super(label, collapsibleState);

        if (contextValue === 'section') {
            this.iconPath = new vscode.ThemeIcon('dashboard');
        } else if (contextValue === 'metric') {
            this.iconPath = this.getMetricIcon(status);
        } else if (contextValue === 'error') {
            this.iconPath = new vscode.ThemeIcon('error');
        }
    }

    private getMetricIcon(status?: string): vscode.ThemeIcon {
        switch (status) {
            case 'critical':
                return new vscode.ThemeIcon('error', new vscode.ThemeColor('errorForeground'));
            case 'warning':
                return new vscode.ThemeIcon('warning', new vscode.ThemeColor('warningForeground'));
            case 'success':
                return new vscode.ThemeIcon('check', new vscode.ThemeColor('debugIcon.startForeground'));
            case 'info':
                return new vscode.ThemeIcon('info', new vscode.ThemeColor('infoForeground'));
            default:
                return new vscode.ThemeIcon('circle');
        }
    }
}

