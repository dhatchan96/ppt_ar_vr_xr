# Centralized Dropdown Configuration

This directory contains the centralized configuration for AIT, SPK, and REPO dropdown values used across all pages of the application.

## Files

- `dropdownData.js` - Main configuration file containing all dropdown data and helper functions
- `README.md` - This documentation file

## Usage

### Importing the Configuration

```javascript
import { 
  aitData, 
  spkData, 
  repoData, 
  getAITName, 
  getSPKName, 
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
} from '../config/dropdownData';
```

### Data Structure

#### AIT Data
```javascript
const aitData = {
  'AIT001': 'Application Integration Team 1',
  'AIT002': 'Application Integration Team 2',
  'AIT003': 'Application Integration Team 3',
  'AIT004': 'Application Integration Team 4',
  'AIT005': 'Application Integration Team 5'
};
```

#### SPK Data (Nested under AIT)
```javascript
const spkData = {
  'AIT001': {
    'SPK001': 'Security Product Key 1',
    'SPK002': 'Security Product Key 2',
    'SPK003': 'Security Product Key 3'
  },
  'AIT002': {
    'SPK004': 'Security Product Key 4',
    'SPK005': 'Security Product Key 5',
    'SPK006': 'Security Product Key 6'
  }
  // ... more AITs
};
```

#### Repository Data (Nested under SPK)
```javascript
const repoData = {
  'SPK001': ['REPO001', 'REPO002', 'REPO003'],
  'SPK002': ['REPO004', 'REPO005'],
  'SPK003': ['REPO006']
  // ... more SPKs
};
```

### Helper Functions

#### Getting Display Names
```javascript
// Get AIT display name
const aitName = getAITName('AIT001'); // Returns: 'Application Integration Team 1'

// Get SPK display name
const spkName = getSPKName('SPK001'); // Returns: 'Security Product Key 1'

// Get Repository display name
const repoName = getRepoName('REPO001'); // Returns: 'REPO001'
```

#### Getting Available Options for Cascading Dropdowns
```javascript
// Get available SPKs for a selected AIT
const availableSPKs = getAvailableSPKs('AIT001'); // Returns: ['SPK001', 'SPK002', 'SPK003']

// Get available repositories for a selected SPK
const availableRepos = getAvailableRepos('SPK001'); // Returns: ['REPO001', 'REPO002', 'REPO003']
```

### Example Usage in Components

```javascript
import React, { useState } from 'react';
import { 
  aitData, 
  getAITName, 
  getSPKName, 
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
} from '../config/dropdownData';

const MyComponent = () => {
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');

  const availableSPKs = getAvailableSPKs(selectedAIT);
  const availableRepos = getAvailableRepos(selectedSPK);

  return (
    <div>
      {/* AIT Dropdown */}
      <select value={selectedAIT} onChange={(e) => setSelectedAIT(e.target.value)}>
        <option value="">Select AIT</option>
        {Object.keys(aitData).map(ait => (
          <option key={ait} value={ait}>{getAITName(ait)}</option>
        ))}
      </select>

      {/* SPK Dropdown */}
      <select 
        value={selectedSPK} 
        onChange={(e) => setSelectedSPK(e.target.value)}
        disabled={!selectedAIT}
      >
        <option value="">Select SPK</option>
        {availableSPKs.map(spk => (
          <option key={spk} value={spk}>{getSPKName(spk)}</option>
        ))}
      </select>

      {/* Repository Dropdown */}
      <select 
        value={selectedRepo} 
        onChange={(e) => setSelectedRepo(e.target.value)}
        disabled={!selectedSPK}
      >
        <option value="">Select Repository</option>
        {availableRepos.map(repo => (
          <option key={repo} value={repo}>{getRepoName(repo)}</option>
        ))}
      </select>
    </div>
  );
};
```

## Adding New Values

To add new AIT, SPK, or Repository values:

1. Open `dropdownData.js`
2. Add the new values to the appropriate data structure
3. The changes will automatically be reflected across all components that use this configuration

### Example: Adding a New AIT

```javascript
// In dropdownData.js
export const aitData = {
  'AIT001': 'Application Integration Team 1',
  'AIT002': 'Application Integration Team 2',
  'AIT003': 'Application Integration Team 3',
  'AIT004': 'Application Integration Team 4',
  'AIT005': 'Application Integration Team 5',
  'AIT006': 'Application Integration Team 6' // New AIT
};
```

### Example: Adding SPKs for a New AIT

```javascript
// In dropdownData.js
export const spkData = {
  // ... existing AITs
  'AIT006': {
    'SPK016': 'Security Product Key 16',
    'SPK017': 'Security Product Key 17'
  }
};
```

### Example: Adding Repositories for a New SPK

```javascript
// In dropdownData.js
export const repoData = {
  // ... existing SPKs
  'SPK016': ['REPO024', 'REPO025'],
  'SPK017': ['REPO026']
};
```

## Benefits

1. **Centralized Management**: All dropdown values are managed in one place
2. **Consistency**: All components use the same data and naming conventions
3. **Easy Updates**: Changes to dropdown values only need to be made in one file
4. **Type Safety**: Helper functions provide consistent data access patterns
5. **Maintainability**: Reduces code duplication and makes the codebase easier to maintain

## Components Using This Configuration

The following components have been updated to use the centralized configuration:

- `FileUpload.js`
- `Dashboard.js`
- `ThreadDemo.js`
- `ThreatIntelligence.js`
- `ThreatIssues.js`
- `SecurityTechDebt.js`
- `ThreatGuardDashboard.js`

All these components now import and use the centralized configuration, ensuring consistency across the application.
