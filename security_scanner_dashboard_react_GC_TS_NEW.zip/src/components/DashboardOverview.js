import React, { useState, useEffect } from 'react';
import { Line, Doughnut, Bar, Radar, PolarArea } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  RadialLinearScale,
  ArcElement,
  Tooltip,
  Legend,
  Filler
} from "chart.js";
import API from '../api';
import {
  FaShieldAlt,
  FaExclamationTriangle,
  FaChartLine,
  FaClock,
  FaServer,
  FaFileCode,
  FaBug,
  FaCheckCircle,
  FaTimesCircle,
  FaEye,
  FaCogs,
  FaRobot,
  FaBrain,
  FaHeartbeat,
  FaArrowUp,
  FaArrowDown,
  FaMinus
} from 'react-icons/fa';
import '../style.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  RadialLinearScale,
  ArcElement,
  Tooltip,
  Legend,
  Filler
);

const DashboardOverview = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    fetchDashboardData();
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(fetchDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch multiple data sources in parallel
      const [
        metricsResponse,
        healthResponse,
        vulnerabilitiesResponse,
        jobsResponse
      ] = await Promise.allSettled([
        API.get('/api/command-center/metrics'),
        API.get('/api/health'),
        API.get('/api/v1/vulnerabilities/enhanced?page=1&per_page=100'),
        API.get('/api/jobs/status')
      ]);

      const data = {
        metrics: metricsResponse.status === 'fulfilled' ? metricsResponse.value.data : null,
        health: healthResponse.status === 'fulfilled' ? healthResponse.value.data : null,
        vulnerabilities: vulnerabilitiesResponse.status === 'fulfilled' ? vulnerabilitiesResponse.value.data : null,
        jobs: jobsResponse.status === 'fulfilled' ? jobsResponse.value.data : null
      };

      setDashboardData(data);
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getTrendIcon = (current, previous) => {
    if (current > previous) return <FaArrowUp className="text-success" />;
    if (current < previous) return <FaArrowDown className="text-danger" />;
    return <FaMinus className="text-muted" />;
  };

  const getSeverityColor = (severity) => {
    const colors = {
      'CRITICAL': '#dc3545',
      'HIGH': '#fd7e14', 
      'MEDIUM': '#ffc107',
      'LOW': '#28a745',
      'INFO': '#17a2b8'
    };
    return colors[severity] || '#6c757d';
  };

  const getStatusColor = (status) => {
    const colors = {
      'healthy': '#28a745',
      'warning': '#ffc107',
      'error': '#dc3545',
      'running': '#17a2b8',
      'completed': '#28a745',
      'failed': '#dc3545'
    };
    return colors[status] || '#6c757d';
  };

  // Chart configurations - White Theme
  const securityTrendChart = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Current'],
    datasets: [
      {
        label: 'Security Rating',
        data: [85, 82, 88, 91, 94],
        borderColor: '#007bff',
        backgroundColor: 'rgba(0, 123, 255, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Threats Detected',
        data: [12, 8, 15, 6, 4],
        borderColor: '#dc3545',
        backgroundColor: 'rgba(220, 53, 69, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const vulnerabilityDistributionChart = {
    labels: ['Critical', 'High', 'Medium', 'Low'],
    datasets: [{
      data: [12, 28, 45, 15],
      backgroundColor: [
        '#dc3545',
        '#fd7e14',
        '#ffc107',
        '#28a745'
      ],
      borderWidth: 2,
      borderColor: '#ffffff'
    }]
  };

  const scanPerformanceChart = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Files Scanned',
        data: [1200, 1900, 3000, 2800, 2200, 1800, 1500],
        backgroundColor: 'rgba(0, 123, 255, 0.5)',
        borderColor: '#007bff',
        borderWidth: 2
      },
      {
        label: 'Issues Found',
        data: [45, 67, 89, 76, 58, 42, 38],
        backgroundColor: 'rgba(220, 53, 69, 0.5)',
        borderColor: '#dc3545',
        borderWidth: 2
      }
    ]
  };

  const systemHealthRadarChart = {
    labels: ['Performance', 'Security', 'Reliability', 'Availability', 'Scalability'],
    datasets: [{
      label: 'System Health',
      data: [85, 92, 88, 95, 82],
      backgroundColor: 'rgba(0, 123, 255, 0.2)',
      borderColor: '#007bff',
      borderWidth: 2,
      pointBackgroundColor: '#007bff',
      pointBorderColor: '#ffffff',
      pointBorderWidth: 2
    }]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          usePointStyle: true,
          padding: 20
        }
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#ffffff',
        bodyColor: '#ffffff',
        borderColor: '#ffffff',
        borderWidth: 1
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)'
        }
      },
      x: {
        grid: {
          color: 'rgba(0, 0, 0, 0.1)'
        }
      }
    }
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          padding: 20
        }
      }
    }
  };

  const radarOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top'
      }
    },
    scales: {
      r: {
        beginAtZero: true,
        max: 100,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)'
        }
      }
    }
  };

  if (loading) {
    return (
      <div className="container-fluid">
        <div className="d-flex justify-content-center align-items-center" style={{ height: '60vh' }}>
          <div className="text-center">
            <div className="spinner-border text-primary mb-3" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <h4>Loading Dashboard...</h4>
            <p className="text-muted">Fetching real-time metrics and analytics</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container-fluid">
        <div className="alert alert-danger" role="alert">
          <h4 className="alert-heading">Dashboard Error</h4>
          <p>{error}</p>
          <button className="btn btn-outline-danger" onClick={fetchDashboardData}>
            <FaCogs className="me-2" />
            Retry
          </button>
        </div>
      </div>
    );
  }

  const metrics = dashboardData?.metrics || {};
  const health = dashboardData?.health || {};
  const vulnerabilities = dashboardData?.vulnerabilities || {};
  const jobs = dashboardData?.jobs || {};

  return (
    <div className="container-fluid dashboard-overview">
      {/* Header */}
      <div className="row mb-4">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h1 className="h3 mb-1">
                <FaShieldAlt className="me-2 text-primary" />
                ThreatGuard Pro Dashboard
              </h1>
              <p className="text-muted mb-0">Comprehensive security analytics and monitoring</p>
            </div>
            <div className="text-end">
              <small className="text-muted">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </small>
              <button 
                className="btn btn-outline-primary btn-sm ms-3"
                onClick={fetchDashboardData}
              >
                <FaCogs className="me-1" />
                Refresh
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="row g-4 mb-4">
        <div className="col-lg-3 col-md-6">
          <div className="metric-card">
            <div className="d-flex align-items-center justify-content-center mb-3">
              <div className="bg-primary bg-opacity-10 rounded-circle p-3 border border-primary border-opacity-20">
                <FaShieldAlt className="text-primary" size={24} />
              </div>
            </div>
            <div className="metric-value">
              {metrics.threat_ratings?.security || 'A'}
            </div>
            <div className="metric-label">Security Rating</div>
            <div className="d-flex align-items-center justify-content-center mt-2">
              {getTrendIcon(94, 91)}
              <small className="ms-1 opacity-75">+3% from last week</small>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6">
          <div className="metric-card">
            <div className="d-flex align-items-center justify-content-center mb-3">
              <div className="bg-danger bg-opacity-10 rounded-circle p-3 border border-danger border-opacity-20">
                <FaExclamationTriangle className="text-danger" size={24} />
              </div>
            </div>
            <div className="metric-value">
              {metrics.threats?.total || 0}
            </div>
            <div className="metric-label">Active Threats</div>
            <div className="d-flex align-items-center justify-content-center mt-2">
              {getTrendIcon(4, 6)}
              <small className="ms-1 opacity-75">-33% from last week</small>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6">
          <div className="metric-card">
            <div className="d-flex align-items-center justify-content-center mb-3">
              <div className="bg-success bg-opacity-10 rounded-circle p-3 border border-success border-opacity-20">
                <FaFileCode className="text-success" size={24} />
              </div>
            </div>
            <div className="metric-value">
              {metrics.scan_info?.files_scanned?.toLocaleString() || '0'}
            </div>
            <div className="metric-label">Files Scanned</div>
            <div className="d-flex align-items-center justify-content-center mt-2">
              {getTrendIcon(1500, 1200)}
              <small className="ms-1 opacity-75">+25% from last week</small>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6">
          <div className="metric-card">
            <div className="d-flex align-items-center justify-content-center mb-3">
              <div className="bg-info bg-opacity-10 rounded-circle p-3 border border-info border-opacity-20">
                <FaHeartbeat className="text-info" size={24} />
              </div>
            </div>
            <div className="metric-value">
              {health.status === 'healthy' ? '99.9%' : '98.5%'}
            </div>
            <div className="metric-label">System Uptime</div>
            <div className="d-flex align-items-center justify-content-center mt-2">
              <FaCheckCircle className="text-success" />
              <small className="ms-1 opacity-75">All systems operational</small>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="row g-4 mb-4">
        {/* Security Trend Chart */}
        <div className="col-lg-8">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaChartLine className="me-2 text-primary" size={20} />
              <h5 className="mb-0 fw-bold">Security Trend Analysis</h5>
            </div>
            <div style={{ height: '300px' }}>
              <Line data={securityTrendChart} options={chartOptions} />
            </div>
          </div>
        </div>

        {/* Vulnerability Distribution */}
        <div className="col-lg-4">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaBug className="me-2 text-warning" size={20} />
              <h5 className="mb-0 fw-bold">Vulnerability Distribution</h5>
            </div>
            <div style={{ height: '300px' }}>
              <Doughnut data={vulnerabilityDistributionChart} options={doughnutOptions} />
            </div>
          </div>
        </div>
      </div>

      {/* Second Charts Row */}
      <div className="row g-4 mb-4">
        {/* Scan Performance */}
        <div className="col-lg-6">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaServer className="me-2 text-info" size={20} />
              <h5 className="mb-0 fw-bold">Scan Performance</h5>
            </div>
            <div style={{ height: '300px' }}>
              <Bar data={scanPerformanceChart} options={chartOptions} />
            </div>
          </div>
        </div>

        {/* System Health Radar */}
        <div className="col-lg-6">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaBrain className="me-2 text-success" size={20} />
              <h5 className="mb-0 fw-bold">System Health Overview</h5>
            </div>
            <div style={{ height: '300px' }}>
              <Radar data={systemHealthRadarChart} options={radarOptions} />
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Metrics Row */}
      <div className="row g-4">
        {/* Threat Breakdown */}
        <div className="col-lg-4">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaExclamationTriangle className="me-2 text-danger" size={20} />
              <h5 className="mb-0 fw-bold">Threat Breakdown</h5>
            </div>
            <div>
              {Object.entries(metrics.threats?.by_severity || {}).map(([severity, count]) => (
                <div key={severity} className="d-flex justify-content-between align-items-center mb-3">
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-2" 
                      style={{ 
                        width: '12px', 
                        height: '12px', 
                        backgroundColor: getSeverityColor(severity) 
                      }}
                    />
                    <span className="text-capitalize fw-medium">{severity.toLowerCase()}</span>
                  </div>
                  <span className="fw-bold text-primary">{count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="col-lg-4">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaClock className="me-2 text-info" size={20} />
              <h5 className="mb-0 fw-bold">Recent Activity</h5>
            </div>
            <div>
              <div className="activity-item">
                <div className="activity-icon" style={{backgroundColor: '#d4edda', color: '#155724'}}>
                  <FaCheckCircle />
                </div>
                <div className="activity-content">
                  <div className="activity-title">Security scan completed</div>
                  <div className="activity-time">2 minutes ago</div>
                </div>
              </div>
              <div className="activity-item">
                <div className="activity-icon" style={{backgroundColor: '#fff3cd', color: '#856404'}}>
                  <FaExclamationTriangle />
                </div>
                <div className="activity-content">
                  <div className="activity-title">3 new vulnerabilities detected</div>
                  <div className="activity-time">15 minutes ago</div>
                </div>
              </div>
              <div className="activity-item">
                <div className="activity-icon" style={{backgroundColor: '#d1ecf1', color: '#0c5460'}}>
                  <FaRobot />
                </div>
                <div className="activity-content">
                  <div className="activity-title">AI remediation completed</div>
                  <div className="activity-time">1 hour ago</div>
                </div>
              </div>
              <div className="activity-item">
                <div className="activity-icon" style={{backgroundColor: '#f8d7da', color: '#721c24'}}>
                  <FaEye />
                </div>
                <div className="activity-content">
                  <div className="activity-title">Threat intelligence updated</div>
                  <div className="activity-time">3 hours ago</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* System Status */}
        <div className="col-lg-4">
          <div className="chart-container">
            <div className="d-flex align-items-center mb-3">
              <FaHeartbeat className="me-2 text-success" size={20} />
              <h5 className="mb-0 fw-bold">System Status</h5>
            </div>
            <div>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="fw-medium">API Server</span>
                <span className={`status-indicator ${health.status === 'healthy' ? 'status-healthy' : 'status-error'}`}>
                  {health.status || 'Unknown'}
                </span>
              </div>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="fw-medium">Database</span>
                <span className="status-indicator status-healthy">Online</span>
              </div>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="fw-medium">Scan Engine</span>
                <span className="status-indicator status-healthy">Active</span>
              </div>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="fw-medium">AI Services</span>
                <span className="status-indicator status-healthy">Running</span>
              </div>
              <div className="d-flex justify-content-between align-items-center">
                <span className="fw-medium">Version</span>
                <span className="text-muted fw-medium">{health.version || 'v2.1.0'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;
