import React, { useState, useEffect } from 'react';
import API from '../api';
import '../style.css';
import * as XLSX from 'xlsx';
import {
  FaUpload,
  FaDownload,
  FaDatabase,
  FaTable,
  FaChartBar,
  FaCog,
  FaEye,
  FaEdit,
  FaTrash,
  FaSync,
  FaFileExcel,
  FaFileCode,
  FaInfoCircle
} from 'react-icons/fa';

const AdminDataManagement = () => {
  const [activeTab, setActiveTab] = useState('import');
  const [importing, setImporting] = useState(false);
  const [aitList, setAitList] = useState([]);
  const [selectedAit, setSelectedAit] = useState('');
  const [spkList, setSpkList] = useState([]);
  const [selectedSpk, setSelectedSpk] = useState('');
  const [repoList, setRepoList] = useState([]);
  const [hierarchicalData, setHierarchicalData] = useState({});
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [clearing, setClearing] = useState(false);

  useEffect(() => {
    loadStatistics();
    loadHierarchicalData();
  }, []);

  useEffect(() => {
    if (activeTab === 'data') {
      loadAitList();
    }
  }, [activeTab]);

  useEffect(() => {
    if (selectedAit) {
      loadSpkList(selectedAit);
    } else {
      setSpkList([]);
      setSelectedSpk('');
    }
  }, [selectedAit]);

  useEffect(() => {
    if (selectedSpk) {
      loadRepoList(selectedSpk);
    } else {
      setRepoList([]);
    }
  }, [selectedSpk]);

  const loadStatistics = async () => {
    try {
      setLoading(true);
      const response = await API.get('/api/admin/statistics');
      if (response.data.success) {
        setStatistics(response.data.data);
      }
    } catch (error) {
      console.error('Error loading statistics:', error);
      showMessage('Failed to load statistics', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadHierarchicalData = async () => {
    try {
      const response = await API.get('/api/admin/hierarchical-data');
      if (response.data.success) {
        setHierarchicalData(response.data.data);
      }
    } catch (error) {
      console.error('Error loading hierarchical data:', error);
    }
  };

  const loadAitList = async () => {
    try {
      setLoading(true);
      const response = await API.get('/api/admin/ait-list');
      if (response.data.success) {
        setAitList(response.data.data);
      }
    } catch (error) {
      console.error('Error loading AIT list:', error);
      showMessage('Failed to load AIT list', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadSpkList = async (aitTag) => {
    try {
      const response = await API.get(`/api/admin/spk-list/${aitTag}`);
      if (response.data.success) {
        setSpkList(response.data.data);
      }
    } catch (error) {
      console.error('Error loading SPK list:', error);
      showMessage('Failed to load SPK list', 'error');
    }
  };

  const loadRepoList = async (spkTag) => {
    try {
      const response = await API.get(`/api/admin/repo-list/${spkTag}`);
      if (response.data.success) {
        setRepoList(response.data.data);
      }
    } catch (error) {
      console.error('Error loading repository list:', error);
      showMessage('Failed to load repository list', 'error');
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      showMessage('Please upload an Excel file (.xlsx or .xls)', 'error');
      return;
    }

    setImporting(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await API.post('/api/admin/import-excel', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success) {
        showMessage(response.data.message, 'success');
        loadStatistics();
        loadHierarchicalData();
        if (activeTab === 'data') {
          loadAitList();
        }
      } else {
        showMessage(response.data.error, 'error');
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      showMessage('Failed to upload file', 'error');
    } finally {
      setImporting(false);
      event.target.value = '';
    }
  };

  const downloadTemplate = async () => {
    try {
      const response = await API.get('/api/admin/download-template', {
        responseType: 'blob',
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'ait_spk_repo_template.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      showMessage('Template downloaded successfully', 'success');
    } catch (error) {
      console.error('Error downloading template:', error);
      showMessage('Failed to download template', 'error');
    }
  };

  const exportToJson = async () => {
    try {
      const response = await API.post('/api/admin/export-json');
      if (response.data.success) {
        showMessage(response.data.message, 'success');
      } else {
        showMessage(response.data.error, 'error');
      }
    } catch (error) {
      console.error('Error exporting to JSON:', error);
      showMessage('Failed to export to JSON', 'error');
    }
  };

  const clearData = async () => {
    if (!window.confirm('Are you sure you want to clear all dropdown data? This action cannot be undone.')) {
      return;
    }

    setClearing(true);
    try {
      const response = await API.post('/api/admin/clear-data');
      if (response.data.success) {
        showMessage(response.data.message, 'success');
        // Reset all states
        setAitList([]);
        setSelectedAit('');
        setSpkList([]);
        setSelectedSpk('');
        setRepoList([]);
        setHierarchicalData({});
        loadStatistics();
      } else {
        showMessage(response.data.error, 'error');
      }
    } catch (error) {
      console.error('Error clearing data:', error);
      showMessage('Failed to clear data', 'error');
    } finally {
      setClearing(false);
    }
  };

  const showMessage = (msg, type) => {
    setMessage(msg);
    setMessageType(type);
    setTimeout(() => {
      setMessage('');
      setMessageType('');
    }, 5000);
  };

  const renderImportTab = () => (
    <div className="import-section">
      <div className="card">
        <div className="card-header">
          <h5><FaUpload className="me-2" />Import AIT-SPK-Repo Mappings</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-6">
              <div className="upload-area">
                <h6>Upload Excel File</h6>
                                 <p className="text-muted">
                   Upload an Excel file with AIT-SPK-Repo mappings.
                   The file should contain columns: AIT_ID (numeric), SPK (acronym), REPOSITORY_NAME
                 </p>
                <div className="mb-3">
                  <input
                    type="file"
                    className="form-control"
                    accept=".xlsx,.xls"
                    onChange={handleFileUpload}
                    disabled={importing}
                  />
                </div>
                {importing && (
                  <div className="alert alert-info">
                    <FaSync className="fa-spin me-2" />
                    Importing data... Please wait.
                  </div>
                )}
              </div>
            </div>
            <div className="col-md-6">
              <div className="template-section">
                <h6>Download Template</h6>
                <p className="text-muted">
                  Download the Excel template to see the required format for your data.
                </p>
                <button
                  className="btn btn-outline-primary"
                  onClick={downloadTemplate}
                >
                  <FaDownload className="me-2" />
                  Download Template
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderDataTab = () => (
    <div className="data-section">
      <div className="row">
        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h6><FaTable className="me-2" />AIT List</h6>
            </div>
            <div className="card-body">
              <select
                className="form-select mb-3"
                value={selectedAit}
                onChange={(e) => setSelectedAit(e.target.value)}
              >
                <option value="">Select AIT</option>
                {aitList.map((ait) => (
                  <option key={ait.ait_tag} value={ait.ait_tag}>
                    {ait.ait_tag} - {ait.ait_name} ({ait.spk_count} SPKs)
                  </option>
                ))}
              </select>
              {selectedAit && (
                <div className="ait-details">
                  <h6>Details:</h6>
                  <p><strong>SPKs:</strong> {aitList.find(a => a.ait_tag === selectedAit)?.spk_count || 0}</p>
                  <p><strong>Repositories:</strong> {aitList.find(a => a.ait_tag === selectedAit)?.repo_count || 0}</p>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h6><FaTable className="me-2" />SPK List</h6>
            </div>
            <div className="card-body">
              <select
                className="form-select mb-3"
                value={selectedSpk}
                onChange={(e) => setSelectedSpk(e.target.value)}
                disabled={!selectedAit}
              >
                <option value="">Select SPK</option>
                {spkList.map((spk) => (
                  <option key={spk.spk_tag} value={spk.spk_tag}>
                    {spk.spk_tag} - {spk.spk_name} ({spk.repo_count} repos)
                  </option>
                ))}
              </select>
              {selectedSpk && (
                <div className="spk-details">
                  <h6>Details:</h6>
                  <p><strong>Repositories:</strong> {spkList.find(s => s.spk_tag === selectedSpk)?.repo_count || 0}</p>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card">
            <div className="card-header">
              <h6><FaTable className="me-2" />Repository List</h6>
            </div>
            <div className="card-body">
              <div className="repo-list">
                {repoList.length > 0 ? (
                  repoList.map((repo, index) => (
                    <div key={index} className="repo-item mb-2">
                      <strong>{repo.repo_name}</strong>
                      {repo.repo_url && (
                        <div>
                          <small className="text-muted">
                            <a href={repo.repo_url} target="_blank" rel="noopener noreferrer">
                              {repo.repo_url}
                            </a>
                          </small>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted">No repositories found</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStatisticsTab = () => (
    <div className="statistics-section">
      <div className="row">
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h3 className="text-primary">{statistics.ait_count || 0}</h3>
              <p className="card-text">AITs</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h3 className="text-success">{statistics.spk_count || 0}</h3>
              <p className="card-text">SPKs</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h3 className="text-info">{statistics.repo_count || 0}</h3>
              <p className="card-text">Repositories</p>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h3 className="text-warning">{statistics.total_records || 0}</h3>
              <p className="card-text">Total Records</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h6><FaChartBar className="me-2" />Hierarchical Data Overview</h6>
            </div>
            <div className="card-body">
              <div className="hierarchical-overview">
                {Object.keys(hierarchicalData).length > 0 ? (
                  Object.entries(hierarchicalData).map(([aitTag, aitData]) => (
                    <div key={aitTag} className="ait-overview mb-3">
                      <h6 className="text-primary">{aitTag} - {aitData.ait_name}</h6>
                      <div className="spk-overview ms-3">
                        {Object.entries(aitData.spks).map(([spkTag, spkData]) => (
                          <div key={spkTag} className="spk-item mb-2">
                            <span className="text-success">• {spkTag} - {spkData.spk_name}</span>
                            <span className="text-muted ms-2">({spkData.repos.length} repos)</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted">No hierarchical data available</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderExportTab = () => (
    <div className="export-section">
      <div className="card">
        <div className="card-header">
          <h5><FaDownload className="me-2" />Export & Manage Data</h5>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4">
              <div className="export-option">
                <h6><FaFileCode className="me-2" />Export to JSON</h6>
                <p className="text-muted">
                  Export the hierarchical data to a JSON file for use in other applications.
                </p>
                <button
                  className="btn btn-primary"
                  onClick={exportToJson}
                >
                  <FaDownload className="me-2" />
                  Export to JSON
                </button>
              </div>
            </div>
            <div className="col-md-4">
              <div className="export-option">
                <h6><FaDatabase className="me-2" />Database Information</h6>
                <p className="text-muted">
                  View database statistics and information.
                </p>
                <div className="db-info">
                  <p><strong>Database:</strong> SQLite (admin_data.db)</p>
                  <p><strong>Tables:</strong> ait_mappings, spk_mappings, repo_mappings</p>
                  <p><strong>Total Records:</strong> {statistics.total_records || 0}</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="clear-option">
                <h6><FaTrash className="me-2" />Clear All Data</h6>
                <p className="text-muted">
                  Remove all AIT, SPK, and Repository data from the database. This action cannot be undone.
                </p>
                <button
                  className="btn btn-danger"
                  onClick={clearData}
                  disabled={clearing}
                >
                  {clearing ? (
                    <>
                      <FaSync className="fa-spin me-2" />
                      Clearing...
                    </>
                  ) : (
                    <>
                      <FaTrash className="me-2" />
                      Clear All Data
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="admin-data-management">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: "#0d6efd" }}>
          <FaCog className="me-2" />
          Admin Data Management
        </h2>
        <button
          className="btn btn-outline-primary"
          onClick={() => {
            loadStatistics();
            loadHierarchicalData();
            if (activeTab === 'data') {
              loadAitList();
            }
          }}
        >
          <FaSync className="me-1" />
          Refresh
        </button>
      </div>

      {message && (
        <div className={`alert alert-${messageType === 'error' ? 'danger' : messageType} alert-dismissible fade show`}>
          {message}
          <button
            type="button"
            className="btn-close"
            onClick={() => setMessage('')}
          ></button>
        </div>
      )}

      <div className="row mb-4">
        <div className="col-12">
          <ul className="nav nav-tabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'import' ? 'active' : ''}`}
                onClick={() => setActiveTab('import')}
                type="button"
                role="tab"
              >
                <FaUpload className="me-2" />
                Import Data
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'data' ? 'active' : ''}`}
                onClick={() => setActiveTab('data')}
                type="button"
                role="tab"
              >
                <FaTable className="me-2" />
                View Data
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'statistics' ? 'active' : ''}`}
                onClick={() => setActiveTab('statistics')}
                type="button"
                role="tab"
              >
                <FaChartBar className="me-2" />
                Statistics
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'export' ? 'active' : ''}`}
                onClick={() => setActiveTab('export')}
                type="button"
                role="tab"
              >
                <FaDownload className="me-2" />
                Export
              </button>
            </li>
          </ul>
        </div>
      </div>

      {loading && (
        <div className="text-center mb-4">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}

      {activeTab === 'import' && renderImportTab()}
      {activeTab === 'data' && renderDataTab()}
      {activeTab === 'statistics' && renderStatisticsTab()}
      {activeTab === 'export' && renderExportTab()}
    </div>
  );
};

export default AdminDataManagement;
