import React, { useState } from 'react';
import API from '../api'; // ✅ Import your centralized Axios instance
import { 
  aitData, 
  spkData, 
  repoData, 
  getAITName, 
  getSPKName, 
  getRepoName,
  getAvailableSPKs,
  getAvailableRepos
} from '../config/dropdownData';

export default function FileUpload() {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [selectedAIT, setSelectedAIT] = useState('');
  const [selectedSPK, setSelectedSPK] = useState('');
  const [selectedRepo, setSelectedRepo] = useState('');

  const handleAITChange = (aitId) => {
    setSelectedAIT(aitId);
    setSelectedSPK('');
    setSelectedRepo('');
  };

  const handleSPKChange = (spkId) => {
    setSelectedSPK(spkId);
    setSelectedRepo('');
  };

  const handleRepoChange = (repoId) => {
    setSelectedRepo(repoId);
  };

  const handleFileChange = (e) => {
    setSelectedFiles(Array.from(e.target.files));
  };

  const handleUpload = async () => {
    if (!selectedFiles.length) return alert('Please select files to scan.');
    if (!selectedAIT || !selectedSPK || !selectedRepo) return alert('Please select AIT, SPK, and Repository.');

    const fileContents = await Promise.all(
      selectedFiles.map(async (file) => {
        const content = await readFileContent(file);
        return {
          id: generateId(),
          name: file.name,
          type: getFileLanguage(file.name),
          content: content,
        };
      })
    );

    const payload = {
      scan_id: generateId(),
      scan_type: 'manual',
      project_id: `upload-scan-${Date.now()}`,
      project_name: 'Quick Security Scan',
      source: 'react-ui', // Add source identifier for filtering
      timestamp: new Date().toISOString(),
      file_contents: fileContents,
      ait_tag: selectedAIT,
      spk_tag: selectedSPK,
      repo_name: selectedRepo
    };

    try {
      setUploading(true);
      const res = await API.post('/api/scan/files', payload); // ✅ Axios call using baseURL
      alert('✅ Scan completed successfully!');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || err.message);
    } finally {
      setUploading(false);
    }
  };

  const readFileContent = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const generateId = () => 'id_' + Math.random().toString(36).substr(2, 9);

  const getFileLanguage = (filename) => {
    const ext = filename.split('.').pop().toLowerCase();
    const map = {
      py: 'python', js: 'javascript', ts: 'typescript', java: 'java',
      html: 'html', css: 'css', json: 'json', xml: 'xml', sql: 'sql',
    };
    return map[ext] || 'unknown';
  };

  const availableSPKs = getAvailableSPKs(selectedAIT);
  const availableRepos = getAvailableRepos(selectedSPK);

  return (
    <div className="card p-4 shadow-sm">
      <h5>Quick Security Scan</h5>
      
      {/* Project Selection Dropdowns */}
      <div className="row mb-3">
        <div className="col-md-4">
          <label className="form-label">AIT (Application Integration Team)</label>
          <select 
            className="form-select" 
            value={selectedAIT} 
            onChange={(e) => handleAITChange(e.target.value)}
          >
            <option value="">Select AIT</option>
            {Object.keys(aitData).map(ait => (
              <option key={ait} value={ait}>{getAITName(ait)}</option>
            ))}
          </select>
        </div>
        
        <div className="col-md-4">
          <label className="form-label">SPK (Security Product Key)</label>
          <select 
            className="form-select" 
            value={selectedSPK} 
            onChange={(e) => handleSPKChange(e.target.value)}
            disabled={!selectedAIT}
            style={{ opacity: selectedAIT ? 1 : 0.6 }}
          >
            <option value="">Select SPK</option>
            {availableSPKs.map(spk => (
              <option key={spk} value={spk}>{getSPKName(spk)}</option>
            ))}
          </select>
        </div>
        
        <div className="col-md-4">
          <label className="form-label">Repository</label>
          <select 
            className="form-select" 
            value={selectedRepo} 
            onChange={(e) => handleRepoChange(e.target.value)}
            disabled={!selectedSPK}
            style={{ opacity: selectedSPK ? 1 : 0.6 }}
          >
            <option value="">Select Repository</option>
            {availableRepos.map(repo => (
              <option key={repo} value={repo}>{getRepoName(repo)}</option>
            ))}
          </select>
        </div>
      </div>

      {/* File Upload */}
      <div className="mb-3">
        <label className="form-label">Select Files to Scan</label>
        <input type="file" multiple onChange={handleFileChange} className="form-control" />
      </div>

      {/* Selected Project Summary */}
      {selectedAIT && selectedSPK && selectedRepo && (
        <div className="alert alert-info mb-3">
          <strong>Selected Project:</strong><br />
          <strong>AIT:</strong> {getAITName(selectedAIT)}<br />
          <strong>SPK:</strong> {getSPKName(selectedSPK)}<br />
          <strong>Repository:</strong> {getRepoName(selectedRepo)}
        </div>
      )}

      <button 
        className="btn btn-primary" 
        onClick={handleUpload} 
        disabled={uploading || !selectedAIT || !selectedSPK || !selectedRepo || !selectedFiles.length}
      >
        {uploading ? 'Scanning...' : 'Start Scan'}
      </button>
    </div>
  );
}
