import React, { useState, useEffect } from "react";
import API from "../api";
import "../style.css";
import { getAITName, getSPKName, getRepoName } from '../config/dropdownData';
import * as XLSX from 'xlsx';
import {
  FaShieldAlt,
  FaBug,
  FaExclamationTriangle,
  FaTools,
  FaFilter,
  FaTimesCircle,
  FaEye,
  FaCheck,
  FaBan,
  FaInfoCircle,
  FaUndo,
  FaServer
} from "react-icons/fa";

const ActiveThreatsManagement = () => {
  const [activeTab, setActiveTab] = useState("issue");
  const [activeSubTab, setActiveSubTab] = useState("malicious");
  const [activeVulnSubTab, setActiveVulnSubTab] = useState("application");
  const [threats, setThreats] = useState([]);
  const [vulnerabilities, setVulnerabilities] = useState([]);
  const [infrastructureVulnerabilities, setInfrastructureVulnerabilities] = useState([]);
  
  // Hierarchical filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  
  // Vulnerability filter states
  const [vulnFilterSeverity, setVulnFilterSeverity] = useState('ALL');
  const [vulnFilterStatus, setVulnFilterStatus] = useState('ALL');

  // Add pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Details popup state
  const [showDetailsPopup, setShowDetailsPopup] = useState(false);
  const [selectedThreat, setSelectedThreat] = useState(null);
  const [showVulnerabilityDetailsPopup, setShowVulnerabilityDetailsPopup] = useState(false);
  const [selectedVulnerability, setSelectedVulnerability] = useState(null);
  const [importingExcel, setImportingExcel] = useState(false);
  const [excelData, setExcelData] = useState([]);


  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch threats from the same endpoint as ThreatIssues
      const threatsRes = await API.get("/api/threats");
      console.log("Threats API response:", threatsRes);
      const threatsData = threatsRes.data?.threats || threatsRes.data || [];
      console.log("Processed threats data:", threatsData);
      setThreats(threatsData);
      
      // Fetch enhanced vulnerabilities from API
      try {
        const params = new URLSearchParams({
          severity: 'ALL',
          priority: 'ALL',
          wave_assignment: 'ALL',
          type: 'application',  // Only fetch application vulnerabilities
          page: 1,
          per_page: 1000
        });
        const vulnerabilitiesRes = await API.get(`/api/v1/vulnerabilities/enhanced?${params}`);
        let apiVulnerabilities = [];
        if (vulnerabilitiesRes.data?.success) {
          apiVulnerabilities = vulnerabilitiesRes.data.vulnerabilities || [];
          console.log(`🔍 Fetched ${apiVulnerabilities.length} application vulnerabilities from enhanced API`);
          console.log(`📋 API Response type: ${vulnerabilitiesRes.data?.vulnerability_type || 'Not specified'}`);
        }
        
        // Fetch Excel-imported vulnerabilities from SQLite
        try {
          const excelVulnsRes = await API.get('/api/v1/vulnerabilities/excel-export?type=application');
          let excelVulnerabilities = [];
          if (excelVulnsRes.data?.success) {
            excelVulnerabilities = excelVulnsRes.data.vulnerabilities || [];
          }
          
          // Merge API data with Excel data, avoiding duplicates
          const existingIds = new Set(apiVulnerabilities.map(v => v.id));
          const newExcelVulns = excelVulnerabilities.filter(v => !existingIds.has(v.id));
          const mergedVulnerabilities = [...apiVulnerabilities, ...newExcelVulns];
          
          setVulnerabilities(mergedVulnerabilities);
          console.log(`Loaded ${apiVulnerabilities.length} API vulnerabilities and ${excelVulnerabilities.length} Excel vulnerabilities (${newExcelVulns.length} new)`);
        } catch (excelError) {
          console.warn('Excel vulnerabilities API not available, using API data only:', excelError);
          setVulnerabilities(apiVulnerabilities);
        }
      } catch (vulnError) {
        console.log("Enhanced vulnerabilities endpoint not available, using empty array");
        setVulnerabilities([]);
      }
      
      // Fetch infrastructure vulnerabilities from SQLite
      try {
        const infraVulnsRes = await API.get('/api/v1/vulnerabilities/excel-export?type=infrastructure');
        let infrastructureVulnerabilities = [];
        if (infraVulnsRes.data?.success) {
          infrastructureVulnerabilities = infraVulnsRes.data.vulnerabilities || [];
        }
        setInfrastructureVulnerabilities(infrastructureVulnerabilities);
        console.log(`🔍 Loaded ${infrastructureVulnerabilities.length} infrastructure vulnerabilities from SQLite`);
        if (infrastructureVulnerabilities.length > 0) {
          console.log(`📋 Sample infrastructure vulnerability: ${infrastructureVulnerabilities[0].title?.substring(0, 50)}...`);
        }
      } catch (infraError) {
        console.warn('Infrastructure vulnerabilities API not available:', infraError);
        setInfrastructureVulnerabilities([]);
      }
      
    } catch (err) {
      console.error("Failed to fetch data:", err);
      setVulnerabilities([]);
      setInfrastructureVulnerabilities([]);
    }
  };

  const handleStatusToggle = async (id) => {
    const threat = threats.find((t) => t.id === id);
    const newStatus =
      threat.status === "ACTIVE_THREAT" ? "NEUTRALIZED" : "ACTIVE_THREAT";
    try {
      await API.put(`/api/threats/${id}/status`, { status: newStatus });
      fetchData();
    } catch (err) {
      console.error("Failed to update threat status:", err);
    }
  };

  const neutralizeThreat = async (id) => {
    if (!window.confirm("Are you sure you want to neutralize this threat?"))
      return;
    try {
      await API.post(`/api/threats/${id}/neutralize`);
      fetchData();
    } catch (err) {
      console.error("Failed to neutralize threat:", err);
    }
  };

  const revertThreat = async (id) => {
    if (!window.confirm("Are you sure you want to revert this threat to active status?"))
      return;
    try {
      // Use the same endpoint as neutralize but with different method or use status update
      await API.put(`/api/threats/${id}/status`, { status: "ACTIVE_THREAT" });
      fetchData();
    } catch (err) {
      console.error("Failed to revert threat:", err);
    }
  };

  const showDetails = (threat) => {
    setSelectedThreat(threat);
    setShowDetailsPopup(true);
  };

  const closeDetails = () => {
    setShowDetailsPopup(false);
    setSelectedThreat(null);
  };

  const showVulnerabilityDetails = (vulnerability) => {
    setSelectedVulnerability(vulnerability);
    setShowVulnerabilityDetailsPopup(true);
  };

  const closeVulnerabilityDetails = () => {
    setShowVulnerabilityDetailsPopup(false);
    setSelectedVulnerability(null);
  };

  const neutralizeVulnerability = async (id) => {
    if (!window.confirm("Are you sure you want to neutralize this vulnerability?"))
      return;
    try {
      // Update vulnerability status to NEUTRALIZED
      await API.put(`/api/v1/vulnerabilities/enhanced/${id}/status`, { status: "NEUTRALIZED" });
      fetchData();
    } catch (err) {
      console.error("Failed to neutralize vulnerability:", err);
    }
  };

  const revertVulnerability = async (id) => {
    if (!window.confirm("Are you sure you want to revert this vulnerability to active status?"))
      return;
    try {
      // Update vulnerability status back to ACTIVE
      await API.put(`/api/vulnerabilities/${id}/status`, { status: "ACTIVE" });
      fetchData();
    } catch (err) {
      console.error("Failed to revert vulnerability:", err);
    }
  };

  const handleExcelUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setImportingExcel(true);
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        // Process data
        const processedData = jsonData.slice(1).map((row, index) => {
          const title = row[2] || 'Unknown Vulnerability';
          
          return {
            id: `excel-${Date.now()}-${index}`,
            gis_id: row[0] || `excel-${Date.now()}-${index}`,
            ait_tag: row[1] || 'AIT-Unknown',
            title: title,
            description: title,
            remediation_action: row[3] || 'Update to latest version',
            status: row[4] || 'ACTIVE',
            severity: 'MEDIUM_RISK',
            risk_score: Math.floor(Math.random() * 10) + 1,
            wave_assignment: 'UNASSIGNED',
            cost_impact: 0,
            created_date: new Date().toISOString(),
            source: 'excel_import'
          };
        });

        // Determine vulnerability type
        const isInfrastructure = activeVulnSubTab === 'infrastructure';
        const vulnerabilityType = isInfrastructure ? 'infrastructure' : 'application';

        // Save to SQLite via API
        try {
          const response = await API.post('/api/v1/vulnerabilities/excel-import', {
            vulnerabilities: processedData,
            type: vulnerabilityType
          });

          if (response.data.success) {
            // Update local state
            if (isInfrastructure) {
              setInfrastructureVulnerabilities(processedData);
            } else {
              setVulnerabilities(processedData);
            }
            
            alert(`✅ Successfully imported ${processedData.length} vulnerabilities to SQLite!`);
          } else {
            throw new Error(response.data.error || 'Import failed');
          }
        } catch (apiError) {
          console.error('API import failed:', apiError);
          // Fallback to localStorage
          if (isInfrastructure) {
            setInfrastructureVulnerabilities(processedData);
            localStorage.setItem('infrastructure_vulnerabilities', JSON.stringify(processedData));
          } else {
            setVulnerabilities(processedData);
            localStorage.setItem('excel_vulnerabilities', JSON.stringify(processedData));
          }
          alert(`⚠️ Imported ${processedData.length} vulnerabilities to local storage (API unavailable)`);
        }
      } catch (error) {
        console.error('Error processing Excel file:', error);
        alert('Error processing Excel file. Please check the file format.');
      } finally {
        setImportingExcel(false);
      }
    };

    reader.onerror = () => {
      alert('Error reading Excel file.');
      setImportingExcel(false);
    };

    reader.readAsArrayBuffer(file);
    event.target.value = '';
  };

  const downloadSampleExcel = () => {
    const isInfrastructure = activeVulnSubTab === 'infrastructure';
    
    const sampleData = isInfrastructure ? [
      ['GIS Id', 'AIT #', 'TITLE', 'Remediation Steps', 'Status'],
      ['827593952', 'AIT-001', '2551 Unsecured Database Port Exposed', 'Configure firewall rules to restrict database access to authorized networks only', 'ACTIVE'],
      ['829991671', 'AIT-002', '2552 Missing SSL/TLS Configuration', 'Install and configure SSL certificates with proper TLS settings', 'ACTIVE'],
      ['843226554', 'AIT-003', '2553 Outdated Server Operating System', 'Update operating system to latest supported version and apply security patches', 'ACTIVE'],
      ['851234567', 'AIT-001', '2554 Weak Network Security Group Rules', 'Review and tighten network security group rules to follow least privilege principle', 'ACTIVE'],
      ['862345678', 'AIT-004', '2555 Missing Backup Encryption', 'Implement encrypted backup solution and secure backup storage', 'ACTIVE'],
      ['873456789', 'AIT-002', '2556 Unsecured API Endpoints', 'Implement API authentication and rate limiting', 'ACTIVE'],
      ['884567890', 'AIT-005', '2557 Missing Security Headers', 'Configure security headers (HSTS, X-Frame-Options, etc.)', 'ACTIVE'],
      ['895678901', 'AIT-003', '2558 Insecure Container Configuration', 'Update container security settings and remove unnecessary privileges', 'ACTIVE'],
      ['906789012', 'AIT-001', '2559 Weak Encryption Algorithms', 'Upgrade to stronger encryption algorithms and key lengths', 'ACTIVE'],
      ['917890123', 'AIT-004', '2560 Missing Log Monitoring', 'Implement comprehensive logging and monitoring solution', 'ACTIVE']
    ] : [
      ['GIS Id', 'AIT #', 'TITLE', 'Remediation Steps', 'Status'],
      ['727593952', 'AIT-001', '2551 Insecure Content-Security-Policy (CSP)', 'Implement proper CSP headers with restrictive directives', 'ACTIVE'],
      ['729991671', 'AIT-002', '2551 Missing Content-Security-Policy (CSP)', 'Add Content-Security-Policy header to all HTTP responses', 'ACTIVE'],
      ['743226554', 'AIT-003', '2551 Content Security Policy Allows Unsafe in-line Scripts', 'Remove unsafe-inline from script-src directive', 'ACTIVE'],
      ['751234567', 'AIT-001', '2552 SQL Injection Vulnerability', 'Use parameterized queries and input validation', 'ACTIVE'],
      ['762345678', 'AIT-004', '2553 Cross-Site Scripting (XSS)', 'Implement input validation and output encoding', 'ACTIVE'],
      ['773456789', 'AIT-002', '2554 Hardcoded Credentials', 'Move credentials to environment variables or secure vault', 'ACTIVE'],
      ['784567890', 'AIT-005', '2555 Insecure File Upload', 'Implement file type validation and virus scanning', 'ACTIVE'],
      ['795678901', 'AIT-003', '2556 Missing Input Validation', 'Add comprehensive input validation on all user inputs', 'ACTIVE'],
      ['806789012', 'AIT-001', '2557 Weak Password Policy', 'Enforce strong password requirements and complexity rules', 'ACTIVE'],
      ['817890123', 'AIT-004', '2558 Insecure Session Management', 'Implement secure session handling with proper timeouts', 'ACTIVE']
    ];

    const ws = XLSX.utils.aoa_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    const sheetName = isInfrastructure ? 'Infrastructure_Vulnerabilities' : 'Application_Vulnerabilities';
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    
    // Auto-size columns
    const colWidths = [
      { wch: 12 }, // GIS Id
      { wch: 10 }, // AIT #
      { wch: 50 }, // TITLE
      { wch: 60 }, // Remediation Steps
      { wch: 12 }  // Status
    ];
    ws['!cols'] = colWidths;

    // Add some styling to the header row
    for (let col = 0; col < sampleData[0].length; col++) {
      const cellRef = XLSX.utils.encode_cell({ r: 0, c: col });
      if (!ws[cellRef]) continue;
      ws[cellRef].s = {
        font: { bold: true, color: { rgb: "FFFFFF" } },
        fill: { fgColor: { rgb: "4472C4" } },
        alignment: { horizontal: "center" }
      };
    }

    const filename = isInfrastructure ? 'infrastructure_vulnerability_template.xlsx' : 'application_vulnerability_template.xlsx';
    XLSX.writeFile(wb, filename);
  };

  const resetToApiData = () => {
    setExcelData([]);
    localStorage.removeItem('excel_vulnerabilities'); // Clear localStorage backup
    fetchData(); // This will fetch fresh data from the backend and properly handle the merge
    alert('Refreshed data from API and cleared local backup. Any persisted Excel data will be included.');
  };

  const clearAllVulnerabilities = () => {
    const isInfrastructure = activeVulnSubTab === 'infrastructure';
    const tabType = isInfrastructure ? 'infrastructure' : 'application';
    
    if (!window.confirm(`Are you sure you want to clear ALL ${tabType} vulnerability records? This action cannot be undone.`)) {
      return;
    }
    
    // Clear vulnerability data based on current sub-tab
    if (isInfrastructure) {
      setInfrastructureVulnerabilities([]);
      localStorage.removeItem('infrastructure_vulnerabilities');
    } else {
      setVulnerabilities([]);
      setExcelData([]);
      localStorage.removeItem('excel_vulnerabilities');
    }
    
    // Optionally clear from backend API
    try {
      // You can add API call here to clear backend data if needed
      // await API.delete('/api/v1/vulnerabilities/enhanced/clear');
    } catch (error) {
      console.error('Error clearing backend data:', error);
    }
    
    alert(`All ${tabType} vulnerability records have been cleared successfully!`);
  };

  const loadSampleInfrastructureData = () => {
    if (!window.confirm('Load sample infrastructure vulnerability data? This will replace any existing data.')) {
      return;
    }
    
    const sampleInfrastructureVulns = [
      {
        id: 'infra-001',
        gis_id: '827593952',
        ait_tag: 'AIT-001',
        title: '2551 Unsecured Database Port Exposed',
        description: 'Database port 3306 is exposed to public network without proper firewall rules',
        remediation_action: 'Configure firewall rules to restrict database access to authorized networks only',
        status: 'ACTIVE',
        severity: 'HIGH_RISK',
        risk_score: 8,
        wave_assignment: 'UNASSIGNED',
        cost_impact: 0,
        created_date: new Date().toISOString(),
        source: 'infrastructure_scan'
      },
      {
        id: 'infra-002',
        gis_id: '829991671',
        ait_tag: 'AIT-002',
        title: '2552 Missing SSL/TLS Configuration',
        description: 'Web server is not configured with proper SSL/TLS encryption',
        remediation_action: 'Install and configure SSL certificates with proper TLS settings',
        status: 'ACTIVE',
        severity: 'CRITICAL_BOMB',
        risk_score: 9,
        wave_assignment: 'UNASSIGNED',
        cost_impact: 0,
        created_date: new Date().toISOString(),
        source: 'infrastructure_scan'
      },
      {
        id: 'infra-003',
        gis_id: '843226554',
        ait_tag: 'AIT-003',
        title: '2553 Outdated Server Operating System',
        description: 'Server is running outdated OS version with known security vulnerabilities',
        remediation_action: 'Update operating system to latest supported version and apply security patches',
        status: 'ACTIVE',
        severity: 'HIGH_RISK',
        risk_score: 7,
        wave_assignment: 'UNASSIGNED',
        cost_impact: 0,
        created_date: new Date().toISOString(),
        source: 'infrastructure_scan'
      },
      {
        id: 'infra-004',
        gis_id: '851234567',
        ait_tag: 'AIT-001',
        title: '2554 Weak Network Security Group Rules',
        description: 'Network security groups allow overly permissive inbound traffic',
        remediation_action: 'Review and tighten network security group rules to follow least privilege principle',
        status: 'ACTIVE',
        severity: 'MEDIUM_RISK',
        risk_score: 6,
        wave_assignment: 'UNASSIGNED',
        cost_impact: 0,
        created_date: new Date().toISOString(),
        source: 'infrastructure_scan'
      },
      {
        id: 'infra-005',
        gis_id: '862345678',
        ait_tag: 'AIT-004',
        title: '2555 Missing Backup Encryption',
        description: 'Database backups are not encrypted and stored in unsecured location',
        remediation_action: 'Implement encrypted backup solution and secure backup storage',
        status: 'ACTIVE',
        severity: 'HIGH_RISK',
        risk_score: 8,
        wave_assignment: 'UNASSIGNED',
        cost_impact: 0,
        created_date: new Date().toISOString(),
        source: 'infrastructure_scan'
      }
    ];
    
    setInfrastructureVulnerabilities(sampleInfrastructureVulns);
    localStorage.setItem('infrastructure_vulnerabilities', JSON.stringify(sampleInfrastructureVulns));
    alert('Sample infrastructure vulnerability data loaded successfully!');
  };

  // Filter threats based on type - including security debt in tech debt
  const maliciousThreats = threats.filter((threat) => {
    // Exclude tech debt, vulnerability, and security debt types
    const threatType = threat.type?.toLowerCase() || '';
    const threatRuleId = threat.rule_id?.toLowerCase() || '';
    const threatMessage = threat.message?.toLowerCase() || '';
    
    const isTechDebt = threatType.includes('tech debt') || 
                      threatType.includes('vulnerability') ||
                      threatType.includes('security debt') ||
                      threatType.includes('security tech debt') ||
                      threatType.includes('security_tech_debt') ||
                      threatRuleId.includes('tech_debt') ||
                      threatRuleId.includes('vulnerability') ||
                      threatRuleId.includes('security_debt') ||
                      threatRuleId.includes('security_tech_debt') ||
                      threatMessage.includes('tech debt') ||
                      threatMessage.includes('vulnerability') ||
                      threatMessage.includes('security debt') ||
                      threatMessage.includes('security tech debt');
    
    // Apply hierarchical filters
    if (filterAIT && threat.ait_tag !== filterAIT) return false;
    if (filterSPK && threat.spk_tag !== filterSPK) return false;
    if (filterRepo && threat.repo_name !== filterRepo) return false;
    
    const result = !isTechDebt;
    if (threat.type) {
      console.log(`Threat ${threat.id}: type="${threat.type}", isTechDebt=${isTechDebt}, result=${result}`);
    }
    return result;
  });

  const techDebtThreats = threats.filter((threat) => {
    // Include tech debt, vulnerability, and security debt types
    const threatType = threat.type?.toLowerCase() || '';
    const threatRuleId = threat.rule_id?.toLowerCase() || '';
    const threatMessage = threat.message?.toLowerCase() || '';
    
    const isTechDebt = threatType.includes('tech debt') || 
                      threatType.includes('vulnerability') ||
                      threatType.includes('security debt') ||
                      threatType.includes('security tech debt') ||
                      threatType.includes('security_tech_debt') ||
                      threatRuleId.includes('tech_debt') ||
                      threatRuleId.includes('vulnerability') ||
                      threatRuleId.includes('security_debt') ||
                      threatRuleId.includes('security_tech_debt') ||
                      threatMessage.includes('tech debt') ||
                      threatMessage.includes('vulnerability') ||
                      threatMessage.includes('security debt') ||
                      threatMessage.includes('security tech debt');
    
    // Apply hierarchical filters
    if (filterAIT && threat.ait_tag !== filterAIT) return false;
    if (filterSPK && threat.spk_tag !== filterSPK) return false;
    if (filterRepo && threat.repo_name !== filterRepo) return false;
    
    return isTechDebt;
  });

  // Additional statistics for tech debt categories
  const hardcodedCredentials = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('hardcoded') || 
    threat.rule_id?.toLowerCase().includes('credentials') ||
    threat.debt_category === 'HARDCODED_CREDENTIALS'
  );

  const hardcodedUrls = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('url') || 
    threat.rule_id?.toLowerCase().includes('endpoint') ||
    threat.debt_category === 'HARDCODED_URLS'
  );

  const inputValidation = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('input') || 
    threat.rule_id?.toLowerCase().includes('validation') ||
    threat.debt_category === 'INPUT_VALIDATION'
  );

  const vulnerableLibraries = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('library') || 
    threat.rule_id?.toLowerCase().includes('dependency') ||
    threat.debt_category === 'VULNERABLE_LIBRARIES'
  );

  const accessControl = techDebtThreats.filter(threat => 
    threat.rule_id?.toLowerCase().includes('access') || 
    threat.rule_id?.toLowerCase().includes('control') ||
    threat.debt_category === 'ACCESS_CONTROL'
  );

  // Calculate total hours (assuming each threat has an effort field)
  const totalHours = techDebtThreats.reduce((total, threat) => {
    return total + (threat.effort || 0);
  }, 0);

  // Get current vulnerability data based on sub-tab
  const getCurrentVulnerabilityData = () => {
    return activeVulnSubTab === 'application' ? vulnerabilities : infrastructureVulnerabilities;
  };

  // Filter vulnerabilities based on selected filters
  const filteredVulnerabilities = getCurrentVulnerabilityData().filter((vuln) => {
    // Apply severity filter
    if (vulnFilterSeverity !== 'ALL' && vuln.severity !== vulnFilterSeverity) return false;
    
    // Apply status filter
    if (vulnFilterStatus !== 'ALL') {
      const vulnStatus = vuln.status || 'ACTIVE';
      if (vulnFilterStatus === 'ACTIVE' && vulnStatus !== 'ACTIVE') return false;
      if (vulnFilterStatus === 'NEUTRALIZED' && vulnStatus !== 'NEUTRALIZED') return false;
      if (vulnFilterStatus === 'RESOLVED' && vulnStatus !== 'RESOLVED') return false;
    }
    
    return true;
  });

  // Vulnerability statistics based on new table structure
  const activeVulnerabilities = filteredVulnerabilities.filter(v => (v.status || 'ACTIVE') === 'ACTIVE');
  const neutralizedVulnerabilities = filteredVulnerabilities.filter(v => v.status === 'NEUTRALIZED');
  const resolvedVulnerabilities = filteredVulnerabilities.filter(v => v.status === 'RESOLVED');
  
  // AIT-based statistics
  const aitCounts = {};
  filteredVulnerabilities.forEach(v => {
    const ait = v.ait_tag || 'Unknown';
    aitCounts[ait] = (aitCounts[ait] || 0) + 1;
  });
  const topAIT = Object.keys(aitCounts).reduce((a, b) => aitCounts[a] > aitCounts[b] ? a : b, 'Unknown');
  
  // Vulnerability type statistics (based on title patterns and sub-tab)
  const cspVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && v.title.toLowerCase().includes('content-security-policy')
  );
  const sqlInjectionVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && v.title.toLowerCase().includes('sql injection')
  );
  const xssVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && (v.title.toLowerCase().includes('xss') || v.title.toLowerCase().includes('cross-site'))
  );
  const credentialVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && (v.title.toLowerCase().includes('credential') || v.title.toLowerCase().includes('password'))
  );
  
  // Infrastructure-specific vulnerability types
  const sslVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && (v.title.toLowerCase().includes('ssl') || v.title.toLowerCase().includes('tls'))
  );
  const networkVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && (v.title.toLowerCase().includes('network') || v.title.toLowerCase().includes('firewall') || v.title.toLowerCase().includes('port'))
  );
  const osVulnerabilities = filteredVulnerabilities.filter(v => 
    v.title && (v.title.toLowerCase().includes('operating system') || v.title.toLowerCase().includes('server'))
  );
  
  // Calculate total vulnerabilities
  const totalVulnerabilities = filteredVulnerabilities.length;
  
  // Calculate completion rate
  const completionRate = totalVulnerabilities > 0 
    ? ((resolvedVulnerabilities.length + neutralizedVulnerabilities.length) / totalVulnerabilities * 100).toFixed(1)
    : 0;

  // Get current data based on active tabs
  const getCurrentData = () => {
    if (activeTab === "issue") {
      if (activeSubTab === "malicious") {
        // If no malicious threats found, show all threats
        return maliciousThreats.length > 0 ? maliciousThreats : threats;
      } else {
        // If no tech debt threats found, show all threats
        return techDebtThreats.length > 0 ? techDebtThreats : threats;
      }
    } else {
      return filteredVulnerabilities;
    }
  };

  const currentData = getCurrentData();

  // Calculate paginated data
  const totalPages = Math.ceil(currentData.length / pageSize) || 1;
  const paginatedData = currentData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Reset to page 1 if filters change
  useEffect(() => { setCurrentPage(1); }, [activeTab, activeSubTab, activeVulnSubTab, filterAIT, filterSPK, filterRepo, vulnFilterSeverity, vulnFilterStatus, pageSize, currentData.length]);

  // Responsive pagination window logic
  function getPaginationWindow(current, total) {
    const windowSize = 3;
    let pages = [];
    if (total <= 7) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      pages.push(1);
      let start = Math.max(2, current - windowSize);
      let end = Math.min(total - 1, current + windowSize);
      if (start > 2) pages.push('ellipsis-prev');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < total - 1) pages.push('ellipsis-next');
      pages.push(total);
    }
    return pages;
  }

  const renderThreatTable = (data) => (
    <div className="table-responsive">
      <table className="table table-bordered table-hover align-middle">
        <thead className="table-light">
          <tr className="text-center">
            <th>Threat Level</th>
            <th>Type</th>
            <th>AIT</th>
            <th>SPK</th>
            <th>Repository</th>
            <th style={{minWidth: "150px"}}>File Name</th>
            <th>Line #</th>
            <th>Code Snippet</th>
            <th>Status</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.length > 0 ? (
            data.map((threat) => (
              <tr key={threat.id}>
                <td>
                  {(() => {
                    let badgeClass = "border-secondary text-secondary bg-secondary-subtle";
                    if (threat.severity === "CRITICAL_BOMB") {
                      badgeClass = "border-danger text-danger bg-danger-subtle";
                    } else if (threat.severity === "HIGH_RISK") {
                      badgeClass = "border-warning text-warning bg-warning-subtle";
                    } else if (threat.severity === "MEDIUM_RISK") {
                      badgeClass = "border-info text-info bg-info-subtle";
                    }
                    return (
                      <span className={`badge border ${badgeClass}`}>
                        {threat.severity}
                      </span>
                    );
                  })()}
                </td>
                <td>
                  <span className="badge bg-primary">{threat.type}</span>
                </td>
                <td>
                  <small>{getAITName(threat.ait_tag) || threat.ait_tag || "AIT"}</small>
                </td>
                <td>
                  <small>{getSPKName(threat.spk_tag) || threat.spk_tag || "SPK"}</small>
                </td>
                <td>
                  <small>{getRepoName(threat.repo_name) || threat.repo_name || "Repo"}</small>
                </td>
                <td>
                  <code className="small">{threat.file_path}</code>
                </td>
                <td className="text-center">{threat.line_number}</td>
                <td>
                  <code className="small" style={{ maxWidth: "200px", overflow: "hidden", textOverflow: "ellipsis", display: "block" }}>
                    {threat.code_snippet}
                  </code>
                </td>
                <td>
                  <span className={`badge ${threat.status === "ACTIVE_THREAT" ? "bg-danger" : "bg-success"}`}>
                    {threat.status}
                  </span>
                </td>
                <td className="text-center">
                  <div className="btn-group btn-group-sm" role="group">
                    <button
                      className="btn btn-outline-info"
                      onClick={() => showDetails(threat)}
                      title="View Details"
                    >
                      <FaInfoCircle />
                    </button>
                    {threat.status === "ACTIVE_THREAT" ? (
                      <button
                        className="btn btn-outline-success"
                        onClick={() => neutralizeThreat(threat.id)}
                        title="Neutralize Threat"
                      >
                        <FaCheck />
                      </button>
                    ) : (
                      <button
                        className="btn btn-outline-warning"
                        onClick={() => revertThreat(threat.id)}
                        title="Revert Threat"
                      >
                        <FaUndo />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="10" className="text-center text-muted">
                No {activeSubTab === "malicious" ? "malicious threats" : "tech debt issues"} found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  const renderVulnerabilityTable = (data) => (
    <div className="table-responsive">
      <table className="table table-bordered table-hover align-middle">
        <thead className="table-light">
          <tr className="text-center">
            <th>GIS Id</th>
            <th>AIT #</th>
            <th>TITLE</th>
            <th>Remediation Steps</th>
            <th>Status</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.length > 0 ? (
            data.map((vuln) => (
              <tr key={vuln.id}>
                <td>
                  <code className="small">{vuln.gis_id || vuln.id?.substring(0, 8)}...</code>
                </td>
                <td>
                  <span className="badge bg-secondary">{vuln.ait_tag || 'AIT-Unknown'}</span>
                </td>
                <td>
                  <div>
                    <strong>{vuln.title || vuln.description}</strong>
                  </div>
                </td>
                <td>
                  <small>{vuln.remediation_action || 'Update to latest version'}</small>
                </td>
                <td>
                  <span className={`badge ${(vuln.status || 'ACTIVE') === 'ACTIVE' ? 'bg-danger' : 'bg-success'}`}>
                    {vuln.status || 'ACTIVE'}
                  </span>
                </td>
                <td className="text-center">
                  <div className="btn-group btn-group-sm" role="group">
                    <button
                      className="btn btn-outline-info"
                      onClick={() => showVulnerabilityDetails(vuln)}
                      title="View Details"
                    >
                      <FaInfoCircle />
                    </button>
                    {(vuln.status || 'ACTIVE') === 'ACTIVE' ? (
                      <button
                        className="btn btn-outline-success"
                        onClick={() => neutralizeVulnerability(vuln.id)}
                        title="Neutralize Vulnerability"
                      >
                        <FaCheck />
                      </button>
                    ) : (
                      <button
                        className="btn btn-outline-warning"
                        onClick={() => revertVulnerability(vuln.id)}
                        title="Revert Vulnerability"
                      >
                        <FaUndo />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="text-center text-muted">
                No vulnerabilities found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );

  // Details Popup Component
  const DetailsPopup = () => {
    if (!selectedThreat) return null;

    return (
      <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
        <div className="modal-dialog modal-lg" style={{ zIndex: 1055 }}>
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Threat Details</h5>
              <button type="button" className="btn-close" onClick={closeDetails}></button>
            </div>
            <div className="modal-body">
              <div className="row">
                <div className="col-md-6">
                  <h6>Basic Information</h6>
                  <table className="table table-sm">
                    <tbody>
                      <tr><td><strong>ID:</strong></td><td>{selectedThreat.id}</td></tr>
                      <tr><td><strong>Type:</strong></td><td><span className="badge bg-primary">{selectedThreat.type}</span></td></tr>
                      <tr><td><strong>Severity:</strong></td><td>
                        <span className={`badge ${
                          selectedThreat.severity === "CRITICAL_BOMB" ? "bg-danger" :
                          selectedThreat.severity === "HIGH_RISK" ? "bg-warning" :
                          selectedThreat.severity === "MEDIUM_RISK" ? "bg-info" : "bg-secondary"
                        }`}>
                          {selectedThreat.severity}
                        </span>
                      </td></tr>
                      <tr><td><strong>Status:</strong></td><td>
                        <span className={`badge ${selectedThreat.status === "ACTIVE_THREAT" ? "bg-danger" : "bg-success"}`}>
                          {selectedThreat.status}
                        </span>
                      </td></tr>
                      <tr><td><strong>Rule ID:</strong></td><td>{selectedThreat.rule_id || 'N/A'}</td></tr>
                    </tbody>
                  </table>
                </div>
                <div className="col-md-6">
                  <h6>Project Information</h6>
                  <table className="table table-sm">
                    <tbody>
                      <tr><td><strong>AIT:</strong></td><td>{getAITName(selectedThreat.ait_tag) || selectedThreat.ait_tag || 'N/A'}</td></tr>
                      <tr><td><strong>SPK:</strong></td><td>{getSPKName(selectedThreat.spk_tag) || selectedThreat.spk_tag || 'N/A'}</td></tr>
                      <tr><td><strong>Repository:</strong></td><td>{getRepoName(selectedThreat.repo_name) || selectedThreat.repo_name || 'N/A'}</td></tr>
                      <tr><td><strong>File Path:</strong></td><td><code>{selectedThreat.file_path}</code></td></tr>
                      <tr><td><strong>Line Number:</strong></td><td>{selectedThreat.line_number}</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="row mt-3">
                <div className="col-12">
                  <h6>Code Snippet</h6>
                  <pre className="bg-light p-3 rounded" style={{ fontSize: '0.9em' }}>
                    <code>{selectedThreat.code_snippet}</code>
                  </pre>
                </div>
              </div>
              {selectedThreat.message && (
                <div className="row mt-3">
                  <div className="col-12">
                    <h6>Message</h6>
                    <p className="text-muted">{selectedThreat.message}</p>
                  </div>
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={closeDetails}>Close</button>
            </div>
          </div>
        </div>
        <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
      </div>
         );
   };

   // Vulnerability Details Popup Component
   const VulnerabilityDetailsPopup = () => {
     if (!selectedVulnerability) return null;



     return (
       <div className="modal fade show" style={{ display: 'block', zIndex: 1050 }} tabIndex="-1">
         <div className="modal-dialog modal-xl" style={{ zIndex: 1055, maxWidth: '90vw' }}>
           <div className="modal-content">
             <div className="modal-header">
               <h5 className="modal-title">Vulnerability Details</h5>
               <button type="button" className="btn-close" onClick={closeVulnerabilityDetails}></button>
             </div>
             <div className="modal-body" style={{ padding: '1.5rem' }}>
               <div className="row g-4">
                 <div className="col-lg-6">
                   <div className="card h-100">
                     <div className="card-header">
                       <h6 className="mb-0">Basic Information</h6>
                     </div>
                     <div className="card-body">
                       <div className="mb-3">
                         <label className="form-label fw-bold">GIS Id:</label>
                         <div className="p-2 bg-light rounded">
                           <code>{selectedVulnerability.gis_id || selectedVulnerability.id}</code>
                         </div>
                       </div>
                       <div className="mb-3">
                         <label className="form-label fw-bold">AIT #:</label>
                         <div className="p-2 bg-light rounded">
                           <span className="badge bg-secondary fs-6">{selectedVulnerability.ait_tag || 'AIT-Unknown'}</span>
                         </div>
                       </div>
                       <div className="mb-3">
                         <label className="form-label fw-bold">Status:</label>
                         <div className="p-2 bg-light rounded">
                           <span className={`badge fs-6 ${selectedVulnerability.status === "ACTIVE" ? "bg-danger" : "bg-success"}`}>
                             {selectedVulnerability.status || 'ACTIVE'}
                           </span>
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
                 <div className="col-lg-6">
                   <div className="card h-100">
                     <div className="card-header">
                       <h6 className="mb-0">Vulnerability Details</h6>
                     </div>
                     <div className="card-body">
                       <div className="mb-3">
                         <label className="form-label fw-bold">Title:</label>
                         <div className="p-3 bg-light rounded" style={{ minHeight: '60px', wordWrap: 'break-word' }}>
                           <strong>{selectedVulnerability.title || selectedVulnerability.description}</strong>
                         </div>
                       </div>
                       <div className="mb-3">
                         <label className="form-label fw-bold">Remediation Steps:</label>
                         <div className="p-3 bg-light rounded" style={{ minHeight: '80px', wordWrap: 'break-word' }}>
                           <small className="text-muted">{selectedVulnerability.remediation_action || 'Update to latest version'}</small>
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
             <div className="modal-footer">
               <button type="button" className="btn btn-secondary" onClick={closeVulnerabilityDetails}>Close</button>
             </div>
           </div>
         </div>
         <div className="modal-backdrop fade show" style={{ zIndex: 1040 }}></div>
       </div>
     );
   };

   return (
    <div style={{ background: "#fff", color: "#222", minHeight: "100vh" }}>
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 style={{ color: "#0d6efd" }}>🚨 Active Threats Management</h2>
        <button className="btn btn-outline-primary" onClick={fetchData}>
          <FaEye className="me-1" />
          Refresh
        </button>
      </div>

      {/* Main Tab Navigation */}
      <div className="row mb-4">
        <div className="col-12">
          <ul className="nav nav-tabs" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'issue' ? 'active' : ''}`}
                onClick={() => setActiveTab('issue')}
                type="button"
                role="tab"
              >
                <FaShieldAlt className="me-2" />
                Issue Management
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link ${activeTab === 'vulnerability' ? 'active' : ''}`}
                onClick={() => setActiveTab('vulnerability')}
                type="button"
                role="tab"
              >
                <FaBug className="me-2" />
                Vulnerability Management
              </button>
            </li>
          </ul>
        </div>
      </div>

             {/* Filter Controls */}
       {activeTab === 'issue' ? (
         <div className="mb-4 p-3 bg-light rounded">
           <h6 className="mb-2" style={{ color: "#222" }}>
             <FaFilter className="me-2" /> Filter by Project Hierarchy
           </h6>
           <div className="row g-2">
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterAIT}
                 onChange={(e) => setFilterAIT(e.target.value)}
               >
                 <option value="">All AITs</option>
                 {Array.from(new Set(threats.map(t => t.ait_tag).filter(Boolean))).map(ait => (
                   <option key={ait} value={ait}>{getAITName(ait)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterSPK}
                 onChange={(e) => setFilterSPK(e.target.value)}
               >
                 <option value="">All SPKs</option>
                 {Array.from(new Set(threats.map(t => t.spk_tag).filter(Boolean))).map(spk => (
                   <option key={spk} value={spk}>{getSPKName(spk)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <select
                 className="form-select form-select-sm"
                 value={filterRepo}
                 onChange={(e) => setFilterRepo(e.target.value)}
               >
                 <option value="">All Repositories</option>
                 {Array.from(new Set(threats.map(t => t.repo_name).filter(Boolean))).map(repo => (
                   <option key={repo} value={repo}>{getRepoName(repo)}</option>
                 ))}
               </select>
             </div>
             <div className="col-md-3">
               <button
                 className="btn btn-outline-secondary btn-sm w-100"
                 onClick={() => {
                   setFilterAIT('');
                   setFilterSPK('');
                   setFilterRepo('');
                 }}
               >
                 <FaTimesCircle className="me-1" /> Clear Filters
               </button>
             </div>
           </div>
           {(filterAIT || filterSPK || filterRepo) && (
             <div className="mt-2">
               <small className="text-muted">
                 Showing {currentData.length} of {threats.length} items
               </small>
             </div>
           )}
         </div>
       ) : (
         <div className="mb-4 p-3 bg-light rounded">
           <h6 className="mb-2" style={{ color: "#222" }}>
             <FaFilter className="me-2" /> Filter Vulnerabilities
           </h6>
           <div className="row g-2 mb-3">
             <div className="col-md-4">
               <select
                 className="form-select form-select-sm"
                 value={vulnFilterSeverity}
                 onChange={(e) => setVulnFilterSeverity(e.target.value)}
               >
                 <option value="ALL">All Severities</option>
                 <option value="CRITICAL_BOMB">Critical Bomb</option>
                 <option value="HIGH_RISK">High Risk</option>
                 <option value="MEDIUM_RISK">Medium Risk</option>
                 <option value="LOW_RISK">Low Risk</option>
                 <option value="SUSPICIOUS">Suspicious</option>
               </select>
             </div>
             <div className="col-md-4">
               <select
                 className="form-select form-select-sm"
                 value={vulnFilterStatus}
                 onChange={(e) => setVulnFilterStatus(e.target.value)}
               >
                 <option value="ALL">All Statuses</option>
                 <option value="ACTIVE">Active</option>
                 <option value="NEUTRALIZED">Neutralized</option>
                 <option value="RESOLVED">Resolved</option>
               </select>
             </div>
             <div className="col-md-4">
               <button
                 className="btn btn-outline-secondary btn-sm w-100"
                 onClick={() => {
                   setVulnFilterSeverity('ALL');
                   setVulnFilterStatus('ALL');
                 }}
               >
                 <FaTimesCircle className="me-1" /> Clear Filters
               </button>
             </div>
           </div>
           
           {/* Excel Import Section */}
           <div className="row g-2 mb-3">
             <div className="col-md-12">
               <div className="d-flex gap-2 align-items-center">
                 <span className="text-muted small">📊 Excel Import:</span>
                 {excelData.length > 0 && (
                   <span className="badge bg-success">
                     {excelData.length} Excel records loaded
                   </span>
                 )}
                 {localStorage.getItem('excel_vulnerabilities') && (
                   <span className="badge bg-info">
                     📁 Persisted
                   </span>
                 )}
                 <button 
                   className="btn btn-outline-primary btn-sm"
                   onClick={downloadSampleExcel}
                   title="Download sample Excel template"
                 >
                   📥 Download Template
                 </button>
                 <div className="excel-upload-container">
                   <input
                     type="file"
                     id="excel-upload"
                     accept=".xlsx,.xls"
                     onChange={handleExcelUpload}
                     style={{ display: 'none' }}
                   />
                   <label 
                     htmlFor="excel-upload" 
                     className="btn btn-success btn-sm"
                     title="Upload Excel file to populate vulnerability table"
                   >
                     {importingExcel ? '📊 Importing...' : '📊 Fetch from Excel'}
                   </label>
                 </div>
                 <button 
                   className="btn btn-outline-danger btn-sm"
                   onClick={clearAllVulnerabilities}
                   title="Clear all vulnerability records"
                 >
                   🗑️ Clear All
                 </button>
                 {activeVulnSubTab === 'infrastructure' && (
                   <button 
                     className="btn btn-outline-info btn-sm"
                     onClick={loadSampleInfrastructureData}
                     title="Load sample infrastructure vulnerability data"
                   >
                     📋 Load Sample Data
                   </button>
                 )}
               </div>
             </div>
           </div>
         </div>
       )}

             {/* Statistics Cards - First Row */}
       {activeTab === 'issue' ? (
         <div className="row g-4 mb-4">
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-danger">{maliciousThreats.length}</h3>
                 <p className="card-text">Malicious Threats</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-warning">{techDebtThreats.length}</h3>
                 <p className="card-text">Tech Debt Issues</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-info">{vulnerabilities.length}</h3>
                 <p className="card-text">Vulnerabilities</p>
               </div>
             </div>
           </div>
           <div className="col-md-3">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{threats.filter(t => t.status === 'NEUTRALIZED').length}</h3>
                 <p className="card-text">Resolved</p>
               </div>
             </div>
           </div>
         </div>
       ) : (
         <div className="row g-4 mb-4">
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-primary">{totalVulnerabilities}</h3>
                 <p className="card-text">Total Vulnerabilities</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-danger">{activeVulnerabilities.length}</h3>
                 <p className="card-text">Active</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{neutralizedVulnerabilities.length}</h3>
                 <p className="card-text">Neutralized</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-info">{resolvedVulnerabilities.length}</h3>
                 <p className="card-text">Resolved</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-warning">{cspVulnerabilities.length}</h3>
                 <p className="card-text">CSP Issues</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-secondary">{completionRate}%</h3>
                 <p className="card-text">Completion Rate</p>
               </div>
             </div>
           </div>
         </div>
       )}

             {/* Statistics Cards - Second Row */}
       {activeTab === 'issue' ? (
         <div className="row g-4 mb-4">
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-primary">{hardcodedCredentials.length}</h3>
                 <p className="card-text">Hardcoded Credentials</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-secondary">{hardcodedUrls.length}</h3>
                 <p className="card-text">Hardcoded URLs</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-dark">{inputValidation.length}</h3>
                 <p className="card-text">Input Validation</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-muted">{vulnerableLibraries.length}</h3>
                 <p className="card-text">Vulnerable Libraries</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-body">{accessControl.length}</h3>
                 <p className="card-text">Access Control</p>
               </div>
             </div>
           </div>
           <div className="col-md-2">
             <div className="card text-center shadow-sm">
               <div className="card-body">
                 <h3 className="text-success">{totalHours}</h3>
                 <p className="card-text">Total Hours</p>
               </div>
             </div>
           </div>
         </div>
               ) : (
          <div className="row g-4 mb-4">
            {activeVulnSubTab === 'application' ? (
              <>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-danger">{sqlInjectionVulnerabilities.length}</h3>
                      <p className="card-text">SQL Injection</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-warning">{xssVulnerabilities.length}</h3>
                      <p className="card-text">XSS Issues</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-info">{credentialVulnerabilities.length}</h3>
                      <p className="card-text">Credential Issues</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-secondary">{topAIT}</h3>
                      <p className="card-text">Top AIT</p>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-danger">{sslVulnerabilities.length}</h3>
                      <p className="card-text">SSL/TLS Issues</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-warning">{networkVulnerabilities.length}</h3>
                      <p className="card-text">Network Issues</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-info">{osVulnerabilities.length}</h3>
                      <p className="card-text">OS Issues</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="card text-center shadow-sm">
                    <div className="card-body">
                      <h3 className="text-secondary">{topAIT}</h3>
                      <p className="card-text">Top AIT</p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

      {/* Table Content */}
      <div className="card shadow-sm">
        <div className="card-header">
          <h5 className="mb-0">
            {activeTab === 'issue' ? 
              (activeSubTab === 'malicious' ? '🚨 Malicious Threats' : '📄 Tech Debt & Vulnerabilities') :
              '🐛 Vulnerability Management'
            }
          </h5>
        </div>
        
        {/* Sub-tab Navigation for Issue Management - Now immediately above table */}
        {activeTab === 'issue' && (
          <div className="card-body border-bottom">
            <ul className="nav nav-pills" role="tablist">
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeSubTab === 'malicious' ? 'active' : ''}`}
                  onClick={() => setActiveSubTab('malicious')}
                  type="button"
                  role="tab"
                >
                  <FaExclamationTriangle className="me-2" />
                  🚨 Malicious Threats ({maliciousThreats.length})
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeSubTab === 'techdebt' ? 'active' : ''}`}
                  onClick={() => setActiveSubTab('techdebt')}
                  type="button"
                  role="tab"
                >
                  <FaTools className="me-2" />
                  📄 Tech Debt & Vulnerabilities ({techDebtThreats.length})
                </button>
              </li>
            </ul>
          </div>
        )}
        
        {/* Sub-tab Navigation for Vulnerability Management */}
        {activeTab === 'vulnerability' && (
          <div className="card-body border-bottom">
            <ul className="nav nav-pills" role="tablist">
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeVulnSubTab === 'application' ? 'active' : ''}`}
                  onClick={() => setActiveVulnSubTab('application')}
                  type="button"
                  role="tab"
                >
                  <FaBug className="me-2" />
                  🐛 Application Vulnerabilities ({vulnerabilities.length})
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link ${activeVulnSubTab === 'infrastructure' ? 'active' : ''}`}
                  onClick={() => setActiveVulnSubTab('infrastructure')}
                  type="button"
                  role="tab"
                >
                  <FaServer className="me-2" />
                  🖥️ Infrastructure Vulnerabilities ({infrastructureVulnerabilities.length})
                </button>
              </li>
            </ul>
          </div>
        )}
        
        <div className="card-body">
          {activeTab === 'issue' ? renderThreatTable(paginatedData) : renderVulnerabilityTable(paginatedData)}
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-center mt-4">
          <nav>
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button
                  className="page-link"
                  onClick={() => setCurrentPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
              </li>
              
              {getPaginationWindow(currentPage, totalPages).map((page, index) => (
                <li key={index} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                  {page === 'ellipsis-prev' || page === 'ellipsis-next' ? (
                    <span className="page-link">...</span>
                  ) : (
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </button>
                  )}
                </li>
              ))}
              
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button
                  className="page-link"
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

             {/* Details Popup */}
       {showDetailsPopup && <DetailsPopup />}
       
       {/* Vulnerability Details Popup */}
       {showVulnerabilityDetailsPopup && <VulnerabilityDetailsPopup />}
    </div>
  );
};

export default ActiveThreatsManagement;
