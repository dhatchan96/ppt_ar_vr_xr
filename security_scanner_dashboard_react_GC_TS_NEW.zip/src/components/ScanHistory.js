import React, { useEffect, useState } from 'react';
import API from '../api';
import '../style.css';
import { FaFilter, FaTimes, FaDownload, FaEye } from 'react-icons/fa';

const ScanHistory = () => {
  const [history, setHistory] = useState([]);
  const [filteredHistory, setFilteredHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filter states
  const [filterAIT, setFilterAIT] = useState('');
  const [filterSPK, setFilterSPK] = useState('');
  const [filterRepo, setFilterRepo] = useState('');
  const [filterSource, setFilterSource] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Unique values for dropdowns
  const [uniqueAITs, setUniqueAITs] = useState([]);
  const [uniqueSPKs, setUniqueSPKs] = useState([]);
  const [uniqueRepos, setUniqueRepos] = useState([]);
  const [uniqueSources, setUniqueSources] = useState([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [history, filterAIT, filterSPK, filterRepo, filterSource]);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const res = await API.get('/api/scan-history');
      
      if (res.data && res.data.scan_history) {
        const scanHistory = res.data.scan_history.sort((a, b) => 
          new Date(b.timestamp) - new Date(a.timestamp)
        );
        setHistory(scanHistory);
        
        // Extract unique values for filters
        const aits = Array.from(new Set(scanHistory.map(s => s.ait_tag).filter(Boolean)));
        const spks = Array.from(new Set(scanHistory.map(s => s.spk_tag).filter(Boolean)));
        const repos = Array.from(new Set(scanHistory.map(s => s.repo_name).filter(Boolean)));
        const sources = Array.from(new Set(scanHistory.map(s => s.source).filter(Boolean)));
        
        setUniqueAITs(aits);
        setUniqueSPKs(spks);
        setUniqueRepos(repos);
        setUniqueSources(sources);
      }
    } catch (error) {
      console.error('Failed to fetch scan history:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...history];
    
    if (filterAIT) {
      filtered = filtered.filter(scan => scan.ait_tag === filterAIT);
    }
    
    if (filterSPK) {
      filtered = filtered.filter(scan => scan.spk_tag === filterSPK);
    }
    
    if (filterRepo) {
      filtered = filtered.filter(scan => scan.repo_name === filterRepo);
    }
    
    if (filterSource) {
      filtered = filtered.filter(scan => scan.source === filterSource);
    }
    
    setFilteredHistory(filtered);
  };

  const clearFilters = () => {
    setFilterAIT('');
    setFilterSPK('');
    setFilterRepo('');
    setFilterSource('');
  };

  const getDisplayName = (value, type) => {
    if (!value) return 'Unknown';
    
    switch (type) {
      case 'ait':
        return value === 'AIT' ? 'Default AIT' : value;
      case 'spk':
        return value === 'SPK-DEFAULT' ? 'Default SPK' : value;
      case 'repo':
        return value === 'unknown-repo' ? 'Unknown Repository' : value;
      case 'source':
        return value === 'main_scan' ? 'Repository Scan' : 
               value === 'vscode_extension' ? 'VSCode Extension' : value;
      default:
        return value;
    }
  };

  const getStatusBadge = (status) => {
    const statusClass = status === 'PASSED' ? 'success' : 
                       status === 'BLOCKED' ? 'danger' : 
                       status === 'WARNING' ? 'warning' : 'secondary';
    return <span className={`badge bg-${statusClass}`}>{status}</span>;
  };

  const getThreatLevelBadge = (level) => {
    const levelClass = level === 'CRITICAL' ? 'danger' : 
                      level === 'HIGH' ? 'warning' : 
                      level === 'MEDIUM' ? 'info' : 
                      level === 'LOW' ? 'success' : 'secondary';
    return <span className={`badge bg-${levelClass}`}>{level}</span>;
  };

  if (loading) {
    return (
      <div className="container-fluid mt-4 px-5">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading scan history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid mt-4 px-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>📋 Scan History</h2>
        <div className="d-flex gap-2">
          <button 
            className={`btn btn-outline-primary btn-sm ${showFilters ? 'active' : ''}`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <FaFilter className="me-1" />
            Filters
          </button>
          <button 
            className="btn btn-outline-secondary btn-sm"
            onClick={clearFilters}
            disabled={!filterAIT && !filterSPK && !filterRepo && !filterSource}
          >
            <FaTimes className="me-1" />
            Clear
          </button>
        </div>
      </div>

      {/* Filter Section */}
      {showFilters && (
        <div className="card mb-4">
          <div className="card-header">
            <h6 className="mb-0">
              <FaFilter className="me-2" />
              Filter Scan History
            </h6>
          </div>
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label">AIT (Application Integration Team)</label>
                <select
                  className="form-select"
                  value={filterAIT}
                  onChange={(e) => setFilterAIT(e.target.value)}
                >
                  <option value="">All AITs</option>
                  {uniqueAITs.map(ait => (
                    <option key={ait} value={ait}>
                      {getDisplayName(ait, 'ait')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">SPK (Specific Product/Workstream Key)</label>
                <select
                  className="form-select"
                  value={filterSPK}
                  onChange={(e) => setFilterSPK(e.target.value)}
                >
                  <option value="">All SPKs</option>
                  {uniqueSPKs.map(spk => (
                    <option key={spk} value={spk}>
                      {getDisplayName(spk, 'spk')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">Repository Name</label>
                <select
                  className="form-select"
                  value={filterRepo}
                  onChange={(e) => setFilterRepo(e.target.value)}
                >
                  <option value="">All Repositories</option>
                  {uniqueRepos.map(repo => (
                    <option key={repo} value={repo}>
                      {getDisplayName(repo, 'repo')}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="col-md-3">
                <label className="form-label">Scan Source</label>
                <select
                  className="form-select"
                  value={filterSource}
                  onChange={(e) => setFilterSource(e.target.value)}
                >
                  <option value="">All Sources</option>
                  {uniqueSources.map(source => (
                    <option key={source} value={source}>
                      {getDisplayName(source, 'source')}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            {/* Active Filters Display */}
            {(filterAIT || filterSPK || filterRepo || filterSource) && (
              <div className="mt-3">
                <small className="text-muted">Active filters:</small>
                <div className="d-flex flex-wrap gap-2 mt-1">
                  {filterAIT && (
                    <span className="badge bg-primary">
                      AIT: {getDisplayName(filterAIT, 'ait')}
                    </span>
                  )}
                  {filterSPK && (
                    <span className="badge bg-info">
                      SPK: {getDisplayName(filterSPK, 'spk')}
                    </span>
                  )}
                  {filterRepo && (
                    <span className="badge bg-success">
                      Repo: {getDisplayName(filterRepo, 'repo')}
                    </span>
                  )}
                  {filterSource && (
                    <span className="badge bg-warning">
                      Source: {getDisplayName(filterSource, 'source')}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Statistics Summary */}
      <div className="row mb-4">
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-primary">{filteredHistory.length}</h4>
              <small className="text-muted">Filtered Scans</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-success">{history.length}</h4>
              <small className="text-muted">Total Scans</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-warning">
                {filteredHistory.reduce((sum, scan) => sum + (scan.issues_found || scan.logic_bombs || 0), 0)}
              </h4>
              <small className="text-muted">Total Issues</small>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card text-center">
            <div className="card-body">
              <h4 className="text-info">
                {filteredHistory.length > 0 ? 
                  Math.round(filteredHistory.reduce((sum, scan) => sum + (scan.duration_ms || 0), 0) / filteredHistory.length / 1000 * 100) / 100 : 0
                }s
              </h4>
              <small className="text-muted">Avg Duration</small>
            </div>
          </div>
        </div>
      </div>

      {/* Scan History Table */}
      <div className="card">
        <div className="card-header">
          <h6 className="mb-0">
            <FaEye className="me-2" />
            Scan Results ({filteredHistory.length} of {history.length} scans)
          </h6>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-hover mb-0">
              <thead className="table-light">
                <tr>
                  <th>#</th>
                  <th>Project/Repo</th>
                  <th>AIT</th>
                  <th>SPK</th>
                  <th>Source</th>
                  <th>Timestamp</th>
                  <th>Files</th>
                  <th>Issues</th>
                  <th>Risk Score</th>
                  <th>Threat Level</th>
                  <th>Quality Gate</th>
                  <th>Duration</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredHistory.length > 0 ? (
                  filteredHistory.map((scan, index) => (
                    <tr key={scan.scan_id}>
                      <td>{index + 1}</td>
                      <td>
                        <div>
                          <strong>{scan.project_id || scan.repo_name || 'Unknown'}</strong>
                          {scan.file_name && (
                            <div><small className="text-muted">{scan.file_name}</small></div>
                          )}
                        </div>
                      </td>
                      <td>
                        <span className="badge bg-primary">
                          {getDisplayName(scan.ait_tag, 'ait')}
                        </span>
                      </td>
                      <td>
                        <span className="badge bg-info">
                          {getDisplayName(scan.spk_tag, 'spk')}
                        </span>
                      </td>
                      <td>
                        <span className="badge bg-secondary">
                          {getDisplayName(scan.source, 'source')}
                        </span>
                      </td>
                      <td>
                        <small>
                          {new Date(scan.timestamp).toLocaleDateString()}<br/>
                          {new Date(scan.timestamp).toLocaleTimeString()}
                        </small>
                      </td>
                      <td>{scan.files_scanned || 1}</td>
                      <td>
                        <span className={`badge ${(scan.issues_found || scan.logic_bombs || 0) > 0 ? 'bg-danger' : 'bg-success'}`}>
                          {scan.issues_found || scan.logic_bombs || 0}
                        </span>
                      </td>
                      <td>
                        {scan.logic_bomb_risk_score ? (
                          <span className={`badge ${scan.logic_bomb_risk_score > 7 ? 'bg-danger' : 
                                               scan.logic_bomb_risk_score > 4 ? 'bg-warning' : 'bg-success'}`}>
                            {scan.logic_bomb_risk_score.toFixed(1)}
                          </span>
                        ) : (
                          <span className="badge bg-secondary">N/A</span>
                        )}
                      </td>
                      <td>
                        {scan.threat_level ? getThreatLevelBadge(scan.threat_level) : (
                          <span className="badge bg-secondary">N/A</span>
                        )}
                      </td>
                      <td>
                        {scan.quality_gate_status ? getStatusBadge(scan.quality_gate_status) : (
                          <span className="badge bg-secondary">N/A</span>
                        )}
                      </td>
                      <td>
                        <small>{(scan.duration_ms / 1000).toFixed(2)}s</small>
                      </td>
                      <td>
                        <div className="btn-group btn-group-sm">
                          <button 
                            className="btn btn-outline-primary"
                            title="View Details"
                            onClick={() => console.log('View scan details:', scan.scan_id)}
                          >
                            <FaEye />
                          </button>
                          <button 
                            className="btn btn-outline-secondary"
                            title="Download Report"
                            onClick={() => console.log('Download report for:', scan.scan_id)}
                          >
                            <FaDownload />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="12" className="text-center py-4">
                      <div className="text-muted">
                        {history.length === 0 ? 'No scan history available.' : 'No scans match the current filters.'}
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScanHistory;
