"""Unit tests for agents."""
import pytest
from src.agents import (
    create_question_validator_agent,
    create_schema_table_master_agent,
    create_schema_database_master_agent,
    create_context_validator_agent,
    create_sql_create_master_agent,
    create_query_executor_agent,
    create_manager_agent
)


class TestAgentCreation:
    """Tests for agent creation."""
    
    def test_create_question_validator(self):
        """Test creating question validator agent."""
        agent = create_question_validator_agent()
        assert agent is not None
        assert agent.role == "Question Validation Specialist"
    
    def test_create_schema_table_master(self):
        """Test creating schema table master agent."""
        agent = create_schema_table_master_agent()
        assert agent is not None
        assert agent.role == "Schema Table Discovery Specialist"
        assert len(agent.tools) > 0
    
    def test_create_schema_database_master(self):
        """Test creating schema database master agent."""
        agent = create_schema_database_master_agent()
        assert agent is not None
        assert agent.role == "Schema Database Specialist"
    
    def test_create_context_validator(self):
        """Test creating context validator agent."""
        agent = create_context_validator_agent()
        assert agent is not None
        assert agent.role == "Query Feasibility Validator"
    
    def test_create_sql_create_master(self):
        """Test creating SQL create master agent."""
        agent = create_sql_create_master_agent()
        assert agent is not None
        assert agent.role == "SQL Query Generation Master"
    
    def test_create_query_executor(self):
        """Test creating query executor agent."""
        agent = create_query_executor_agent()
        assert agent is not None
        assert agent.role == "SQL Execution Specialist"
    
    def test_create_manager(self):
        """Test creating manager agent."""
        agent = create_manager_agent()
        assert agent is not None
        assert agent.role == "Query Planning Manager"
        assert agent.allow_delegation == True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

