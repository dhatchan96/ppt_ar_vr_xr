"""Configuration package for Text-to-SQL system."""
from .settings import settings

__all__ = ["settings"]

