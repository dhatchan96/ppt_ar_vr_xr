"""Settings management for Text-to-SQL system."""
import os
from pathlib import Path
from typing import Optional
import yaml
from pydantic import BaseModel, Field


class DatabaseConfig(BaseModel):
    """Database configuration."""
    type: str = "impala"
    host: str = "localhost"
    port: int = 21050
    database: str = "default"
    auth_mechanism: str = "PLAIN"
    user: Optional[str] = None
    password: Optional[str] = None


class AgentConfig(BaseModel):
    """Agent configuration."""
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.0
    max_iterations: int = 5
    cache_ttl: int = 3600
    max_timeout: int = 60
    default_limit: int = 100
    format_instructions: Optional[str] = None


class OpenAIConfig(BaseModel):
    """OpenAI configuration."""
    api_key: str = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))


class RedisConfig(BaseModel):
    """Redis configuration."""
    enabled: bool = True
    host: str = "localhost"
    port: int = 6379
    db: int = 0


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file: str = "text2sql.log"


class Settings(BaseModel):
    """Main settings class."""
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @classmethod
    def load_from_yaml(cls, config_path: Optional[Path] = None) -> "Settings":
        """Load settings from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent / "config.yaml"
        
        if not config_path.exists():
            return cls()
        
        with open(config_path, 'r') as f:
            config_data = yaml.safe_load(f)
        
        # Process environment variables in config
        config_str = yaml.dump(config_data)
        for key, value in os.environ.items():
            config_str = config_str.replace(f"${{{key}}}", value)
        config_data = yaml.safe_load(config_str)
        
        return cls(**config_data)


# Global settings instance
settings = Settings.load_from_yaml()

