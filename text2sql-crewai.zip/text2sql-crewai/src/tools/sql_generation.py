"""SQL generation tool for creating optimized SQL queries."""
import json
import logging
from typing import Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SQLGenerationInput(BaseModel):
    """Input schema for SQLGenerationTool."""
    query_plan: dict = Field(..., description="Parsed query plan with requirements")
    db_schema: dict = Field(..., description="Database schema information")
    dialect: str = Field(default="impala", description="SQL dialect (impala, postgresql, mysql)")


class SQLGenerationTool(BaseTool):
    """
    Generates optimized SQL queries from structured requirements.
    """
    name: str = "sql_generator"
    description: str = """
    Generates optimized SQL query from structured requirements.
    Input should be a JSON string with keys:
    - query_plan (dict): Parsed query plan with entities, conditions, query_type
    - db_schema (dict): Database schema information
    - dialect (str): SQL dialect - 'impala', 'postgresql', or 'mysql'
    
    Returns: JSON with:
    - sql (str): Generated SQL query
    - explanation (str): Query explanation
    - estimated_complexity (str): Query complexity estimate
    
    Example input:
    {
        "query_plan": {"query_type": "SELECT", "entities": ["customers"], "conditions": []},
        "db_schema": {"customers": {"columns": ["id", "name"]}},
        "dialect": "impala"
    }
    """

    def _run(self, query_plan: dict, db_schema: dict, dialect: str = "impala") -> str:
        """
        Generate SQL query.
        
        Args:
            query_plan: Parsed query requirements
            db_schema: Database schema information
            dialect: SQL dialect to use
            
        Returns:
            JSON string with SQL query and metadata
        """
        try:
            logger.info(f"Generating SQL with dialect={dialect}")
            
            result = self._generate_sql(query_plan, db_schema, dialect)
            
            return json.dumps(result, indent=2)
        
        except Exception as e:
            logger.error(f"Error generating SQL: {str(e)}")
            return json.dumps({
                "sql": None,
                "explanation": f"Error: {str(e)}",
                "estimated_complexity": "unknown",
                "error": str(e)
            })

    def _generate_sql(self, query_plan: dict, db_schema: dict, dialect: str) -> dict[str, Any]:
        """
        Generate SQL based on query plan and schema.
        
        This is a simplified implementation. In production, this would use
        more sophisticated SQL generation techniques or leverage LLMs.
        """
        query_type = query_plan.get("query_type", "SELECT")
        entities = query_plan.get("entities", [])
        conditions = query_plan.get("conditions", [])
        aggregations = query_plan.get("aggregations", [])
        
        tables = db_schema.get("tables", {})
        
        # Start building SQL
        sql_parts = {
            "select": [],
            "from": [],
            "where": [],
            "group_by": [],
            "order_by": [],
            "limit": None
        }
        
        # Determine main table
        main_table = entities[0] if entities else list(tables.keys())[0]
        sql_parts["from"].append(main_table)
        
        # Build SELECT clause
        if query_type == "AGGREGATE" or aggregations:
            # Handle aggregations
            for agg in aggregations:
                agg_func = agg.get("function", "COUNT")
                agg_column = agg.get("column", "*")
                sql_parts["select"].append(f"{agg_func}({agg_column}) as {agg_func.lower()}_{agg_column}")
        else:
            # Select all columns from main table
            if main_table in tables:
                table_info = tables[main_table]
                if isinstance(table_info, dict) and "columns" in table_info:
                    columns = table_info["columns"]
                    for col in columns[:10]:  # Limit to first 10 columns
                        col_name = col["name"] if isinstance(col, dict) else col
                        sql_parts["select"].append(self._quote_identifier(col_name, dialect))
                else:
                    sql_parts["select"].append("*")
            else:
                sql_parts["select"].append("*")
        
        # Build WHERE clause
        for condition in conditions:
            if isinstance(condition, dict):
                column = condition.get("column")
                operator = condition.get("operator", "=")
                value = condition.get("value")
                sql_parts["where"].append(f"{self._quote_identifier(column, dialect)} {operator} {self._format_value(value)}")
            elif isinstance(condition, str):
                sql_parts["where"].append(condition)
        
        # Build GROUP BY if aggregations present
        if aggregations:
            group_columns = query_plan.get("group_by", [])
            if group_columns:
                sql_parts["group_by"] = [self._quote_identifier(col, dialect) for col in group_columns]
        
        # Add LIMIT
        sql_parts["limit"] = query_plan.get("limit", 100)
        
        # Construct final SQL
        sql = self._construct_sql(sql_parts, dialect)
        
        # Generate explanation
        explanation = self._generate_explanation(sql_parts, query_type)
        
        # Estimate complexity
        complexity = self._estimate_complexity(sql_parts, tables)
        
        return {
            "sql": sql,
            "explanation": explanation,
            "estimated_complexity": complexity,
            "dialect": dialect
        }

    def _quote_identifier(self, identifier: str, dialect: str) -> str:
        """Quote identifier based on dialect."""
        if dialect == "impala":
            return f"`{identifier}`"
        elif dialect == "postgresql":
            return f'"{identifier}"'
        elif dialect == "mysql":
            return f"`{identifier}`"
        else:
            return identifier

    def _format_value(self, value: Any) -> str:
        """Format value for SQL."""
        if isinstance(value, str):
            return f"'{value}'"
        elif value is None:
            return "NULL"
        else:
            return str(value)

    def _construct_sql(self, sql_parts: dict, dialect: str) -> str:
        """Construct final SQL from parts."""
        sql = "SELECT "
        
        # SELECT clause
        if sql_parts["select"]:
            sql += ", ".join(sql_parts["select"])
        else:
            sql += "*"
        
        # FROM clause
        sql += "\nFROM " + ", ".join(sql_parts["from"])
        
        # WHERE clause
        if sql_parts["where"]:
            sql += "\nWHERE " + " AND ".join(sql_parts["where"])
        
        # GROUP BY clause
        if sql_parts["group_by"]:
            sql += "\nGROUP BY " + ", ".join(sql_parts["group_by"])
        
        # ORDER BY clause
        if sql_parts["order_by"]:
            sql += "\nORDER BY " + ", ".join(sql_parts["order_by"])
        
        # LIMIT clause
        if sql_parts["limit"]:
            sql += f"\nLIMIT {sql_parts['limit']}"
        
        return sql

    def _generate_explanation(self, sql_parts: dict, query_type: str) -> str:
        """Generate human-readable explanation."""
        explanation = []
        
        explanation.append(f"This is a {query_type} query that:")
        
        if sql_parts["select"]:
            explanation.append(f"- Selects {len(sql_parts['select'])} column(s)")
        
        if sql_parts["from"]:
            explanation.append(f"- From table(s): {', '.join(sql_parts['from'])}")
        
        if sql_parts["where"]:
            explanation.append(f"- Filters data with {len(sql_parts['where'])} condition(s)")
        
        if sql_parts["group_by"]:
            explanation.append(f"- Groups results by {len(sql_parts['group_by'])} column(s)")
        
        if sql_parts["limit"]:
            explanation.append(f"- Limits output to {sql_parts['limit']} rows")
        
        return "\n".join(explanation)

    def _estimate_complexity(self, sql_parts: dict, tables: dict) -> str:
        """Estimate query complexity."""
        score = 0
        
        # Base complexity
        score += len(sql_parts["select"]) * 1
        score += len(sql_parts["from"]) * 5
        score += len(sql_parts["where"]) * 2
        score += len(sql_parts["group_by"]) * 3
        
        # Estimate based on table sizes (if available)
        for table in sql_parts["from"]:
            if table in tables:
                table_info = tables.get(table, {})
                if isinstance(table_info, dict):
                    row_count = table_info.get("row_count", 0)
                    if row_count > 1000000:
                        score += 10
                    elif row_count > 100000:
                        score += 5
        
        if score < 10:
            return "low"
        elif score < 25:
            return "medium"
        else:
            return "high"

