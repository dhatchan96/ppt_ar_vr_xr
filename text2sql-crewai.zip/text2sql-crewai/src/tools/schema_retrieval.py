"""Schema retrieval tool for accessing database metadata."""
import json
import logging
from typing import Optional, Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Module-level cache for schema data
_schema_cache = {}


class SchemaRetrievalInput(BaseModel):
    """Input schema for SchemaRetrievalTool."""
    database: str = Field(..., description="Database name")
    tables: Optional[list[str]] = Field(None, description="List of table names (optional)")
    level: str = Field(default="table", description="Level of detail: 'database', 'table', or 'column'")


class SchemaRetrievalTool(BaseTool):
    """
    Retrieves database schema information.
    Caches results for performance.
    """
    name: str = "schema_retrieval"
    description: str = """
    Retrieves database, table, and column metadata.
    Input should be a JSON string with keys: 
    - database (str): Database name
    - tables (list, optional): List of table names
    - level (str): Level of detail - 'database', 'table', or 'column'
    
    Returns: Structured schema information as JSON
    
    Example input:
    {"database": "sales_db", "tables": ["customers", "orders"], "level": "column"}
    """

    def _run(self, database: str, tables: Optional[list[str]] = None, level: str = "table") -> str:
        """
        Retrieve schema information.
        
        Args:
            database: Database name
            tables: Optional list of table names
            level: Level of detail ('database', 'table', 'column')
            
        Returns:
            JSON string with schema information
        """
        try:
            logger.info(f"Retrieving schema for database={database}, tables={tables}, level={level}")
            
            schema_info = self._get_schema_cached(database, tuple(tables) if tables else None, level)
            
            return json.dumps(schema_info, indent=2)
        
        except Exception as e:
            logger.error(f"Error retrieving schema: {str(e)}")
            return json.dumps({"error": str(e), "status": "failed"})

    def _get_schema_cached(self, database: str, tables: Optional[tuple[str, ...]], level: str) -> dict[str, Any]:
        """
        Cached schema retrieval using module-level cache.
        
        Note: In production, this should connect to actual database or metadata service.
        This is a mock implementation for the POC.
        """
        # Create cache key
        cache_key = f"{database}:{tables}:{level}"
        
        # Check cache
        if cache_key in _schema_cache:
            logger.debug(f"Cache hit for {cache_key}")
            return _schema_cache[cache_key]
        
        # Get schema data
        if level == "database":
            result = self._get_database_schema(database)
        elif level == "table":
            result = self._get_table_schema(database, list(tables) if tables else None)
        elif level == "column":
            result = self._get_column_schema(database, list(tables) if tables else None)
        else:
            result = {"error": f"Invalid level: {level}"}
        
        # Store in cache
        _schema_cache[cache_key] = result
        
        return result

    def _get_database_schema(self, database: str) -> dict[str, Any]:
        """Get database-level schema."""
        # Mock implementation
        return {
            "database": database,
            "tables": [
                "customers", "orders", "products", "sales", 
                "employees", "departments", "regions"
            ],
            "total_tables": 7,
            "created_at": "2024-01-01"
        }

    def _get_table_schema(self, database: str, tables: Optional[list[str]]) -> dict[str, Any]:
        """Get table-level schema."""
        # Mock implementation
        all_tables = {
            "customers": {
                "description": "Customer information including demographics",
                "row_count": 15000,
                "columns": ["customer_id", "name", "email", "country", "created_date"]
            },
            "orders": {
                "description": "Order transactions and details",
                "row_count": 50000,
                "columns": ["order_id", "customer_id", "product_id", "order_date", "amount", "status"]
            },
            "products": {
                "description": "Product catalog with pricing",
                "row_count": 1000,
                "columns": ["product_id", "name", "category", "price", "stock_quantity"]
            },
            "sales": {
                "description": "Sales transactions by region",
                "row_count": 75000,
                "columns": ["sale_id", "order_id", "region", "amount", "sale_date", "salesperson_id"]
            }
        }
        
        if tables:
            filtered_tables = {k: v for k, v in all_tables.items() if k in tables}
        else:
            filtered_tables = all_tables
        
        return {
            "database": database,
            "tables": filtered_tables,
            "level": "table"
        }

    def _get_column_schema(self, database: str, tables: Optional[list[str]]) -> dict[str, Any]:
        """Get column-level schema."""
        # Mock implementation
        all_columns = {
            "customers": {
                "columns": [
                    {"name": "customer_id", "type": "INT", "nullable": False, "primary_key": True},
                    {"name": "name", "type": "STRING", "nullable": False},
                    {"name": "email", "type": "STRING", "nullable": False},
                    {"name": "country", "type": "STRING", "nullable": True},
                    {"name": "created_date", "type": "TIMESTAMP", "nullable": False}
                ],
                "primary_key": ["customer_id"],
                "foreign_keys": []
            },
            "orders": {
                "columns": [
                    {"name": "order_id", "type": "INT", "nullable": False, "primary_key": True},
                    {"name": "customer_id", "type": "INT", "nullable": False},
                    {"name": "product_id", "type": "INT", "nullable": False},
                    {"name": "order_date", "type": "TIMESTAMP", "nullable": False},
                    {"name": "amount", "type": "DECIMAL", "nullable": False},
                    {"name": "status", "type": "STRING", "nullable": False}
                ],
                "primary_key": ["order_id"],
                "foreign_keys": [
                    {"column": "customer_id", "references": "customers.customer_id"},
                    {"column": "product_id", "references": "products.product_id"}
                ]
            },
            "products": {
                "columns": [
                    {"name": "product_id", "type": "INT", "nullable": False, "primary_key": True},
                    {"name": "name", "type": "STRING", "nullable": False},
                    {"name": "category", "type": "STRING", "nullable": True},
                    {"name": "price", "type": "DECIMAL", "nullable": False},
                    {"name": "stock_quantity", "type": "INT", "nullable": False}
                ],
                "primary_key": ["product_id"],
                "foreign_keys": []
            },
            "sales": {
                "columns": [
                    {"name": "sale_id", "type": "INT", "nullable": False, "primary_key": True},
                    {"name": "order_id", "type": "INT", "nullable": False},
                    {"name": "region", "type": "STRING", "nullable": False},
                    {"name": "amount", "type": "DECIMAL", "nullable": False},
                    {"name": "sale_date", "type": "TIMESTAMP", "nullable": False},
                    {"name": "salesperson_id", "type": "INT", "nullable": True}
                ],
                "primary_key": ["sale_id"],
                "foreign_keys": [
                    {"column": "order_id", "references": "orders.order_id"}
                ]
            }
        }
        
        if tables:
            filtered_columns = {k: v for k, v in all_columns.items() if k in tables}
        else:
            filtered_columns = all_columns
        
        return {
            "database": database,
            "tables": filtered_columns,
            "level": "column"
        }

