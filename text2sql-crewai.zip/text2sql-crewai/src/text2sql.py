"""Main module for Text-to-SQL system."""
import logging
from datetime import datetime
from crewai import Crew, Process, Task
from langchain_openai import ChatOpenAI

from .config import settings
from .agents import (
    create_question_validator_agent,
    create_schema_table_master_agent,
    create_schema_database_master_agent,
    create_context_validator_agent,
    create_sql_create_master_agent,
    create_query_executor_agent,
    create_manager_agent
)
from .models import QueryRequest, QueryResponse, QueryResult, ValidationResult, SchemaInfo

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.logging.level),
    format=settings.logging.format,
    handlers=[
        logging.FileHandler(settings.logging.file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class Text2SQLCrew:
    """Main Text-to-SQL multi-agent system."""
    
    def __init__(self, use_hierarchical: bool = True):
        """
        Initialize the Text-to-SQL crew.
        
        Args:
            use_hierarchical: Use hierarchical process with manager agent
        """
        self.use_hierarchical = use_hierarchical
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def create_crew(self, user_query: str, database: str, sql_dialect: str = "impala") -> Crew:
        """
        Create a crew for processing a query.
        
        Args:
            user_query: Natural language query
            database: Target database name
            sql_dialect: SQL dialect to use
            
        Returns:
            Configured Crew instance
        """
        # Create agents
        question_validator = create_question_validator_agent()
        schema_table_master = create_schema_table_master_agent()
        schema_database_master = create_schema_database_master_agent()
        context_validator = create_context_validator_agent()
        sql_create_master = create_sql_create_master_agent()
        query_executor = create_query_executor_agent()
        
        # Create tasks
        validation_task = Task(
            description=f"""
            Analyze this query: {user_query}
            
            Determine:
            1. Is this a SQL-appropriate query? (PASS/FAIL)
            2. What type of query? (SELECT, aggregation, join, etc.)
            3. What entities are mentioned?
            4. What conditions/filters are needed?
            5. Any ambiguities or missing information?
            
            Provide structured JSON output with query_type, entities, conditions, and ambiguities.
            """,
            agent=question_validator,
            expected_output="Validation decision with structured requirements in JSON format"
        )
        
        table_discovery_task = Task(
            description=f"""
            Find relevant tables for this query: {user_query}
            Database: {database}
            
            Use the table_matcher tool to identify the top 5 most relevant tables.
            Provide table names with relevance scores and reasons.
            """,
            agent=schema_table_master,
            expected_output="List of relevant tables with relevance scores in JSON format",
            context=[validation_task]
        )
        
        schema_detail_task = Task(
            description=f"""
            Retrieve detailed column-level schema for the tables identified in the previous task.
            Database: {database}
            
            Use schema_retrieval tool with level='column' to get detailed schema information
            including column names, types, constraints, and relationships.
            """,
            agent=schema_database_master,
            expected_output="Detailed schema for selected tables",
            context=[table_discovery_task]
        )
        
        feasibility_task = Task(
            description=f"""
            Validate that the query: {user_query}
            Can be answered with the available schema.
            
            Use query_validator tool to check:
            - All required columns exist
            - Data types are compatible
            - Join conditions are valid
            
            Provide validation result (PASS/FAIL) with findings and recommendations.
            """,
            agent=context_validator,
            expected_output="Validation result with findings",
            context=[validation_task, schema_detail_task]
        )
        
        sql_generation_task = Task(
            description=f"""
            Generate optimized SQL query for: {user_query}
            SQL Dialect: {sql_dialect}
            
            Use the validated requirements and schema to generate a clean, efficient SQL query.
            Follow best practices for {sql_dialect}.
            Include explanation of the query logic.
            """,
            agent=sql_create_master,
            expected_output="SQL query with explanation",
            context=[validation_task, schema_detail_task, feasibility_task]
        )
        
        execution_task = Task(
            description="""
            Execute the generated SQL query using sql_executor tool.
            
            Handle execution results:
            - Success: Format results as table
            - Timeout: Return partial results
            - Error: Return error details
            
            Provide execution status, row count, and timing information.
            """,
            agent=query_executor,
            expected_output="Query execution results or error details",
            context=[sql_generation_task]
        )
        
        # Create crew
        agents_list = [
            question_validator,
            schema_table_master,
            schema_database_master,
            context_validator,
            sql_create_master,
            query_executor
        ]
        
        tasks_list = [
            validation_task,
            table_discovery_task,
            schema_detail_task,
            feasibility_task,
            sql_generation_task,
            execution_task
        ]
        
        if self.use_hierarchical:
            manager_agent = create_manager_agent()
            crew = Crew(
                agents=agents_list,
                tasks=tasks_list,
                process=Process.hierarchical,
                manager_agent=manager_agent,
                verbose=True
            )
        else:
            crew = Crew(
                agents=agents_list,
                tasks=tasks_list,
                process=Process.sequential,
                verbose=True
            )
        
        return crew
    
    def process_query(self, request: QueryRequest) -> QueryResponse:
        """
        Process a natural language query and return SQL.
        
        Args:
            request: QueryRequest with query details
            
        Returns:
            QueryResponse with SQL and results
        """
        start_time = datetime.now()
        
        try:
            self.logger.info(f"Processing query: {request.query}")
            
            # Validate user permissions
            if request.user_context:
                self._validate_permissions(request.user_context, request.database)
            
            # Create and execute crew
            crew = self.create_crew(
                user_query=request.query,
                database=request.database,
                sql_dialect=request.sql_dialect
            )
            
            result = crew.kickoff()
            
            # Parse result and construct response
            processing_time = (datetime.now() - start_time).total_seconds()
            
            response = QueryResponse(
                status="success",
                sql=self._extract_sql_from_result(result),
                explanation=self._extract_explanation_from_result(result),
                processing_time=processing_time,
                timestamp=datetime.now()
            )
            
            self.logger.info(f"Query processed successfully in {processing_time:.2f}s")
            return response
        
        except Exception as e:
            self.logger.error(f"Error processing query: {str(e)}", exc_info=True)
            processing_time = (datetime.now() - start_time).total_seconds()
            
            return QueryResponse(
                status="failed",
                error=str(e),
                processing_time=processing_time,
                timestamp=datetime.now()
            )
    
    def _validate_permissions(self, user_context, database: str):
        """Validate user has access to database."""
        if user_context.permissions and database not in user_context.permissions:
            raise PermissionError(
                f"User {user_context.user_id} does not have access to database {database}"
            )
    
    def _extract_sql_from_result(self, result) -> str:
        """Extract SQL query from crew result."""
        # Parse the result to extract SQL
        # This is a simplified implementation
        result_str = str(result)
        
        # Look for SQL in markdown code blocks
        if "```sql" in result_str:
            start = result_str.find("```sql") + 6
            end = result_str.find("```", start)
            return result_str[start:end].strip()
        
        # Look for SELECT statements
        if "SELECT" in result_str.upper():
            lines = result_str.split("\n")
            sql_lines = []
            in_sql = False
            for line in lines:
                if "SELECT" in line.upper():
                    in_sql = True
                if in_sql:
                    sql_lines.append(line)
                    if ";" in line or "LIMIT" in line.upper():
                        break
            return "\n".join(sql_lines).strip()
        
        return result_str
    
    def _extract_explanation_from_result(self, result) -> str:
        """Extract explanation from crew result."""
        # This is a simplified implementation
        result_str = str(result)
        
        # Look for explanation section
        if "# EXPLANATION" in result_str:
            start = result_str.find("# EXPLANATION") + 13
            end = result_str.find("# END", start)
            if end == -1:
                end = len(result_str)
            return result_str[start:end].strip()
        
        return "Query generated successfully"


def create_text2sql_crew(use_hierarchical: bool = True) -> Text2SQLCrew:
    """
    Factory function to create Text2SQL crew.
    
    Args:
        use_hierarchical: Use hierarchical process with manager
        
    Returns:
        Text2SQLCrew instance
    """
    return Text2SQLCrew(use_hierarchical=use_hierarchical)

