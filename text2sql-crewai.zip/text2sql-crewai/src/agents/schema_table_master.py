"""Schema Table Master agent for table discovery."""
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings
from ..tools import SchemaRetrievalTool, SchemaTableMatchingTool


def create_schema_table_master_agent() -> Agent:
    """
    Create the Schema Table Master Agent.
    
    This agent identifies relevant database tables for a given query.
    """
    config = settings.agents.get("schema_table_master", {})
    
    return Agent(
        role="Schema Table Discovery Specialist",
        goal="Identify relevant database tables for the query",
        backstory="""You are an expert in database schema analysis. You can 
        quickly identify which tables are relevant for a given query by analyzing 
        table names, descriptions, and metadata. You use semantic search and 
        keyword matching to find the most appropriate tables. You provide relevance 
        scores and clear justifications for your selections.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-3.5-turbo",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[SchemaRetrievalTool(), SchemaTableMatchingTool()],
        allow_delegation=False
    )


def create_table_discovery_task(agent: Agent, user_query: str, database: str, query_requirements: dict) -> Task:
    """Create table discovery task for the schema table master agent."""
    return Task(
        description=f"""
        Find relevant tables for this query: {user_query}
        
        Database: {database}
        Requirements: {query_requirements}
        
        Use the schema_retrieval and table_matcher tools to:
        1. Get list of available tables
        2. Match tables to query semantically
        3. Select top 5 most relevant tables
        
        Respond with:
        # DISCUSSION
        Brief explanation of table selection
        
        # RELEVANT TABLES
        ```json
        [
            {{
                "table": "table_name",
                "relevance_score": 0.95,
                "reason": "why this table is relevant"
            }}
        ]
        ```
        
        # END
        """,
        agent=agent,
        expected_output="List of relevant tables with relevance scores"
    )

