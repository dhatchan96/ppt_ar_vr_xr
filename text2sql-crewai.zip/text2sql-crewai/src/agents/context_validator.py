"""Context Validator agent for query feasibility validation."""
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings
from ..tools import QueryValidationTool


def create_context_validator_agent() -> Agent:
    """
    Create the Context Validator Agent.
    
    This agent verifies that queries can be answered with the available schema.
    """
    config = settings.agents.get("context_validator", {})
    
    return Agent(
        role="Query Feasibility Validator",
        goal="Verify that the query can be answered with available schema",
        backstory="""You are a meticulous validator who checks every requirement 
        against the database schema to ensure queries are feasible. You verify that 
        required columns exist, data types are compatible, join conditions are valid, 
        and filters can be applied. You identify missing information and suggest 
        alternatives. You provide detailed validation reports with clear 
        recommendations.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-3.5-turbo",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[QueryValidationTool()],
        allow_delegation=False
    )


def create_feasibility_task(agent: Agent, user_query: str, query_requirements: dict, detailed_schema: dict) -> Task:
    """Create feasibility validation task for the context validator agent."""
    return Task(
        description=f"""
        Validate feasibility of this query: {user_query}
        
        Requirements: {query_requirements}
        Schema: {detailed_schema}
        
        Check:
        1. All required columns exist
        2. Data types are compatible
        3. Join conditions are valid
        4. Filters can be applied
        5. Aggregations are supported
        
        Use query_validator tool and respond:
        
        # VALIDATION RESULT
        PASS or FAIL
        
        # FINDINGS
        - ✓ Column X exists in table Y
        - ✗ Column Z not found - suggest alternative: column_alt
        
        # RECOMMENDATIONS
        - Use table A instead of table B for better performance
        - Add index on column C for faster execution
        
        # END
        """,
        agent=agent,
        expected_output="Validation result with findings and recommendations"
    )

