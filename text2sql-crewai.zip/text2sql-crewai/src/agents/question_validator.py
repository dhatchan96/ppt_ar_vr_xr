"""Question Validator agent for validating natural language queries."""
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings


def create_question_validator_agent() -> Agent:
    """
    Create the Question Validator Agent.
    
    This agent analyzes natural language queries to determine if they
    can be converted to SQL and extracts key requirements.
    """
    config = settings.agents.get("question_validator", {})
    
    return Agent(
        role="Question Validation Specialist",
        goal="Determine if natural language query can be converted to SQL",
        backstory="""You are an expert in natural language processing and SQL 
        query analysis. You can quickly identify whether a question is answerable 
        via SQL and extract key requirements. You understand query types, entities, 
        conditions, and can detect ambiguities. You provide clear PASS/FAIL decisions 
        with detailed reasoning.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-3.5-turbo",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        allow_delegation=False
    )


def create_validation_task(agent: Agent, user_query: str) -> Task:
    """Create validation task for the question validator agent."""
    return Task(
        description=f"""
        Analyze this query: {user_query}
        
        Determine:
        1. Is this a SQL-appropriate query? (PASS/FAIL)
        2. What type of query? (SELECT, aggregation, join, etc.)
        3. What entities are mentioned?
        4. What conditions/filters are needed?
        5. Any ambiguities or missing information?
        
        Respond in this format:
        # DISCUSSION
        Brief analysis of the query
        
        # DECISION
        PASS or FAIL
        
        # REQUIREMENTS
        ```json
        {{
            "query_type": "SELECT/AGGREGATE/JOIN/etc",
            "entities": ["entity1", "entity2"],
            "conditions": ["condition1"],
            "ambiguities": ["ambiguity1"]
        }}
        ```
        
        # END
        """,
        agent=agent,
        expected_output="Validation decision with structured requirements"
    )

