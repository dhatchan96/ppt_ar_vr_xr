"""Manager agent for orchestrating the Text-to-SQL workflow."""
from crewai import Agent
from langchain_openai import ChatOpenAI
from ..config import settings


def create_manager_agent() -> Agent:
    """
    Create the Manager Agent.
    
    The Manager Agent orchestrates the entire workflow and coordinates
    between specialist agents.
    """
    config = settings.agents.get("manager", {})
    
    return Agent(
        role="Query Planning Manager",
        goal="Orchestrate the text-to-SQL workflow and produce accurate SQL queries",
        backstory="""You are an expert SQL query planner with deep knowledge of 
        database systems. You coordinate a team of specialists to convert natural 
        language into optimized SQL queries. You make strategic decisions about which 
        agents to consult and in what order. You ensure the final SQL query is 
        accurate, optimized, and meets the user's requirements.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-4",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        allow_delegation=True,
        max_iter=config.max_iterations if hasattr(config, 'max_iterations') else 5
    )

