"""API endpoint tests."""
import pytest
from fastapi.testclient import TestClient
from src.main import app


@pytest.fixture
def client():
    """Create test client."""
    return TestClient(app)


class TestAPIEndpoints:
    """Tests for API endpoints."""
    
    def test_root_endpoint(self, client):
        """Test root endpoint."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "version" in data
    
    def test_health_endpoint(self, client):
        """Test health check endpoint."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
    
    def test_list_databases_endpoint(self, client):
        """Test list databases endpoint."""
        response = client.get("/api/v1/databases")
        assert response.status_code == 200
        data = response.json()
        assert "databases" in data
        assert isinstance(data["databases"], list)
    
    def test_get_schema_endpoint(self, client):
        """Test get schema endpoint."""
        response = client.get("/api/v1/schema/test_db")
        assert response.status_code == 200
        data = response.json()
        assert "database" in data or "tables" in data
    
    @pytest.mark.skip(reason="Requires OpenAI API key")
    def test_generate_sql_endpoint(self, client):
        """Test generate SQL endpoint."""
        request_data = {
            "query": "Show me all customers",
            "database": "test_db",
            "sql_dialect": "impala"
        }
        
        response = client.post("/api/v1/generate-sql", json=request_data)
        assert response.status_code in [200, 500]  # May fail without API key
    
    def test_generate_sql_invalid_request(self, client):
        """Test generate SQL with invalid request."""
        request_data = {
            "database": "test_db"
            # Missing required 'query' field
        }
        
        response = client.post("/api/v1/generate-sql", json=request_data)
        assert response.status_code == 422  # Validation error


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

