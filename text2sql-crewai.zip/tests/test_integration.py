"""Integration tests for the complete workflow."""
import pytest
from src.text2sql import create_text2sql_crew
from src.models import QueryRequest, UserContext


class TestText2SQLIntegration:
    """Integration tests for Text-to-SQL system."""
    
    @pytest.fixture
    def crew(self):
        """Create a Text2SQL crew instance."""
        return create_text2sql_crew(use_hierarchical=False)
    
    def test_crew_creation(self, crew):
        """Test crew creation."""
        assert crew is not None
    
    def test_query_request_validation(self):
        """Test query request model validation."""
        request = QueryRequest(
            query="Show me all customers",
            database="test_db",
            sql_dialect="impala"
        )
        
        assert request.query == "Show me all customers"
        assert request.database == "test_db"
        assert request.sql_dialect == "impala"
        assert request.execute == False
        assert request.limit == 100
    
    def test_query_request_with_user_context(self):
        """Test query request with user context."""
        user_context = UserContext(
            user_id="test_user",
            permissions=["test_db", "sales_db"]
        )
        
        request = QueryRequest(
            query="Show me sales data",
            database="sales_db",
            user_context=user_context
        )
        
        assert request.user_context.user_id == "test_user"
        assert "sales_db" in request.user_context.permissions
    
    @pytest.mark.skip(reason="Requires OpenAI API key and takes time")
    def test_full_workflow(self, crew):
        """Test complete workflow from query to SQL."""
        request = QueryRequest(
            query="Count customers by country",
            database="test_db",
            sql_dialect="impala"
        )
        
        response = crew.process_query(request)
        
        assert response.status in ["success", "failed"]
        if response.status == "success":
            assert response.sql is not None
            assert "SELECT" in response.sql.upper()
            assert "COUNT" in response.sql.upper() or "GROUP BY" in response.sql.upper()
    
    @pytest.mark.skip(reason="Requires OpenAI API key")
    def test_query_with_aggregation(self, crew):
        """Test query with aggregation."""
        request = QueryRequest(
            query="What is the total sales by region?",
            database="sales_db",
            sql_dialect="impala"
        )
        
        response = crew.process_query(request)
        
        assert response.status == "success"
        assert "SUM" in response.sql.upper() or "TOTAL" in response.sql.upper()
    
    @pytest.mark.skip(reason="Requires OpenAI API key")
    def test_permission_validation(self, crew):
        """Test permission validation."""
        user_context = UserContext(
            user_id="test_user",
            permissions=["allowed_db"]
        )
        
        request = QueryRequest(
            query="Show me data",
            database="restricted_db",
            user_context=user_context
        )
        
        with pytest.raises(PermissionError):
            crew.process_query(request)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

