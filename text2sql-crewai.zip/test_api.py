"""Simple test script for the Text-to-SQL API."""
import requests
import time
import sys

BASE_URL = "http://127.0.0.1:8001"

print("=" * 60)
print("Testing Text-to-SQL API Server")
print("=" * 60)
print(f"\nBase URL: {BASE_URL}\n")

# Wait for server to be ready
print("Waiting for server to start...")
for i in range(5):
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=2)
        if response.status_code == 200:
            print("✓ Server is running!\n")
            break
    except requests.exceptions.ConnectionError:
        print(f"  Attempt {i+1}/5: Server not ready yet...")
        time.sleep(2)
else:
    print("✗ Server did not start")
    sys.exit(1)

# Test endpoints
tests = [
    ("Root endpoint", "GET", "/"),
    ("Health check", "GET", "/health"),
    ("List databases", "GET", "/api/v1/databases"),
    ("Get schema", "GET", "/api/v1/schema/test_db"),
]

print("Testing endpoints:")
print("-" * 60)

for name, method, path in tests:
    url = f"{BASE_URL}{path}"
    print(f"\n{name}: {method} {path}")
    print(f"  URL: {url}")
    
    try:
        response = requests.get(url, timeout=5)
        print(f"  Status: {response.status_code}")
        
        if response.status_code == 200:
            print("  Result: ✓ SUCCESS")
            data = response.json()
            print(f"  Response: {data}")
        else:
            print(f"  Result: ✗ FAILED - Status {response.status_code}")
    except Exception as e:
        print(f"  Result: ✗ ERROR - {str(e)}")

print("\n" + "=" * 60)
print("Server Information")
print("=" * 60)
print(f"API URL: {BASE_URL}")
print(f"API Documentation: {BASE_URL}/docs")
print(f"ReDoc: {BASE_URL}/redoc")
print("\n✓ Server is running successfully!")
print("=" * 60)

