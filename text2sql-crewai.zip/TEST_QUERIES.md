# Test Queries for Text-to-SQL System

These queries have been tested and verified to work with the database schema.

## Database Schema Overview

**Tables:**
- `customers`: customer_id, name, email, country, created_date
- `products`: product_id, name, category, price, stock_quantity
- `orders`: order_id, customer_id, product_id, order_date, amount, status
- `sales`: sale_id, order_id, region, amount, sale_date, salesperson_id
- `employees`: employee_id, name, email, department, hire_date, salary
- `departments`: department_id, name, description, manager_id
- `regions`: region_id, name, country, description

## Simple Queries (Single Table)

1. **Show me all customers**
   - Expected: SELECT * FROM customers

2. **List all products**
   - Expected: SELECT * FROM products

3. **Show all orders**
   - Expected: SELECT * FROM orders

4. **List all sales**
   - Expected: SELECT * FROM sales

5. **Show all employees**
   - Expected: SELECT * FROM employees

## Aggregation Queries (Single Table)

6. **What is the total sales by region?**
   - Expected: SELECT region, SUM(amount) AS total_sales FROM sales GROUP BY region

7. **Count orders by status**
   - Expected: SELECT status, COUNT(*) AS count FROM orders GROUP BY status

8. **Show average order amount**
   - Expected: SELECT AVG(amount) AS avg_amount FROM orders

9. **Find total revenue by product category**
   - Expected: SELECT category, SUM(price * stock_quantity) AS revenue FROM products GROUP BY category

10. **Show employee count by department**
    - Expected: SELECT department, COUNT(*) AS count FROM employees GROUP BY department

## Multi-Table Queries (JOINs)

11. **Show total sales by region and product category**
    - Expected: 
      ```sql
      SELECT sales.region, products.category, SUM(sales.amount) AS total_sales
      FROM sales
      INNER JOIN orders ON sales.order_id = orders.order_id
      INNER JOIN products ON orders.product_id = products.product_id
      GROUP BY sales.region, products.category
      ```

12. **Show customer names with their order counts**
    - Expected:
      ```sql
      SELECT customers.name, COUNT(orders.order_id) AS order_count
      FROM customers
      LEFT JOIN orders ON customers.customer_id = orders.customer_id
      GROUP BY customers.customer_id, customers.name
      ```

13. **Show average order amount by customer country**
    - Expected:
      ```sql
      SELECT customers.country, AVG(orders.amount) AS avg_order_amount
      FROM customers
      INNER JOIN orders ON customers.customer_id = orders.customer_id
      GROUP BY customers.country
      ```

14. **List products with their order counts**
    - Expected:
      ```sql
      SELECT products.name, products.category, COUNT(orders.order_id) AS order_count
      FROM products
      LEFT JOIN orders ON products.product_id = orders.product_id
      GROUP BY products.product_id, products.name, products.category
      ```

15. **Show sales with customer information**
    - Expected:
      ```sql
      SELECT sales.region, sales.amount, customers.name AS customer_name, customers.country
      FROM sales
      INNER JOIN orders ON sales.order_id = orders.order_id
      INNER JOIN customers ON orders.customer_id = customers.customer_id
      ```

## Filtered Queries (WHERE clause)

16. **Show sales for the last 30 days**
    - Expected: SELECT * FROM sales WHERE sale_date >= date('now', '-30 days')

17. **Find orders with status completed**
    - Expected: SELECT * FROM orders WHERE status = 'completed'

18. **Show products in Electronics category**
    - Expected: SELECT * FROM products WHERE category = 'Electronics'

19. **Find customers from USA**
    - Expected: SELECT * FROM customers WHERE country = 'USA'

20. **Show employees in Sales department**
    - Expected: SELECT * FROM employees WHERE department = 'Sales'

## Complex Queries (Multiple Conditions)

21. **Show high-value orders (amount > 1000)**
    - Expected: SELECT * FROM orders WHERE amount > 1000

22. **Find products with low stock (stock_quantity < 50)**
    - Expected: SELECT * FROM products WHERE stock_quantity < 50

23. **Show sales in North region for last month**
    - Expected: SELECT * FROM sales WHERE region = 'North' AND sale_date >= date('now', '-30 days')

24. **Find completed orders from last week**
    - Expected: SELECT * FROM orders WHERE status = 'completed' AND order_date >= date('now', '-7 days')

## Sorting and Limiting

25. **Show top 10 products by price**
    - Expected: SELECT * FROM products ORDER BY price DESC LIMIT 10

26. **List customers ordered by creation date**
    - Expected: SELECT * FROM customers ORDER BY created_date DESC

27. **Show highest sales amounts**
    - Expected: SELECT * FROM sales ORDER BY amount DESC LIMIT 10

## Notes for Testing

- All queries use SQLite syntax
- Date functions use SQLite format: `date('now', '-30 days')`
- Column names are exact: `amount` (not `sale_amount`), `category` (not `product_category`), `name` (not `customer_name`)
- For multi-table queries, use table prefixes: `products.category`, `customers.name`, `sales.amount`
- The `sales` table has `region` as a TEXT column (not a foreign key to regions table)
- Use `SUM(amount)` not `SUM(sale_amount)` for sales aggregation

