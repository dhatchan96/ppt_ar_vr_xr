# PowerShell script to test the Text-to-SQL API server
Write-Host "Testing Text-to-SQL API Server..." -ForegroundColor Cyan
Write-Host ""

$baseUrl = "http://127.0.0.1:8001"
$maxRetries = 5
$retryDelay = 2

# Function to test endpoint
function Test-Endpoint {
    param(
        [string]$url,
        [string]$method = "GET",
        [object]$body = $null
    )
    
    try {
        if ($method -eq "GET") {
            $response = Invoke-RestMethod -Uri $url -Method GET -ErrorAction Stop
        } else {
            $response = Invoke-RestMethod -Uri $url -Method POST -Body ($body | ConvertTo-Json) -ContentType "application/json" -ErrorAction Stop
        }
        return @{ Success = $true; Data = $response }
    } catch {
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

# Wait for server to start
Write-Host "Waiting for server to start..." -ForegroundColor Yellow
for ($i = 1; $i -le $maxRetries; $i++) {
    Write-Host "  Attempt $i/$maxRetries..." -NoNewline
    Start-Sleep -Seconds $retryDelay
    
    $result = Test-Endpoint "$baseUrl/health"
    if ($result.Success) {
        Write-Host " ✓ Server is running!" -ForegroundColor Green
        break
    } else {
        Write-Host " ✗ Not ready yet" -ForegroundColor Red
    }
    
    if ($i -eq $maxRetries) {
        Write-Host ""
        Write-Host "Error: Server did not start within expected time" -ForegroundColor Red
        Write-Host "Error details: $($result.Error)" -ForegroundColor Red
        exit 1
    }
}

Write-Host ""
Write-Host "="*60 -ForegroundColor Cyan
Write-Host "Server Status: RUNNING" -ForegroundColor Green
Write-Host "="*60 -ForegroundColor Cyan
Write-Host ""

# Test endpoints
Write-Host "Testing Endpoints:" -ForegroundColor Cyan
Write-Host ""

# 1. Root endpoint
Write-Host "1. Testing root endpoint (/)..." -NoNewline
$result = Test-Endpoint "$baseUrl/"
if ($result.Success) {
    Write-Host " ✓" -ForegroundColor Green
    Write-Host "   Response: $($result.Data | ConvertTo-Json -Compress)"
} else {
    Write-Host " ✗" -ForegroundColor Red
    Write-Host "   Error: $($result.Error)"
}
Write-Host ""

# 2. Health endpoint
Write-Host "2. Testing health endpoint (/health)..." -NoNewline
$result = Test-Endpoint "$baseUrl/health"
if ($result.Success) {
    Write-Host " ✓" -ForegroundColor Green
    Write-Host "   Response: $($result.Data | ConvertTo-Json -Compress)"
} else {
    Write-Host " ✗" -ForegroundColor Red
    Write-Host "   Error: $($result.Error)"
}
Write-Host ""

# 3. List databases
Write-Host "3. Testing list databases endpoint (/api/v1/databases)..." -NoNewline
$result = Test-Endpoint "$baseUrl/api/v1/databases"
if ($result.Success) {
    Write-Host " ✓" -ForegroundColor Green
    Write-Host "   Response: $($result.Data | ConvertTo-Json -Compress)"
} else {
    Write-Host " ✗" -ForegroundColor Red
    Write-Host "   Error: $($result.Error)"
}
Write-Host ""

# 4. Get schema
Write-Host "4. Testing get schema endpoint (/api/v1/schema/test_db)..." -NoNewline
$result = Test-Endpoint "$baseUrl/api/v1/schema/test_db"
if ($result.Success) {
    Write-Host " ✓" -ForegroundColor Green
    Write-Host "   Schema retrieved successfully"
} else {
    Write-Host " ✗" -ForegroundColor Red
    Write-Host "   Error: $($result.Error)"
}
Write-Host ""
Write-Host ""

Write-Host "="*60 -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "="*60 -ForegroundColor Cyan
Write-Host ""
Write-Host "Server URL: $baseUrl" -ForegroundColor Green
Write-Host "API Documentation: $baseUrl/docs" -ForegroundColor Green
Write-Host "Interactive Docs: $baseUrl/redoc" -ForegroundColor Green
Write-Host ""
Write-Host "✓ Server is running successfully!" -ForegroundColor Green
Write-Host ""

