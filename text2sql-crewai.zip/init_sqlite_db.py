"""Initialize SQLite database with mock table data."""
import sqlite3
import random
from pathlib import Path
from datetime import datetime, timedelta

# Database path
DB_PATH = Path("data") / "text2sql.db"
DB_PATH.parent.mkdir(exist_ok=True)

def create_tables(conn):
    """Create all tables with proper schema."""
    cursor = conn.cursor()
    
    # Create customers table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            country TEXT,
            created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create products table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS products (
            product_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            price DECIMAL(10, 2) NOT NULL,
            stock_quantity INTEGER NOT NULL DEFAULT 0
        )
    """)
    
    # Create orders table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            amount DECIMAL(10, 2) NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
            FOREIGN KEY (product_id) REFERENCES products(product_id)
        )
    """)
    
    # Create sales table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            region TEXT NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            sale_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            salesperson_id INTEGER,
            FOREIGN KEY (order_id) REFERENCES orders(order_id)
        )
    """)
    
    # Create employees table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            employee_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            department TEXT,
            hire_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            salary DECIMAL(10, 2)
        )
    """)
    
    # Create departments table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS departments (
            department_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            manager_id INTEGER
        )
    """)
    
    # Create regions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS regions (
            region_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            country TEXT,
            description TEXT
        )
    """)
    
    conn.commit()
    print("Tables created successfully")

def insert_sample_data(conn):
    """Insert sample data into tables."""
    cursor = conn.cursor()
    
    # Clear existing data
    cursor.execute("DELETE FROM sales")
    cursor.execute("DELETE FROM orders")
    cursor.execute("DELETE FROM customers")
    cursor.execute("DELETE FROM products")
    cursor.execute("DELETE FROM employees")
    cursor.execute("DELETE FROM departments")
    cursor.execute("DELETE FROM regions")
    
    # Insert regions
    regions_data = [
        ("North", "USA", "Northern region"),
        ("South", "USA", "Southern region"),
        ("East", "USA", "Eastern region"),
        ("West", "USA", "Western region"),
        ("Central", "USA", "Central region"),
        ("Europe", "Europe", "European region"),
        ("Asia", "Asia", "Asian region"),
        ("Latin America", "Americas", "Latin American region"),
        ("Middle East", "Middle East", "Middle Eastern region"),
        ("Africa", "Africa", "African region")
    ]
    cursor.executemany("INSERT INTO regions (name, country, description) VALUES (?, ?, ?)", regions_data)
    
    # Insert departments
    departments_data = [
        ("Sales", "Sales department"),
        ("Marketing", "Marketing department"),
        ("Engineering", "Engineering department"),
        ("HR", "Human Resources"),
        ("Finance", "Finance department"),
        ("Operations", "Operations department"),
        ("Customer Support", "Customer support team"),
        ("IT", "Information Technology"),
        ("Product", "Product management"),
        ("Legal", "Legal department"),
        ("Research", "Research and Development"),
        ("Quality Assurance", "QA department"),
        ("Logistics", "Logistics and supply chain"),
        ("Procurement", "Procurement department"),
        ("Administration", "Administrative services"),
        ("Business Development", "Business development team"),
        ("Public Relations", "PR department"),
        ("Training", "Training and development"),
        ("Security", "Security department"),
        ("Facilities", "Facilities management")
    ]
    cursor.executemany("INSERT INTO departments (name, description) VALUES (?, ?)", departments_data)
    
    # Insert customers
    countries = ["USA", "UK", "Canada", "Germany", "France", "Japan", "Australia", "Brazil", "India", "China"]
    customers_data = []
    for i in range(1, 101):  # 100 customers
        customers_data.append((
            f"Customer {i}",
            f"customer{i}@example.com",
            random.choice(countries),
            (datetime.now() - timedelta(days=random.randint(1, 365))).isoformat()
        ))
    cursor.executemany("INSERT INTO customers (name, email, country, created_date) VALUES (?, ?, ?, ?)", customers_data)
    
    # Insert products
    categories = ["Electronics", "Clothing", "Food", "Books", "Toys", "Home", "Sports", "Automotive", "Health", "Beauty"]
    products_data = []
    for i in range(1, 51):  # 50 products
        products_data.append((
            f"Product {i}",
            random.choice(categories),
            round(random.uniform(10.0, 500.0), 2),
            random.randint(0, 1000)
        ))
    cursor.executemany("INSERT INTO products (name, category, price, stock_quantity) VALUES (?, ?, ?, ?)", products_data)
    
    # Insert employees
    employees_data = []
    for i in range(1, 51):  # 50 employees
        employees_data.append((
            f"Employee {i}",
            f"employee{i}@company.com",
            random.choice([d[0] for d in departments_data]),
            (datetime.now() - timedelta(days=random.randint(30, 1825))).isoformat(),
            round(random.uniform(40000, 150000), 2)
        ))
    cursor.executemany("INSERT INTO employees (name, email, department, hire_date, salary) VALUES (?, ?, ?, ?, ?)", employees_data)
    
    # Insert orders
    statuses = ["pending", "completed", "shipped", "cancelled", "processing"]
    orders_data = []
    for i in range(1, 201):  # 200 orders
        orders_data.append((
            random.randint(1, 100),  # customer_id
            random.randint(1, 50),   # product_id
            (datetime.now() - timedelta(days=random.randint(1, 90))).isoformat(),
            round(random.uniform(50.0, 2000.0), 2),
            random.choice(statuses)
        ))
    cursor.executemany("INSERT INTO orders (customer_id, product_id, order_date, amount, status) VALUES (?, ?, ?, ?, ?)", orders_data)
    
    # Insert sales
    regions_list = [r[0] for r in regions_data]
    sales_data = []
    for i in range(1, 201):  # 200 sales records
        sales_data.append((
            i,  # order_id
            random.choice(regions_list),
            round(random.uniform(100.0, 5000.0), 2),
            (datetime.now() - timedelta(days=random.randint(1, 90))).isoformat(),
            random.randint(1, 50) if random.random() > 0.2 else None  # salesperson_id (20% null)
        ))
    cursor.executemany("INSERT INTO sales (order_id, region, amount, sale_date, salesperson_id) VALUES (?, ?, ?, ?, ?)", sales_data)
    
    conn.commit()
    print("Sample data inserted successfully")
    
    # Print row counts
    for table in ["customers", "products", "orders", "sales", "employees", "departments", "regions"]:
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        print(f"  {table}: {count} rows")

def main():
    """Initialize the SQLite database."""
    print(f"Initializing SQLite database at: {DB_PATH}")
    
    # Remove existing database if it exists
    if DB_PATH.exists():
        print("Removing existing database...")
        DB_PATH.unlink()
    
    # Create database and tables
    conn = sqlite3.connect(str(DB_PATH))
    try:
        create_tables(conn)
        insert_sample_data(conn)
        print(f"\nDatabase initialized successfully at: {DB_PATH.absolute()}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()

