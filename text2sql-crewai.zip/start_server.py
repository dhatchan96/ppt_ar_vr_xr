"""Startup script to run the server on port 8001."""
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

print("Starting Text-to-SQL API server...")
print("Python version:", sys.version)
print("Current directory:", os.getcwd())

try:
    print("\nImporting modules...")
    import uvicorn
    from src.main import app
    print("✓ Imports successful")
    
    print("\nStarting server on http://127.0.0.1:8001")
    print("API Documentation: http://127.0.0.1:8001/docs")
    print("\nPress CTRL+C to stop the server\n")
    
    uvicorn.run(app, host="127.0.0.1", port=8001, log_level="info")
    
except ImportError as e:
    print(f"\n❌ Import error: {e}")
    print("\nPlease install dependencies:")
    print("  pip install -r requirements.txt")
    sys.exit(1)
except Exception as e:
    print(f"\n❌ Error starting server: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

