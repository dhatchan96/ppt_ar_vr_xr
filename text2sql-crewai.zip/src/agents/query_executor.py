"""Query Executor agent for SQL execution."""
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings
from ..tools import SQLExecutionTool


def create_query_executor_agent() -> Agent:
    """
    Create the Query Executor Agent.
    
    This agent executes SQL queries and returns formatted results.
    """
    config = settings.agents.get("query_executor", {})
    
    return Agent(
        role="SQL Execution Specialist",
        goal="Execute SQL queries and return formatted results",
        backstory="""You are a database operations expert who safely executes 
        queries and handles results efficiently. You manage query timeouts, handle 
        errors gracefully, and format results in a user-friendly way. You provide 
        clear execution status, row counts, and timing information. You ensure 
        queries execute safely and return meaningful results.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-3.5-turbo",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[SQLExecutionTool()],
        allow_delegation=False
    )


def create_execution_task(agent: Agent, sql_query: str, limit: int = 100, timeout: int = 60) -> Task:
    """Create execution task for the query executor agent."""
    return Task(
        description=f"""
        Execute this SQL query: {sql_query}
        
        Parameters:
        - Limit: {limit} rows
        - Timeout: {timeout} seconds
        
        Use sql_executor tool and handle:
        1. Successful execution → format results as table
        2. Timeout → return partial results with warning
        3. Error → return detailed error message
        
        Format results as:
        # EXECUTION RESULT
        Status: Success/Failed
        Rows: X
        Time: Y seconds
        
        # DATA
        | Column1 | Column2 | Column3 |
        |---------|---------|---------|
        | value1  | value2  | value3  |
        
        # END
        """,
        agent=agent,
        expected_output="Query execution results or error details"
    )

