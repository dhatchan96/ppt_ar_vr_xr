"""SQL Create Master agent for SQL query generation."""
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings
from ..tools import SQLGenerationTool


def create_sql_create_master_agent() -> Agent:
    """
    Create the SQL Create Master Agent.
    
    This agent generates optimized SQL queries from validated requirements.
    """
    config = settings.agents.get("sql_create_master", {})
    
    return Agent(
        role="SQL Query Generation Master",
        goal="Generate optimized, correct SQL queries",
        backstory="""You are a senior database engineer with expertise in SQL 
        optimization. You write clean, efficient, and correct SQL queries that 
        follow best practices. You understand different SQL dialects (Impala, 
        PostgreSQL, MySQL) and apply appropriate syntax. You optimize queries for 
        performance using appropriate indexes, joins, and filters. You provide 
        clear explanations for your query construction decisions.""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-4",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[SQLGenerationTool()],
        allow_delegation=False
    )


def create_sql_generation_task(
    agent: Agent,
    user_query: str,
    query_requirements: dict,
    detailed_schema: dict,
    validation_result: dict,
    sql_dialect: str
) -> Task:
    """Create SQL generation task for the SQL create master agent."""
    
    format_instructions = settings.agents.get("sql_create_master", {})
    dialect_rules = getattr(format_instructions, 'format_instructions', None) or f"""
    Follow these rules for {sql_dialect}:
    - Quote column names with special characters appropriately
    - Use appropriate date/time functions
    - Optimize JOIN operations
    - Add LIMIT clause if not specified
    """
    
    return Task(
        description=f"""
        Generate SQL for: {user_query}
        
        Requirements: {query_requirements}
        Schema: {detailed_schema}
        Validation: {validation_result}
        Dialect: {sql_dialect}
        
        {dialect_rules}
        
        Format:
        # DISCUSSION
        Explain query construction
        
        # QUERY
        ```sql
        SELECT ...
        FROM ...
        WHERE ...
        ```
        
        # EXPLANATION
        - Line 1: Selects columns X, Y
        - Line 3: Filters by condition Z
        
        # END
        """,
        agent=agent,
        expected_output="Formatted SQL query with explanation"
    )

