"""SQL Create Master agent for SQL query generation."""
import json
from crewai import Agent, Task
from langchain_openai import ChatOpenAI
from ..config import settings
from ..tools import SQLGenerationTool


def create_sql_create_master_agent() -> Agent:
    """
    Create the SQL Create Master Agent.
    
    This agent generates optimized SQL queries from validated requirements.
    """
    config = settings.agents.get("sql_create_master", {})
    
    max_iter = getattr(config, 'max_iterations', 3) if hasattr(config, 'max_iterations') else 3
    
    return Agent(
        role="SQL Query Generation Master",
        goal="Generate optimized, correct SQL queries",
        backstory="""You are a senior database engineer with expertise in SQL 
        optimization. You write clean, efficient, and correct SQL queries that 
        follow best practices. You understand different SQL dialects (SQLite, 
        Impala, PostgreSQL, MySQL) and apply appropriate syntax. You optimize queries for 
        performance using appropriate indexes, joins, and filters. You provide 
        clear explanations for your query construction decisions.
        
        IMPORTANT: When using the sql_generator tool, you MUST:
        1. Use the EXACT table name from db_schema (e.g., "sales" not "region")
        2. Include ALL entities from query_plan in the SELECT clause
        3. Include GROUP BY clause if group_by is specified in query_plan
        4. Use the correct column names from db_schema
        5. If you make an error, analyze it carefully and fix it in the next attempt
        6. Do NOT repeat the same incorrect input - try a different approach""",
        llm=ChatOpenAI(
            model=config.model if hasattr(config, 'model') else "gpt-4",
            temperature=config.temperature if hasattr(config, 'temperature') else 0.0
        ),
        verbose=True,
        tools=[SQLGenerationTool()],
        allow_delegation=False,
        max_iter=max_iter
    )


def create_sql_generation_task(
    agent: Agent,
    user_query: str,
    query_requirements: dict,
    detailed_schema: dict,
    validation_result: dict,
    sql_dialect: str
) -> Task:
    """Create SQL generation task for the SQL create master agent."""
    
    format_instructions = settings.agents.get("sql_create_master", {})
    dialect_rules = getattr(format_instructions, 'format_instructions', None) or f"""
    Follow these rules for {sql_dialect}:
    - Quote column names with special characters appropriately
    - Use appropriate date/time functions
    - Optimize JOIN operations
    - Add LIMIT clause if not specified
    """
    
    # Build task description
    # If schema is provided, use it; otherwise instruct agent to get it from context
    if detailed_schema and detailed_schema.get("tables"):
        schema_text = f"""
        Database Schema (use as db_schema):
        {json.dumps(detailed_schema, indent=2)}
        """
    else:
        schema_text = """
        Database Schema: Extract from the context of previous tasks (schema_detail_task).
        Look for schema information in the task outputs above.
        """
    
    if query_requirements and len(query_requirements) > 1:
        requirements_text = f"""
        Query Requirements (use as query_plan):
        {json.dumps(query_requirements, indent=2)}
        """
    else:
        requirements_text = """
        Query Requirements: Extract from the context of previous tasks (feasibility_task).
        Look for query plan information in the task outputs above.
        """
    
    return Task(
        description=f"""
        Generate SQL query for: {user_query}
        
        CRITICAL INSTRUCTIONS:
        1. DO NOT say "I need to extract" - you MUST extract and use the information NOW
        2. DO NOT request anything from the user - all information is in the context
        3. You MUST use the sql_generator tool - do not generate SQL manually
        
        EXTRACTION PROCESS:
        
        STEP 1: Get the database schema
        - Look at the context from schema_detail_task
        - The schema should be in JSON format with tables and columns
        - If you see schema_retrieval tool output, that's the schema - use it directly
        - Extract it as a dict with structure: {{"tables": {{"table_name": {{"columns": [...]}}}}}}
        
        STEP 2: Get the query plan
        - Look at the context from feasibility_task or validation_task
        - Extract entities (what to SELECT), conditions (WHERE clauses), group_by (GROUP BY clauses)
        - Format as: {{"entities": [...], "conditions": [...], "group_by": [...], "query_type": "SELECT"}}
        
        STEP 3: Call sql_generator tool IMMEDIATELY
        - Input format: query_plan (dict), db_schema (dict), dialect (string: "{sql_dialect}")
        - Example call:
          sql_generator(
            query_plan={{"entities": ["region", "SUM(amount)"], "group_by": ["region"], "query_type": "SELECT"}},
            db_schema={{"tables": {{"sales": {{"columns": ["sale_id", "order_id", "region", "amount"]}}}}}},
            dialect="{sql_dialect}"
          )
        
        STEP 4: Extract SQL from tool response
        - The tool returns JSON with "sql" field
        - Extract the "sql" value
        - Return ONLY the SQL query in this format:
        
        ```sql
        [SQL QUERY HERE]
        ```
        
        EXAMPLE:
        If user query is "What is the total sales by region?":
        1. Schema shows: sales table with columns: sale_id, order_id, region, amount, sale_date
        2. Query plan: {{"entities": ["region", "SUM(amount) AS total_sales"], "group_by": ["region"], "query_type": "SELECT"}}
        3. Call tool with these parameters
        4. Extract SQL from response
        5. Return: ```sql\nSELECT region, SUM(amount) AS total_sales FROM sales GROUP BY region\n```
        
        DO NOT:
        - Say "I need to extract" - just extract and use it
        - Say "I need to request" - everything is in context
        - Generate SQL manually - use the tool
        - Return explanations or text - only return SQL in code block
        """,
        agent=agent,
        expected_output="SQL query in markdown code block format (```sql ... ```), extracted from sql_generator tool"
    )

