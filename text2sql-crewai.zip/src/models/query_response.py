"""Response models for Text-to-SQL API."""
from typing import Optional, Any
from datetime import datetime
from pydantic import BaseModel, Field


class ValidationResult(BaseModel):
    """Query validation result."""
    valid: bool = Field(..., description="Whether the query is valid")
    query_type: Optional[str] = Field(None, description="Type of query (SELECT, AGGREGATE, etc.)")
    entities: list[str] = Field(default_factory=list, description="Extracted entities")
    conditions: list[str] = Field(default_factory=list, description="Extracted conditions")
    ambiguities: list[str] = Field(default_factory=list, description="Detected ambiguities")
    missing_info: list[str] = Field(default_factory=list, description="Missing information")
    suggestions: list[str] = Field(default_factory=list, description="Suggestions for improvement")


class SchemaInfo(BaseModel):
    """Schema information."""
    table: str = Field(..., description="Table name")
    relevance_score: float = Field(..., description="Relevance score (0-1)")
    columns: list[dict[str, Any]] = Field(default_factory=list, description="Column information")
    description: Optional[str] = Field(None, description="Table description")


class QueryResult(BaseModel):
    """SQL query execution result."""
    status: str = Field(..., description="Execution status (success, failed, timeout)")
    rows: int = Field(default=0, description="Number of rows returned")
    execution_time: float = Field(default=0.0, description="Execution time in seconds")
    data: list[dict[str, Any]] = Field(default_factory=list, description="Query result data")
    error: Optional[str] = Field(None, description="Error message if failed")


class QueryResponse(BaseModel):
    """Response model for SQL generation."""
    status: str = Field(..., description="Overall status (success, failed)")
    sql: Optional[str] = Field(None, description="Generated SQL query")
    explanation: Optional[str] = Field(None, description="Query explanation")
    validation: Optional[ValidationResult] = Field(None, description="Validation results")
    schema_used: list[SchemaInfo] = Field(default_factory=list, description="Schema information used")
    execution_result: Optional[QueryResult] = Field(None, description="Execution results if executed")
    error: Optional[str] = Field(None, description="Error message if failed")
    processing_time: float = Field(default=0.0, description="Total processing time")
    timestamp: datetime = Field(default_factory=datetime.now, description="Response timestamp")

    class Config:
        json_schema_extra = {
            "example": {
                "status": "success",
                "sql": "SELECT region, SUM(amount) as total_sales FROM sales WHERE date >= DATE_SUB(NOW(), 90) GROUP BY region",
                "explanation": "This query calculates total sales by region for the last quarter",
                "processing_time": 3.45,
                "execution_result": {
                    "status": "success",
                    "rows": 5,
                    "execution_time": 1.2,
                    "data": []
                }
            }
        }

