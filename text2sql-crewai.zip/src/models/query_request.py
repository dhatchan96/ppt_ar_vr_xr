"""Request models for Text-to-SQL API."""
from typing import Optional
from pydantic import BaseModel, Field


class UserContext(BaseModel):
    """User authentication and authorization context."""
    user_id: str = Field(..., description="Unique user identifier")
    jwt_token: Optional[str] = Field(None, description="JWT authentication token")
    permissions: list[str] = Field(default_factory=list, description="List of accessible databases")


class QueryRequest(BaseModel):
    """Request model for SQL generation."""
    query: str = Field(..., description="Natural language query", min_length=1)
    database: str = Field(..., description="Target database name")
    sql_dialect: str = Field(default="sqlite", description="SQL dialect (sqlite, impala, postgresql, mysql)")
    user_context: Optional[UserContext] = Field(None, description="User context for authorization")
    execute: bool = Field(default=False, description="Whether to execute the query")
    limit: int = Field(default=100, description="Maximum number of rows to return", gt=0, le=10000)
    timeout: int = Field(default=60, description="Query timeout in seconds", gt=0, le=300)

    class Config:
        json_schema_extra = {
            "example": {
                "query": "Show me total sales by region for last quarter",
                "database": "sales_db",
                "sql_dialect": "impala",
                "execute": True,
                "limit": 100
            }
        }

