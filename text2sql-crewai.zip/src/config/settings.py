"""Settings management for Text-to-SQL system."""
import os
from pathlib import Path
from typing import Optional
import yaml
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Check if API key is already set in system environment
existing_key = os.getenv("OPENAI_API_KEY", "")
if existing_key:
    print(f"Found existing OPENAI_API_KEY in system environment (last 4: {existing_key[-4:]})")

# Load environment variables from .env file
# Try loading from project root (parent of src directory)
# settings.py is in src/config/, so go up 2 levels to get project root
project_root = Path(__file__).parent.parent.parent
env_file = project_root / ".env"

# Also try current working directory
cwd_env = Path.cwd() / ".env"

# Load .env file - use override=False to keep existing env vars, or True to override
if env_file.exists():
    load_dotenv(dotenv_path=env_file, override=True)  # Override system env with .env
    new_key = os.getenv("OPENAI_API_KEY", "")
    if new_key and new_key != existing_key:
        print(f"Loaded .env file from: {env_file}")
        print(f"API key updated (last 4: {new_key[-4:]})")
    elif new_key:
        print(f"Loaded .env file from: {env_file} (same key as system env)")
    else:
        print(f"Warning: .env file found at {env_file} but OPENAI_API_KEY not set in it")
elif cwd_env.exists():
    load_dotenv(dotenv_path=cwd_env, override=True)
    new_key = os.getenv("OPENAI_API_KEY", "")
    if new_key and new_key != existing_key:
        print(f"Loaded .env file from: {cwd_env}")
        print(f"API key updated (last 4: {new_key[-4:]})")
    elif new_key:
        print(f"Loaded .env file from: {cwd_env} (same key as system env)")
    else:
        print(f"Warning: .env file found at {cwd_env} but OPENAI_API_KEY not set in it")
else:
    # Fallback: load_dotenv() searches current directory and parent directories
    result = load_dotenv(override=True)
    final_key = os.getenv("OPENAI_API_KEY", "")
    if result and final_key:
        print(f"Loaded .env file from default search path (last 4: {final_key[-4:]})")
    elif final_key:
        print(f"Using API key from system environment (last 4: {final_key[-4:]})")
    else:
        print(f"Warning: .env file not found. Searched in: {env_file}, {cwd_env}, and default locations")
        print("OPENAI_API_KEY not set in environment or .env file")


class DatabaseConfig(BaseModel):
    """Database configuration."""
    type: str = "sqlite"  # sqlite, impala, postgresql, mysql
    path: Optional[str] = "data/text2sql.db"  # For SQLite
    host: str = "localhost"  # For Impala/PostgreSQL/MySQL
    port: int = 21050
    database: str = "default"
    auth_mechanism: str = "PLAIN"
    user: Optional[str] = None
    password: Optional[str] = None


class AgentConfig(BaseModel):
    """Agent configuration."""
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.0
    max_iterations: int = 5
    cache_ttl: int = 3600
    max_timeout: int = 60
    default_limit: int = 100
    format_instructions: Optional[str] = None


class OpenAIConfig(BaseModel):
    """OpenAI configuration."""
    api_key: str = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    model: str = "gpt-4"
    temperature: float = 0.0
    
    def __init__(self, **data):
        # Ensure we get the latest value from environment after load_dotenv
        if "api_key" not in data or not data.get("api_key"):
            data["api_key"] = os.getenv("OPENAI_API_KEY", "")
        super().__init__(**data)


class OrchestraConfig(BaseModel):
    """Orchestra API gateway configuration."""
    api_key: str = Field(default_factory=lambda: os.getenv("ORCHESTRA_API_KEY", ""))
    base_url: str = "https://api-gateway.example.com/api/v1/chat"
    model: str = "gpt-4.1-2025-04-14"
    temperature: float = 0.0
    
    def __init__(self, **data):
        # Ensure we get the latest value from environment after load_dotenv
        if "api_key" not in data or not data.get("api_key"):
            data["api_key"] = os.getenv("ORCHESTRA_API_KEY", "")
        super().__init__(**data)


class AnthropicConfig(BaseModel):
    """Anthropic Claude configuration."""
    api_key: str = Field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))
    model: str = "claude-3-5-sonnet-20241022"
    temperature: float = 0.0
    
    def __init__(self, **data):
        # Ensure we get the latest value from environment after load_dotenv
        if "api_key" not in data or not data.get("api_key"):
            data["api_key"] = os.getenv("ANTHROPIC_API_KEY", "")
        super().__init__(**data)


class LLMConfig(BaseModel):
    """LLM provider configuration."""
    provider: str = "openai"  # "orchestra", "openai", or "anthropic"
    orchestra: Optional[OrchestraConfig] = None
    openai: Optional[OpenAIConfig] = None
    anthropic: Optional[AnthropicConfig] = None


class RedisConfig(BaseModel):
    """Redis configuration."""
    enabled: bool = True
    host: str = "localhost"
    port: int = 6379
    db: int = 0


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file: str = "text2sql.log"


class Settings(BaseModel):
    """Main settings class."""
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)
    llm: Optional[LLMConfig] = None
    openai: Optional[OpenAIConfig] = Field(default_factory=OpenAIConfig)  # Keep for backward compatibility
    redis: RedisConfig = Field(default_factory=RedisConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    @classmethod
    def load_from_yaml(cls, config_path: Optional[Path] = None) -> "Settings":
        """Load settings from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent / "config.yaml"
        
        if not config_path.exists():
            return cls()
        
        with open(config_path, 'r') as f:
            config_data = yaml.safe_load(f)
        
        # Process environment variables in config
        config_str = yaml.dump(config_data)
        for key, value in os.environ.items():
            config_str = config_str.replace(f"${{{key}}}", value)
        config_data = yaml.safe_load(config_str)
        
        # Ensure API key from environment takes precedence over YAML
        # (in case YAML has placeholder that wasn't replaced)
        if "openai" in config_data and "api_key" in config_data["openai"]:
            env_key = os.getenv("OPENAI_API_KEY", "")
            if env_key:
                config_data["openai"]["api_key"] = env_key
                print(f"Using API key from environment variable (last 4: {env_key[-4:]})")
            elif config_data["openai"]["api_key"] and config_data["openai"]["api_key"] != "${OPENAI_API_KEY}":
                print(f"Using API key from config.yaml (last 4: {config_data['openai']['api_key'][-4:]})")
            else:
                print("Warning: No API key found in environment or config.yaml")
        
        # Handle LLM config with provider selection
        if "llm" in config_data:
            llm_config = config_data["llm"]
            provider = llm_config.get("provider", "openai")
            
            # Set API keys from environment for the selected provider
            if provider == "orchestra" and "orchestra" in llm_config:
                env_key = os.getenv("ORCHESTRA_API_KEY", "")
                if env_key:
                    llm_config["orchestra"]["api_key"] = env_key
                    print(f"Using Orchestra API key from environment (last 4: {env_key[-4:]})")
            elif provider == "openai" and "openai" in llm_config:
                env_key = os.getenv("OPENAI_API_KEY", "")
                if env_key:
                    llm_config["openai"]["api_key"] = env_key
                    print(f"Using OpenAI API key from environment (last 4: {env_key[-4:]})")
            elif provider == "anthropic" and "anthropic" in llm_config:
                env_key = os.getenv("ANTHROPIC_API_KEY", "")
                if env_key:
                    llm_config["anthropic"]["api_key"] = env_key
                    print(f"Using Anthropic API key from environment (last 4: {env_key[-4:]})")
            
            print(f"LLM Provider: {provider}")
        
        return cls(**config_data)


# Global settings instance
settings = Settings.load_from_yaml()

