"""SQL generation tool for creating optimized SQL queries."""
import json
import logging
from typing import Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SQLGenerationInput(BaseModel):
    """Input schema for SQLGenerationTool."""
    query_plan: dict = Field(..., description="Parsed query plan with requirements")
    db_schema: dict = Field(..., description="Database schema information")
    dialect: str = Field(default="sqlite", description="SQL dialect (sqlite, impala, postgresql, mysql)")


class SQLGenerationTool(BaseTool):
    """
    Generates optimized SQL queries from structured requirements.
    """
    name: str = "sql_generator"
    description: str = """
    Generates optimized SQL query from structured requirements.
    Input should be a JSON string with keys:
    - query_plan (dict): Parsed query plan with entities, conditions, query_type
    - db_schema (dict): Database schema information
    - dialect (str): SQL dialect - 'impala', 'postgresql', or 'mysql'
    
    Returns: JSON with:
    - sql (str): Generated SQL query
    - explanation (str): Query explanation
    - estimated_complexity (str): Query complexity estimate
    
    Example input:
    {
        "query_plan": {"query_type": "SELECT", "entities": ["customers"], "conditions": []},
        "db_schema": {"customers": {"columns": ["id", "name"]}},
        "dialect": "impala"
    }
    """

    def _run(self, query_plan: dict, db_schema: dict, dialect: str = "sqlite") -> str:
        """
        Generate SQL query.
        
        Args:
            query_plan: Parsed query requirements
            db_schema: Database schema information
            dialect: SQL dialect to use
            
        Returns:
            JSON string with SQL query and metadata
        """
        try:
            logger.info(f"Generating SQL with dialect={dialect}")
            
            result = self._generate_sql(query_plan, db_schema, dialect)
            
            return json.dumps(result, indent=2)
        
        except Exception as e:
            logger.error(f"Error generating SQL: {str(e)}")
            return json.dumps({
                "sql": None,
                "explanation": f"Error: {str(e)}",
                "estimated_complexity": "unknown",
                "error": str(e)
            })

    def _generate_sql(self, query_plan: dict, db_schema: dict, dialect: str) -> dict[str, Any]:
        """
        Generate SQL based on query plan and schema.
        
        This uses LLM-based generation for better accuracy.
        """
        from ..config import settings
        from ..utils.llm_factory import get_llm
        
        # Use LLM to generate SQL from query plan
        config = settings.agents.get("sql_create_master", {})
        llm = get_llm(
            settings,
            model=getattr(config, 'model', 'gpt-4') if hasattr(config, 'model') else 'gpt-4',
            temperature=getattr(config, 'temperature', 0.0) if hasattr(config, 'temperature') else 0.0
        )
        
        # Build prompt for LLM
        format_instructions = getattr(config, 'format_instructions', '') if hasattr(config, 'format_instructions') else ''
        
        # Extract table name from schema
        table_name = None
        if isinstance(db_schema, dict):
            if "tables" in db_schema:
                tables_dict = db_schema["tables"]
                if isinstance(tables_dict, dict):
                    # Get the first table that matches conditions
                    for tname in tables_dict.keys():
                        if tname in str(query_plan.get("conditions", [])) or tname in str(query_plan.get("entities", [])):
                            table_name = tname
                            break
                    if not table_name and tables_dict:
                        table_name = list(tables_dict.keys())[0]
            else:
                # Schema is already the tables dict
                for tname in db_schema.keys():
                    if tname in str(query_plan.get("conditions", [])) or tname in str(query_plan.get("entities", [])):
                        table_name = tname
                        break
                if not table_name and db_schema:
                    table_name = list(db_schema.keys())[0]
        
        # Format schema in a clear, readable way for the LLM
        schema_text = self._format_schema_for_llm(db_schema)
        
        prompt = f"""Generate a correct SQL query for SQLite based on the following query plan and schema.

QUERY PLAN:
{json.dumps(query_plan, indent=2)}

DATABASE SCHEMA (READ THIS CAREFULLY - USE EXACT COLUMN NAMES FROM HERE):
{schema_text}

SQL DIALECT: {dialect}

{format_instructions}

CRITICAL RULES - FOLLOW THESE EXACTLY:
1. The table name is: {table_name if table_name else 'determine from schema'}
   - Use this EXACT table name in the FROM clause
   - DO NOT use column names (like "region") as table names

2. COLUMN NAMES - READ THE SCHEMA ABOVE AND USE EXACT COLUMN NAMES:
   - The schema above shows the EXACT column names for each table
   - DO NOT guess or make up column names
   - DO NOT use variations like "sale_amount" when schema shows "amount"
   - DO NOT use "product_category" when schema shows "category"
   - DO NOT use "customer_name" when schema shows "name"
   - For each table in the schema, use ONLY the column names listed
   - If multiple tables are involved, use table.column format (e.g., "products.category")
   - Cross-reference every column name you use with the schema above

3. SELECT clause:
   - Include ALL items from query_plan.entities in SELECT
   - Replace any incorrect column names with correct ones from db_schema
   - If entities has "SUM(sale_amount)", change to "SUM(amount)"
   - If entities has "region", use "region" (it's a column in sales table)

4. GROUP BY clause:
   - If query_plan.group_by exists, you MUST include GROUP BY
   - Use exact column names from db_schema

5. WHERE clause:
   - Include ALL conditions from query_plan.conditions
   - Use correct column names from db_schema
   - Use table.column format if needed (e.g., "sales.sale_date")

6. JOINs (for multi-table queries):
   - If query requires multiple tables, use appropriate JOINs
   - For sales by product category: JOIN sales -> orders -> products
   - Use correct foreign key relationships:
     * sales.order_id = orders.order_id
     * orders.product_id = products.product_id
     * orders.customer_id = customers.customer_id
   - Always use table.column format in JOINs and SELECT when multiple tables are involved
   - DO NOT use non-existent columns like "customer_name" - use "customers.name" instead

EXAMPLE:
If query_plan has:
- entities: ["region", "SUM(amount) AS total_sales"]
- group_by: ["region"]
- conditions: ["sale_date >= date('now', '-3 month')"]
- db_schema shows table "sales" with columns: ["sale_id", "order_id", "region", "amount", "sale_date", "salesperson_id"]

Then generate:
SELECT region, SUM(amount) AS total_sales
FROM sales
WHERE sale_date >= date('now', '-3 month')
GROUP BY region
LIMIT 100

CRITICAL VALIDATION STEP:
Before returning SQL, verify:
1. Every column name in your SQL exists in the schema above
2. Every table name in your SQL exists in the schema above
3. For multi-table queries, you're using table.column format
4. You're using the EXACT column names from the schema, not variations

If the schema shows:
- Table "products" has column "category" → use "products.category" (NOT "product_category")
- Table "sales" has column "amount" → use "sales.amount" (NOT "sale_amount")
- Table "customers" has column "name" → use "customers.name" (NOT "customer_name")

READ THE SCHEMA CAREFULLY - it shows the exact structure. Use it.

EXAMPLE FOR MULTI-TABLE QUERY:
If query is "Show total sales by region and product category":
- Join: sales -> orders (on sales.order_id = orders.order_id) -> products (on orders.product_id = products.product_id)
- SELECT: sales.region, products.category, SUM(sales.amount) AS total_sales
- GROUP BY: sales.region, products.category

SQL:
SELECT sales.region, products.category, SUM(sales.amount) AS total_sales
FROM sales
INNER JOIN orders ON sales.order_id = orders.order_id
INNER JOIN products ON orders.product_id = products.product_id
GROUP BY sales.region, products.category
LIMIT 100

Return ONLY the SQL query, no markdown, no explanations."""

        try:
            response = llm.invoke(prompt)
            sql = response.content.strip()
            
            # Remove markdown code blocks if present
            if sql.startswith("```"):
                lines = sql.split("\n")
                sql = "\n".join([line for line in lines if not line.strip().startswith("```")])
            
            sql = sql.strip()
            
            # Validate SQL has required components
            sql_lower = sql.lower()
            if "select" not in sql_lower:
                raise ValueError("Generated SQL missing SELECT clause")
            
            # Fix common column name mistakes
            sql = self._fix_column_names(sql, db_schema)
            sql_lower = sql.lower()  # Recalculate after fixes
            
            # Extract table name for explanation
            from_table = None
            if "from" in sql_lower:
                parts = sql_lower.split("from")
                if len(parts) > 1:
                    from_table = parts[1].split()[0].strip()
            
            explanation = f"Generated SQL query for {dialect} dialect"
            if from_table:
                explanation += f" querying {from_table} table"
            
            complexity = "medium"
            if "group by" in sql_lower or "sum(" in sql_lower or "count(" in sql_lower:
                complexity = "medium"
            if "join" in sql_lower:
                complexity = "high"
            
            return {
                "sql": sql,
                "explanation": explanation,
                "estimated_complexity": complexity,
                "dialect": dialect
            }
        
        except Exception as e:
            logger.error(f"Error in LLM-based SQL generation: {str(e)}")
            # Fallback to rule-based generation
            return self._generate_sql_rule_based(query_plan, db_schema, dialect)
    
    def _generate_sql_rule_based(self, query_plan: dict, db_schema: dict, dialect: str) -> dict[str, Any]:
        """Fallback rule-based SQL generation."""
        query_type = query_plan.get("query_type", "SELECT")
        entities = query_plan.get("entities", [])
        conditions = query_plan.get("conditions", [])
        group_by = query_plan.get("group_by", [])
        
        tables = db_schema.get("tables", {})
        if isinstance(tables, dict) and "tables" in tables:
            tables = tables["tables"]
        
        # Start building SQL
        sql_parts = {
            "select": [],
            "from": [],
            "where": [],
            "group_by": [],
            "order_by": [],
            "limit": None
        }
        
        # Extract table name from entities or schema
        main_table = None
        for entity in entities:
            if "." in entity:
                main_table = entity.split(".")[0]
                break
        
        if not main_table:
            # Try to find table from schema
            for table_name in tables.keys():
                if table_name in str(entities) or table_name in str(conditions):
                    main_table = table_name
                    break
        
        if not main_table and tables:
            main_table = list(tables.keys())[0]
        
        if main_table:
            sql_parts["from"].append(main_table)
        
        # Build SELECT clause from entities
        for entity in entities:
            # Handle table.column format
            if "." in entity:
                parts = entity.split(".")
                if len(parts) == 2:
                    col = parts[1]
                    sql_parts["select"].append(self._quote_identifier(col, dialect))
                else:
                    sql_parts["select"].append(entity)
            elif entity.upper().startswith(("SUM(", "COUNT(", "AVG(", "MAX(", "MIN(")):
                # Aggregation function
                sql_parts["select"].append(entity)
            else:
                # Regular column
                sql_parts["select"].append(self._quote_identifier(entity, dialect))
        
        if not sql_parts["select"]:
            sql_parts["select"].append("*")
        
        # Build WHERE clause
        for condition in conditions:
            if isinstance(condition, str):
                sql_parts["where"].append(condition)
            elif isinstance(condition, dict):
                column = condition.get("column")
                operator = condition.get("operator", "=")
                value = condition.get("value")
                sql_parts["where"].append(f"{self._quote_identifier(column, dialect)} {operator} {self._format_value(value)}")
        
        # Build GROUP BY
        for col in group_by:
            if "." in col:
                col = col.split(".")[-1]
            sql_parts["group_by"].append(self._quote_identifier(col, dialect))
        
        # Add LIMIT
        sql_parts["limit"] = query_plan.get("limit", 100)
        
        # Construct final SQL
        sql = self._construct_sql(sql_parts, dialect)
        
        explanation = self._generate_explanation(sql_parts, query_type)
        complexity = self._estimate_complexity(sql_parts, tables)
        
        return {
            "sql": sql,
            "explanation": explanation,
            "estimated_complexity": complexity,
            "dialect": dialect
        }

    def _quote_identifier(self, identifier: str, dialect: str) -> str:
        """Quote identifier based on dialect."""
        if dialect == "sqlite":
            # SQLite can use double quotes or backticks, but double quotes are standard
            return f'"{identifier}"'
        elif dialect == "impala":
            return f"`{identifier}`"
        elif dialect == "postgresql":
            return f'"{identifier}"'
        elif dialect == "mysql":
            return f"`{identifier}`"
        else:
            return identifier

    def _format_value(self, value: Any) -> str:
        """Format value for SQL."""
        if isinstance(value, str):
            return f"'{value}'"
        elif value is None:
            return "NULL"
        else:
            return str(value)

    def _construct_sql(self, sql_parts: dict, dialect: str) -> str:
        """Construct final SQL from parts."""
        sql = "SELECT "
        
        # SELECT clause
        if sql_parts["select"]:
            sql += ", ".join(sql_parts["select"])
        else:
            sql += "*"
        
        # FROM clause
        sql += "\nFROM " + ", ".join(sql_parts["from"])
        
        # WHERE clause
        if sql_parts["where"]:
            sql += "\nWHERE " + " AND ".join(sql_parts["where"])
        
        # GROUP BY clause
        if sql_parts["group_by"]:
            sql += "\nGROUP BY " + ", ".join(sql_parts["group_by"])
        
        # ORDER BY clause
        if sql_parts["order_by"]:
            sql += "\nORDER BY " + ", ".join(sql_parts["order_by"])
        
        # LIMIT clause
        if sql_parts["limit"]:
            sql += f"\nLIMIT {sql_parts['limit']}"
        
        return sql

    def _generate_explanation(self, sql_parts: dict, query_type: str) -> str:
        """Generate human-readable explanation."""
        explanation = []
        
        explanation.append(f"This is a {query_type} query that:")
        
        if sql_parts["select"]:
            explanation.append(f"- Selects {len(sql_parts['select'])} column(s)")
        
        if sql_parts["from"]:
            explanation.append(f"- From table(s): {', '.join(sql_parts['from'])}")
        
        if sql_parts["where"]:
            explanation.append(f"- Filters data with {len(sql_parts['where'])} condition(s)")
        
        if sql_parts["group_by"]:
            explanation.append(f"- Groups results by {len(sql_parts['group_by'])} column(s)")
        
        if sql_parts["limit"]:
            explanation.append(f"- Limits output to {sql_parts['limit']} rows")
        
        return "\n".join(explanation)

    def _fix_column_names(self, sql: str, db_schema: dict) -> str:
        """Fix common column name mistakes in generated SQL."""
        import re
        
        # Common mistakes to fix
        fixes = {
            "sale_amount": "amount",  # sales table uses "amount" not "sale_amount"
            "region_name": "name",  # regions table uses "name" not "region_name"
            "sales.region_id": "sales.region",  # sales has "region" TEXT, not "region_id"
            "customer_name": "customers.name",  # customers table has "name" not "customer_name"
            "customers.customer_name": "customers.name",
            "product_name": "products.name",  # products table has "name" not "product_name"
            "products.product_name": "products.name",
            "product_category": "products.category",  # products table has "category" not "product_category"
            "products.product_category": "products.category",
            "category": "products.category",  # If in context of products table, use products.category
        }
        
        # Get actual column names from schema
        if isinstance(db_schema, dict):
            tables = db_schema.get("tables", {})
            if isinstance(tables, dict):
                # Build a map of common wrong names to correct names
                for table_name, table_info in tables.items():
                    if isinstance(table_info, dict):
                        columns = table_info.get("columns", [])
                        if isinstance(columns, list):
                            # Check for sales table
                            if table_name == "sales" and "amount" in columns:
                                fixes["sale_amount"] = "amount"
                                fixes["sales.sale_amount"] = "sales.amount"
                                fixes["SUM(sale_amount)"] = "SUM(amount)"
                                fixes["SUM(sales.sale_amount)"] = "SUM(sales.amount)"
                            # Check for regions table
                            if table_name == "regions" and "name" in columns:
                                fixes["region_name"] = "name"
                                fixes["regions.region_name"] = "regions.name"
                            # Check for customers table
                            if table_name == "customers" and "name" in columns:
                                fixes["customer_name"] = "customers.name"
                                fixes["customers.customer_name"] = "customers.name"
                            # Check for products table
                            if table_name == "products":
                                if "name" in columns:
                                    fixes["product_name"] = "products.name"
                                    fixes["products.product_name"] = "products.name"
                                if "category" in columns:
                                    fixes["product_category"] = "products.category"
                                    fixes["products.product_category"] = "products.category"
        
        # Apply fixes (order matters - do longer matches first)
        fixed_sql = sql
        for wrong, correct in sorted(fixes.items(), key=lambda x: -len(x[0])):
            # Replace whole word matches (case insensitive)
            # Escape special regex characters
            escaped = re.escape(wrong)
            pattern = re.compile(r'\b' + escaped + r'\b', re.IGNORECASE)
            fixed_sql = pattern.sub(correct, fixed_sql)
        
        # Additional fix: Remove references to non-existent columns in SELECT
        # If we see customer_name without table prefix and customers table exists, fix it
        if "customer_name" in fixed_sql.lower() and "customers.name" not in fixed_sql.lower():
            pattern = re.compile(r'\bcustomer_name\b', re.IGNORECASE)
            fixed_sql = pattern.sub("customers.name", fixed_sql)
        
        # Fix product_category -> products.category
        if "product_category" in fixed_sql and "products.category" not in fixed_sql:
            # Check if it's in a multi-table context (has products table)
            if "products" in fixed_sql.lower() or "FROM products" in fixed_sql.upper() or "JOIN products" in fixed_sql.upper():
                pattern = re.compile(r'\bproduct_category\b', re.IGNORECASE)
                fixed_sql = pattern.sub("products.category", fixed_sql)
        
        return fixed_sql
    
    def _estimate_complexity(self, sql_parts: dict, tables: dict) -> str:
        """Estimate query complexity."""
        score = 0
        
        # Base complexity
        score += len(sql_parts["select"]) * 1
        score += len(sql_parts["from"]) * 5
        score += len(sql_parts["where"]) * 2
        score += len(sql_parts["group_by"]) * 3
        
        # Estimate based on table sizes (if available)
        for table in sql_parts["from"]:
            if table in tables:
                table_info = tables.get(table, {})
                if isinstance(table_info, dict):
                    row_count = table_info.get("row_count", 0)
                    if row_count > 1000000:
                        score += 10
                    elif row_count > 100000:
                        score += 5
        
        if score < 10:
            return "low"
        elif score < 25:
            return "medium"
        else:
            return "high"

