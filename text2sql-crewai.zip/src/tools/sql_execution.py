"""SQL execution tool for running queries against database."""
import json
import logging
import time
from typing import Any, Optional
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SQLExecutionInput(BaseModel):
    """Input schema for SQLExecutionTool."""
    sql: str = Field(..., description="SQL query to execute")
    limit: int = Field(default=100, description="Maximum number of rows to return")
    timeout: int = Field(default=60, description="Query timeout in seconds")


class SQLExecutionTool(BaseTool):
    """
    Executes SQL queries and returns formatted results.
    """
    name: str = "sql_executor"
    description: str = """
    Executes SQL query against the database.
    Input should be a JSON string with keys:
    - sql (str): The SQL query to execute
    - limit (int, optional): Maximum rows to return (default: 100)
    - timeout (int, optional): Timeout in seconds (default: 60)
    
    Returns: JSON with:
    - results (list): Query result rows as list of dictionaries
    - row_count (int): Number of rows returned
    - execution_time (float): Execution time in seconds
    - status (str): Execution status
    
    Example input:
    {"sql": "SELECT * FROM customers LIMIT 10", "limit": 100, "timeout": 60}
    """

    def _run(self, sql: str, limit: int = 100, timeout: int = 60) -> str:
        """
        Execute SQL query.
        
        Args:
            sql: SQL query to execute
            limit: Maximum number of rows to return
            timeout: Query timeout in seconds
            
        Returns:
            JSON string with execution results
        """
        try:
            logger.info(f"Executing SQL query with limit={limit}, timeout={timeout}")
            logger.debug(f"SQL: {sql}")
            
            result = self._execute_query(sql, limit, timeout)
            
            return json.dumps(result, indent=2, default=str)
        
        except Exception as e:
            logger.error(f"Error executing SQL: {str(e)}")
            return json.dumps({
                "status": "failed",
                "error": str(e),
                "results": [],
                "row_count": 0,
                "execution_time": 0.0
            })

    def _execute_query(self, sql: str, limit: int, timeout: int) -> dict[str, Any]:
        """
        Execute query against database.
        """
        start_time = time.time()
        
        try:
            from ..config import settings
            
            # Get database config
            db_config = {
                "type": settings.database.type,
                "path": settings.database.path,
                "host": settings.database.host,
                "port": settings.database.port,
                "database": settings.database.database,
            }
            
            # Connect to database
            conn = self._connect_to_database(db_config)
            cursor = conn.cursor()
            
            try:
                # Add LIMIT if not present and it's a SELECT query
                sql_upper = sql.upper().strip()
                if sql_upper.startswith("SELECT") and "LIMIT" not in sql_upper:
                    sql = f"{sql.rstrip(';')} LIMIT {limit}"
                
                # Execute query
                cursor.execute(sql)
                
                # Fetch results
                rows = cursor.fetchall()
                
                # Get column names
                columns = [description[0] for description in cursor.description] if cursor.description else []
                
                # Convert rows to dictionaries
                if db_config["type"] == "sqlite":
                    # sqlite3.Row objects can be converted to dict
                    data = [dict(row) for row in rows]
                else:
                    # For other databases, convert tuple rows to dict
                    data = [dict(zip(columns, row)) for row in rows]
                
                execution_time = time.time() - start_time
                
                return {
                    "status": "success",
                    "results": data,
                    "row_count": len(data),
                    "execution_time": execution_time,
                    "columns": columns
                }
            
            finally:
                cursor.close()
                conn.close()
        
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Error executing query: {str(e)}", exc_info=True)
            
            return {
                "status": "failed",
                "results": [],
                "row_count": 0,
                "execution_time": execution_time,
                "columns": [],
                "error": str(e)
            }

    def _generate_mock_results(self, sql: str, limit: int) -> dict[str, Any]:
        """
        Generate mock results for demonstration.
        
        In production, this would be replaced with actual query execution.
        """
        sql_lower = sql.lower()
        
        # Determine columns from SQL (simplified parsing)
        columns = []
        data = []
        
        if "customers" in sql_lower:
            columns = ["customer_id", "name", "email", "country", "created_date"]
            data = [
                {
                    "customer_id": i,
                    "name": f"Customer {i}",
                    "email": f"customer{i}@example.com",
                    "country": ["USA", "UK", "Canada", "Germany"][i % 4],
                    "created_date": f"2024-0{(i % 9) + 1}-15"
                }
                for i in range(1, min(limit + 1, 6))
            ]
        
        elif "orders" in sql_lower:
            columns = ["order_id", "customer_id", "product_id", "order_date", "amount", "status"]
            data = [
                {
                    "order_id": i,
                    "customer_id": (i % 5) + 1,
                    "product_id": (i % 10) + 1,
                    "order_date": f"2024-{(i % 12) + 1:02d}-15",
                    "amount": round(100.0 + (i * 25.5), 2),
                    "status": ["pending", "completed", "shipped"][i % 3]
                }
                for i in range(1, min(limit + 1, 6))
            ]
        
        elif "sales" in sql_lower and ("sum" in sql_lower or "count" in sql_lower or "group by" in sql_lower):
            # Aggregation query
            columns = ["region", "total_sales"]
            data = [
                {"region": "North", "total_sales": 125000.50},
                {"region": "South", "total_sales": 98500.75},
                {"region": "East", "total_sales": 156000.25},
                {"region": "West", "total_sales": 142500.00}
            ]
        
        else:
            # Generic result
            columns = ["column1", "column2", "column3"]
            data = [
                {
                    "column1": f"value{i}_1",
                    "column2": f"value{i}_2",
                    "column3": i * 10
                }
                for i in range(1, min(limit + 1, 6))
            ]
        
        return {
            "columns": columns,
            "data": data
        }

    def _connect_to_database(self, config: dict) -> Any:
        """
        Connect to database based on configuration.
        """
        db_type = config.get("type", "sqlite")
        
        if db_type == "sqlite":
            import sqlite3
            from pathlib import Path
            
            db_path = config.get("path", "data/text2sql.db")
            # Handle relative paths
            if not Path(db_path).is_absolute():
                # Assume path is relative to project root
                # sql_execution.py is in src/tools/, so go up 3 levels to project root
                project_root = Path(__file__).parent.parent.parent
                db_path = project_root / db_path
            
            if not Path(db_path).exists():
                raise FileNotFoundError(f"SQLite database not found at: {db_path}")
            
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row  # Return rows as dict-like objects
            return conn
        
        elif db_type == "impala":
            # from impyla.dbapi import connect
            # conn = connect(
            #     host=config["host"],
            #     port=config["port"],
            #     database=config["database"],
            #     auth_mechanism=config.get("auth_mechanism", "PLAIN"),
            #     user=config.get("user"),
            #     password=config.get("password")
            # )
            # return conn
            raise NotImplementedError("Impala connection not yet implemented")
        
        elif db_type == "postgresql":
            # import psycopg2
            # conn = psycopg2.connect(
            #     host=config["host"],
            #     port=config["port"],
            #     database=config["database"],
            #     user=config["user"],
            #     password=config["password"]
            # )
            # return conn
            raise NotImplementedError("PostgreSQL connection not yet implemented")
        
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

