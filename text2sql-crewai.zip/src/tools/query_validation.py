"""Query validation tool for checking query feasibility."""
import json
import logging
from typing import Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class QueryValidationInput(BaseModel):
    """Input schema for QueryValidationTool."""
    query: str = Field(..., description="Natural language query to validate")
    db_schema: dict = Field(..., description="Database schema information")


class QueryValidationTool(BaseTool):
    """
    Validates natural language query feasibility against database schema.
    """
    name: str = "query_validator"
    description: str = """
    Validates if a natural language query can be answered with the available schema.
    Input should be a JSON string with keys:
    - query (str): The natural language query
    - db_schema (dict): The database schema information
    
    Returns: JSON with validation result including:
    - valid (bool): Whether the query is valid
    - missing_info (list): List of missing information
    - suggestions (list): List of suggestions
    - compatible_columns (list): Columns that match the query requirements
    
    Example input:
    {"query": "Show me all customers", "db_schema": {"customers": {"columns": ["id", "name", "email"]}}}
    """

    def _run(self, query: str, db_schema: dict) -> str:
        """
        Validate query against schema.
        
        Args:
            query: Natural language query
            db_schema: Database schema information
            
        Returns:
            JSON string with validation results
        """
        try:
            logger.info(f"Validating query: {query}")
            
            result = self._validate_query(query, db_schema)
            
            return json.dumps(result, indent=2)
        
        except Exception as e:
            logger.error(f"Error validating query: {str(e)}")
            return json.dumps({
                "valid": False,
                "error": str(e),
                "missing_info": [],
                "suggestions": ["Please check the query and try again"]
            })

    def _validate_query(self, query: str, schema: dict) -> dict[str, Any]:
        """
        Perform validation logic.
        
        This is a simplified implementation. In production, this would use
        more sophisticated NLP and schema matching.
        """
        query_lower = query.lower()
        missing_info = []
        suggestions = []
        compatible_columns = []
        
        # Extract tables from schema
        tables = schema.get("tables", {})
        
        if not tables:
            return {
                "valid": False,
                "missing_info": ["No schema information available"],
                "suggestions": ["Ensure schema is loaded before validation"],
                "compatible_columns": []
            }
        
        # Check for common query patterns
        found_tables = []
        for table_name, table_info in tables.items():
            if table_name in query_lower:
                found_tables.append(table_name)
                
                # Check for columns
                if isinstance(table_info, dict):
                    columns = table_info.get("columns", [])
                    for col in columns:
                        col_name = col["name"] if isinstance(col, dict) else col
                        if any(keyword in query_lower for keyword in [col_name.lower(), "all", "*"]):
                            compatible_columns.append({
                                "table": table_name,
                                "column": col_name,
                                "type": col.get("type") if isinstance(col, dict) else "UNKNOWN"
                            })
        
        # Validation logic
        if not found_tables:
            # Try to suggest tables based on query keywords
            suggested_tables = self._suggest_tables(query_lower, tables)
            if suggested_tables:
                suggestions.append(f"Consider using tables: {', '.join(suggested_tables)}")
            else:
                missing_info.append("Could not identify relevant tables from query")
        
        # Check for aggregation keywords
        aggregation_keywords = ["count", "sum", "avg", "average", "max", "min", "total"]
        has_aggregation = any(keyword in query_lower for keyword in aggregation_keywords)
        
        if has_aggregation and "group by" not in query_lower:
            suggestions.append("Consider adding grouping criteria for aggregation")
        
        # Check for date/time filters
        time_keywords = ["last", "previous", "recent", "today", "yesterday", "week", "month", "quarter", "year"]
        has_time_filter = any(keyword in query_lower for keyword in time_keywords)
        
        if has_time_filter:
            # Check if schema has date columns
            date_columns = []
            for table_name, table_info in tables.items():
                if isinstance(table_info, dict):
                    columns = table_info.get("columns", [])
                    for col in columns:
                        if isinstance(col, dict):
                            if "date" in col["name"].lower() or "timestamp" in col.get("type", "").lower():
                                date_columns.append(f"{table_name}.{col['name']}")
            
            if date_columns:
                compatible_columns.extend([
                    {"table": col.split(".")[0], "column": col.split(".")[1], "type": "TIMESTAMP"}
                    for col in date_columns
                ])
            else:
                missing_info.append("No date/timestamp columns found for time-based filtering")
        
        # Determine validity
        valid = len(missing_info) == 0 or len(found_tables) > 0
        
        return {
            "valid": valid,
            "missing_info": missing_info,
            "suggestions": suggestions,
            "compatible_columns": compatible_columns,
            "identified_tables": found_tables,
            "has_aggregation": has_aggregation,
            "has_time_filter": has_time_filter
        }

    def _suggest_tables(self, query: str, tables: dict) -> list[str]:
        """Suggest relevant tables based on query keywords."""
        suggestions = []
        
        # Simple keyword matching
        keyword_map = {
            "customer": ["customers"],
            "order": ["orders"],
            "product": ["products"],
            "sale": ["sales"],
            "employee": ["employees"],
            "department": ["departments"],
            "region": ["regions"]
        }
        
        for keyword, table_names in keyword_map.items():
            if keyword in query:
                suggestions.extend([t for t in table_names if t in tables])
        
        return list(set(suggestions))

