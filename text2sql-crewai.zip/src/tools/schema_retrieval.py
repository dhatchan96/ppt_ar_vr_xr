"""Schema retrieval tool for accessing database metadata."""
import json
import logging
import sqlite3
from pathlib import Path
from typing import Optional, Any
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Module-level cache for schema data
_schema_cache = {}

def _get_sqlite_connection():
    """Get SQLite database connection."""
    from ..config import settings
    
    db_path = settings.database.path or "data/text2sql.db"
    if not Path(db_path).is_absolute():
        # schema_retrieval.py is in src/tools/, so go up 3 levels to project root
        project_root = Path(__file__).parent.parent.parent
        db_path = project_root / db_path
    
    if not Path(db_path).exists():
        raise FileNotFoundError(f"SQLite database not found at: {db_path}")
    
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


class SchemaRetrievalInput(BaseModel):
    """Input schema for SchemaRetrievalTool."""
    database: str = Field(..., description="Database name")
    tables: Optional[list[str]] = Field(None, description="List of table names (optional)")
    level: str = Field(default="table", description="Level of detail: 'database', 'table', or 'column'")


class SchemaRetrievalTool(BaseTool):
    """
    Retrieves database schema information.
    Caches results for performance.
    """
    name: str = "schema_retrieval"
    description: str = """
    Retrieves database, table, and column metadata.
    Input should be a JSON string with keys: 
    - database (str): Database name
    - tables (list, optional): List of table names
    - level (str): Level of detail - 'database', 'table', or 'column'
    
    Returns: Structured schema information as JSON
    
    Example input:
    {"database": "sales_db", "tables": ["customers", "orders"], "level": "column"}
    """

    def _run(self, database: str, tables: Optional[list[str]] = None, level: str = "table") -> str:
        """
        Retrieve schema information.
        
        Args:
            database: Database name
            tables: Optional list of table names
            level: Level of detail ('database', 'table', 'column')
            
        Returns:
            JSON string with schema information
        """
        try:
            logger.info(f"Retrieving schema for database={database}, tables={tables}, level={level}")
            
            schema_info = self._get_schema_cached(database, tuple(tables) if tables else None, level)
            
            return json.dumps(schema_info, indent=2)
        
        except Exception as e:
            logger.error(f"Error retrieving schema: {str(e)}")
            return json.dumps({"error": str(e), "status": "failed"})

    def _get_schema_cached(self, database: str, tables: Optional[tuple[str, ...]], level: str) -> dict[str, Any]:
        """
        Cached schema retrieval using module-level cache.
        
        Note: In production, this should connect to actual database or metadata service.
        This is a mock implementation for the POC.
        """
        # Create cache key
        cache_key = f"{database}:{tables}:{level}"
        
        # Check cache
        if cache_key in _schema_cache:
            logger.debug(f"Cache hit for {cache_key}")
            return _schema_cache[cache_key]
        
        # Get schema data
        if level == "database":
            result = self._get_database_schema(database)
        elif level == "table":
            result = self._get_table_schema(database, list(tables) if tables else None)
        elif level == "column":
            result = self._get_column_schema(database, list(tables) if tables else None)
        else:
            result = {"error": f"Invalid level: {level}"}
        
        # Store in cache
        _schema_cache[cache_key] = result
        
        return result

    def _get_database_schema(self, database: str) -> dict[str, Any]:
        """Get database-level schema."""
        try:
            conn = _get_sqlite_connection()
            cursor = conn.cursor()
            
            # Get all tables
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name NOT LIKE 'sqlite_%'
                ORDER BY name
            """)
            tables = [row[0] for row in cursor.fetchall()]
            
            conn.close()
            
            return {
                "database": database,
                "tables": tables,
                "total_tables": len(tables),
                "created_at": "2024-01-01"
            }
        except Exception as e:
            logger.error(f"Error getting database schema: {str(e)}")
            # Fallback to known tables
            return {
                "database": database,
                "tables": [
                    "customers", "orders", "products", "sales", 
                    "employees", "departments", "regions"
                ],
                "total_tables": 7,
                "created_at": "2024-01-01"
            }

    def _get_table_schema(self, database: str, tables: Optional[list[str]]) -> dict[str, Any]:
        """Get table-level schema."""
        try:
            conn = _get_sqlite_connection()
            cursor = conn.cursor()
            
            # Get list of tables to query
            if tables:
                table_list = tables
            else:
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name NOT LIKE 'sqlite_%'
                    ORDER BY name
                """)
                table_list = [row[0] for row in cursor.fetchall()]
            
            all_tables = {}
            for table_name in table_list:
                # Get row count
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                row_count = cursor.fetchone()[0]
                
                # Get column names
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns = [row[1] for row in cursor.fetchall()]
                
                all_tables[table_name] = {
                    "description": f"{table_name} table",
                    "row_count": row_count,
                    "columns": columns
                }
            
            conn.close()
            
            return {
                "database": database,
                "tables": all_tables,
                "level": "table"
            }
        except Exception as e:
            logger.error(f"Error getting table schema: {str(e)}")
            # Fallback to mock data
            all_tables = {
                "customers": {
                    "description": "Customer information including demographics",
                    "row_count": 0,
                    "columns": ["customer_id", "name", "email", "country", "created_date"]
                },
                "orders": {
                    "description": "Order transactions and details",
                    "row_count": 0,
                    "columns": ["order_id", "customer_id", "product_id", "order_date", "amount", "status"]
                },
                "products": {
                    "description": "Product catalog with pricing",
                    "row_count": 0,
                    "columns": ["product_id", "name", "category", "price", "stock_quantity"]
                },
                "sales": {
                    "description": "Sales transactions by region",
                    "row_count": 0,
                    "columns": ["sale_id", "order_id", "region", "amount", "sale_date", "salesperson_id"]
                }
            }
            
            if tables:
                filtered_tables = {k: v for k, v in all_tables.items() if k in tables}
            else:
                filtered_tables = all_tables
            
            return {
                "database": database,
                "tables": filtered_tables,
                "level": "table"
            }

    def _get_column_schema(self, database: str, tables: Optional[list[str]]) -> dict[str, Any]:
        """Get column-level schema."""
        try:
            conn = _get_sqlite_connection()
            cursor = conn.cursor()
            
            # Get list of tables to query
            if tables:
                table_list = tables
            else:
                cursor.execute("""
                    SELECT name FROM sqlite_master 
                    WHERE type='table' AND name NOT LIKE 'sqlite_%'
                    ORDER BY name
                """)
                table_list = [row[0] for row in cursor.fetchall()]
            
            all_columns = {}
            for table_name in table_list:
                # Get column information using PRAGMA
                cursor.execute(f"PRAGMA table_info({table_name})")
                columns_info = cursor.fetchall()
                
                # Get foreign keys
                cursor.execute(f"PRAGMA foreign_key_list({table_name})")
                fk_info = cursor.fetchall()
                
                columns = []
                primary_keys = []
                foreign_keys = []
                
                for col in columns_info:
                    col_name = col[1]
                    col_type = col[2]
                    not_null = col[3]
                    is_pk = col[5]
                    
                    columns.append({
                        "name": col_name,
                        "type": col_type.upper(),
                        "nullable": not bool(not_null),
                        "primary_key": bool(is_pk)
                    })
                    
                    if is_pk:
                        primary_keys.append(col_name)
                
                # Process foreign keys
                for fk in fk_info:
                    foreign_keys.append({
                        "column": fk[3],  # from column
                        "references": f"{fk[2]}.{fk[4]}"  # to table.to column
                    })
                
                all_columns[table_name] = {
                    "columns": columns,
                    "primary_key": primary_keys,
                    "foreign_keys": foreign_keys
                }
            
            conn.close()
            
            return {
                "database": database,
                "tables": all_columns,
                "level": "column"
            }
        except Exception as e:
            logger.error(f"Error getting column schema: {str(e)}")
            # Fallback to mock data structure
            all_columns = {
                "customers": {
                    "columns": [
                        {"name": "customer_id", "type": "INTEGER", "nullable": False, "primary_key": True},
                        {"name": "name", "type": "TEXT", "nullable": False},
                        {"name": "email", "type": "TEXT", "nullable": False},
                        {"name": "country", "type": "TEXT", "nullable": True},
                        {"name": "created_date", "type": "TIMESTAMP", "nullable": False}
                    ],
                    "primary_key": ["customer_id"],
                    "foreign_keys": []
                }
            }
            
            if tables:
                filtered_columns = {k: v for k, v in all_columns.items() if k in tables}
            else:
                filtered_columns = all_columns
            
            return {
                "database": database,
                "tables": filtered_columns,
                "level": "column"
            }

