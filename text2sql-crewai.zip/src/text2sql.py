"""Main module for Text-to-SQL system."""
import logging
from datetime import datetime
from crewai import Crew, Process, Task

from .config import settings
from .agents import (
    create_question_validator_agent,
    create_schema_table_master_agent,
    create_schema_database_master_agent,
    create_context_validator_agent,
    create_sql_create_master_agent,
    create_query_executor_agent,
    create_manager_agent
)
from .models import QueryRequest, QueryResponse, QueryResult, ValidationResult, SchemaInfo
from typing import Optional

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.logging.level),
    format=settings.logging.format,
    handlers=[
        logging.FileHandler(settings.logging.file),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class Text2SQLCrew:
    """Main Text-to-SQL multi-agent system."""
    
    def __init__(self, use_hierarchical: bool = True):
        """
        Initialize the Text-to-SQL crew.
        
        Args:
            use_hierarchical: Use hierarchical process with manager agent
        """
        self.use_hierarchical = use_hierarchical
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def create_crew(self, user_query: str, database: str, sql_dialect: str = "sqlite") -> Crew:
        """
        Create a crew for processing a query.
        
        Args:
            user_query: Natural language query
            database: Target database name
            sql_dialect: SQL dialect to use
            
        Returns:
            Configured Crew instance
        """
        # Create agents
        question_validator = create_question_validator_agent()
        schema_table_master = create_schema_table_master_agent()
        schema_database_master = create_schema_database_master_agent()
        context_validator = create_context_validator_agent()
        sql_create_master = create_sql_create_master_agent()
        query_executor = create_query_executor_agent()
        
        # Create tasks
        validation_task = Task(
            description=f"""
            Analyze this query: {user_query}
            
            Determine:
            1. Is this a SQL-appropriate query? (PASS/FAIL)
            2. What type of query? (SELECT, aggregation, join, etc.)
            3. What entities are mentioned?
            4. What conditions/filters are needed?
            5. Any ambiguities or missing information?
            
            Provide structured JSON output with query_type, entities, conditions, and ambiguities.
            """,
            agent=question_validator,
            expected_output="Validation decision with structured requirements in JSON format"
        )
        
        table_discovery_task = Task(
            description=f"""
            Find relevant tables for this query: {user_query}
            Database: {database}
            
            Use the table_matcher tool to identify the top 5 most relevant tables.
            Provide table names with relevance scores and reasons.
            """,
            agent=schema_table_master,
            expected_output="List of relevant tables with relevance scores in JSON format",
            context=[validation_task]
        )
        
        schema_detail_task = Task(
            description=f"""
            Retrieve detailed column-level schema for the tables identified in the previous task.
            Database: {database}
            
            Use schema_retrieval tool with level='column' to get detailed schema information
            including column names, types, constraints, and relationships.
            """,
            agent=schema_database_master,
            expected_output="Detailed schema for selected tables",
            context=[table_discovery_task]
        )
        
        feasibility_task = Task(
            description=f"""
            Validate that the query: {user_query}
            Can be answered with the available schema.
            
            Use query_validator tool to check:
            - All required columns exist
            - Data types are compatible
            - Join conditions are valid
            
            Provide validation result (PASS/FAIL) with findings and recommendations.
            """,
            agent=context_validator,
            expected_output="Validation result with findings",
            context=[schema_detail_task]  # Only pass schema, not validation task
        )
        
        # Import the task creation function
        from .agents.sql_create_master import create_sql_generation_task
        
        # Create SQL generation task
        # The agent will extract schema and requirements from the context of previous tasks
        sql_generation_task = create_sql_generation_task(
            agent=sql_create_master,
            user_query=user_query,
            query_requirements={"query": user_query, "dialect": sql_dialect},  # Basic requirements
            detailed_schema={"note": "Extract schema from schema_detail_task context"},  # Will be in context
            validation_result={"note": "Extract validation from feasibility_task context"},  # Will be in context
            sql_dialect=sql_dialect
        )
        
        # Update context to include all relevant tasks for schema information
        sql_generation_task.context = [schema_detail_task, feasibility_task]
        
        # Create crew
        agents_list = [
            question_validator,
            schema_table_master,
            schema_database_master,
            context_validator,
            sql_create_master
        ]
        
        tasks_list = [
            validation_task,
            table_discovery_task,
            schema_detail_task,
            feasibility_task,
            sql_generation_task
        ]
        
        # Add execution task only if execute is requested
        # Note: We'll execute the query directly in process_query instead
        # to have better control over result extraction
        
        if self.use_hierarchical:
            manager_agent = create_manager_agent()
            crew = Crew(
                agents=agents_list,
                tasks=tasks_list,
                process=Process.hierarchical,
                manager_agent=manager_agent,
                verbose=True
            )
        else:
            crew = Crew(
                agents=agents_list,
                tasks=tasks_list,
                process=Process.sequential,
                verbose=True
            )
        
        return crew
    
    def process_query(self, request: QueryRequest) -> QueryResponse:
        """
        Process a natural language query and return SQL.
        
        Args:
            request: QueryRequest with query details
            
        Returns:
            QueryResponse with SQL and results
        """
        start_time = datetime.now()
        
        try:
            self.logger.info(f"Processing query: {request.query}")
            
            # Validate user permissions
            if request.user_context:
                self._validate_permissions(request.user_context, request.database)
            
            # Create and execute crew
            crew = self.create_crew(
                user_query=request.query,
                database=request.database,
                sql_dialect=request.sql_dialect
            )
            
            result = crew.kickoff()
            
            # Parse result and construct response
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Extract SQL - try to get from specific task output
            sql = self._extract_sql_from_result(result)
            
            # Validate SQL was actually generated (not just extraction text)
            if not sql or len(sql) > 1000 or ("I need to" in sql.lower() and ("extract" in sql.lower() or "request" in sql.lower())):
                # Likely got agent thinking text instead of SQL, try alternative methods
                result_str = str(result)
                sql = self._extract_sql_from_text(result_str)
            
            # Validate SQL is actually valid SQL (not agent thinking text)
            if not sql or not self._is_valid_sql(sql):
                error_msg = "Failed to generate valid SQL query. "
                if sql and ("I need to" in sql.lower() or "extract" in sql.lower()):
                    error_msg += "Agent did not properly extract schema or query plan from context."
                else:
                    error_msg += "SQL generation failed or returned invalid result."
                
                self.logger.error(f"SQL validation failed. Extracted text: {sql[:200] if sql else 'None'}")
                return QueryResponse(
                    status="failed",
                    error=error_msg,
                    processing_time=processing_time,
                    timestamp=datetime.now()
                )
            
            # Execute query directly if requested and we have valid SQL
            execution_result = None
            if request.execute and sql and "SELECT" in sql.upper():
                try:
                    from .tools import SQLExecutionTool
                    executor = SQLExecutionTool()
                    exec_result_str = executor._run(sql=sql, limit=request.limit, timeout=request.timeout)
                    import json
                    exec_data = json.loads(exec_result_str)
                    
                    from .models import QueryResult
                    # Get columns from execution result or extract from data
                    columns = exec_data.get("columns", [])
                    results_data = exec_data.get("results", [])
                    
                    # If no columns but we have data, extract column names from first row
                    if not columns and results_data:
                        columns = list(results_data[0].keys())
                    
                    self.logger.info(f"Query execution completed: status={exec_data.get('status')}, rows={len(results_data)}, columns={columns}")
                    
                    # Validate execution was successful
                    exec_status = exec_data.get("status", "unknown")
                    if exec_status == "failed":
                        error_msg = exec_data.get("error", "Query execution failed")
                        self.logger.error(f"Query execution failed: {error_msg}")
                        return QueryResponse(
                            status="failed",
                            sql=sql,
                            error=f"SQL generated but execution failed: {error_msg}",
                            processing_time=processing_time,
                            timestamp=datetime.now()
                        )
                    
                    execution_result = QueryResult(
                        status=exec_status,
                        rows=exec_data.get("row_count", len(results_data)),
                        execution_time=exec_data.get("execution_time", 0.0),
                        data=results_data,
                        columns=columns,  # Include columns for UI
                        error=exec_data.get("error")
                    )
                except Exception as e:
                    self.logger.error(f"Error executing query: {str(e)}", exc_info=True)
                    return QueryResponse(
                        status="failed",
                        sql=sql,
                        error=f"SQL generated but execution error: {str(e)}",
                        processing_time=processing_time,
                        timestamp=datetime.now()
                    )
            elif request.execute:
                # SQL was requested but not generated or invalid
                return QueryResponse(
                    status="failed",
                    error="SQL generation failed - no valid SQL to execute",
                    processing_time=processing_time,
                    timestamp=datetime.now()
                )
            
            # Only return success if SQL is valid and (if execute requested) execution succeeded
            response = QueryResponse(
                status="success",
                sql=sql,
                explanation=self._extract_explanation_from_result(result),
                execution_result=execution_result,
                processing_time=processing_time,
                timestamp=datetime.now()
            )
            
            self.logger.info(f"Query processed successfully in {processing_time:.2f}s")
            return response
        
        except Exception as e:
            self.logger.error(f"Error processing query: {str(e)}", exc_info=True)
            processing_time = (datetime.now() - start_time).total_seconds()
            
            # Check for context length errors
            error_msg = str(e)
            if "context length" in error_msg.lower() or "token" in error_msg.lower():
                error_msg = "Query too complex - context length exceeded. Try simplifying your query or use sequential processing mode."
            
            return QueryResponse(
                status="failed",
                error=error_msg,
                processing_time=processing_time,
                timestamp=datetime.now()
            )
    
    def _validate_permissions(self, user_context, database: str):
        """Validate user has access to database."""
        if user_context.permissions and database not in user_context.permissions:
            raise PermissionError(
                f"User {user_context.user_id} does not have access to database {database}"
            )
    
    def _extract_sql_from_result(self, result) -> str:
        """Extract SQL query from crew result."""
        result_str = str(result)
        
        # Try to get SQL from task outputs if available
        if hasattr(result, 'tasks_output'):
            # Look for SQL generation task output
            for task_output in result.tasks_output:
                if hasattr(task_output, 'output'):
                    output = str(task_output.output)
                    # Check if this looks like SQL generation output
                    if "```sql" in output or ("SELECT" in output.upper() and "FROM" in output.upper()):
                        sql = self._extract_sql_from_text(output)
                        if sql and sql != output:  # Found actual SQL, not just the full output
                            return sql
        
        # Fallback: extract from full result string
        return self._extract_sql_from_text(result_str)
    
    def _extract_sql_from_text(self, text: str) -> str:
        """Extract SQL from text, prioritizing SQL generation task output."""
        import re
        
        # Look for SQL in markdown code blocks first (most reliable)
        if "```sql" in text:
            # Find all SQL code blocks
            matches = re.findall(r'```sql\s*(.*?)\s*```', text, re.DOTALL)
            if matches:
                # Return the first SQL block (should be from SQL generation task)
                sql = matches[0].strip()
                # Clean up any extra text after the SQL
                if "I need to" in sql or "execute" in sql.lower():
                    # This is not SQL, try next match
                    if len(matches) > 1:
                        return matches[1].strip()
                return sql
        
        # Look for complete SQL statements (SELECT ... FROM ...)
        # Try to find SQL that appears before execution-related text
        sql_pattern = r'(SELECT\s+.*?FROM\s+\w+.*?(?:WHERE.*?)?(?:GROUP\s+BY.*?)?(?:ORDER\s+BY.*?)?(?:LIMIT\s+\d+)?)'
        matches = re.findall(sql_pattern, text, re.IGNORECASE | re.DOTALL)
        if matches:
            # Return the first match that looks like actual SQL
            for match in matches:
                sql = match.strip()
                # Filter out matches that are too short or don't look like SQL
                if len(sql) > 20 and "FROM" in sql.upper() and not ("I need to" in sql or "execute" in sql.lower()):
                    # Clean up
                    sql = re.sub(r'\s+', ' ', sql)  # Normalize whitespace
                    sql = sql.replace(' ;', ';')
                    return sql
        
        # Fallback: look for SELECT statements line by line
        lines = text.split("\n")
        sql_lines = []
        in_sql = False
        found_from = False
        found_execute_text = False
        
        for i, line in enumerate(lines):
            line_upper = line.upper().strip()
            
            # Stop if we hit execution-related text
            if "I need to execute" in line or "sql_executor" in line.lower():
                found_execute_text = True
                if in_sql and found_from:
                    # We have a complete SQL, stop here
                    break
            
            # Start collecting when we see SELECT
            if "SELECT" in line_upper and not in_sql and not found_execute_text:
                in_sql = True
                sql_lines = [line]
                found_from = False
                continue
            
            if in_sql and not found_execute_text:
                sql_lines.append(line)
                
                # Check if we found FROM clause
                if "FROM" in line_upper:
                    found_from = True
                
                # Stop at certain points if we have a complete query
                if found_from and ("LIMIT" in line_upper or line.strip().endswith(";")):
                    # Might be end of SQL
                    if i + 1 < len(lines):
                        next_line = lines[i + 1].upper().strip()
                        if not next_line or next_line.startswith(("WHERE", "GROUP", "ORDER", "AND", "OR")):
                            continue  # SQL continues
                    break
        
        if sql_lines and found_from:
            sql = "\n".join(sql_lines).strip()
            # Clean up - remove any trailing non-SQL text
            if ";" in sql:
                sql = sql.split(";")[0] + ";"
            # Remove any text after SQL that's not SQL
            if "I need to" in sql:
                sql = sql.split("I need to")[0].strip()
            return sql
        
        # Last resort: return text if it contains SELECT but filter out execution text
        if "SELECT" in text.upper() and "I need to execute" not in text:
            # Try to extract just the SELECT part
            select_match = re.search(r'(SELECT\s+.*?)(?:\n\n|\nI need|$)', text, re.IGNORECASE | re.DOTALL)
            if select_match:
                return select_match.group(1).strip()
            return text.strip()
        
        return text
    
    def _is_valid_sql(self, sql: str) -> bool:
        """Validate that extracted text is actually SQL, not agent thinking text."""
        if not sql or len(sql.strip()) < 10:
            return False
        
        sql_lower = sql.lower().strip()
        
        # Must contain SQL keywords
        if "select" not in sql_lower:
            return False
        
        # Should not contain agent thinking patterns
        invalid_patterns = [
            "i need to",
            "i should",
            "let me",
            "first, i",
            "step 1:",
            "step 2:",
            "action:",
            "thinking:",
            "i'll extract",
            "i will extract",
            "i need to extract",
            "i need to request"
        ]
        
        # Check first 200 chars for invalid patterns
        first_part = sql_lower[:200]
        for pattern in invalid_patterns:
            if pattern in first_part:
                return False
        
        # Should look like SQL (has FROM, or has structure)
        if "from" in sql_lower or "join" in sql_lower or "where" in sql_lower:
            return True
        
        # If it's very short and has SELECT, might be valid
        if len(sql.strip()) < 50 and "select" in sql_lower:
            return True
        
        return False
    
    def _extract_explanation_from_result(self, result) -> str:
        """Extract explanation from crew result."""
        # This is a simplified implementation
        result_str = str(result)
        
        # Look for explanation section
        if "# EXPLANATION" in result_str:
            start = result_str.find("# EXPLANATION") + 13
            end = result_str.find("# END", start)
            if end == -1:
                end = len(result_str)
            return result_str[start:end].strip()
        
        return "Query generated successfully"


def create_text2sql_crew(use_hierarchical: bool = True) -> Text2SQLCrew:
    """
    Factory function to create Text2SQL crew.
    
    Args:
        use_hierarchical: Use hierarchical process with manager
        
    Returns:
        Text2SQLCrew instance
    """
    return Text2SQLCrew(use_hierarchical=use_hierarchical)

