"""Utility functions for Text-to-SQL system."""

