"""LLM factory for creating LLM instances based on provider configuration."""
from langchain_openai import ChatOpenAI
from ..config.settings import Settings

# Optional import for Anthropic (may not be installed)
try:
    from langchain_anthropic import ChatAnthropic
except ImportError:
    ChatAnthropic = None


def get_llm(settings: Settings, model: str = None, temperature: float = None):
    """
    Get LLM instance based on provider configuration.
    
    Args:
        settings: Settings instance with LLM configuration
        model: Optional model name override
        temperature: Optional temperature override
        
    Returns:
        LLM instance (ChatOpenAI or ChatAnthropic)
    """
    # Determine provider
    provider = "openai"  # default
    if settings.llm and settings.llm.provider:
        provider = settings.llm.provider
    
    if provider == "orchestra":
        if not settings.llm or not settings.llm.orchestra:
            raise ValueError("Orchestra provider selected but orchestra config not found")
        
        config = settings.llm.orchestra
        return ChatOpenAI(
            model=model or config.model,
            temperature=temperature if temperature is not None else config.temperature,
            api_key=config.api_key,
            base_url=config.base_url
        )
    
    elif provider == "openai":
        # Check new llm config first, fallback to old openai config for backward compatibility
        if settings.llm and settings.llm.openai:
            config = settings.llm.openai
            api_key = config.api_key
            default_model = config.model
            default_temp = config.temperature
        elif settings.openai:
            api_key = settings.openai.api_key
            default_model = "gpt-4"
            default_temp = 0.0
        else:
            raise ValueError("OpenAI provider selected but OpenAI config not found")
        
        return ChatOpenAI(
            model=model or default_model,
            temperature=temperature if temperature is not None else default_temp,
            api_key=api_key
        )
    
    elif provider == "anthropic":
        if ChatAnthropic is None:
            raise ValueError("Anthropic provider selected but langchain-anthropic package is not installed. Install it with: pip install langchain-anthropic")
        if not settings.llm or not settings.llm.anthropic:
            raise ValueError("Anthropic provider selected but Anthropic config not found")
        
        config = settings.llm.anthropic
        return ChatAnthropic(
            model=model or config.model,
            temperature=temperature if temperature is not None else config.temperature,
            api_key=config.api_key
        )
    
    else:
        raise ValueError(f"Unknown LLM provider: {provider}")

