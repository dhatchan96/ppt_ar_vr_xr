"""LLM factory for creating LLM instances using Orchestra API gateway."""
from langchain_openai import ChatOpenAI
from ..config.settings import Settings


def get_llm(settings: Settings, model: str = None, temperature: float = None):
    """
    Get LLM instance using Orchestra API gateway.
    
    Args:
        settings: Settings instance with Orchestra configuration
        model: Optional model name override
        temperature: Optional temperature override
        
    Returns:
        ChatOpenAI instance configured for Orchestra gateway
    """
    if not settings.llm or not settings.llm.orchestra:
        raise ValueError("Orchestra config not found. Please configure llm.orchestra in config.yaml")
    
    config = settings.llm.orchestra
    
    if not config.api_key:
        raise ValueError("Orchestra API key not set. Please set api_key in config.yaml or ORCHESTRA_API_KEY environment variable")
    
    return ChatOpenAI(
        model=model or config.model,
        temperature=temperature if temperature is not None else config.temperature,
        api_key=config.api_key,
        base_url=config.base_url
    )

