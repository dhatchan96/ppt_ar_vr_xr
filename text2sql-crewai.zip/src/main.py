"""FastAPI application for Text-to-SQL API."""
import logging
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from .models import QueryRequest, QueryResponse
from .text2sql import create_text2sql_crew
from .config import settings

# Configure logging
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events."""
    # Startup
    logger.info("Starting Text-to-SQL API")
    logger.info(f"Using OpenAI API Key: {'*' * 10}{settings.openai.api_key[-4:] if settings.openai.api_key else 'NOT SET'}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Text-to-SQL API")


# Create FastAPI app
app = FastAPI(
    title="Text-to-SQL API",
    description="Multi-agent system for converting natural language to SQL using CrewAI",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files directory
# Get the project root directory (parent of src)
project_root = Path(__file__).parent.parent
static_dir = project_root / "static"

if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
    logger.info(f"Static files mounted from: {static_dir}")

# Create Text2SQL crew instance
# Using sequential process to avoid context length issues with hierarchical
text2sql_crew = create_text2sql_crew(use_hierarchical=False)


@app.get("/")
async def root():
    """Root endpoint - serves the HTML interface."""
    # Try to serve index.html from static directory
    project_root = Path(__file__).parent.parent
    index_file = project_root / "static" / "index.html"
    
    if index_file.exists():
        return FileResponse(
            path=str(index_file),
            media_type="text/html"
        )
    
    # Fallback to JSON response if index.html doesn't exist
    return {
        "message": "Text-to-SQL API",
        "version": "1.0.0",
        "docs": "/docs",
        "ui": "/static/index.html"
    }


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "text2sql-api"
    }


@app.post("/api/v1/generate-sql", response_model=QueryResponse)
async def generate_sql(request: QueryRequest):
    """
    Generate SQL from natural language query.
    
    Args:
        request: QueryRequest with query details
        
    Returns:
        QueryResponse with generated SQL and metadata
    """
    try:
        logger.info(f"Received query request: {request.query}")
        
        # Validate API key is set
        if not settings.openai.api_key:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="OpenAI API key not configured"
            )
        
        # Process query
        response = text2sql_crew.process_query(request)
        
        return response
    
    except PermissionError as e:
        logger.warning(f"Permission error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )
    
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing query: {str(e)}"
        )


@app.post("/api/v1/validate-query")
async def validate_query(request: QueryRequest):
    """
    Validate if a natural language query can be converted to SQL.
    
    Args:
        request: QueryRequest with query to validate
        
    Returns:
        Validation result
    """
    try:
        logger.info(f"Validating query: {request.query}")
        
        # Create a simplified crew for validation only
        from .agents import create_question_validator_agent
        from crewai import Task
        
        validator = create_question_validator_agent()
        task = Task(
            description=f"Validate if this query can be converted to SQL: {request.query}",
            agent=validator,
            expected_output="Validation result"
        )
        
        # This would need to be properly implemented
        return {
            "valid": True,
            "message": "Query validation endpoint - full implementation pending"
        }
    
    except Exception as e:
        logger.error(f"Error validating query: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error validating query: {str(e)}"
        )


@app.get("/api/v1/databases")
async def list_databases():
    """
    List available databases.
    
    Returns:
        List of database names
    """
    # This is a mock implementation
    # In production, this would query metadata service
    return {
        "databases": [
            "sales_db",
            "user_db",
            "analytics_db",
            "inventory_db"
        ]
    }


@app.get("/api/v1/schema/{database}")
async def get_schema(database: str):
    """
    Get schema information for a database.
    
    Args:
        database: Database name
        
    Returns:
        Schema information
    """
    try:
        from .tools import SchemaRetrievalTool
        
        tool = SchemaRetrievalTool()
        result = tool._run(database=database, level="table")
        
        import json
        return JSONResponse(content=json.loads(result))
    
    except Exception as e:
        logger.error(f"Error retrieving schema: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving schema: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

